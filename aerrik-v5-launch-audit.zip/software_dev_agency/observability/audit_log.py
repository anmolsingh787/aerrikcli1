"""
📝 aerrik.dev — Immutable Append-Only Audit Log

Security properties:
- Append-only (entries cannot be modified or deleted)
- Hash-chained (each entry includes hash of previous entry)
- Tamper detection (broken chain = tampered log)
- Secret redaction (API keys, tokens, passwords never stored)
"""
import os
import json
import hashlib
import time
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class AuditEntry:
    """A single immutable audit entry"""
    seq: int                          # Sequence number (monotonic)
    timestamp: str
    action: str
    actor: str
    resource: str
    risk_level: str                   # low, medium, high, critical
    details: Dict[str, Any]
    prev_hash: str                    # Hash of previous entry
    entry_hash: str = ""              # Hash of this entry (computed)

    def compute_hash(self) -> str:
        """Compute SHA-256 hash of this entry"""
        data = json.dumps({
            "seq": self.seq,
            "timestamp": self.timestamp,
            "action": self.action,
            "actor": self.actor,
            "resource": self.resource,
            "risk_level": self.risk_level,
            "details": self.details,
            "prev_hash": self.prev_hash,
        }, sort_keys=True)
        return hashlib.sha256(data.encode()).hexdigest()


class ImmutableAuditLog:
    """
    📝 Immutable append-only audit log with hash chaining.

    Properties:
    - Entries are append-only (no update/delete)
    - Each entry includes SHA-256 hash of previous entry
    - Chain integrity can be verified at any time
    - Secrets are redacted before storage
    - Log file is written as JSONL (one JSON object per line)
    """

    GENESIS_HASH = "0" * 64  # Hash for the first entry's prev_hash

    # Patterns to redact
    REDACT_PATTERNS = [
        (r'sk-[a-zA-Z0-9]{20,}', 'sk-••••REDACTED'),
        (r'sk-ant-[a-zA-Z0-9]{20,}', 'sk-ant-••••REDACTED'),
        (r'gsk_[a-zA-Z0-9]{20,}', 'gsk_••••REDACTED'),
        (r'AIza[a-zA-Z0-9_-]{30,}', 'AIza••••REDACTED'),
        (r'sk-or-[a-zA-Z0-9]{20,}', 'sk-or-••••REDACTED'),
        (r'pplx-[a-zA-Z0-9]{20,}', 'pplx-••••REDACTED'),
        (r'Bearer\s+[a-zA-Z0-9._-]+', 'Bearer ••••REDACTED'),
        (r'(?i)(password|secret|token|api_key)\s*[:=]\s*["\'][^"\']+["\']', r'\1=••••REDACTED'),
    ]

    def __init__(self, log_dir: str = ".aerrik/audit"):
        self.log_dir = log_dir
        os.makedirs(log_dir, exist_ok=True)
        self._log_file = os.path.join(log_dir, "audit.jsonl")
        self._chain_file = os.path.join(log_dir, "chain.state")
        self._seq = 0
        self._last_hash = self.GENESIS_HASH
        self._in_memory: List[AuditEntry] = []

        # Load existing state
        self._load_state()

    def _load_state(self):
        """Load last sequence number and hash from chain state"""
        if os.path.exists(self._chain_file):
            try:
                with open(self._chain_file) as f:
                    state = json.load(f)
                self._seq = state.get("seq", 0)
                self._last_hash = state.get("last_hash", self.GENESIS_HASH)
            except Exception:
                pass

        # Also count entries in log file
        if os.path.exists(self._log_file):
            try:
                with open(self._log_file) as f:
                    count = sum(1 for _ in f)
                self._seq = max(self._seq, count)
            except Exception:
                pass

    def _save_state(self):
        """Save chain state"""
        with open(self._chain_file, 'w') as f:
            json.dump({"seq": self._seq, "last_hash": self._last_hash}, f)

    def _redact(self, text: str) -> str:
        """Redact secrets from text"""
        import re
        result = text
        for pattern, replacement in self.REDACT_PATTERNS:
            result = re.sub(pattern, replacement, result)
        return result

    def _redact_dict(self, d: Dict) -> Dict:
        """Redact secrets from a dictionary"""
        result = {}
        for key, value in d.items():
            if isinstance(value, str):
                # Redact keys that suggest secrets
                if any(kw in key.lower() for kw in ['key', 'secret', 'token', 'password', 'auth']):
                    result[key] = '••••REDACTED'
                else:
                    result[key] = self._redact(value)
            elif isinstance(value, dict):
                result[key] = self._redact_dict(value)
            else:
                result[key] = value
        return result

    def log(
        self,
        action: str,
        actor: str = "",
        resource: str = "",
        details: Dict = None,
        risk_level: str = "low",
    ) -> AuditEntry:
        """
        Append an immutable entry to the audit log.

        Returns the AuditEntry with computed hash.
        """
        self._seq += 1

        # Redact secrets from details
        safe_details = self._redact_dict(details or {})

        entry = AuditEntry(
            seq=self._seq,
            timestamp=datetime.now().isoformat(),
            action=action,
            actor=actor,
            resource=resource,
            risk_level=risk_level,
            details=safe_details,
            prev_hash=self._last_hash,
        )

        # Compute hash
        entry.entry_hash = entry.compute_hash()

        # Append to log file (JSONL format)
        with open(self._log_file, 'a') as f:
            f.write(json.dumps({
                "seq": entry.seq,
                "timestamp": entry.timestamp,
                "action": entry.action,
                "actor": entry.actor,
                "resource": entry.resource,
                "risk_level": entry.risk_level,
                "details": entry.details,
                "prev_hash": entry.prev_hash,
                "hash": entry.entry_hash,
            }) + "\n")

        # Update chain state
        self._last_hash = entry.entry_hash
        self._save_state()

        # Keep in memory
        self._in_memory.append(entry)

        return entry

    def verify_chain(self) -> Dict:
        """
        Verify the integrity of the entire audit log chain.

        Returns:
            {"valid": bool, "entries_checked": int, "broken_at": int or None}
        """
        if not os.path.exists(self._log_file):
            return {"valid": True, "entries_checked": 0, "broken_at": None}

        prev_hash = self.GENESIS_HASH
        entries_checked = 0

        with open(self._log_file) as f:
            for line_num, line in enumerate(f, 1):
                try:
                    data = json.loads(line.strip())
                except json.JSONDecodeError:
                    return {"valid": False, "entries_checked": entries_checked, "broken_at": line_num}

                # Verify prev_hash matches
                if data.get("prev_hash") != prev_hash:
                    return {"valid": False, "entries_checked": entries_checked, "broken_at": line_num}

                # Recompute hash and verify
                entry_data = {k: v for k, v in data.items() if k != "hash"}
                computed = hashlib.sha256(
                    json.dumps(entry_data, sort_keys=True).encode()
                ).hexdigest()

                if computed != data.get("hash"):
                    return {"valid": False, "entries_checked": entries_checked, "broken_at": line_num}

                prev_hash = data["hash"]
                entries_checked += 1

        return {"valid": True, "entries_checked": entries_checked, "broken_at": None}

    def get_entries(
        self, action: str = None, risk_level: str = None, last_n: int = 50
    ) -> List[Dict]:
        """Get audit entries (read from file, not memory)"""
        if not os.path.exists(self._log_file):
            return []

        entries = []
        with open(self._log_file) as f:
            for line in f:
                try:
                    data = json.loads(line.strip())
                    if action and data.get("action") != action:
                        continue
                    if risk_level and data.get("risk_level") != risk_level:
                        continue
                    entries.append(data)
                except json.JSONDecodeError:
                    continue

        return entries[-last_n:]

    def get_stats(self) -> Dict:
        """Get audit log statistics"""
        entries = self.get_entries(last_n=10000)
        by_action = {}
        by_risk = {}
        for e in entries:
            a = e.get("action", "unknown")
            r = e.get("risk_level", "unknown")
            by_action[a] = by_action.get(a, 0) + 1
            by_risk[r] = by_risk.get(r, 0) + 1

        return {
            "total_entries": len(entries),
            "by_action": by_action,
            "by_risk": by_risk,
            "chain_valid": self.verify_chain()["valid"],
        }
