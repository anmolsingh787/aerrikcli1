"""
🔐 aerrik.dev — Permission Engine

Classifies tool calls as SAFE / MODERATE / DANGEROUS.
Prevents the agent from doing things it shouldn't.

SAFE       → Auto-approve (read, glob, grep)
MODERATE   → Log + proceed (write, edit, npm install)
DANGEROUS  → Block or require explicit approval

Dangerous patterns:
  rm -rf, git push --force, DROP TABLE, sudo, chmod 777,
  writing to system dirs, accessing .env files, etc.
"""
import re
from typing import Dict, Optional
from dataclasses import dataclass
from enum import Enum


class PermissionLevel(Enum):
    ALLOW = "allow"
    ASK = "ask"
    BLOCK = "block"


@dataclass
class PermissionResult:
    blocked: bool = False
    needs_approval: bool = False
    level: PermissionLevel = PermissionLevel.ALLOW
    reason: str = ""


# ─── Dangerous patterns ─────────────────────────────────
DANGEROUS_COMMANDS = [
    r'\brm\s+(-[a-zA-Z]*f[a-zA-Z]*\s+)?/',        # rm -rf /
    r'\brm\s+(-[a-zA-Z]*r[a-zA-Z]*\s+)?\*',        # rm -r *
    r'\bsudo\b',                                      # sudo anything
    r'\bchmod\s+777\b',                               # chmod 777
    r'\bmkfs\b',                                      # format disk
    r'\bdd\s+if=',                                    # dd (disk write)
    r':\(\)\s*\{',                                    # fork bomb (no \b before :)
    r'\bshutdown\b',                                  # shutdown
    r'\breboot\b',                                    # reboot
    r'\bformat\s+[a-zA-Z]:',                         # format drive
    r'\.\.',                                          # path traversal (..)
    r'git\s+push\s+(-[a-zA-Z]*f[a-zA-Z]*|--force)',  # force push via shell
    r'git\s+reset\s+--hard',                          # hard reset via shell
]

DANGEROUS_GIT = [
    r'push\s+(-[a-zA-Z]*f[a-zA-Z]*|--force)',        # force push
    r'reset\s+--hard',                                # hard reset
    r'clean\s+-f',                                    # force clean
]

DANGEROUS_SQL = [
    r'\bDROP\s+(TABLE|DATABASE|SCHEMA)\b',            # DROP TABLE
    r'\bTRUNCATE\b',                                   # TRUNCATE
    r'\bDELETE\s+FROM\s+\w+\s*;',                     # DELETE without WHERE
    r'\bGRANT\s+ALL\b',                               # GRANT ALL
]

PROTECTED_PATHS = [
    r'\.env(\.\w+)?$',                                # .env files
    r'\.ssh/',                                         # SSH keys
    r'\.aws/',                                         # AWS credentials
    r'\.gnupg/',                                       # GPG keys
    r'id_rsa',                                         # SSH private key
    r'\.keystore$',                                    # Java keystore
    r'credentials',                                     # credentials files
    r'secrets?\.(json|yaml|yml|toml)$',                # secrets files
]

MODERATE_COMMANDS = [
    r'\bnpm\s+install\b',
    r'\bpip\s+install\b',
    r'\byarn\s+add\b',
    r'\bapt-get\b',
    r'\bbrew\s+install\b',
    r'\bgit\s+push\b',                                # normal push
    r'\bgit\s+commit\b',
    r'\bnpm\s+run\s+build\b',
    r'\bdocker\s+build\b',
]


class PermissionEngine:
    """
    🔐 Permission Engine

    Evaluates every tool call before execution.
    """

    def __init__(
        self,
        strict_mode: bool = False,
        auto_approve_moderate: bool = True,
        protected_dirs: list = None,
    ):
        self.strict_mode = strict_mode
        self.auto_approve_moderate = auto_approve_moderate
        self.protected_dirs = protected_dirs or []
        self.audit_log: list = []

    def check(self, tool_name: str, arguments: Dict) -> PermissionResult:
        """Check if a tool call is permitted"""
        result = PermissionResult()

        # ─── Read/Glob/Grep: always safe ──────────────
        if tool_name in ("read", "glob", "grep"):
            # But check if reading protected files
            path = arguments.get("path", "")
            if self._is_protected_path(path):
                result.blocked = True
                result.level = PermissionLevel.BLOCK
                result.reason = f"Cannot read protected file: {path}"
                self._audit(tool_name, arguments, result)
                return result
            return result

        # ─── Write/Edit: check path ────────────────────
        if tool_name in ("write", "edit"):
            path = arguments.get("path", "")
            if self._is_protected_path(path):
                result.blocked = True
                result.level = PermissionLevel.BLOCK
                result.reason = f"Cannot write to protected file: {path}"
                self._audit(tool_name, arguments, result)
                return result

            if self._is_protected_dir(path):
                result.blocked = True
                result.level = PermissionLevel.BLOCK
                result.reason = f"Cannot write to protected directory: {path}"
                self._audit(tool_name, arguments, result)
                return result

            result.needs_approval = not self.auto_approve_moderate
            result.level = PermissionLevel.ASK if result.needs_approval else PermissionLevel.ALLOW
            result.reason = "File write" if result.needs_approval else ""
            self._audit(tool_name, arguments, result)
            return result

        # ─── Shell: check command ──────────────────────
        if tool_name == "shell":
            command = arguments.get("command", "")
            return self._check_shell(command, arguments)

        # ─── Git: check subcommand ─────────────────────
        if tool_name == "git":
            command = arguments.get("command", "")
            args = arguments.get("args", "")
            full = f"{command} {args}"
            return self._check_git(full, arguments)

        # ─── Unknown tool: moderate ────────────────────
        result.needs_approval = self.strict_mode
        result.level = PermissionLevel.ASK if self.strict_mode else PermissionLevel.ALLOW
        self._audit(tool_name, arguments, result)
        return result

    def _check_shell(self, command: str, arguments: Dict) -> PermissionResult:
        """Check shell command safety"""
        result = PermissionResult()

        # Check dangerous patterns
        for pattern in DANGEROUS_COMMANDS:
            if re.search(pattern, command, re.IGNORECASE):
                result.blocked = True
                result.level = PermissionLevel.BLOCK
                result.reason = f"Dangerous command blocked: {command[:80]}"
                self._audit("shell", arguments, result)
                return result

        # Check moderate patterns
        for pattern in MODERATE_COMMANDS:
            if re.search(pattern, command, re.IGNORECASE):
                result.needs_approval = not self.auto_approve_moderate
                result.level = PermissionLevel.ASK if result.needs_approval else PermissionLevel.ALLOW
                result.reason = f"Moderate command: {command[:80]}"
                self._audit("shell", arguments, result)
                return result

        # Default: moderate
        result.level = PermissionLevel.ALLOW
        self._audit("shell", arguments, result)
        return result

    def _check_git(self, full_command: str, arguments: Dict) -> PermissionResult:
        """Check git command safety"""
        result = PermissionResult()

        for pattern in DANGEROUS_GIT:
            if re.search(pattern, full_command, re.IGNORECASE):
                result.blocked = True
                result.level = PermissionLevel.BLOCK
                result.reason = f"Dangerous git command blocked: git {full_command[:80]}"
                self._audit("git", arguments, result)
                return result

        result.level = PermissionLevel.ALLOW
        self._audit("git", arguments, result)
        return result

    def _is_protected_path(self, path: str) -> bool:
        """Check if file path is protected"""
        # Check path traversal
        if '..' in path:
            return True

        for pattern in PROTECTED_PATHS:
            if re.search(pattern, path, re.IGNORECASE):
                return True
        return False

    def _is_protected_dir(self, path: str) -> bool:
        """Check if path is in a protected directory"""
        for protected in self.protected_dirs:
            if path.startswith(protected):
                return True
        return False

    def _audit(self, tool: str, args: Dict, result: PermissionResult):
        """Log permission decision"""
        self.audit_log.append({
            "tool": tool,
            "args_summary": str(args)[:200],
            "level": result.level.value,
            "blocked": result.blocked,
            "reason": result.reason,
        })

    def get_audit_log(self) -> list:
        return self.audit_log
