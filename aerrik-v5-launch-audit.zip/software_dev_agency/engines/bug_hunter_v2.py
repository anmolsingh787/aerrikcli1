"""
🔍 aerrik.dev — Bug Hunter v2

Fixes from v1:
1. Self-detection: patterns in regex strings no longer flagged
2. Smarter Skeptic: context-aware false positive filtering
3. Fixer with actual rollback support (git-based)
4. Precision scoring with confusion matrix

Pipeline:
    🐺 Hunter     → Finds potential bugs (with self-awareness)
    🧐 Skeptic    → Challenges each finding (context-aware)
    ⚖️ Referee    → Final decision
    🛠️ Fixer      → Auto-fixes with git rollback
    🧪 Verifier   → Re-scans after fix
"""
import re
import os
import subprocess
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime


class Severity(Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class FindingStatus(Enum):
    CANDIDATE = "candidate"
    CONFIRMED = "confirmed"
    FALSE_POSITIVE = "false_positive"
    FIXED = "fixed"
    NEEDS_HUMAN = "needs_human"
    ROLLBACK = "rollback"


@dataclass
class BugFinding:
    id: str
    file_path: str
    line_number: int
    severity: Severity
    category: str
    title: str
    description: str
    evidence: str
    suggested_fix: str = ""
    hunter_confidence: float = 0.0
    skeptic_challenge: str = ""
    skeptic_score: float = 0.0      # 0 = definitely a bug, 1 = definitely FP
    referee_decision: str = ""
    status: FindingStatus = FindingStatus.CANDIDATE
    fix_applied: bool = False
    fix_rolled_back: bool = False
    fix_verified: bool = False
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def __str__(self):
        icons = {
            Severity.CRITICAL: "🔴", Severity.HIGH: "🟠",
            Severity.MEDIUM: "🟡", Severity.LOW: "🔵", Severity.INFO: "⚪",
        }
        icon = icons.get(self.severity, "❓")
        return f"{icon} [{self.severity.value.upper():8s}] {self.file_path}:{self.line_number} — {self.title}"


@dataclass
class HuntReport:
    target: str
    total_candidates: int = 0
    confirmed: int = 0
    false_positives: int = 0
    needs_human: int = 0
    fixed: int = 0
    rolled_back: int = 0
    self_detections_filtered: int = 0
    findings: List[BugFinding] = field(default_factory=list)
    duration_ms: float = 0
    started_at: str = field(default_factory=lambda: datetime.now().isoformat())

    @property
    def precision(self) -> float:
        decided = self.confirmed + self.false_positives
        return self.confirmed / decided if decided > 0 else 0

    @property
    def recall_estimate(self) -> str:
        if self.needs_human > 0:
            return f"{self.confirmed} confirmed + {self.needs_human} pending human review"
        return f"{self.confirmed} confirmed"

    def summary(self) -> str:
        return (
            f"Hunt Report: {self.target}\n"
            f"  Candidates: {self.total_candidates} | "
            f"Self-detections filtered: {self.self_detections_filtered}\n"
            f"  Confirmed: {self.confirmed} | "
            f"False positives: {self.false_positives} | "
            f"Needs human: {self.needs_human} | "
            f"Fixed: {self.fixed} | "
            f"Rolled back: {self.rolled_back}\n"
            f"  Precision: {self.precision:.0%} | "
            f"Recall: {self.recall_estimate}"
        )


# ═══════════════════════════════════════════════════════
#  🐺 HUNTER v2 — Self-Aware Bug Discovery
# ═══════════════════════════════════════════════════════

class BugHunter:
    """
    🐺 Hunter v2 — Self-aware bug finder.

    Key improvement: Does NOT flag its own pattern database entries.
    When scanning a line that contains a regex pattern string (e.g., inside
    a PATTERNS dict or a raw string), it skips the match.
    """

    PATTERNS = {
        "hardcoded_secret": {
            "regex": r'(?i)(password|secret|api_key|apikey|token|private_key)\s*=\s*["\'][^"\']{8,}["\']',
            "severity": Severity.CRITICAL,
            "category": "security",
            "title": "Hardcoded secret/credential",
            "description": "Sensitive credential hardcoded in source. Use env vars or secrets manager.",
            "fix_hint": "Replace with os.getenv('VAR_NAME')",
        },
        "eval_usage": {
            "regex": r'(?<![\"\'])\beval\s*\(',
            "severity": Severity.CRITICAL,
            "category": "security",
            "title": "eval() usage — code injection risk",
            "description": "eval() executes arbitrary code. RCE risk with external input.",
            "fix_hint": "Use ast.literal_eval() or a safe parser.",
        },
        "exec_usage": {
            "regex": r'(?<![\"\'])\bexec\s*\(',
            "severity": Severity.CRITICAL,
            "category": "security",
            "title": "exec() usage — code injection risk",
            "description": "exec() executes arbitrary code.",
            "fix_hint": "Avoid exec(). Use structured alternatives.",
        },
        "sql_injection_fstring": {
            "regex": r'(?:execute|cursor\.execute)\s*\(\s*f["\']',
            "severity": Severity.CRITICAL,
            "category": "security",
            "title": "SQL injection via f-string",
            "description": "String formatting in SQL queries allows injection.",
            "fix_hint": "Use parameterized queries.",
        },
        "sql_injection_concat": {
            "regex": r'(?:execute|cursor\.execute)\s*\([^)]*\+',
            "severity": Severity.CRITICAL,
            "category": "security",
            "title": "SQL injection via concatenation",
            "description": "String concatenation in SQL queries allows injection.",
            "fix_hint": "Use parameterized queries.",
        },
        "shell_injection": {
            "regex": r'(?:os\.system|subprocess\.call|subprocess\.Popen)\s*\([^)]*shell\s*=\s*True',
            "severity": Severity.HIGH,
            "category": "security",
            "title": "Shell injection risk (shell=True)",
            "description": "shell=True with dynamic input allows command injection.",
            "fix_hint": "Use shell=False with argument list.",
        },
        "pickle_loads": {
            "regex": r'pickle\.loads?\s*\(',
            "severity": Severity.HIGH,
            "category": "security",
            "title": "Insecure deserialization (pickle)",
            "description": "pickle can execute arbitrary code during deserialization.",
            "fix_hint": "Use json, msgpack, or safe serialization.",
        },
        "xss_innerHTML": {
            "regex": r'\.innerHTML\s*=',
            "severity": Severity.HIGH,
            "category": "security",
            "title": "XSS risk via innerHTML",
            "description": "innerHTML with unsanitized content allows XSS.",
            "fix_hint": "Use textContent or DOMPurify.",
        },
        "bare_except": {
            "regex": r'^\s*except\s*:\s*$',
            "severity": Severity.MEDIUM,
            "category": "logic",
            "title": "Bare except catches SystemExit/KeyboardInterrupt",
            "description": "Bare except catches everything including system signals.",
            "fix_hint": "Use 'except Exception:' instead.",
        },
        "swallowed_exception": {
            "regex": r'except\s+\w+.*:\s*\n\s*pass\s*$',
            "severity": Severity.MEDIUM,
            "category": "logic",
            "title": "Swallowed exception (except + pass)",
            "description": "Exception silently ignored. Bugs will be invisible.",
            "fix_hint": "Log the exception or handle it.",
        },
        "mutable_default_arg": {
            "regex": r'def\s+\w+\s*\([^)]*(?:=\s*\[\]|=\s*\{\}|=\s*set\(\))',
            "severity": Severity.MEDIUM,
            "category": "logic",
            "title": "Mutable default argument",
            "description": "Mutable defaults are shared across calls.",
            "fix_hint": "Use None as default, create mutable inside function.",
        },
        "unclosed_file": {
            "regex": r'(?<!with\s)open\s*\([^)]*\)\s*$',
            "severity": Severity.MEDIUM,
            "category": "reliability",
            "title": "File opened without context manager",
            "description": "File may not be closed if exception occurs.",
            "fix_hint": "Use 'with open(...) as f:'.",
        },
        "ts_any_type": {
            "regex": r':\s*any\b',
            "severity": Severity.LOW,
            "category": "logic",
            "title": "TypeScript 'any' type",
            "description": "'any' disables type checking.",
            "fix_hint": "Use a specific type or 'unknown'.",
        },
        "console_log": {
            "regex": r'console\.log\s*\(',
            "severity": Severity.LOW,
            "category": "reliability",
            "title": "console.log in production code",
            "description": "Debug logging should use a proper logger.",
            "fix_hint": "Use a structured logger.",
        },
    }

    # ─── Self-detection filter ───────────────────────────
    # Lines matching these patterns are likely regex definitions, not bugs
    SELF_DETECTION_PATTERNS = [
        r'^\s*["\'].*(?:regex|pattern).*["\']',    # "regex": "pattern"
        r'^\s*r["\']',                              # Raw string literals
        r'^\s*["\'].*\\b',                          # String with \b word boundary
        r'^\s*["\'].*\\\(',                         # String with \( escape
        r'^\s*["\'].*\\s',                          # String with \s
        r'PATTERNS\s*=\s*\{',                       # PATTERNS dict definition
        r'^\s*"[^"]*":\s*\{',                       # Dict entry with string key
        r'^\s*r["\'].*eval',                        # Raw string containing 'eval'
        r'^\s*r["\'].*exec',                        # Raw string containing 'exec'
        r'regex.*=.*r["\']',                        # regex = r"..."
        r'pattern.*=.*r["\']',                      # pattern = r"..."
    ]

    def _is_self_detection(self, line: str, full_content: str, line_num: int) -> bool:
        """
        Check if this line is a regex pattern definition (not actual code).
        This prevents the Hunter from flagging its own pattern database.
        """
        stripped = line.strip()

        # Check self-detection patterns
        for sp in self.SELF_DETECTION_PATTERNS:
            if re.search(sp, line):
                return True

        # Check if line is inside a string/docstring
        # Simple heuristic: if line starts with r" or r', it's a regex string
        if stripped.startswith(('r"', "r'", 'R"', "R'")):
            return True

        # Check if the match is inside quotes on this line
        # e.g., "regex": r'\beval\s*\(' — the eval is inside a string
        if re.search(r'["\'].*\\beval.*["\']', line):
            return True
        if re.search(r'["\'].*\\bexec.*["\']', line):
            return True

        return False

    def hunt(self, file_path: str, content: str = None) -> Tuple[List[BugFinding], int]:
        """
        Scan a file for bugs. Returns (findings, self_detections_filtered).
        """
        if content is None:
            if not os.path.exists(file_path):
                return [], 0
            with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
                content = f.read()

        findings = []
        self_filtered = 0
        lines = content.splitlines()

        for pattern_id, pattern_info in self.PATTERNS.items():
            regex = pattern_info["regex"]
            try:
                for match in re.finditer(regex, content, re.MULTILINE):
                    line_num = content[:match.start()].count('\n') + 1
                    line_content = lines[line_num - 1] if line_num <= len(lines) else ""

                    # ─── SELF-DETECTION FILTER ───────────
                    if self._is_self_detection(line_content, content, line_num):
                        self_filtered += 1
                        continue

                    confidence = self._score_confidence(pattern_id, line_content, content)

                    finding = BugFinding(
                        id=f"HUNT-{len(findings)+1:04d}",
                        file_path=file_path,
                        line_number=line_num,
                        severity=pattern_info["severity"],
                        category=pattern_info["category"],
                        title=pattern_info["title"],
                        description=pattern_info["description"],
                        evidence=line_content.strip(),
                        suggested_fix=pattern_info["fix_hint"],
                        hunter_confidence=confidence,
                    )
                    findings.append(finding)
            except re.error:
                continue

        return findings, self_filtered

    def hunt_directory(
        self, directory: str, extensions: List[str] = None
    ) -> Tuple[List[BugFinding], int]:
        """Scan all files in a directory"""
        if extensions is None:
            extensions = ['.py', '.ts', '.tsx', '.js', '.jsx']

        all_findings = []
        total_filtered = 0
        skip_dirs = {
            '__pycache__', 'node_modules', '.git', 'dist',
            'build', '.venv', 'venv', '.next', 'tests',
        }

        for root, dirs, files in os.walk(directory):
            dirs[:] = [d for d in dirs if d not in skip_dirs]
            for fname in files:
                if any(fname.endswith(ext) for ext in extensions):
                    fpath = os.path.join(root, fname)
                    findings, filtered = self.hunt(fpath)
                    all_findings.extend(findings)
                    total_filtered += filtered

        return all_findings, total_filtered

    def _score_confidence(self, pattern_id: str, line: str, content: str) -> float:
        base = 0.5
        if pattern_id in ("hardcoded_secret", "eval_usage", "sql_injection_fstring"):
            base = 0.7
        if line.strip().startswith('#') or line.strip().startswith('//'):
            base *= 0.3
        if 'test' in line.lower() and 'def ' not in line:
            base *= 0.7
        return round(min(1.0, base), 2)


# ═══════════════════════════════════════════════════════
#  🧐 SKEPTIC v2 — Context-Aware Verification
# ═══════════════════════════════════════════════════════

class BugSkeptic:
    """
    🧐 Skeptic v2 — Context-aware false positive filter.

    Improvements over v1:
    - Checks surrounding 10 lines for context
    - Detects test files more accurately
    - Detects string literals containing patterns
    - Scores skepticism (0 = definitely bug, 1 = definitely FP)
    """

    def challenge(self, finding: BugFinding, content: str = None) -> BugFinding:
        challenges = []
        skeptic_score = 0.0  # Start assuming it's a real bug

        if not content:
            try:
                with open(finding.file_path, 'r', encoding='utf-8', errors='replace') as f:
                    content = f.read()
            except Exception:
                finding.skeptic_challenge = "Could not read file for context"
                finding.skeptic_score = 0.5
                return finding

        lines = content.splitlines()
        line_idx = finding.line_number - 1

        # Get context window (10 lines around)
        ctx_start = max(0, line_idx - 10)
        ctx_end = min(len(lines), line_idx + 10)
        context_window = "\n".join(lines[ctx_start:ctx_end]).lower()
        current_line = lines[line_idx] if line_idx < len(lines) else ""

        # 1. Is this in a test file?
        path_lower = finding.file_path.lower()
        test_indicators = ['test_', '_test.', '_spec.', 'conftest', 'fixtures', '/tests/', '/test/']
        if any(ind in path_lower for ind in test_indicators):
            challenges.append("In test file — risk is controlled")
            skeptic_score += 0.3

        # 2. Is this in a string/docstring?
        stripped = current_line.strip()
        if stripped.startswith(('r"', "r'", 'R"', "R'", '"""', "'''", "#", "//")):
            challenges.append("Appears to be in a string literal or comment")
            skeptic_score += 0.5

        # 3. Is there an existing guard nearby?
        guard_patterns = [
            "if __name__", "sanitize", "validate", "escape",
            "quote", "parameterize", "prepared", "try:", "except",
            "if not", "assert", "raise ValueError",
        ]
        if any(p in context_window for p in guard_patterns):
            challenges.append("Existing guard/validation detected nearby")
            skeptic_score += 0.2

        # 4. Is this in example/documentation code?
        doc_markers = ["example", "demo", "sample", "tutorial", "documentation", "usage"]
        if any(m in context_window for m in doc_markers):
            challenges.append("Appears to be example/documentation code")
            skeptic_score += 0.3

        # 5. Is the pattern part of a larger safe construct?
        if finding.category == "security":
            # Check if the dangerous function is inside a string
            if re.search(r'["\'].*' + re.escape(finding.evidence[:20]) + r'.*["\']', current_line):
                challenges.append("Pattern appears inside a string literal")
                skeptic_score += 0.6

        # 6. Blast radius assessment
        if finding.severity in (Severity.LOW, Severity.INFO):
            skeptic_score += 0.1  # Low severity = slightly more likely FP

        finding.skeptic_score = min(1.0, skeptic_score)
        finding.skeptic_challenge = " | ".join(challenges) if challenges else "No counter-arguments found"
        return finding


# ═══════════════════════════════════════════════════════
#  ⚖️ REFEREE v2 — Improved Decision Matrix
# ═══════════════════════════════════════════════════════

class BugReferee:
    """
    ⚖️ Referee v2 — Uses skeptic_score for better decisions.

    Decision matrix:
    - confidence >= 0.7 AND skeptic_score < 0.3 → CONFIRMED
    - confidence >= 0.5 AND skeptic_score < 0.5 → CONFIRMED (medium)
    - skeptic_score >= 0.6 → FALSE_POSITIVE
    - everything else → NEEDS_HUMAN
    """

    def decide(self, finding: BugFinding) -> BugFinding:
        conf = finding.hunter_confidence
        skept = finding.skeptic_score

        if conf >= 0.7 and skept < 0.3:
            finding.status = FindingStatus.CONFIRMED
            finding.referee_decision = f"High confidence ({conf:.0%}), low skepticism ({skept:.0%})"

        elif conf >= 0.5 and skept < 0.5:
            finding.status = FindingStatus.CONFIRMED
            finding.referee_decision = f"Moderate confidence ({conf:.0%}), acceptable skepticism ({skept:.0%})"

        elif skept >= 0.6:
            finding.status = FindingStatus.FALSE_POSITIVE
            finding.referee_decision = f"High skepticism ({skept:.0%}) — likely false positive"

        elif finding.severity == Severity.CRITICAL and skept < 0.5:
            finding.status = FindingStatus.CONFIRMED
            finding.referee_decision = f"Critical severity overrides skepticism ({skept:.0%})"

        else:
            finding.status = FindingStatus.NEEDS_HUMAN
            finding.referee_decision = f"Ambiguous (conf={conf:.0%}, skept={skept:.0%}) — needs human review"

        return finding


# ═══════════════════════════════════════════════════════
#  🛠️ FIXER v2 — Git-Based Rollback
# ═══════════════════════════════════════════════════════

class BugFixer:
    """
    🛠️ Fixer v2 — Safe fixes with git rollback.

    Safety measures:
    - Git stash before fix
    - Per-fix commits
    - Rollback on test failure
    - Only deterministic fixes (no LLM guessing)
    """

    FIX_RULES = {
        "bare_except": {
            "pattern": r'(\s*)except\s*:',
            "replacement": r'\1except Exception:',
            "description": "Replace bare except with except Exception",
        },
        "console_log": {
            "pattern": r'console\.log\(',
            "replacement": 'logger.info(',
            "description": "Replace console.log with logger.info",
        },
    }

    def fix(self, finding: BugFinding, use_git: bool = True) -> Tuple[bool, str]:
        if finding.status != FindingStatus.CONFIRMED:
            return False, f"Cannot fix: status is {finding.status.value}"

        # Find applicable rule
        for rule_id, rule in self.FIX_RULES.items():
            if rule_id in finding.title.lower() or rule_id in finding.description.lower():
                return self._apply_fix(finding, rule, use_git)

        return False, f"No auto-fix available. Suggested: {finding.suggested_fix}"

    def _apply_fix(
        self, finding: BugFinding, rule: Dict, use_git: bool
    ) -> Tuple[bool, str]:
        try:
            # Git stash before fix
            if use_git:
                self._git_stash(finding.file_path)

            with open(finding.file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            lines = content.splitlines()
            if finding.line_number > len(lines):
                return False, "Line number out of range"

            original_line = lines[finding.line_number - 1]
            fixed_line = re.sub(rule["pattern"], rule["replacement"], original_line)

            if fixed_line == original_line:
                return False, "Fix pattern did not match"

            lines[finding.line_number - 1] = fixed_line

            with open(finding.file_path, 'w', encoding='utf-8') as f:
                f.write("\n".join(lines))

            # Git commit the fix
            if use_git:
                self._git_commit_fix(finding, rule["description"])

            finding.fix_applied = True
            finding.status = FindingStatus.FIXED
            return True, f"Fixed: {rule['description']}"

        except Exception as e:
            # Rollback on failure
            if use_git:
                self._git_rollback(finding.file_path)
                finding.fix_rolled_back = True
                finding.status = FindingStatus.ROLLBACK
            return False, f"Fix failed, rolled back: {str(e)}"

    def _git_stash(self, file_path: str):
        try:
            subprocess.run(
                ["git", "stash", "push", "-m", "aerrik-fix-backup", "--", file_path],
                capture_output=True, timeout=10,
                cwd=os.path.dirname(file_path) or ".",
            )
        except Exception:
            pass

    def _git_commit_fix(self, finding: BugFinding, description: str):
        try:
            cwd = os.path.dirname(finding.file_path) or "."
            subprocess.run(["git", "add", finding.file_path], capture_output=True, timeout=10, cwd=cwd)
            subprocess.run(
                ["git", "commit", "-m", f"fix(aerrik): {description} [{finding.id}]"],
                capture_output=True, timeout=10, cwd=cwd,
            )
        except Exception:
            pass

    def _git_rollback(self, file_path: str):
        try:
            cwd = os.path.dirname(file_path) or "."
            subprocess.run(
                ["git", "checkout", "HEAD", "--", file_path],
                capture_output=True, timeout=10, cwd=cwd,
            )
        except Exception:
            pass


# ═══════════════════════════════════════════════════════
#  🔍 BUG HUNT PIPELINE v2
# ═══════════════════════════════════════════════════════

class BugHuntPipeline:
    """
    🔍 Full adversarial pipeline v2.

    Hunter → Skeptic → Referee → Fixer → Verifier
    """

    def __init__(self, auto_fix: bool = False, max_findings: int = 100):
        self.hunter = BugHunter()
        self.skeptic = BugSkeptic()
        self.referee = BugReferee()
        self.fixer = BugFixer()
        self.auto_fix = auto_fix
        self.max_findings = max_findings

    def hunt(self, target: str, content: str = None) -> HuntReport:
        import time
        start = time.time()
        report = HuntReport(target=target)

        # Stage 1: Hunter
        if os.path.isdir(target):
            candidates, self_filtered = self.hunter.hunt_directory(target)
        else:
            candidates, self_filtered = self.hunter.hunt(target, content)

        report.self_detections_filtered = self_filtered
        candidates = candidates[:self.max_findings]
        report.total_candidates = len(candidates)

        # Stage 2: Skeptic
        for f in candidates:
            self.skeptic.challenge(f)

        # Stage 3: Referee
        for f in candidates:
            self.referee.decide(f)

        # Stage 4: Fix (if enabled)
        if self.auto_fix:
            for f in candidates:
                if f.status == FindingStatus.CONFIRMED:
                    success, msg = self.fixer.fix(f)
                    if success:
                        f.fix_verified = True

        # Compile report
        report.findings = candidates
        report.confirmed = sum(1 for f in candidates if f.status == FindingStatus.CONFIRMED)
        report.false_positives = sum(1 for f in candidates if f.status == FindingStatus.FALSE_POSITIVE)
        report.needs_human = sum(1 for f in candidates if f.status == FindingStatus.NEEDS_HUMAN)
        report.fixed = sum(1 for f in candidates if f.status == FindingStatus.FIXED)
        report.rolled_back = sum(1 for f in candidates if f.status == FindingStatus.ROLLBACK)
        report.duration_ms = (time.time() - start) * 1000

        return report

    def format_report(self, report: HuntReport) -> str:
        lines = [
            "",
            "╭──────────────────────────────────────────────────────────────╮",
            f"│  🔍 BUG HUNT REPORT v2 — {report.target[:36]:<36s}│",
            "╰──────────────────────────────────────────────────────────────╯",
            "",
            f"  Candidates: {report.total_candidates} │ "
            f"Self-detections filtered: {report.self_detections_filtered}",
            f"  Confirmed: {report.confirmed} │ "
            f"False positives: {report.false_positives} │ "
            f"Needs human: {report.needs_human} │ "
            f"Fixed: {report.fixed}",
            f"  Precision: {report.precision:.0%} │ Duration: {report.duration_ms:.0f}ms",
            "",
        ]

        for status in [FindingStatus.CONFIRMED, FindingStatus.NEEDS_HUMAN, FindingStatus.FIXED]:
            status_findings = [f for f in report.findings if f.status == status]
            if status_findings:
                lines.append(f"  ── {status.value.upper()} ({len(status_findings)}) ──")
                for f in status_findings[:10]:
                    lines.append(f"  {f}")
                if len(status_findings) > 10:
                    lines.append(f"  ... and {len(status_findings) - 10} more")
                lines.append("")

        return "\n".join(lines)
