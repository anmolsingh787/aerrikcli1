#!/usr/bin/env python3
"""
🛡️ aerrik.dev — Security Audit Suite

Tests:
1. BYOK key leak — API keys never in logs/responses
2. MCP permission bypass — MCP tools go through permission engine
3. Prompt injection — Malicious input doesn't override system prompt
4. Dangerous tool bypass — rm -rf, sudo, etc. always blocked
5. Secret exposure — Secrets redacted from all output
6. Path traversal — ../etc/passwd blocked
7. Command injection — Shell injection patterns blocked
8. User isolation — User A cannot access User B's keys
9. Token security — JWT/session tokens not leaked
10. Audit log integrity — Hash chain verification
"""
import os
import sys
import json
import tempfile
import shutil
from typing import Dict, List
from dataclasses import dataclass, field
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


@dataclass
class SecurityFinding:
    test_id: str
    name: str
    severity: str       # critical, high, medium, low, info
    status: str         # pass, fail, warning
    description: str
    details: str = ""
    recommendation: str = ""


@dataclass
class SecurityReport:
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    total_tests: int = 0
    passed: int = 0
    failed: int = 0
    warnings: int = 0
    critical: int = 0
    high: int = 0
    medium: int = 0
    low: int = 0
    findings: List[SecurityFinding] = field(default_factory=list)

    def add(self, finding: SecurityFinding):
        self.findings.append(finding)
        self.total_tests += 1
        if finding.status == "pass":
            self.passed += 1
        elif finding.status == "fail":
            self.failed += 1
            if finding.severity == "critical":
                self.critical += 1
            elif finding.severity == "high":
                self.high += 1
            elif finding.severity == "medium":
                self.medium += 1
            else:
                self.low += 1
        elif finding.status == "warning":
            self.warnings += 1


class SecurityAudit:
    """
    🛡️ Security Audit Suite
    """

    def __init__(self, verbose: bool = True):
        self.verbose = verbose

    def run(self) -> SecurityReport:
        report = SecurityReport()

        if self.verbose:
            print(f"\n{'═' * 60}")
            print(f"  🛡️  AERRIK SECURITY AUDIT")
            print(f"{'═' * 60}\n")

        self._test_byok_key_leak(report)
        self._test_mcp_permission_bypass(report)
        self._test_prompt_injection(report)
        self._test_dangerous_tool_bypass(report)
        self._test_secret_exposure(report)
        self._test_path_traversal(report)
        self._test_command_injection(report)
        self._test_user_isolation(report)
        self._test_token_security(report)
        self._test_audit_log_integrity(report)

        if self.verbose:
            self._print_report(report)

        return report

    # ─── 1. BYOK Key Leak ──────────────────────────────

    def _test_byok_key_leak(self, report: SecurityReport):
        """Test that API keys are never exposed"""
        try:
            from auth.crypto import CryptoEngine, ProviderKeyManager

            crypto = CryptoEngine()
            tmp = tempfile.mkdtemp()
            pkm = ProviderKeyManager(crypto=crypto, storage_path=tmp)

            # Connect a key
            pk = pkm.connect_key("user1", "groq", "gsk_test_secret_key_12345678")

            # Check safe dict doesn't contain full key
            safe = pk.to_safe_dict()
            safe_json = json.dumps(safe)
            if "test_secret_key_12345678" in safe_json:
                report.add(SecurityFinding(
                    test_id="BYOK-001", name="BYOK Key Leak in Safe Dict",
                    severity="critical", status="fail",
                    description="Full API key found in safe dict output",
                ))
            else:
                report.add(SecurityFinding(
                    test_id="BYOK-001", name="BYOK Key Leak in Safe Dict",
                    severity="critical", status="pass",
                    description="API key properly masked in safe dict",
                ))

            # Check masked key format
            if "•" in pk.masked_key:
                report.add(SecurityFinding(
                    test_id="BYOK-002", name="BYOK Key Masking",
                    severity="high", status="pass",
                    description="Key properly masked with • characters",
                ))
            else:
                report.add(SecurityFinding(
                    test_id="BYOK-002", name="BYOK Key Masking",
                    severity="high", status="fail",
                    description="Key masking not working",
                ))

            # Check encryption
            enc = crypto.encrypt("sk-test-secret-1234567890")
            if "sk-test-secret-1234567890" not in json.dumps(enc):
                report.add(SecurityFinding(
                    test_id="BYOK-003", name="BYOK Encryption",
                    severity="critical", status="pass",
                    description="API key encrypted, not in plaintext",
                ))
            else:
                report.add(SecurityFinding(
                    test_id="BYOK-003", name="BYOK Encryption",
                    severity="critical", status="fail",
                    description="API key found in plaintext in encrypted output",
                ))

            shutil.rmtree(tmp)

        except Exception as e:
            report.add(SecurityFinding(
                test_id="BYOK-ERR", name="BYOK Test Error",
                severity="medium", status="fail",
                description=f"BYOK test failed: {str(e)}",
            ))

    # ─── 2. MCP Permission Bypass ──────────────────────

    def _test_mcp_permission_bypass(self, report: SecurityReport):
        """Test that MCP tools go through permission engine"""
        try:
            from runtime.permission_engine import PermissionEngine
            pe = PermissionEngine()

            # Test that dangerous shell commands are blocked even via MCP
            r = pe.check("shell", {"command": "rm -rf /"})
            if r.blocked:
                report.add(SecurityFinding(
                    test_id="MCP-001", name="MCP Dangerous Command Block",
                    severity="critical", status="pass",
                    description="Dangerous commands blocked by permission engine",
                ))
            else:
                report.add(SecurityFinding(
                    test_id="MCP-001", name="MCP Dangerous Command Block",
                    severity="critical", status="fail",
                    description="Dangerous command NOT blocked — bypass possible",
                ))

            # Test that disabled MCP servers can't execute
            from adk.mcp_manager import MCPManager
            tmp = tempfile.mkdtemp()
            mcp = MCPManager(config_dir=tmp)
            mcp.add_server("browser")
            mcp.disable_server("browser")

            result = mcp.execute("browser", "navigate", {"url": "http://evil.com"})
            if "disabled" in result.get("error", "").lower() or "error" in result:
                report.add(SecurityFinding(
                    test_id="MCP-002", name="MCP Disabled Server Block",
                    severity="high", status="pass",
                    description="Disabled MCP server cannot execute tools",
                ))
            else:
                report.add(SecurityFinding(
                    test_id="MCP-002", name="MCP Disabled Server Block",
                    severity="high", status="fail",
                    description="Disabled MCP server still executing tools",
                ))

            shutil.rmtree(tmp)

        except Exception as e:
            report.add(SecurityFinding(
                test_id="MCP-ERR", name="MCP Test Error",
                severity="medium", status="fail",
                description=f"MCP test failed: {str(e)}",
            ))

    # ─── 3. Prompt Injection ───────────────────────────

    def _test_prompt_injection(self, report: SecurityReport):
        """Test that prompt injection doesn't override system behavior"""
        try:
            from engines.policy_engine import PolicyEngine, PolicyInput, Decision

            pe = PolicyEngine()

            # Try to bypass policy with crafted input
            # Even if task description says "skip all checks", policy should still enforce
            malicious_input = PolicyInput(
                risk_score=9.5,
                budget_remaining=1.0,
                estimated_cost=0.5,
                task_complexity="complex",
            )
            decision = pe.decide(malicious_input)

            if decision.require_human_approval:
                report.add(SecurityFinding(
                    test_id="INJ-001", name="Prompt Injection — Policy Bypass",
                    severity="critical", status="pass",
                    description="High-risk tasks still require human approval",
                ))
            else:
                report.add(SecurityFinding(
                    test_id="INJ-001", name="Prompt Injection — Policy Bypass",
                    severity="critical", status="fail",
                    description="Policy bypassed — high-risk task not requiring approval",
                ))

            # Test that security failures always block
            sec_input = PolicyInput(
                risk_score=5.0,
                security_tool_failed=True,
                security_findings=["SQL injection detected"],
                budget_remaining=5.0,
                estimated_cost=0.01,
            )
            decision = pe.decide(sec_input)

            if decision.decision == Decision.BLOCK_WRITE:
                report.add(SecurityFinding(
                    test_id="INJ-002", name="Security Failure Block",
                    severity="critical", status="pass",
                    description="Security tool failures always block writes",
                ))
            else:
                report.add(SecurityFinding(
                    test_id="INJ-002", name="Security Failure Block",
                    severity="critical", status="fail",
                    description="Security tool failure did NOT block write",
                ))

        except Exception as e:
            report.add(SecurityFinding(
                test_id="INJ-ERR", name="Injection Test Error",
                severity="medium", status="fail",
                description=f"Injection test failed: {str(e)}",
            ))

    # ─── 4. Dangerous Tool Bypass ──────────────────────

    def _test_dangerous_tool_bypass(self, report: SecurityReport):
        """Test that dangerous tools are always blocked"""
        try:
            from runtime.permission_engine import PermissionEngine
            pe = PermissionEngine()

            dangerous_commands = [
                ("rm -rf /", "rm -rf root"),
                ("sudo rm -rf /tmp", "sudo rm"),
                ("chmod 777 /etc/passwd", "chmod 777"),
                ("mkfs /dev/sda", "mkfs"),
                ("dd if=/dev/zero of=/dev/sda", "dd disk write"),
                (":(){:|:&};:", "fork bomb"),
                ("git push --force origin main", "force push"),
                ("git reset --hard HEAD", "hard reset"),
            ]

            all_blocked = True
            for cmd, desc in dangerous_commands:
                r = pe.check("shell", {"command": cmd})
                if not r.blocked:
                    all_blocked = False
                    report.add(SecurityFinding(
                        test_id=f"DANGER-{desc}", name=f"Dangerous Command: {desc}",
                        severity="critical", status="fail",
                        description=f"Command NOT blocked: {cmd}",
                    ))

            if all_blocked:
                report.add(SecurityFinding(
                    test_id="DANGER-ALL", name="All Dangerous Commands Blocked",
                    severity="critical", status="pass",
                    description=f"All {len(dangerous_commands)} dangerous commands blocked",
                ))

        except Exception as e:
            report.add(SecurityFinding(
                test_id="DANGER-ERR", name="Dangerous Tool Test Error",
                severity="medium", status="fail",
                description=f"Test failed: {str(e)}",
            ))

    # ─── 5. Secret Exposure ────────────────────────────

    def _test_secret_exposure(self, report: SecurityReport):
        """Test that secrets are redacted from all output"""
        try:
            from auth.crypto import SecretRedactor

            test_cases = [
                ("Error with key sk-1234567890abcdefghij", "OpenAI key"),
                ("Using gsk_abcdefghijklmnop1234 for Groq", "Groq key"),
                ("Bearer eyJhbGciOiJIUzI1NiJ9.test", "JWT token"),
                ("password = 'my_secret_password_123'", "Password"),
                ("Authorization: Bearer sk-ant-1234567890abcdef", "Anthropic key"),
            ]

            all_redacted = True
            for text, desc in test_cases:
                redacted = SecretRedactor.redact(text)
                # Check that the secret part is gone
                if "1234567890" in redacted or "abcdefghijklmnop" in redacted:
                    all_redacted = False
                    report.add(SecurityFinding(
                        test_id=f"SECRET-{desc}", name=f"Secret Redaction: {desc}",
                        severity="critical", status="fail",
                        description=f"Secret NOT redacted: {desc}",
                    ))

            if all_redacted:
                report.add(SecurityFinding(
                    test_id="SECRET-ALL", name="All Secrets Redacted",
                    severity="critical", status="pass",
                    description=f"All {len(test_cases)} secret patterns redacted",
                ))

        except Exception as e:
            report.add(SecurityFinding(
                test_id="SECRET-ERR", name="Secret Redaction Test Error",
                severity="medium", status="fail",
                description=f"Test failed: {str(e)}",
            ))

    # ─── 6. Path Traversal ─────────────────────────────

    def _test_path_traversal(self, report: SecurityReport):
        """Test that path traversal is blocked"""
        try:
            from runtime.permission_engine import PermissionEngine
            pe = PermissionEngine()

            traversal_paths = [
                "../../../etc/passwd",
                "../../../../etc/shadow",
                ".env",
                ".env.production",
                "~/.ssh/id_rsa",
                "~/.aws/credentials",
                "~/.gnupg/secring.gpg",
            ]

            all_blocked = True
            for path in traversal_paths:
                r = pe.check("read", {"path": path})
                if not r.blocked:
                    all_blocked = False

            if all_blocked:
                report.add(SecurityFinding(
                    test_id="PATH-ALL", name="Path Traversal Protection",
                    severity="critical", status="pass",
                    description=f"All {len(traversal_paths)} traversal paths blocked",
                ))
            else:
                report.add(SecurityFinding(
                    test_id="PATH-ALL", name="Path Traversal Protection",
                    severity="critical", status="fail",
                    description="Some traversal paths NOT blocked",
                ))

        except Exception as e:
            report.add(SecurityFinding(
                test_id="PATH-ERR", name="Path Traversal Test Error",
                severity="medium", status="fail",
                description=f"Test failed: {str(e)}",
            ))

    # ─── 7. Command Injection ──────────────────────────

    def _test_command_injection(self, report: SecurityReport):
        """Test that command injection patterns are blocked"""
        try:
            from runtime.tool_registry import ToolRegistry
            tr = ToolRegistry()

            # Test shell tool blocks dangerous commands
            result = tr.execute("shell", {"command": "echo safe"})
            if "safe" in result.lower() or "exit: 0" in result:
                report.add(SecurityFinding(
                    test_id="CMD-001", name="Safe Command Execution",
                    severity="low", status="pass",
                    description="Safe commands execute normally",
                ))

            result = tr.execute("shell", {"command": "rm -rf /"})
            if "blocked" in result.lower() or "⛔" in result:
                report.add(SecurityFinding(
                    test_id="CMD-002", name="Dangerous Command Blocked",
                    severity="critical", status="pass",
                    description="rm -rf / blocked by shell tool",
                ))
            else:
                report.add(SecurityFinding(
                    test_id="CMD-002", name="Dangerous Command Blocked",
                    severity="critical", status="fail",
                    description="rm -rf / NOT blocked by shell tool",
                ))

        except Exception as e:
            report.add(SecurityFinding(
                test_id="CMD-ERR", name="Command Injection Test Error",
                severity="medium", status="fail",
                description=f"Test failed: {str(e)}",
            ))

    # ─── 8. User Isolation ─────────────────────────────

    def _test_user_isolation(self, report: SecurityReport):
        """Test that users cannot access each other's keys"""
        try:
            from auth.crypto import CryptoEngine, ProviderKeyManager

            crypto = CryptoEngine()
            tmp = tempfile.mkdtemp()
            pkm = ProviderKeyManager(crypto=crypto, storage_path=tmp)

            # User A connects a key
            pkm.connect_key("user_a", "groq", "gsk_user_a_secret_key_1234")

            # User B tries to access
            user_b_keys = pkm.get_user_keys("user_b")
            if len(user_b_keys) == 0:
                report.add(SecurityFinding(
                    test_id="ISO-001", name="User Isolation — Cross-User Access",
                    severity="critical", status="pass",
                    description="User B cannot access User A's keys",
                ))
            else:
                report.add(SecurityFinding(
                    test_id="ISO-001", name="User Isolation — Cross-User Access",
                    severity="critical", status="fail",
                    description="User B CAN access User A's keys — isolation broken",
                ))

            # User A can access their own keys
            user_a_keys = pkm.get_user_keys("user_a")
            if len(user_a_keys) == 1:
                report.add(SecurityFinding(
                    test_id="ISO-002", name="User Isolation — Self Access",
                    severity="high", status="pass",
                    description="User A can access their own keys",
                ))
            else:
                report.add(SecurityFinding(
                    test_id="ISO-002", name="User Isolation — Self Access",
                    severity="high", status="fail",
                    description="User A cannot access their own keys",
                ))

            shutil.rmtree(tmp)

        except Exception as e:
            report.add(SecurityFinding(
                test_id="ISO-ERR", name="User Isolation Test Error",
                severity="medium", status="fail",
                description=f"Test failed: {str(e)}",
            ))

    # ─── 9. Token Security ─────────────────────────────

    def _test_token_security(self, report: SecurityReport):
        """Test JWT/session token security"""
        try:
            from auth.crypto import CryptoEngine, TokenManager

            tm = TokenManager(secret="test_secret_key_for_audit")

            # Create a token
            token = tm.create_access_token("user_123")

            # Verify it works
            payload = tm.verify_access_token(token)
            if payload and payload.get("sub") == "user_123":
                report.add(SecurityFinding(
                    test_id="TOKEN-001", name="Token Creation and Verification",
                    severity="high", status="pass",
                    description="Tokens created and verified correctly",
                ))
            else:
                report.add(SecurityFinding(
                    test_id="TOKEN-001", name="Token Creation and Verification",
                    severity="high", status="fail",
                    description="Token verification failed",
                ))

            # Test tampered token
            tampered = token[:-5] + "XXXXX"
            result = tm.verify_access_token(tampered)
            if result is None:
                report.add(SecurityFinding(
                    test_id="TOKEN-002", name="Tampered Token Rejected",
                    severity="critical", status="pass",
                    description="Tampered tokens are rejected",
                ))
            else:
                report.add(SecurityFinding(
                    test_id="TOKEN-002", name="Tampered Token Rejected",
                    severity="critical", status="fail",
                    description="Tampered token ACCEPTED — signature not verified",
                ))

        except Exception as e:
            report.add(SecurityFinding(
                test_id="TOKEN-ERR", name="Token Security Test Error",
                severity="medium", status="fail",
                description=f"Test failed: {str(e)}",
            ))

    # ─── 10. Audit Log Integrity ───────────────────────

    def _test_audit_log_integrity(self, report: SecurityReport):
        """Test that audit log is immutable and hash-chained"""
        try:
            from observability.audit_log import ImmutableAuditLog

            tmp = tempfile.mkdtemp()
            log = ImmutableAuditLog(log_dir=tmp)

            # Add entries
            log.log("test_action_1", actor="user1", risk_level="low")
            log.log("test_action_2", actor="user2", risk_level="high",
                    details={"key": "value"})
            log.log("test_action_3", actor="user1", risk_level="critical")

            # Verify chain
            verification = log.verify_chain()
            if verification["valid"]:
                report.add(SecurityFinding(
                    test_id="AUDIT-001", name="Audit Log Chain Integrity",
                    severity="critical", status="pass",
                    description=f"Hash chain valid for {verification['entries_checked']} entries",
                ))
            else:
                report.add(SecurityFinding(
                    test_id="AUDIT-001", name="Audit Log Chain Integrity",
                    severity="critical", status="fail",
                    description=f"Hash chain broken at entry {verification['broken_at']}",
                ))

            # Test secret redaction in audit
            log.log("api_key_added", actor="user1", risk_level="high",
                    details={"api_key": "sk-secret-1234567890", "provider": "openai"})

            entries = log.get_entries(action="api_key_added")
            if entries:
                details_json = json.dumps(entries[-1].get("details", {}))
                if "sk-secret-1234567890" not in details_json:
                    report.add(SecurityFinding(
                        test_id="AUDIT-002", name="Audit Log Secret Redaction",
                        severity="critical", status="pass",
                        description="Secrets redacted in audit log",
                    ))
                else:
                    report.add(SecurityFinding(
                        test_id="AUDIT-002", name="Audit Log Secret Redaction",
                        severity="critical", status="fail",
                        description="Secrets NOT redacted in audit log",
                    ))

            shutil.rmtree(tmp)

        except Exception as e:
            report.add(SecurityFinding(
                test_id="AUDIT-ERR", name="Audit Log Test Error",
                severity="medium", status="fail",
                description=f"Test failed: {str(e)}",
            ))

    def _print_report(self, report: SecurityReport):
        print(f"\n{'═' * 60}")
        print(f"  🛡️  SECURITY AUDIT RESULTS")
        print(f"{'═' * 60}")
        print(f"  Total Tests:  {report.total_tests}")
        print(f"  Passed:       {report.passed}")
        print(f"  Failed:       {report.failed}")
        print(f"  Warnings:     {report.warnings}")
        print(f"")
        print(f"  By Severity:")
        print(f"    Critical:   {report.critical}")
        print(f"    High:       {report.high}")
        print(f"    Medium:     {report.medium}")
        print(f"    Low:        {report.low}")
        print(f"{'═' * 60}")

        # Show failures
        failures = [f for f in report.findings if f.status == "fail"]
        if failures:
            print(f"\n  ❌ FAILURES:")
            for f in failures:
                print(f"    [{f.severity.upper():8s}] {f.test_id}: {f.name}")
                print(f"             {f.description}")

        passes = [f for f in report.findings if f.status == "pass"]
        if passes:
            print(f"\n  ✅ PASSED:")
            for f in passes:
                print(f"    [{f.severity.upper():8s}] {f.test_id}: {f.name}")


if __name__ == "__main__":
    audit = SecurityAudit(verbose=True)
    report = audit.run()

    # Save report
    os.makedirs(".aerrik/audit", exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = f".aerrik/audit/security_audit_{ts}.json"

    import json
    from dataclasses import asdict
    with open(path, 'w') as f:
        json.dump({
            "timestamp": report.timestamp,
            "total_tests": report.total_tests,
            "passed": report.passed,
            "failed": report.failed,
            "critical": report.critical,
            "high": report.high,
            "medium": report.medium,
            "low": report.low,
            "findings": [asdict(f) for f in report.findings],
        }, f, indent=2)

    print(f"\n  💾 Report saved: {path}")
