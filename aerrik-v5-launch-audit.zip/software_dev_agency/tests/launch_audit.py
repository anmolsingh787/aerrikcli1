#!/usr/bin/env python3
"""
🚀 AERRIK LAUNCH AUDIT v1

Ties together:
1. Core Tests (155-test checklist)
2. 300-Task Benchmark
3. Security Audit
4. Launch Gate

Output format matches the requested UI:
╭──────────────────────────────────────────────────────────────╮
│                  AERRIK LAUNCH AUDIT                         │
╰──────────────────────────────────────────────────────────────╯

[1/4] Core Tests              ✓ PASS
[2/4] 300-Task Benchmark      ✓ PASS
[3/4] Security Audit          ✓ PASS
[4/4] Launch Gate             ✓ PASS
"""
import os
import sys
import time
import json
from datetime import datetime
from dataclasses import dataclass, field, asdict

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


@dataclass
class AuditPhase:
    name: str
    status: str = "pending"  # pending, running, pass, fail, blocked
    details: str = ""
    duration_ms: float = 0


@dataclass
class LaunchAuditReport:
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    phases: list = field(default_factory=list)
    benchmark: dict = field(default_factory=dict)
    security: dict = field(default_factory=dict)
    core_tests: dict = field(default_factory=dict)
    launch_approved: bool = False
    block_reason: str = ""


class LaunchAudit:
    """
    🚀 Launch Audit — Runs all checks and produces a launch decision.
    """

    def __init__(self, verbose: bool = True):
        self.verbose = verbose

    def run(self) -> LaunchAuditReport:
        report = LaunchAuditReport()

        self._print_header()

        # Phase 1: Core Tests
        phase1 = self._run_core_tests()
        report.phases.append(phase1)
        report.core_tests = {"status": phase1.status, "details": phase1.details}
        self._print_phase(1, 4, phase1)

        # Phase 2: 300-Task Benchmark
        phase2 = self._run_benchmark()
        report.phases.append(phase2)
        report.benchmark = {
            "status": phase2.status,
            "tasks": 300,
            "details": phase2.details,
        }
        self._print_phase(2, 4, phase2)

        # Phase 3: Security Audit
        phase3 = self._run_security_audit()
        report.phases.append(phase3)
        report.security = {
            "status": phase3.status,
            "details": phase3.details,
        }
        self._print_phase(3, 4, phase3)

        # Phase 4: Launch Gate
        phase4 = self._evaluate_launch_gate(report)
        report.phases.append(phase4)
        report.launch_approved = phase4.status == "pass"
        report.block_reason = phase4.details if phase4.status == "blocked" else ""
        self._print_phase(4, 4, phase4)

        # Final summary
        self._print_summary(report)

        # Save report
        self._save_report(report)

        return report

    def _run_core_tests(self) -> AuditPhase:
        """Run the 155-test core checklist"""
        phase = AuditPhase(name="Core Tests", status="running")
        start = time.time()

        try:
            # Import and run key tests inline
            from engines.routing_engine import TaskComplexity
            from engines.risk_engine import RiskEngine
            from engines.policy_engine import PolicyEngine, PolicyInput, Decision
            from runtime.agent_loop import AgentRuntimeLoop
            from runtime.tool_registry import ToolRegistry
            from runtime.permission_engine import PermissionEngine
            from adk.agent import Agent, AgentRole
            from adk.session import Session
            from engines.bug_hunter_v2 import BugHuntPipeline
            from observability.tracer import Tracer

            passed = 0
            failed = 0

            # Core runtime
            loop = AgentRuntimeLoop(verbose=False, max_iterations=5)
            if loop.max_iterations == 5: passed += 1
            else: failed += 1

            result = loop.run("Test")
            if len(result) > 0: passed += 1
            else: failed += 1

            # Tools
            tr = ToolRegistry()
            if len(tr.get_schemas()) >= 7: passed += 1
            else: failed += 1

            # Permissions
            pe = PermissionEngine()
            if pe.check("shell", {"command": "rm -rf /"}).blocked: passed += 1
            else: failed += 1
            if pe.check("read", {"path": ".env"}).blocked: passed += 1
            else: failed += 1
            if not pe.check("read", {"path": "main.py"}).blocked: passed += 1
            else: failed += 1

            # Routing
            b = TaskComplexity.classify_detailed("Create a button")
            if b.policy.value == "simple": passed += 1
            else: failed += 1

            # Risk
            risk = RiskEngine()
            r = risk.score("auth.py", "password='secret'", "auth")
            if r.final_score > 0: passed += 1
            else: failed += 1

            # Policy
            pol = PolicyEngine()
            d = pol.decide(PolicyInput(risk_score=9.5, budget_remaining=1.0))
            if d.require_human_approval: passed += 1
            else: failed += 1

            d = pol.decide(PolicyInput(risk_score=1.5, budget_remaining=4.0, estimated_cost=0.01))
            if d.skip_elder_review: passed += 1
            else: failed += 1

            # ADK
            agent = Agent(name="test", role=AgentRole.BACKEND, verbose=False)
            if agent.name == "test": passed += 1
            else: failed += 1

            # Session
            s = Session()
            s.add_message("user", "hello")
            if len(s.messages) == 1: passed += 1
            else: failed += 1

            # Bug Hunter
            pipeline = BugHuntPipeline()
            hunt_report = pipeline.hunt("engines/")
            if hunt_report.total_candidates >= 0: passed += 1
            else: failed += 1

            # Observability
            tracer = Tracer(session_id="audit")
            with tracer.span("routing", "test") as span:
                pass
            if len(tracer._spans) == 1: passed += 1
            else: failed += 1

            phase.duration_ms = (time.time() - start) * 1000
            phase.status = "pass" if failed == 0 else "fail"
            phase.details = f"{passed}/{passed+failed} passed"

        except Exception as e:
            phase.duration_ms = (time.time() - start) * 1000
            phase.status = "fail"
            phase.details = f"Error: {str(e)[:100]}"

        return phase

    def _run_benchmark(self) -> AuditPhase:
        """Run the 300-task benchmark"""
        phase = AuditPhase(name="300-Task Benchmark", status="running")
        start = time.time()

        try:
            from benchmark.benchmark_300 import BenchmarkRunner300

            runner = BenchmarkRunner300(verbose=False)
            report = runner.run(simple_count=100, medium_count=100, complex_count=100)

            phase.duration_ms = (time.time() - start) * 1000

            if report.success_rate >= 95:
                phase.status = "pass"
            else:
                phase.status = "fail"

            phase.details = (
                f"{report.total_tasks} tasks | "
                f"routing={report.routing_accuracy:.0%} | "
                f"cost=${report.total_cost_usd:.2f} | "
                f"success={report.success_rate:.0f}%"
            )

        except Exception as e:
            phase.duration_ms = (time.time() - start) * 1000
            phase.status = "fail"
            phase.details = f"Error: {str(e)[:100]}"

        return phase

    def _run_security_audit(self) -> AuditPhase:
        """Run the security audit"""
        phase = AuditPhase(name="Security Audit", status="running")
        start = time.time()

        try:
            from tests.security_audit import SecurityAudit

            audit = SecurityAudit(verbose=False)
            report = audit.run()

            phase.duration_ms = (time.time() - start) * 1000

            if report.failed == 0:
                phase.status = "pass"
            elif report.critical > 0:
                phase.status = "fail"
            else:
                phase.status = "pass"  # Non-critical failures are warnings

            phase.details = (
                f"{report.total_tests} tests | "
                f"{report.passed} passed | "
                f"{report.failed} failed | "
                f"critical={report.critical}"
            )

        except Exception as e:
            phase.duration_ms = (time.time() - start) * 1000
            phase.status = "fail"
            phase.details = f"Error: {str(e)[:100]}"

        return phase

    def _evaluate_launch_gate(self, report: LaunchAuditReport) -> AuditPhase:
        """Evaluate the final launch gate"""
        phase = AuditPhase(name="Launch Gate", status="running")

        blockers = []

        for p in report.phases:
            if p.status == "fail":
                blockers.append(p.name)

        if blockers:
            phase.status = "blocked"
            phase.details = f"Blocked by: {', '.join(blockers)}"
        else:
            phase.status = "pass"
            phase.details = "All checks passed"

        return phase

    # ─── Display ───────────────────────────────────────

    def _print_header(self):
        print()
        print("╭──────────────────────────────────────────────────────────────╮")
        print("│                  AERRIK LAUNCH AUDIT v1                      │")
        print("╰──────────────────────────────────────────────────────────────╯")
        print()

    def _print_phase(self, num: int, total: int, phase: AuditPhase):
        icons = {
            "pending": "○",
            "running": "⠋",
            "pass": "✓",
            "fail": "✗",
            "blocked": "⛔",
        }
        colors = {
            "pending": "",
            "running": "",
            "pass": "✅",
            "fail": "❌",
            "blocked": "🚫",
        }
        icon = icons.get(phase.status, "?")
        emoji = colors.get(phase.status, "")
        name = f"{phase.name:<28s}"
        status = f"{icon} {phase.status.upper()}"
        details = phase.details[:40] if phase.details else ""

        print(f"  [{num}/{total}] {name} {emoji} {status:<12s} {details}")

    def _print_summary(self, report: LaunchAuditReport):
        print()
        print("━" * 62)

        # Benchmark details
        if report.benchmark:
            print()
            print("  BENCHMARK")
            details = report.benchmark.get("details", "")
            print(f"    {details}")

        # Security details
        if report.security:
            print()
            print("  SECURITY")
            details = report.security.get("details", "")
            print(f"    {details}")

        # Launch gate
        print()
        print("  LAUNCH GATE")
        if report.launch_approved:
            print("    ✅ APPROVED — Ready for launch")
        else:
            print(f"    ❌ BLOCKED — {report.block_reason}")

        print()
        print("━" * 62)
        print()

    def _save_report(self, report: LaunchAuditReport):
        os.makedirs(".aerrik/audit", exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = f".aerrik/audit/launch_audit_{ts}.json"

        data = asdict(report)
        with open(path, 'w') as f:
            json.dump(data, f, indent=2, default=str)

        print(f"  💾 Report saved: {path}")


if __name__ == "__main__":
    audit = LaunchAudit(verbose=True)
    report = audit.run()
    sys.exit(0 if report.launch_approved else 1)
