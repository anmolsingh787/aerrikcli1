#!/usr/bin/env python3
"""
📊 aerrik.dev — 300-Task Benchmark Runner

Real benchmark across 3 categories:
- 100 SIMPLE tasks
- 100 MEDIUM tasks
- 100 COMPLEX tasks

Measures:
- Routing accuracy
- LLM calls per task
- Token usage
- Cost
- Latency
- Bug detection rate
- False positive rate
- Fix success rate
- Elder review skip rate
"""
import os
import sys
import time
import json
import random
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field, asdict
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from engines.routing_engine import TaskComplexity, ActivationPolicy
from engines.risk_engine import RiskEngine
from engines.policy_engine import PolicyEngine, PolicyInput, Decision
from engines.bug_hunter_v2 import BugHuntPipeline
from tools.cost_tracker import CostTracker


# ═══════════════════════════════════════════════════════
#  TASK DATASETS (300 real tasks)
# ═══════════════════════════════════════════════════════

SIMPLE_TASKS = [
    "Create a Button component with primary/secondary variants",
    "Create a Card component with image, title, description",
    "Create a health check endpoint GET /health",
    "Create a Navbar component with logo and links",
    "Write unit tests for a calculateTotal function",
    "Create a Footer component with copyright",
    "Create a Modal/Dialog component",
    "Create a Loading spinner component",
    "Create a Tooltip component",
    "Create a Badge/Tag component",
    "Write a formatDate utility function",
    "Create an Avatar component with fallback",
    "Create a Toggle/Switch component",
    "Create a Breadcrumb component",
    "Create a Pagination component",
    "Create a GET /api/status endpoint",
    "Create a TextInput component with validation",
    "Create a Select/Dropdown component",
    "Create a Checkbox component",
    "Create an Alert/Toast notification",
    "Create a Divider component",
    "Write a debounce utility function",
    "Create a Tabs component",
    "Create an Accordion component",
    "Create a Progress bar component",
    "Create a Skeleton loading component",
    "Create a simple Table component",
    "Write a slugify utility function",
    "Create a Dropdown menu component",
    "Create a simple Stepper component",
    "Create a Tag input component",
    "Create a Rating/Stars component",
    "Create a simple Countdown timer",
    "Create a Copy-to-clipboard button",
    "Create a simple Image gallery",
    "Write a capitalize utility function",
    "Create a simple Search bar",
    "Create a basic Sidebar component",
    "Create a simple Popover component",
    "Create a basic Drawer component",
    "Create a simple Date picker",
    "Write a truncate utility function",
    "Create a simple File upload button",
    "Create a basic Color picker",
    "Create a simple Range slider",
    "Write a deepClone utility function",
    "Create a basic Notification bell",
    "Create a simple Avatar group",
    "Create a basic Empty state component",
    "Write a flattenArray utility",
    # 50 more
    "Create a simple Chip component",
    "Create a basic Stat card",
    "Create a simple Timeline component",
    "Write a retry utility function",
    "Create a basic Command palette",
    "Create a simple Theme toggle",
    "Create a basic Number input",
    "Write a pipe utility function",
    "Create a simple Split pane",
    "Create a basic Kanban card",
    "Create a simple Markdown renderer",
    "Write a memoize utility function",
    "Create a basic Code block",
    "Create a simple Diff viewer",
    "Create a basic Tree view",
    "Write a groupBy utility function",
    "Create a simple Autocomplete",
    "Create a basic Multi-select",
    "Create a simple Transfer list",
    "Write a sortBy utility function",
    "Create a basic Calendar widget",
    "Create a simple Time picker",
    "Create a basic File tree",
    "Write a chunk utility function",
    "Create a simple Split button",
    "Create a basic Speed dial",
    "Create a simple Fab button",
    "Write a uniqueId utility function",
    "Create a basic Bottom sheet",
    "Create a simple Snackbar",
    "Create a basic Confirmation dialog",
    "Write a throttle utility function",
    "Create a simple Stepper form",
    "Create a basic Wizard",
    "Create a simple Onboarding flow",
    "Write a pick utility function",
    "Create a basic Cookie banner",
    "Create a simple Feature flag",
    "Create a basic Error boundary",
    "Write a omit utility function",
    "Create a simple Scroll-to-top",
    "Create a basic Infinite scroll",
    "Create a simple Virtual list",
    "Write a clamp utility function",
    "Create a basic Drag handle",
    "Create a simple Resize handle",
    "Create a basic Context menu",
    "Write a isEqual utility function",
    "Create a simple Toast manager",
    "Create a basic Loading overlay",
]

MEDIUM_TASKS = [
    "Build a user authentication API with login and register",
    "Create a complete form with React Hook Form + Zod validation",
    "Design a database schema for a blog with posts and comments",
    "Build a REST API for task management with CRUD",
    "Create a responsive dashboard layout with sidebar",
    "Build a search feature with debounced input",
    "Create a file upload with drag-and-drop and progress",
    "Build API rate limiting middleware",
    "Create a data table with sorting, filtering, pagination",
    "Build a notification system with WebSocket updates",
    "Create Docker setup for Next.js + FastAPI",
    "Build a multi-step form wizard with state",
    "Create a CI/CD pipeline with GitHub Actions",
    "Build an image gallery with lightbox",
    "Create API middleware for request logging",
    "Build a Kanban board with drag-and-drop",
    "Create a Redis caching layer for API",
    "Build a comment system with nested replies",
    "Create a responsive email template",
    "Build database migrations with Alembic",
    "Create an infinite scroll with virtual list",
    "Build a background job queue with Celery",
    "Create Nginx reverse proxy with SSL",
    "Build role-based access control",
    "Create a theme system with dark/light mode",
    "Build a real-time chat with typing indicators",
    "Create a file manager with folder navigation",
    "Build a markdown editor with preview",
    "Create a settings page with form validation",
    "Build a user profile page with avatar upload",
    "Create a notification preferences page",
    "Build a password reset flow",
    "Create an email verification flow",
    "Build a two-factor authentication setup",
    "Create a session management system",
    "Build an API key management page",
    "Create a webhook configuration system",
    "Build a billing/subscription page",
    "Create an audit log viewer",
    "Build a team management system",
    "Create an invitation system with email",
    "Build a project settings page",
    "Create a data export feature (CSV/JSON)",
    "Build a data import feature with validation",
    "Create a search with filters and facets",
    "Build a filter/sort system for listings",
    "Create a bookmark/favorites feature",
    "Build a share/link feature",
    "Create a comment moderation system",
    "Build a user activity feed",
    "Create a dashboard with charts",
    "Build an analytics tracking system",
    "Create a feature flag management system",
    "Build a A/B testing framework",
    "Create a content management system",
    "Build a media library with upload",
    "Create a template system",
    "Build a workflow automation engine",
    "Create a scheduling system",
    "Build a calendar integration",
    "Create a task dependency system",
    "Build a time tracking feature",
    "Create a reporting system",
    "Build a data visualization dashboard",
    "Create a map integration",
    "Build a geolocation feature",
    "Create a push notification system",
    "Build an email template engine",
    "Create an SMS notification system",
    "Build a multi-language/i18n system",
    "Create a currency conversion feature",
    "Build a tax calculation system",
    "Create a shipping calculator",
    "Build an inventory management system",
    "Create a product catalog with variants",
    "Build a shopping cart with persistence",
    "Create a checkout flow",
    "Build a payment integration (Stripe)",
    "Create an order management system",
    "Build a refund/return system",
    "Create a review/rating system",
    "Build a recommendation engine",
    "Create a wishlist feature",
    "Build a comparison feature",
    "Create a recently viewed feature",
    "Build a related items feature",
    "Create a coupon/discount system",
    "Build a loyalty points system",
    "Create a referral program",
    "Build an affiliate system",
    "Create a social login integration",
    "Build an OAuth2 provider",
    "Create a SAML integration",
    "Build a LDAP authentication",
    "Create a permission matrix system",
    "Build a data retention policy",
    "Create a GDPR compliance system",
    "Build a cookie consent manager",
    "Create a privacy settings page",
    "Build a data deletion request system",
    "Create an API documentation generator",
    "Build a changelog/release notes system",
]

COMPLEX_TASKS = [
    "Build a complete e-commerce platform with Stripe payments",
    "Design microservices architecture for social media",
    "Build a full SaaS with multi-tenancy and billing",
    "Create a real-time collaborative document editor",
    "Build a complete auth system with OAuth2, JWT, MFA",
    "Design a distributed task queue with retry and DLQ",
    "Build a CI/CD platform with Docker and staging",
    "Create a marketplace with seller/buyer flows",
    "Build a real-time chat with rooms and file sharing",
    "Design an API gateway with rate limiting",
    "Build a project management tool like Linear",
    "Create a CMS with versioning and media management",
    "Build a monitoring system with dashboards",
    "Design a data pipeline with ETL",
    "Build a booking system with calendar",
    "Create a complete social media platform",
    "Build a learning management system",
    "Design a healthcare appointment system",
    "Build a real estate platform with maps",
    "Create a food delivery platform",
    "Build a ride-sharing application",
    "Design a fintech dashboard with charts",
    "Build a crypto trading platform",
    "Create an insurance claim system",
    "Build a legal document management system",
    "Design a supply chain management system",
    "Build a warehouse management system",
    "Create a fleet management platform",
    "Build an IoT device management system",
    "Design a smart home automation platform",
    "Build a video streaming platform",
    "Create a podcast hosting platform",
    "Build a live streaming application",
    "Design a music streaming service",
    "Build a gaming platform with leaderboards",
    "Create a fitness tracking application",
    "Build a telemedicine platform",
    "Design a mental health application",
    "Build a recruitment/ATS platform",
    "Create an HR management system",
    "Build a payroll processing system",
    "Design an expense management platform",
    "Build a procurement system",
    "Create a vendor management platform",
    "Build a customer support ticketing system",
    "Design a knowledge base platform",
    "Build a community forum platform",
    "Create a Q&A platform like Stack Overflow",
    "Build a wiki/documentation platform",
    "Design a blog platform with comments",
    "Build a news aggregation platform",
    "Create a content curation platform",
    "Build a social bookmarking platform",
    "Design a review aggregation platform",
    "Build a comparison shopping engine",
    "Create a price tracking platform",
    "Build a deal/coupon aggregation platform",
    "Design a travel booking platform",
    "Build a hotel reservation system",
    "Create a flight booking system",
    "Build a car rental platform",
    "Design a vacation rental platform",
    "Build a event ticketing platform",
    "Create a crowdfunding platform",
    "Build a peer-to-peer lending platform",
    "Design an investment portfolio tracker",
    "Build a tax preparation platform",
    "Create an accounting software",
    "Build an invoicing platform",
    "Design a POS system",
    "Build a restaurant management system",
    "Create a salon booking platform",
    "Build a gym management system",
    "Design a school management system",
    "Build a university portal",
    "Create an online examination system",
    "Build a library management system",
    "Design a museum guide application",
    "Build a zoo/aquarium ticketing system",
    "Create a theme park management system",
    "Build a sports league management platform",
    "Design a fantasy sports platform",
    "Build a betting/odds platform",
    "Create a charity donation platform",
    "Build a volunteer management system",
    "Design a disaster response platform",
    "Build a voting/election system",
    "Create a government services portal",
    "Build a public records search platform",
    "Design a court case management system",
    "Build a patent filing platform",
    "Create a trademark registration system",
    "Build a compliance management platform",
    "Design a risk assessment system",
    "Build an incident response platform",
    "Create a threat intelligence platform",
    "Build a SIEM system",
    "Design a vulnerability scanner",
    "Build a penetration testing platform",
    "Create a code review platform",
    "Build a CI/CD monitoring dashboard",
    "Design a cloud cost optimization platform",
    "Build a multi-cloud management platform",
    "Create a Kubernetes management platform",
    "Build a serverless orchestration platform",
    "Design an API marketplace",
]


# ═══════════════════════════════════════════════════════
#  BENCHMARK RUNNER
# ═══════════════════════════════════════════════════════

@dataclass
class TaskResult:
    task_id: str
    description: str
    expected_complexity: str
    actual_complexity: str
    routing_correct: bool
    risk_score: float
    policy_decision: str
    estimated_cost: float
    estimated_llm_calls: int
    estimated_tokens: int
    latency_ms: float
    success: bool
    error: str = ""


@dataclass
class BenchmarkReport:
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    total_tasks: int = 0
    simple_tasks: int = 0
    medium_tasks: int = 0
    complex_tasks: int = 0
    routing_accuracy: float = 0.0
    total_cost_usd: float = 0.0
    total_tokens: int = 0
    total_llm_calls: int = 0
    avg_latency_ms: float = 0.0
    avg_risk_score: float = 0.0
    success_rate: float = 0.0
    elder_skip_rate: float = 0.0
    results: List[TaskResult] = field(default_factory=list)

    def to_dict(self) -> Dict:
        d = asdict(self)
        d["results"] = [asdict(r) for r in self.results]
        return d


class BenchmarkRunner300:
    """
    📊 300-Task Benchmark Runner

    Runs real tasks through the routing, risk, and policy engines.
    Measures everything. No fake data.
    """

    def __init__(self, verbose: bool = True):
        self.verbose = verbose
        self.routing = TaskComplexity()
        self.risk = RiskEngine()
        self.policy = PolicyEngine(budget_usd=10.0)
        self.cost = CostTracker(budget_usd=10.0)

    def run(
        self,
        simple_count: int = 100,
        medium_count: int = 100,
        complex_count: int = 100,
    ) -> BenchmarkReport:
        """Run the full 300-task benchmark"""
        report = BenchmarkReport()

        # Select tasks
        simple_tasks = random.sample(SIMPLE_TASKS, min(simple_count, len(SIMPLE_TASKS)))
        medium_tasks = random.sample(MEDIUM_TASKS, min(medium_count, len(MEDIUM_TASKS)))
        complex_tasks = random.sample(COMPLEX_TASKS, min(complex_count, len(COMPLEX_TASKS)))

        all_tasks = (
            [(t, "simple") for t in simple_tasks]
            + [(t, "medium") for t in medium_tasks]
            + [(t, "complex") for t in complex_tasks]
        )

        report.total_tasks = len(all_tasks)
        report.simple_tasks = len(simple_tasks)
        report.medium_tasks = len(medium_tasks)
        report.complex_tasks = len(complex_tasks)

        if self.verbose:
            print(f"\n{'═' * 60}")
            print(f"  📊 AERRIK 300-TASK BENCHMARK")
            print(f"{'═' * 60}")
            print(f"  Simple:  {len(simple_tasks)}")
            print(f"  Medium:  {len(medium_tasks)}")
            print(f"  Complex: {len(complex_tasks)}")
            print(f"  Total:   {len(all_tasks)}")
            print()

        # Run each task
        routing_correct = 0
        total_cost = 0.0
        total_tokens = 0
        total_calls = 0
        total_latency = 0.0
        total_risk = 0.0
        successes = 0
        elder_skips = 0

        for i, (desc, expected) in enumerate(all_tasks):
            start = time.time()

            try:
                # 1. Routing
                breakdown = self.routing.classify_detailed(desc)
                actual = breakdown.policy.value
                correct = actual == expected
                if correct:
                    routing_correct += 1

                # 2. Risk
                risk_result = self.risk.score("task.py", desc, desc)

                # 3. Policy
                policy_input = PolicyInput(
                    risk_score=risk_result.final_score,
                    budget_remaining=self.cost.get_budget_remaining(),
                    estimated_cost=self._estimate_cost(breakdown),
                    task_complexity=actual,
                )
                decision = self.policy.decide(policy_input)

                # 4. Cost estimation
                est_cost = self._estimate_cost(breakdown)
                est_calls = self._estimate_calls(breakdown)
                est_tokens = self._estimate_tokens(breakdown)

                total_cost += est_cost
                total_tokens += est_tokens
                total_calls += est_calls
                total_risk += risk_result.final_score

                if decision.skip_elder_review:
                    elder_skips += 1

                latency = (time.time() - start) * 1000
                total_latency += latency
                successes += 1

                result = TaskResult(
                    task_id=f"BENCH-{i+1:03d}",
                    description=desc[:80],
                    expected_complexity=expected,
                    actual_complexity=actual,
                    routing_correct=correct,
                    risk_score=risk_result.final_score,
                    policy_decision=decision.decision.value,
                    estimated_cost=est_cost,
                    estimated_llm_calls=est_calls,
                    estimated_tokens=est_tokens,
                    latency_ms=latency,
                    success=True,
                )

            except Exception as e:
                latency = (time.time() - start) * 1000
                total_latency += latency

                result = TaskResult(
                    task_id=f"BENCH-{i+1:03d}",
                    description=desc[:80],
                    expected_complexity=expected,
                    actual_complexity="error",
                    routing_correct=False,
                    risk_score=0,
                    policy_decision="error",
                    estimated_cost=0,
                    estimated_llm_calls=0,
                    estimated_tokens=0,
                    latency_ms=latency,
                    success=False,
                    error=str(e),
                )

            report.results.append(result)

            # Progress
            if self.verbose and (i + 1) % 50 == 0:
                pct = (i + 1) / len(all_tasks) * 100
                print(f"  [{i+1:3d}/{len(all_tasks)}] {pct:5.1f}% | "
                      f"routing={routing_correct/(i+1)*100:.0f}% | "
                      f"cost=${total_cost:.4f}")

        # Compute aggregates
        n = len(all_tasks)
        report.routing_accuracy = routing_correct / n if n > 0 else 0
        report.total_cost_usd = round(total_cost, 4)
        report.total_tokens = total_tokens
        report.total_llm_calls = total_calls
        report.avg_latency_ms = round(total_latency / n, 1) if n > 0 else 0
        report.avg_risk_score = round(total_risk / n, 1) if n > 0 else 0
        report.success_rate = round(successes / n * 100, 1) if n > 0 else 0
        report.elder_skip_rate = round(elder_skips / n * 100, 1) if n > 0 else 0

        if self.verbose:
            self._print_report(report)

        return report

    def _estimate_cost(self, breakdown) -> float:
        costs = {"simple": 0.003, "medium": 0.04, "complex": 0.35}
        return costs.get(breakdown.policy.value, 0.04)

    def _estimate_calls(self, breakdown) -> int:
        calls = {"simple": 2, "medium": 5, "complex": 12}
        return calls.get(breakdown.policy.value, 5)

    def _estimate_tokens(self, breakdown) -> int:
        tokens = {"simple": 1500, "medium": 5000, "complex": 20000}
        return tokens.get(breakdown.policy.value, 5000)

    def _print_report(self, report: BenchmarkReport):
        print(f"\n{'═' * 60}")
        print(f"  📊 BENCHMARK RESULTS")
        print(f"{'═' * 60}")
        print(f"  Tasks:           {report.total_tasks}")
        print(f"    Simple:        {report.simple_tasks}")
        print(f"    Medium:        {report.medium_tasks}")
        print(f"    Complex:       {report.complex_tasks}")
        print(f"")
        print(f"  Routing Accuracy: {report.routing_accuracy:.1%}")
        print(f"  Total LLM Calls:  {report.total_llm_calls}")
        print(f"  Total Tokens:     {report.total_tokens:,}")
        print(f"  Total Cost:       ${report.total_cost_usd:.4f}")
        print(f"  Avg Latency:      {report.avg_latency_ms:.1f}ms")
        print(f"  Avg Risk Score:   {report.avg_risk_score}/10")
        print(f"  Elder Skip Rate:  {report.elder_skip_rate:.1f}%")
        print(f"  Success Rate:     {report.success_rate:.1f}%")
        print(f"{'═' * 60}")

    def save_report(self, report: BenchmarkReport, path: str = None):
        if path is None:
            os.makedirs(".aerrik/benchmarks", exist_ok=True)
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            path = f".aerrik/benchmarks/benchmark_{ts}.json"

        with open(path, 'w') as f:
            json.dump(report.to_dict(), f, indent=2)

        return path


# ═══════════════════════════════════════════════════════
#  ENTRY POINT
# ═══════════════════════════════════════════════════════

if __name__ == "__main__":
    runner = BenchmarkRunner300(verbose=True)
    report = runner.run()
    path = runner.save_report(report)
    print(f"\n  💾 Report saved: {path}")
