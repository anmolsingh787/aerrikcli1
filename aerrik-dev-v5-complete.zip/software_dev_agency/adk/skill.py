"""
🎓 aerrik ADK — Skill Primitive

A Skill is reusable knowledge that can be loaded into an agent.

Progressive disclosure:
- At startup: only name + description (~50 tokens)
- On demand: full content when task matches

Skills can be:
- Markdown files (knowledge)
- Compiled rules (fast lookup)
- Workflow templates (reusable processes)
"""
import os
from typing import Dict, List, Optional
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class SkillMetadata:
    """Lightweight skill metadata (loaded at startup)"""
    name: str
    description: str = ""
    version: str = "1.0"
    tags: List[str] = field(default_factory=list)
    trigger_keywords: List[str] = field(default_factory=list)
    size_lines: int = 0
    source: str = ""  # file path or URL


class Skill:
    """
    🎓 Skill — ADK knowledge primitive.

    Usage:
        skill = Skill(
            name="frontend",
            description="React/Next.js best practices",
            path="skills/frontend_skills.md"
        )

        # Lazy load — only when needed
        content = skill.load()

        # Check relevance to a task
        if skill.is_relevant("Build a React navbar"):
            agent.load_skill(skill.name, skill.load())
    """

    def __init__(
        self,
        name: str,
        description: str = "",
        path: Optional[str] = None,
        content: Optional[str] = None,
        tags: List[str] = None,
        trigger_keywords: List[str] = None,
        version: str = "1.0",
    ):
        self.name = name
        self.description = description
        self.path = path
        self._content = content
        self.tags = tags or []
        self.trigger_keywords = trigger_keywords or []
        self.version = version
        self._loaded = False
        self._load_count = 0

        # Auto-extract keywords from name/description if not provided
        if not self.trigger_keywords:
            self.trigger_keywords = self._extract_keywords()

    def load(self) -> str:
        """Load full skill content (lazy)"""
        if self._content and self._loaded:
            self._load_count += 1
            return self._content

        if self.path and os.path.exists(self.path):
            with open(self.path, 'r', encoding='utf-8') as f:
                self._content = f.read()
            self._loaded = True
            self._load_count += 1
            return self._content

        if self._content:
            self._loaded = True
            self._load_count += 1
            return self._content

        return f"[Skill '{self.name}' content not available]"

    def get_description(self) -> str:
        """Get lightweight description (for startup)"""
        return self.description or f"Skill: {self.name}"

    def is_relevant(self, task: str) -> bool:
        """Check if this skill is relevant to a task"""
        task_lower = task.lower()
        return any(kw in task_lower for kw in self.trigger_keywords)

    def relevance_score(self, task: str) -> float:
        """Score relevance (0-1)"""
        task_lower = task.lower()
        if not self.trigger_keywords:
            return 0
        matches = sum(1 for kw in self.trigger_keywords if kw in task_lower)
        return min(1.0, matches / max(1, len(self.trigger_keywords) * 0.3))

    def _extract_keywords(self) -> List[str]:
        """Extract keywords from name and description"""
        text = f"{self.name} {self.description}".lower()
        # Common skill keywords
        keywords = []
        for word in text.split():
            if len(word) > 3 and word.isalpha():
                keywords.append(word)
        return keywords[:10]

    def get_metadata(self) -> SkillMetadata:
        """Get lightweight metadata"""
        content = self._content or ""
        return SkillMetadata(
            name=self.name,
            description=self.description,
            version=self.version,
            tags=self.tags,
            trigger_keywords=self.trigger_keywords,
            size_lines=len(content.splitlines()) if content else 0,
            source=self.path or "inline",
        )

    def __repr__(self):
        status = "loaded" if self._loaded else "lazy"
        return f"<Skill: {self.name} ({status}) loads={self._load_count}>"


class SkillRegistry:
    """
    Registry for managing multiple skills with progressive disclosure.
    """

    def __init__(self, skills_dir: str = "skills"):
        self.skills_dir = skills_dir
        self._skills: Dict[str, Skill] = {}

    def register(self, skill: Skill):
        """Register a skill"""
        self._skills[skill.name] = skill

    def load_from_directory(self, directory: str = None):
        """Load all .md skills from a directory"""
        dir_path = directory or self.skills_dir
        if not os.path.exists(dir_path):
            return

        for f in Path(dir_path).glob("*.md"):
            name = f.stem
            with open(f, 'r') as fh:
                first_line = fh.readline().strip().lstrip("#").strip()

            self.register(Skill(
                name=name,
                description=first_line,
                path=str(f),
            ))

    def get_relevant_skills(self, task: str, max_skills: int = 3) -> List[Skill]:
        """Get skills relevant to a task (sorted by relevance)"""
        scored = []
        for skill in self._skills.values():
            score = skill.relevance_score(task)
            if score > 0:
                scored.append((score, skill))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [s for _, s in scored[:max_skills]]

    def get_all_descriptions(self) -> List[str]:
        """Get all skill descriptions (for startup context)"""
        return [
            f"- {s.name}: {s.get_description()}"
            for s in self._skills.values()
        ]

    def get(self, name: str) -> Optional[Skill]:
        return self._skills.get(name)

    def list_skills(self) -> List[str]:
        return list(self._skills.keys())

    def __len__(self):
        return len(self._skills)
