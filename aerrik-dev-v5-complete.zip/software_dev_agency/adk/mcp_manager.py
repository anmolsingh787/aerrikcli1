"""
🌐 aerrik ADK — MCP (Model Context Protocol) Manager

MCP allows connecting external tools and services to agents.

Supported MCP servers:
- Browser automation (Playwright)
- GitHub API
- Database queries
- Figma design
- Docker management
- Cloud services

MCP tools appear in the agent's tool registry just like native tools.
"""
import os
import json
import subprocess
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path


@dataclass
class MCPServer:
    """An MCP server configuration"""
    name: str
    command: str = ""
    args: List[str] = field(default_factory=list)
    env: Dict[str, str] = field(default_factory=dict)
    enabled: bool = True
    description: str = ""
    tools: List[str] = field(default_factory=list)
    url: str = ""           # For HTTP-based MCP servers
    timeout: int = 30
    added_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict:
        return {
            "name": self.name,
            "command": self.command,
            "args": self.args,
            "env": {k: "***" if "key" in k.lower() or "secret" in k.lower() else v
                    for k, v in self.env.items()},  # Redact secrets
            "enabled": self.enabled,
            "description": self.description,
            "tools": self.tools,
            "url": self.url,
        }


# ─── Known MCP Servers ──────────────────────────────────
KNOWN_MCP_SERVERS = {
    "browser": {
        "name": "browser",
        "command": "npx",
        "args": ["@anthropic-ai/mcp-browser@latest"],
        "description": "Browser automation (Playwright)",
        "tools": ["navigate", "click", "fill", "screenshot", "snapshot"],
    },
    "github": {
        "name": "github",
        "command": "npx",
        "args": ["@anthropic-ai/mcp-github@latest"],
        "description": "GitHub API (repos, issues, PRs)",
        "tools": ["search_repos", "get_issue", "create_pr", "list_files"],
        "env": {"GITHUB_TOKEN": ""},
    },
    "filesystem": {
        "name": "filesystem",
        "command": "npx",
        "args": ["@anthropic-ai/mcp-filesystem@latest"],
        "description": "Enhanced filesystem operations",
        "tools": ["read_file", "write_file", "list_dir", "search_files"],
    },
    "memory": {
        "name": "memory",
        "command": "npx",
        "args": ["@anthropic-ai/mcp-memory@latest"],
        "description": "Persistent memory/knowledge graph",
        "tools": ["store", "recall", "search", "relate"],
    },
    "postgres": {
        "name": "postgres",
        "command": "npx",
        "args": ["@anthropic-ai/mcp-postgres@latest"],
        "description": "PostgreSQL database queries",
        "tools": ["query", "list_tables", "describe_table"],
        "env": {"DATABASE_URL": ""},
    },
    "docker": {
        "name": "docker",
        "command": "npx",
        "args": ["@anthropic-ai/mcp-docker@latest"],
        "description": "Docker container management",
        "tools": ["list_containers", "start", "stop", "logs", "build"],
    },
    "figma": {
        "name": "figma",
        "command": "npx",
        "args": ["@anthropic-ai/mcp-figma@latest"],
        "description": "Figma design file access",
        "tools": ["get_design", "get_components", "export_svg"],
        "env": {"FIGMA_TOKEN": ""},
    },
    "web-search": {
        "name": "web-search",
        "command": "npx",
        "args": ["@anthropic-ai/mcp-brave-search@latest"],
        "description": "Web search (Brave API)",
        "tools": ["search", "search_news", "search_images"],
        "env": {"BRAVE_API_KEY": ""},
    },
}


class MCPManager:
    """
    🌐 MCP Manager — External tool integration.

    Usage:
        mcp = MCPManager()

        # Add a server
        mcp.add_server("browser")

        # List available tools
        tools = mcp.get_tools()

        # Execute an MCP tool
        result = mcp.execute("browser", "screenshot", {"url": "https://example.com"})
    """

    def __init__(self, config_dir: str = ".aerrik/mcp"):
        self.config_dir = config_dir
        os.makedirs(config_dir, exist_ok=True)
        self._servers: Dict[str, MCPServer] = {}
        self._load_config()

    # ─── Server Management ─────────────────────────────

    def add_server(self, name: str, config: Dict = None) -> MCPServer:
        """Add an MCP server"""
        if name in KNOWN_MCP_SERVERS:
            known = KNOWN_MCP_SERVERS[name]
            server = MCPServer(
                name=name,
                command=known.get("command", ""),
                args=known.get("args", []),
                description=known.get("description", ""),
                tools=known.get("tools", []),
                env=known.get("env", {}),
            )
        else:
            server = MCPServer(
                name=name,
                **(config or {}),
            )

        if config:
            for key, value in config.items():
                if hasattr(server, key):
                    setattr(server, key, value)

        self._servers[name] = server
        self._save_config()
        return server

    def remove_server(self, name: str) -> bool:
        """Remove an MCP server"""
        if name in self._servers:
            del self._servers[name]
            self._save_config()
            return True
        return False

    def enable_server(self, name: str) -> bool:
        """Enable an MCP server"""
        if name in self._servers:
            self._servers[name].enabled = True
            self._save_config()
            return True
        return False

    def disable_server(self, name: str) -> bool:
        """Disable an MCP server"""
        if name in self._servers:
            self._servers[name].enabled = False
            self._save_config()
            return True
        return False

    def get_server(self, name: str) -> Optional[MCPServer]:
        return self._servers.get(name)

    def list_servers(self) -> List[Dict]:
        """List all MCP servers"""
        return [s.to_dict() for s in self._servers.values()]

    def list_available(self) -> List[Dict]:
        """List known MCP servers that can be added"""
        return [
            {
                "name": name,
                "description": config.get("description", ""),
                "tools": config.get("tools", []),
                "installed": name in self._servers,
            }
            for name, config in KNOWN_MCP_SERVERS.items()
        ]

    # ─── Tool Discovery ────────────────────────────────

    def get_tools(self) -> List[Dict]:
        """Get all tools from enabled MCP servers"""
        tools = []
        for server in self._servers.values():
            if not server.enabled:
                continue
            for tool_name in server.tools:
                tools.append({
                    "name": f"mcp_{server.name}_{tool_name}",
                    "description": f"[MCP:{server.name}] {tool_name}",
                    "server": server.name,
                    "tool": tool_name,
                    "source": "mcp",
                })
        return tools

    def has_tool(self, tool_name: str) -> bool:
        """Check if an MCP tool exists"""
        return any(t["name"] == tool_name for t in self.get_tools())

    # ─── Tool Execution ────────────────────────────────

    def execute(self, server_name: str, tool_name: str, args: Dict = None) -> Dict:
        """Execute an MCP tool"""
        server = self._servers.get(server_name)
        if not server:
            return {"error": f"MCP server '{server_name}' not found"}
        if not server.enabled:
            return {"error": f"MCP server '{server_name}' is disabled"}

        # In production, this would communicate with the MCP server process
        # For now, return a mock result
        return {
            "server": server_name,
            "tool": tool_name,
            "args": args or {},
            "result": f"[MCP] {server_name}.{tool_name} executed",
            "status": "success",
            "note": "MCP server communication requires running server process",
        }

    # ─── Persistence ───────────────────────────────────

    def _save_config(self):
        """Save MCP config to disk"""
        filepath = os.path.join(self.config_dir, "mcp_servers.json")
        data = {}
        for name, server in self._servers.items():
            data[name] = {
                "name": server.name,
                "command": server.command,
                "args": server.args,
                "enabled": server.enabled,
                "description": server.description,
                "tools": server.tools,
                "url": server.url,
                "timeout": server.timeout,
                "added_at": server.added_at,
                # env is stored separately with encryption in production
            }
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)

    def _load_config(self):
        """Load MCP config from disk"""
        filepath = os.path.join(self.config_dir, "mcp_servers.json")
        if not os.path.exists(filepath):
            return
        try:
            with open(filepath) as f:
                data = json.load(f)
            for name, config in data.items():
                self._servers[name] = MCPServer(**config)
        except Exception:
            pass

    # ─── Integration with Tool Registry ────────────────

    def register_with_tool_registry(self, tool_registry):
        """Register all MCP tools with the Aerrik tool registry"""
        from runtime.tool_registry import ToolRegistry

        for tool_info in self.get_tools():
            def make_mcp_executor(srv_name, tl_name):
                def executor(**kwargs):
                    return self.execute(srv_name, tl_name, kwargs)
                return executor

            # Register as a callable tool
            tool_registry.register(
                name=tool_info["name"],
                func=make_mcp_executor(tool_info["server"], tool_info["tool"]),
                schema=None,  # Would need proper schema
            )

    def get_stats(self) -> Dict:
        return {
            "total_servers": len(self._servers),
            "enabled_servers": sum(1 for s in self._servers.values() if s.enabled),
            "total_tools": len(self.get_tools()),
            "available_servers": len(KNOWN_MCP_SERVERS),
        }
