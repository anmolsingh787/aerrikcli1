"""
📡 aerrik ADK — Event System

Events fire at key moments in the agent lifecycle:
- task_started / task_completed
- tool_called / tool_completed
- agent_delegated
- error_occurred
- budget_warning
- session_saved
"""
from typing import Dict, List, Optional, Callable, Any
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime


class EventType(Enum):
    TASK_STARTED = "task_started"
    TASK_COMPLETED = "task_completed"
    TOOL_CALLED = "tool_called"
    TOOL_COMPLETED = "tool_completed"
    TOOL_FAILED = "tool_failed"
    AGENT_DELEGATED = "agent_delegated"
    AGENT_COMPLETED = "agent_completed"
    ERROR = "error"
    BUDGET_WARNING = "budget_warning"
    SESSION_SAVED = "session_saved"
    MODE_CHANGED = "mode_changed"
    RISK_ALERT = "risk_alert"
    PERMISSION_DENIED = "permission_denied"
    DOG_BARK = "dog_bark"


@dataclass
class Event:
    """An event in the agent lifecycle"""
    type: EventType
    data: Dict[str, Any] = field(default_factory=dict)
    agent: str = ""
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

    def __str__(self):
        return f"[{self.type.value}] {self.agent}: {self.data}"


class EventBus:
    """
    📡 Event Bus — Subscribe to agent lifecycle events.

    Usage:
        bus = EventBus()

        @bus.on(EventType.TOOL_CALLED)
        def on_tool(event: Event):
            print(f"Tool called: {event.data['tool']}")

        bus.emit(Event(EventType.TOOL_CALLED, {"tool": "read"}))
    """

    def __init__(self):
        self._handlers: Dict[EventType, List[Callable]] = {}
        self._history: List[Event] = []
        self._max_history = 1000

    def on(self, event_type: EventType):
        """Decorator to register an event handler"""
        def decorator(func):
            if event_type not in self._handlers:
                self._handlers[event_type] = []
            self._handlers[event_type].append(func)
            return func
        return decorator

    def subscribe(self, event_type: EventType, handler: Callable):
        """Subscribe to an event"""
        if event_type not in self._handlers:
            self._handlers[event_type] = []
        self._handlers[event_type].append(handler)

    def emit(self, event: Event):
        """Emit an event to all subscribers"""
        self._history.append(event)
        if len(self._history) > self._max_history:
            self._history = self._history[-self._max_history:]

        handlers = self._handlers.get(event.type, [])
        for handler in handlers:
            try:
                handler(event)
            except Exception as e:
                pass  # Don't let event handlers break the system

    def get_history(self, event_type: EventType = None, last_n: int = 50) -> List[Event]:
        """Get event history"""
        events = self._history
        if event_type:
            events = [e for e in events if e.type == event_type]
        return events[-last_n:]

    def clear_history(self):
        self._history.clear()
