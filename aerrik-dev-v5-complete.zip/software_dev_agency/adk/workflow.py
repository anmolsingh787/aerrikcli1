"""
🔄 aerrik ADK — Workflow Primitive

A Workflow is a multi-step process with:
- Ordered steps
- Conditional branching
- Error handling
- Checkpoint/resume support

Workflows can be:
- Simple (linear steps)
- Complex (branching, loops, parallel)
"""
import time
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime


class StepStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class StepResult:
    """Result of a workflow step"""
    step_name: str
    status: StepStatus
    output: str = ""
    error: str = ""
    duration_ms: float = 0
    metadata: Dict = field(default_factory=dict)


@dataclass
class Step:
    """A single step in a workflow"""
    name: str
    description: str = ""
    func: Optional[Callable] = None
    depends_on: List[str] = field(default_factory=list)
    condition: Optional[Callable] = None  # Skip if returns False
    on_failure: str = "stop"  # stop, skip, retry
    max_retries: int = 1
    timeout_seconds: int = 120


class Workflow:
    """
    🔄 Workflow — ADK multi-step process.

    Usage:
        wf = Workflow(name="build_project")

        wf.add_step(Step("analyze", func=analyze_task))
        wf.add_step(Step("plan", func=create_plan, depends_on=["analyze"]))
        wf.add_step(Step("execute", func=execute_plan, depends_on=["plan"]))
        wf.add_step(Step("validate", func=validate_output, depends_on=["execute"]))

        result = wf.run(context={"task": "Build a login page"})
    """

    def __init__(self, name: str, description: str = ""):
        self.name = name
        self.description = description
        self.steps: List[Step] = []
        self.results: List[StepResult] = []
        self.context: Dict[str, Any] = {}
        self.started_at: Optional[str] = None
        self.completed_at: Optional[str] = None

    def add_step(self, step: Step) -> 'Workflow':
        """Add a step to the workflow"""
        self.steps.append(step)
        return self

    def run(self, context: Dict = None, resume_from: str = None) -> Dict:
        """
        Execute the workflow.

        Args:
            context: Shared context dict passed to all steps
            resume_from: Step name to resume from (skip completed steps)
        """
        self.context = context or {}
        self.results = []
        self.started_at = datetime.now().isoformat()

        skip_until = resume_from
        skipping = skip_until is not None

        for step in self.steps:
            # Skip completed steps when resuming
            if skipping:
                if step.name == skip_until:
                    skipping = False
                else:
                    self.results.append(StepResult(
                        step_name=step.name,
                        status=StepStatus.SKIPPED,
                    ))
                    continue

            # Check dependencies
            if step.depends_on:
                failed_deps = [
                    d for d in step.depends_on
                    if not any(r.step_name == d and r.status == StepStatus.COMPLETED for r in self.results)
                ]
                if failed_deps:
                    self.results.append(StepResult(
                        step_name=step.name,
                        status=StepStatus.FAILED,
                        error=f"Dependencies not met: {failed_deps}",
                    ))
                    if step.on_failure == "stop":
                        break
                    continue

            # Check condition
            if step.condition:
                try:
                    if not step.condition(self.context):
                        self.results.append(StepResult(
                            step_name=step.name,
                            status=StepStatus.SKIPPED,
                        ))
                        continue
                except Exception:
                    pass

            # Execute step
            result = self._execute_step(step)
            self.results.append(result)

            # Handle failure
            if result.status == StepStatus.FAILED:
                if step.on_failure == "stop":
                    break
                elif step.on_failure == "skip":
                    continue
                elif step.on_failure == "retry":
                    for retry in range(step.max_retries):
                        result = self._execute_step(step)
                        if result.status == StepStatus.COMPLETED:
                            self.results[-1] = result
                            break

        self.completed_at = datetime.now().isoformat()
        return self.get_summary()

    def _execute_step(self, step: Step) -> StepResult:
        """Execute a single step"""
        start = time.time()

        if step.func is None:
            return StepResult(
                step_name=step.name,
                status=StepStatus.SKIPPED,
                output="No function registered",
            )

        try:
            output = step.func(self.context)
            duration = (time.time() - start) * 1000

            # Update context with step output
            if isinstance(output, dict):
                self.context.update(output)
            elif output is not None:
                self.context[step.name] = output

            return StepResult(
                step_name=step.name,
                status=StepStatus.COMPLETED,
                output=str(output)[:500] if output else "",
                duration_ms=duration,
            )

        except Exception as e:
            duration = (time.time() - start) * 1000
            return StepResult(
                step_name=step.name,
                status=StepStatus.FAILED,
                error=str(e)[:200],
                duration_ms=duration,
            )

    def get_summary(self) -> Dict:
        """Get workflow execution summary"""
        completed = sum(1 for r in self.results if r.status == StepStatus.COMPLETED)
        failed = sum(1 for r in self.results if r.status == StepStatus.FAILED)
        skipped = sum(1 for r in self.results if r.status == StepStatus.SKIPPED)
        total_time = sum(r.duration_ms for r in self.results)

        return {
            "workflow": self.name,
            "total_steps": len(self.steps),
            "completed": completed,
            "failed": failed,
            "skipped": skipped,
            "total_time_ms": round(total_time, 1),
            "status": "completed" if failed == 0 else "failed",
            "steps": [
                {
                    "name": r.step_name,
                    "status": r.status.value,
                    "duration_ms": round(r.duration_ms, 1),
                    "error": r.error,
                }
                for r in self.results
            ],
        }

    def get_checkpoint(self) -> Dict:
        """Get checkpoint for resume"""
        last_completed = None
        for r in reversed(self.results):
            if r.status == StepStatus.COMPLETED:
                last_completed = r.step_name
                break

        return {
            "workflow": self.name,
            "last_completed_step": last_completed,
            "context": self.context,
            "results": [
                {"step": r.step_name, "status": r.status.value}
                for r in self.results
            ],
        }
