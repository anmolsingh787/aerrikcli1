"""
🧩 aerrik.dev — ADK (Agent Development Kit)

Public API for building AI agents with Aerrik Runtime.

Usage:
    from aerrik.adk import Agent, Tool, Skill, Workflow, run

    agent = Agent(name="frontend", skills=["frontend", "visual"])
    agent.add_tool(Tool(name="browser", func=browse_web))
    run(agent, task="Build a responsive dashboard")

The Aerrik Runtime uses ADK internally.
Third-party developers can use ADK to build custom agents.
"""
from adk.agent import Agent
from adk.tool import Tool, ToolResult
from adk.skill import Skill
from adk.workflow import Workflow, Step
from adk.session import Session
from adk.handoff import Handoff
from adk.mcp_manager import MCPManager, MCPServer
from adk.events import Event, EventType

__all__ = [
    "Agent", "Tool", "ToolResult", "Skill",
    "Workflow", "Step", "Session", "Handoff",
    "MCPManager", "MCPServer",
    "Event", "EventType",
]
