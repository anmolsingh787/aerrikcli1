"""
🛠️ aerrik ADK — Tool Primitive

A Tool is an action an agent can take:
- Read a file
- Write a file
- Run a shell command
- Search code
- Call an API
- Browse a website

Tools have:
- Name + description (for LLM function calling)
- Parameter schema (JSON Schema)
- Permission level
- An execution function
"""
import time
import json
from typing import Dict, Any, Callable, Optional, List
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime


class ToolPermission(Enum):
    SAFE = "safe"           # Auto-approve
    MODERATE = "moderate"   # Log + proceed
    DANGEROUS = "dangerous" # Require approval


@dataclass
class ToolResult:
    """Result from tool execution"""
    output: str = ""
    error: str = ""
    success: bool = True
    latency_ms: float = 0
    tokens_estimated: int = 0
    metadata: Dict = field(default_factory=dict)
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


class Tool:
    """
    🛠️ Tool — ADK tool primitive.

    Usage:
        def read_file(path: str) -> str:
            with open(path) as f:
                return f.read()

        tool = Tool(
            name="read",
            description="Read a file",
            func=read_file,
            parameters={
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "File path"}
                },
                "required": ["path"]
            }
        )

        result = tool.execute(path="main.py")
    """

    def __init__(
        self,
        name: str,
        description: str = "",
        func: Optional[Callable] = None,
        parameters: Optional[Dict] = None,
        permission: ToolPermission = ToolPermission.SAFE,
        timeout: int = 30,
        max_output_chars: int = 10000,
        tags: List[str] = None,
    ):
        self.name = name
        self.description = description
        self.func = func
        self.parameters = parameters or {"type": "object", "properties": {}}
        self.permission = permission
        self.timeout = timeout
        self.max_output_chars = max_output_chars
        self.tags = tags or []

        # Stats
        self.call_count: int = 0
        self.error_count: int = 0
        self.total_latency_ms: float = 0

    def execute(self, **kwargs) -> ToolResult:
        """Execute the tool with given arguments"""
        start = time.time()
        self.call_count += 1

        try:
            if self.func is None:
                return ToolResult(
                    error=f"Tool '{self.name}' has no function registered",
                    success=False,
                )

            output = self.func(**kwargs)
            output_str = str(output) if output is not None else ""

            # Truncate large output
            if len(output_str) > self.max_output_chars:
                output_str = (
                    output_str[:self.max_output_chars // 2]
                    + f"\n\n... [{len(output_str) - self.max_output_chars} chars truncated] ...\n\n"
                    + output_str[-self.max_output_chars // 2:]
                )

            latency = (time.time() - start) * 1000
            self.total_latency_ms += latency

            return ToolResult(
                output=output_str,
                success=True,
                latency_ms=latency,
                tokens_estimated=len(output_str) // 4,
            )

        except Exception as e:
            latency = (time.time() - start) * 1000
            self.total_latency_ms += latency
            self.error_count += 1

            return ToolResult(
                error=str(e),
                success=False,
                latency_ms=latency,
            )

    def get_schema(self) -> Dict:
        """Get OpenAI function calling schema"""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            },
        }

    def get_stats(self) -> Dict:
        return {
            "name": self.name,
            "calls": self.call_count,
            "errors": self.error_count,
            "avg_latency_ms": round(
                self.total_latency_ms / max(1, self.call_count), 1
            ),
            "permission": self.permission.value,
        }

    def __repr__(self):
        return f"<Tool: {self.name} ({self.permission.value}) calls={self.call_count}>"


# ═══════════════════════════════════════════════════════
#  BUILT-IN TOOLS (ADK-native)
# ═══════════════════════════════════════════════════════

def create_read_tool(working_dir: str = ".") -> Tool:
    """Create a file read tool"""
    import os

    def read(path: str, offset: int = 0, limit: int = 500) -> str:
        full = os.path.join(working_dir, path) if not os.path.isabs(path) else path
        if not os.path.exists(full):
            return f"Error: File not found: {path}"
        with open(full, 'r', encoding='utf-8', errors='replace') as f:
            lines = f.readlines()
        selected = lines[offset:offset + limit]
        numbered = [f"{i+offset+1:5d} | {l.rstrip()}" for i, l in enumerate(selected)]
        return f"File: {path} ({len(lines)} lines)\n" + "\n".join(numbered)

    return Tool(
        name="read",
        description="Read file contents with line numbers",
        func=read,
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path"},
                "offset": {"type": "integer", "description": "Start line", "default": 0},
                "limit": {"type": "integer", "description": "Max lines", "default": 500},
            },
            "required": ["path"],
        },
        permission=ToolPermission.SAFE,
        tags=["file", "read"],
    )


def create_write_tool(working_dir: str = ".") -> Tool:
    """Create a file write tool"""
    import os

    def write(path: str, content: str) -> str:
        full = os.path.join(working_dir, path) if not os.path.isabs(path) else path
        os.makedirs(os.path.dirname(full), exist_ok=True)
        with open(full, 'w', encoding='utf-8') as f:
            f.write(content)
        return f"✅ Written {len(content)} bytes to {path}"

    return Tool(
        name="write",
        description="Write content to a file (creates parent dirs)",
        func=write,
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path"},
                "content": {"type": "string", "description": "File content"},
            },
            "required": ["path", "content"],
        },
        permission=ToolPermission.MODERATE,
        tags=["file", "write"],
    )


def create_shell_tool(working_dir: str = ".") -> Tool:
    """Create a shell execution tool"""
    import subprocess

    def shell(command: str, timeout: int = 30) -> str:
        # Safety: block dangerous commands
        dangerous = ["rm -rf /", "sudo", "mkfs", "chmod 777", ":(){"]
        for d in dangerous:
            if d in command.lower():
                return f"⛔ Blocked dangerous command: {command[:80]}"

        result = subprocess.run(
            command, shell=True, cwd=working_dir,
            capture_output=True, text=True, timeout=timeout,
        )
        output = result.stdout
        if result.stderr:
            output += f"\n[stderr] {result.stderr}"
        return output + f"\n[exit: {result.returncode}]"

    return Tool(
        name="shell",
        description="Execute a shell command in the project directory",
        func=shell,
        parameters={
            "type": "object",
            "properties": {
                "command": {"type": "string", "description": "Shell command"},
                "timeout": {"type": "integer", "description": "Timeout seconds", "default": 30},
            },
            "required": ["command"],
        },
        permission=ToolPermission.MODERATE,
        tags=["shell", "execute"],
    )
