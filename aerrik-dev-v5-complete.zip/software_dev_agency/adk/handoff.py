"""
🤝 aerrik ADK — Handoff Primitive

A Handoff delegates work from one agent to another.
Used when a task requires a different specialist.
"""
from typing import Dict, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class Handoff:
    """
    🤝 Handoff — Agent delegation.

    Usage:
        handoff = Handoff(
            from_agent="frontend_dev",
            to_agent="designer",
            task="Design the color palette",
            context={"project": "e-commerce dashboard"}
        )
    """
    from_agent: str
    to_agent: str
    task: str
    context: Dict[str, Any] = field(default_factory=dict)
    reason: str = ""
    priority: int = 5       # 1 (highest) to 10
    expected_output: str = ""
    timeout_seconds: int = 120
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict:
        return {
            "from": self.from_agent,
            "to": self.to_agent,
            "task": self.task,
            "reason": self.reason,
            "priority": self.priority,
            "context_keys": list(self.context.keys()),
        }
