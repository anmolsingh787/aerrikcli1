"""
💾 aerrik ADK — Session Primitive

A Session tracks the state of an agent interaction:
- Conversation history
- Tool calls and results
- Files modified
- Cost tracking
- Checkpoints for resume
"""
import os
import json
import uuid
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class SessionMessage:
    """A message in the session"""
    role: str           # user, assistant, tool, system
    content: str
    tool_name: str = ""
    tool_call_id: str = ""
    tokens: int = 0
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    metadata: Dict = field(default_factory=dict)


class Session:
    """
    💾 Session — ADK session state.

    Usage:
        session = Session(agent_name="frontend_dev")

        session.add_message("user", "Build a login page")
        session.add_message("assistant", "I'll create a LoginForm component...")
        session.add_tool_call("write", "LoginForm.tsx", success=True)

        session.save_checkpoint()

        # Later...
        session = Session.load("session_abc123.json")
    """

    def __init__(
        self,
        agent_name: str = "",
        session_id: str = None,
        mode: str = "agent",  # plan, agent, build
    ):
        self.id = session_id or f"session_{uuid.uuid4().hex[:12]}"
        self.agent_name = agent_name
        self.mode = mode
        self.messages: List[SessionMessage] = []
        self.files_modified: List[str] = []
        self.cost_usd: float = 0.0
        self.total_tokens: int = 0
        self.llm_calls: int = 0
        self.tool_calls: int = 0
        self.started_at: str = datetime.now().isoformat()
        self.updated_at: str = datetime.now().isoformat()
        self.metadata: Dict[str, Any] = {}

    # ─── Message Management ────────────────────────────

    def add_message(
        self,
        role: str,
        content: str,
        tool_name: str = "",
        tokens: int = 0,
        metadata: Dict = None,
    ):
        """Add a message to the session"""
        msg = SessionMessage(
            role=role,
            content=content,
            tool_name=tool_name,
            tokens=tokens,
            metadata=metadata or {},
        )
        self.messages.append(msg)
        self.total_tokens += tokens
        self.updated_at = datetime.now().isoformat()

        if role == "assistant":
            self.llm_calls += 1
        elif role == "tool":
            self.tool_calls += 1

    def add_tool_call(
        self,
        tool_name: str,
        output: str,
        success: bool = True,
        latency_ms: float = 0,
    ):
        """Record a tool call"""
        self.add_message(
            role="tool",
            content=output[:2000],
            tool_name=tool_name,
            metadata={"success": success, "latency_ms": latency_ms},
        )

    def add_file_modification(self, path: str):
        """Record a file modification"""
        if path not in self.files_modified:
            self.files_modified.append(path)

    # ─── Context Building ──────────────────────────────

    def get_conversation(self, last_n: int = None) -> List[Dict]:
        """Get conversation as LLM message format"""
        msgs = self.messages if last_n is None else self.messages[-last_n:]
        return [
            {"role": m.role, "content": m.content}
            for m in msgs
        ]

    def get_summary(self) -> str:
        """Get session summary for context compaction"""
        parts = [
            f"Session: {self.id}",
            f"Agent: {self.agent_name}",
            f"Mode: {self.mode}",
            f"Messages: {len(self.messages)}",
            f"LLM calls: {self.llm_calls}",
            f"Tool calls: {self.tool_calls}",
            f"Tokens: {self.total_tokens:,}",
            f"Cost: ${self.cost_usd:.4f}",
            f"Files modified: {', '.join(self.files_modified[:10])}",
        ]
        return "\n".join(parts)

    # ─── Cost Tracking ─────────────────────────────────

    def add_cost(self, cost_usd: float, tokens: int = 0):
        """Add cost from an LLM call"""
        self.cost_usd += cost_usd
        self.total_tokens += tokens

    # ─── Persistence ───────────────────────────────────

    def save_checkpoint(self, directory: str = ".aerrik/sessions") -> str:
        """Save session to disk"""
        os.makedirs(directory, exist_ok=True)
        filepath = os.path.join(directory, f"{self.id}.json")

        data = {
            "id": self.id,
            "agent_name": self.agent_name,
            "mode": self.mode,
            "messages": [
                {
                    "role": m.role,
                    "content": m.content,
                    "tool_name": m.tool_name,
                    "tokens": m.tokens,
                    "timestamp": m.timestamp,
                    "metadata": m.metadata,
                }
                for m in self.messages
            ],
            "files_modified": self.files_modified,
            "cost_usd": self.cost_usd,
            "total_tokens": self.total_tokens,
            "llm_calls": self.llm_calls,
            "tool_calls": self.tool_calls,
            "started_at": self.started_at,
            "updated_at": self.updated_at,
            "metadata": self.metadata,
        }

        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)

        return filepath

    @classmethod
    def load(cls, filepath: str) -> 'Session':
        """Load session from disk"""
        with open(filepath) as f:
            data = json.load(f)

        session = cls(
            agent_name=data.get("agent_name", ""),
            session_id=data.get("id"),
            mode=data.get("mode", "agent"),
        )
        session.cost_usd = data.get("cost_usd", 0)
        session.total_tokens = data.get("total_tokens", 0)
        session.llm_calls = data.get("llm_calls", 0)
        session.tool_calls = data.get("tool_calls", 0)
        session.files_modified = data.get("files_modified", [])
        session.started_at = data.get("started_at", "")
        session.metadata = data.get("metadata", {})

        for m in data.get("messages", []):
            session.messages.append(SessionMessage(
                role=m["role"],
                content=m["content"],
                tool_name=m.get("tool_name", ""),
                tokens=m.get("tokens", 0),
                timestamp=m.get("timestamp", ""),
                metadata=m.get("metadata", {}),
            ))

        return session

    @classmethod
    def list_sessions(cls, directory: str = ".aerrik/sessions") -> List[Dict]:
        """List all saved sessions"""
        if not os.path.exists(directory):
            return []

        sessions = []
        for f in sorted(os.listdir(directory), reverse=True):
            if f.endswith(".json"):
                filepath = os.path.join(directory, f)
                try:
                    with open(filepath) as fh:
                        data = json.load(fh)
                    sessions.append({
                        "id": data.get("id", f),
                        "agent": data.get("agent_name", ""),
                        "mode": data.get("mode", ""),
                        "messages": len(data.get("messages", [])),
                        "cost": data.get("cost_usd", 0),
                        "updated": data.get("updated_at", ""),
                    })
                except Exception:
                    pass
        return sessions

    def get_stats(self) -> Dict:
        return {
            "id": self.id,
            "agent": self.agent_name,
            "mode": self.mode,
            "messages": len(self.messages),
            "llm_calls": self.llm_calls,
            "tool_calls": self.tool_calls,
            "tokens": self.total_tokens,
            "cost_usd": round(self.cost_usd, 4),
            "files_modified": len(self.files_modified),
        }
