"""
Prompts package for Software Development Agency
"""
from .system_prompts import ROLE_PROMPTS
