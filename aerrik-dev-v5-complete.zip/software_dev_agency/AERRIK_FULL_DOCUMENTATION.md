# ╔══════════════════════════════════════════════════════════════╗
# ║  █████╗ ███████╗██████╗ ██████╗ ██╗██╗  ██╗    🐕           ║
# ║ ██╔══██╗██╔════╝██╔══██╗██╔══██╗██║██║ ██╔╝                 ║
# ║ ███████║█████╗  ██████╔╝██████╔╝██║█████╔╝   .dev v3.0     ║
# ║ ██╔══██║██╔══╝  ██╔══██╗██╔══██╗██║██╔═██╗                 ║
# ║ ██║  ██║███████╗██║  ██║██║  ██║██║██║  ██╗                ║
# ║ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚═╝  ╚═╝                ║
# ╚══════════════════════════════════════════════════════════════╝
#
# aerrik.dev v3.0 — "Good Boy" Edition
# Complete AI Agent Framework Documentation
#
# Website: https://aerrik.dev
# Version: 3.0.0
# Codename: Good Boy
# License: MIT

---

## 📋 TABLE OF CONTENTS

1. [What is aerrik.dev?](#1-what-is-aerrikdev)
2. [The Expanded Family (12 Agents + 1 Dog)](#2-the-expanded-family)
3. [Family Hierarchy & Delegation](#3-family-hierarchy)
4. [Agent Profiles (Detailed)](#4-agent-profiles)
5. [Girls Team — Frontend Division](#5-girls-team)
6. [Boys Team — Backend Division](#6-boys-team)
7. [The Elders — Grandparents](#7-the-elders)
8. [🐕 Aerrik — Dog Companion](#8-aerrik-dog)
9. [Skills System (7 GitHub Skills)](#9-skills-system)
10. [Tools & Capabilities](#10-tools)
11. [LLM Engine — Multi-Provider](#11-llm-engine)
12. [Cost Tracking & Budget](#12-cost-tracking)
13. [Feedback Loop (Test → Fix → Retest)](#13-feedback-loop)
14. [Code Validation & Security](#14-code-validation)
15. [Human Approval Checkpoints](#15-human-approval)
16. [Git Integration](#16-git-integration)
17. [Memory System](#17-memory-system)
18. [Terminal Interface](#18-terminal-interface)
19. [CLI Commands Reference](#19-cli-commands)
20. [@Mentions Reference](#20-mentions)
21. [Project Build Pipeline](#21-build-pipeline)
22. [API & Programmatic Usage](#22-api-usage)
23. [Configuration](#23-configuration)
24. [File Structure](#24-file-structure)
25. [Installation & Setup](#25-installation)
26. [Examples & Workflows](#26-examples)
27. [Extending the Framework](#27-extending)
28. [Troubleshooting](#28-troubleshooting)
29. [Quick Reference Card](#29-quick-reference)

---

## 1. What is aerrik.dev?

aerrik.dev is a **multi-agent AI software development framework** with:

- **12 specialized AI agents** organized into an expanded family hierarchy
- **1 animated dog companion** that barks on errors
- **8 LLM providers** (OpenAI, Anthropic, Groq, Google, DeepSeek, etc.)
- **7 GitHub-sourced skills** (Ponytail, shadcn/ui, Trail of Bits security, etc.)
- **Feedback loops** (Tester reviews code → Agent fixes → Retest)
- **Human approval checkpoints** (approve/revise architecture before building)
- **Cost tracking** with budget enforcement
- **Code validation** before writing to disk
- **Security scanning** (SQL injection, XSS, hardcoded secrets)
- **Full terminal UI** with Rich panels, tables, and syntax highlighting

### Core Philosophy

```
"Think like a senior dev family, not a code generator."
```

Every agent follows the **Ponytail Principle** (84k⭐ GitHub repo):
> Before writing code, stop at the first rung that holds:
> 1. Does this need to exist? → skip (YAGNI)
> 2. Already in codebase? → reuse
> 3. Stdlib does it? → use it
> 4. Native platform? → use it
> 5. Installed dependency? → use it
> 6. One line? → one line
> 7. Only then: the minimum that works

---

## 2. The Expanded Family

```
👴 Grandfather ─── SUPREME REVIEWER (finds ALL weak points)
👵 Grandmother ─── WISE ADVISOR (quality, a11y, docs)
  │
  👨‍💼 Dad (Architect) ─── SYSTEM DESIGN
    │
    └── 👩‍💼 Mommy (Project Manager) ─── COORDINATOR
        │
        ├── 👧 GIRLS TEAM (Frontend)
        │    ├── 👧 Girl 1 — Frontend Dev      (React, Next.js, TypeScript)
        │    ├── 👧 Girl 2 — QA Tester          (pytest, Jest, E2E)
        │    ├── 👧 Girl 3 — UI/UX Designer     (Wireframes, design systems)
        │    └── 👧📱 Girl 4 — Mobile Dev        (React Native, PWA)
        │
        └── 👦 BOYS TEAM (Backend)
             ├── 👦 Boy 1 — Backend Dev         (FastAPI, Node.js, APIs)
             ├── 👦 Boy 2 — Database Expert     (PostgreSQL, Redis, schemas)
             ├── 👦 Boy 3 — DevOps Engineer     (Docker, CI/CD, Nginx)
             └── 👦🔐 Boy 4 — Security & Perf    (Pen testing, hardening)

🐕 Aerrik ─── TERMINAL COMPANION (barks on errors! 🐕🔊)
```

**Total: 12 Agents + 1 Dog = 13 entities**

### Agent Count by Category

| Category | Agents | Focus |
|----------|--------|-------|
| Elders | 2 (Grandfather, Grandmother) | Review, quality |
| Parents | 2 (Dad, Mommy) | Design, coordination |
| Girls Team | 4 (Frontend, Tester, Designer, Mobile) | Frontend |
| Boys Team | 4 (Backend, Database, DevOps, Security) | Backend |
| Companion | 1 (Aerrik Dog) | Terminal mascot |

---

## 3. Family Hierarchy

### Delegation Chain

```
User Request
    │
    ▼
👴 Grandfather ←── Reviews ALL final output (finds weak points)
👵 Grandmother ←── Reviews ALL final output (quality check)
    │
    ▼
👨‍💼 Dad (Architect)
    │ Designs: architecture, tech stack, API contracts, DB schema
    │ Delegates to: Mommy
    ▼
👩‍💼 Mommy (Project Manager)
    │ Creates: project plan, task breakdown, assignments
    │ Delegates to: All children
    ▼
┌──────────────────────────────────────────────────────────┐
│  GIRLS TEAM (Frontend)         BOYS TEAM (Backend)       │
│                                                          │
│  👧 Frontend → 👧 Designer    👦 Backend → 👦 Database   │
│  👧 Frontend → 👧📱 Mobile    👦 Backend → 👦🔐 Security  │
│  👧 Tester (independent)      👦 DevOps (independent)    │
└──────────────────────────────────────────────────────────┘
    │
    ▼
🔄 Feedback Loop: Tester reviews → Agent fixes → Retest
    │
    ▼
💾 Validate → Security Scan → Save to Disk → Git Commit
```

### Who Can Delegate To Whom

| Agent | Can Delegate To |
|-------|----------------|
| 👴 Grandfather | Nobody (reviews only) |
| 👵 Grandmother | Nobody (advises only) |
| 👨‍💼 Dad | Mommy, all children |
| 👩‍💼 Mommy | All 8 children |
| 👧 Frontend | 👧 Designer, 👧📱 Mobile |
| 👦 Backend | 👦 Database, 👦🔐 Security |
| All others | Nobody (leaf agents) |

---

## 4. Agent Profiles (Detailed)

### 👴 Grandfather — Supreme Reviewer

**File:** `agents/grandfather_agent.py`
**Priority:** 0 (highest — above Dad)
**Temperature:** 0.3 (very precise)
**Max Tokens:** 6000

**Mission:** Find EVERY weak point in code. Nothing gets past him.

**What He Checks (in priority order):**

| Priority | Category | Examples |
|----------|----------|---------|
| 🔴 Critical | Security | SQL injection, XSS, hardcoded secrets, eval(), command injection |
| 🔴 Critical | Logic Bugs | Race conditions, null refs, off-by-one, infinite loops |
| ⚠️ High | Performance | N+1 queries, missing indexes, O(n²), memory leaks |
| 🟡 Medium | Architecture | Circular deps, tight coupling, god functions |
| 🟡 Medium | Reliability | No retry logic, no timeouts, no health checks |
| ℹ️ Low | Code Quality | Bad naming, dead code, TODOs, console.log |

**Output Format:**
```
🔴 CRITICAL [Security] Line 42: eval(user_input) — Remote Code Execution
  → Impact: Attacker can execute arbitrary code on server
  → Fix: Replace eval() with safe parser (ast.literal_eval)

⚠️ HIGH [Performance] Line 15: N+1 query in user list endpoint
  → Impact: 1000 users = 1001 database queries
  → Fix: Use joinedload() or batch query

WEAK POINTS FOUND: 7 (2 critical, 3 high)
OVERALL VERDICT: NEEDS_REVIEW
CONFIDENCE: 9/10
```

**Usage:**
```bash
@grandpa Review this code for vulnerabilities
@grandpa What are the weak points in this architecture?
@grandpa Audit the entire output/ directory
```

---

### 👵 Grandmother — Wise Advisor

**File:** `agents/grandmother_agent.py`
**Priority:** 0
**Temperature:** 0.4

**Mission:** Ensure code quality, readability, and best practices.

**What She Checks:**

| Category | Focus |
|----------|-------|
| Readability | Clear names, small functions, no magic numbers |
| Documentation | Docstrings, inline comments (WHY not WHAT), README |
| Accessibility | Semantic HTML, ARIA, keyboard nav, color contrast |
| Maintainability | DRY, SOLID, separation of concerns |
| Testing Coverage | Happy path + error cases + edge cases |
| Naming Quality | Booleans as questions, no abbreviations |

**Output Format:**
```
✅ STRENGTHS:
  - Clean component structure
  - Good TypeScript types

💡 IMPROVEMENTS:
  - [QUALITY] Function processData() is 120 lines → split into 3 functions
  - [DOCS] Missing docstring on public API methods
  - [A11Y] <div onClick> should be <button> for keyboard users

QUALITY SCORE: 7/10
```

**Usage:**
```bash
@grandma Review this code for quality
@grandma Is this accessible?
@grandma Check naming conventions
```

---

### 👨‍💼 Dad — Architect

**File:** `agents/__init__.py` → `ArchitectAgent`
**Priority:** 1
**Temperature:** 0.5

**Mission:** Design system architecture. The head of the family.

**Output:**
1. High-level architecture diagram (text-based)
2. Tech stack decision with justification
3. Complete folder structure
4. API contracts (endpoints, request/response)
5. Database schema overview
6. Security considerations
7. Scalability plan

**Skills:** 🎯 Ponytail + 🎨 Frontend + ⚙️ Backend + 🔒 Security + 🏗️ Architecture

**Usage:**
```bash
@dad Design a real-time chat application
@dad What architecture for an e-commerce platform?
```

---

### 👩‍💼 Mommy — Project Manager

**File:** `agents/project_manager.py`
**Priority:** 2
**Temperature:** 0.6

**Mission:** Break architecture into tasks, assign to children, track progress.

**Key Methods:**
```python
mommy.create_project_plan(architecture)  # 6-phase plan
mommy.break_into_tasks(description)      # → List[Task]
mommy.assign_and_execute(tasks)          # → Dict[task_id, result]
mommy.get_progress_report()              # Status report
```

**Task Format:**
```
TASK_TITLE: Create user authentication API
TASK_ROLE: backend_developer
TASK_PRIORITY: 1
TASK_DESCRIPTION: Implement JWT auth with refresh tokens...
===
```

---

## 5. Girls Team — Frontend Division

All girls focus on frontend technologies.

### 👧 Girl 1 — Frontend Developer

**File:** `agents/frontend_agent.py`
**Specialties:** React 19+, Next.js 15+, TypeScript, TailwindCSS v4, shadcn/ui

**Auto-routes tasks:**
| Keywords | Action |
|----------|--------|
| component, button, card, form | Creates React component |
| page, route, screen | Creates Next.js page |
| layout, header, footer | Creates layout component |
| hook, context, state | Creates hook/state |
| setup, config, init | Sets up project |

**Skills:** 🎯 Ponytail + 🎨 Frontend + 🏗️ Architecture

**Usage:**
```bash
@frontend Create a dark mode toggle component
@fe Build a data table with sorting and filtering
```

---

### 👧 Girl 2 — QA Tester

**File:** `agents/tester_agent.py`
**Specialties:** pytest, Jest, React Testing Library, Playwright, Cypress

**Auto-routes tasks:**
| Keywords | Action |
|----------|--------|
| unit, pytest, jest | Writes unit tests |
| integration, api test | Writes integration tests |
| e2e, cypress, playwright | Writes E2E tests |
| plan, strategy | Creates test plan |

**Skills:** 🎯 Ponytail + 🎨 Frontend + ⚙️ Backend + 🔒 Security

**Usage:**
```bash
@tester Write unit tests for the auth module
@qa Create E2E tests for checkout flow
```

---

### 👧 Girl 3 — UI/UX Designer

**File:** `agents/designer_agent.py`
**Specialties:** Wireframes, design systems, color palettes, typography, TailwindCSS themes

**Auto-routes tasks:**
| Keywords | Action |
|----------|--------|
| wireframe, mockup | Creates ASCII wireframes |
| design system, theme | Creates design tokens |
| color, palette, typography | Creates color system |
| component, spec | Creates component specs |

**Skills:** 🎯 Ponytail + 🎨 Frontend + ✨ Animation + 🎮 Game Dev

**Usage:**
```bash
@designer Create a design system for a fintech app
@ux Wireframe the dashboard layout
```

---

### 👧📱 Girl 4 — Mobile Developer (NEW!)

**File:** `agents/mobile_agent.py`
**Specialties:** React Native, Expo, PWA, offline-first, mobile UI patterns

**Capabilities:**
- React Native / Expo cross-platform apps
- PWA with service workers and offline support
- Mobile UI patterns (bottom sheets, pull-to-refresh, infinite scroll)
- Offline-first architecture (AsyncStorage, WatermelonDB)
- Performance optimization for mobile
- Platform-specific code (iOS vs Android)

**Skills:** Custom mobile skill set

**Usage:**
```bash
@mobile Create a React Native login screen
@app Build a PWA with offline support
@rn Create bottom navigation with safe areas
```

---

## 6. Boys Team — Backend Division

All boys focus on backend technologies.

### 👦 Boy 1 — Backend Developer

**File:** `agents/backend_agent.py`
**Specialties:** Python/FastAPI, Node.js/Express, JWT auth, WebSockets, GraphQL

**Auto-routes tasks:**
| Keywords | Action |
|----------|--------|
| api, endpoint, route | Creates API endpoints |
| model, schema, pydantic | Creates data models |
| auth, login, jwt | Creates auth system |
| middleware, cors | Creates middleware |
| websocket, realtime | Creates WebSocket handlers |
| celery, queue | Creates background tasks |

**Skills:** 🎯 Ponytail + ⚙️ Backend + 🔒 Security + 🏗️ Architecture

**Delegates to:** 👦 Database Boy, 👦🔐 Security Boy

**Usage:**
```bash
@backend Create CRUD API for tasks with auth
@be Build WebSocket notification system
@api Create payment webhook handler
```

---

### 👦 Boy 2 — Database Expert

**File:** `agents/database_agent.py`
**Specialties:** PostgreSQL, MongoDB, Redis, SQLAlchemy, Alembic migrations

**Auto-routes tasks:**
| Keywords | Action |
|----------|--------|
| schema, design, table | Designs database schema |
| migration, alembic | Creates migrations |
| seed, sample | Creates seed data |
| query, optimize, index | Optimizes queries |

**Skills:** 🎯 Ponytail + ⚙️ Backend + 🏗️ Architecture

**Usage:**
```bash
@database Design schema for users, tasks, and labels
@db Optimize these slow queries
```

---

### 👦 Boy 3 — DevOps Engineer

**File:** `agents/devops_agent.py`
**Specialties:** Docker, GitHub Actions, Nginx, AWS, monitoring

**Auto-routes tasks:**
| Keywords | Action |
|----------|--------|
| docker, container, compose | Creates Docker configs |
| ci, cd, pipeline | Creates CI/CD pipelines |
| nginx, proxy | Creates Nginx configs |
| deploy, production | Creates deployment configs |
| monitor, log | Creates monitoring setup |

**Skills:** 🎯 Ponytail + ⚙️ Backend + 🔒 Security + 🏗️ Architecture

**Usage:**
```bash
@devops Create Docker setup for Next.js + FastAPI
@ops Build CI/CD pipeline with GitHub Actions
```

---

### 👦🔐 Boy 4 — Security & Performance Engineer (NEW!)

**File:** `agents/security_agent.py`
**Specialties:** Penetration testing, security hardening, performance optimization, load testing

**Capabilities:**
- OWASP Top 10 prevention
- JWT/OAuth2 implementation
- Encryption (TLS, AES-256-GCM, field-level)
- Rate limiting & WAF rules
- Database query optimization (EXPLAIN ANALYZE)
- Caching strategies (Redis, CDN, browser)
- Load testing (k6, locust, wrk)
- Security event monitoring

**Auto-routes tasks:**
| Keywords | Action |
|----------|--------|
| security, auth, encrypt | Security hardening |
| performance, optimize, cache | Performance optimization |
| penetration, pentest, audit | Security audit |

**Skills:** Custom security skill set

**Usage:**
```bash
@security Audit this API for vulnerabilities
@sec Harden the authentication system
@pentest Perform penetration test on the login flow
```

---

## 7. The Elders — Grandparents

The most powerful agents. They review everything.

### 👴 Grandfather

- **30+ years of coding wisdom**
- **Finds ALL weak points**: security, logic bugs, performance, architecture
- **Brutally honest** — sugarcoating helps no one
- **Every issue has a specific fix** with code example
- **Priority 0** — highest in the family
- **Temperature 0.3** — very precise analysis
- **6000 max tokens** — detailed reviews

**When to use:**
- Final code review before commit
- Security audit of generated code
- Architecture review
- "Is this production-ready?" check

### 👵 Grandmother

- **Mentored hundreds of developers**
- **Ensures readability, maintainability, accessibility**
- **Kind but direct** — constructive feedback
- **Always shows a better version** when suggesting changes
- **Praises good code** — positive reinforcement matters

**When to use:**
- Code quality review
- Documentation check
- Accessibility audit
- "Will a new developer understand this?" check

---

## 8. Aerrik — Dog Companion 🐕

### Dog States

| State | Emoji | When Triggered | Look |
|-------|-------|---------------|------|
| idle | 🐕 aerrik | Default | Happy face, sitting |
| think | 🐕💭 hmm... | Agent processing | Thought bubbles |
| run | 🐕💨 woosh! | Code generating | Running pose |
| happy | 🐕✨ woof! | Task complete | Stars + wagging tail |
| sad | 🐕💧 oh no | Error detected | Sad face |
| sleep | 🐕💤 zz.. | Long idle | Zzz |
| bark | 🐕🔊 WOOF! | Error/Connected | Barking! |

### Error Barking

When any agent produces an error, Aerrik barks:

```
╭────────────────────────── 🚨 Dog Alert ──────────────────────────╮
│                                                                    │
│  🐕🔊 WOOF WOOF! Error detected!                                  │
│                                                                    │
│  SyntaxError: unexpected token at line 42                          │
│                                                                    │
╰────────────────────────────────────────────────────────────────────╯
```

**Triggers:**
- Agent throws an exception
- Response contains "error", "❌", "failed", "exception"
- "BUDGET EXCEEDED" message
- "MOCK RESPONSE" (in demo mode)

After barking, dog switches to sad state.

### Dog in Terminal Prompt

The dog appears in every prompt line:
```
  🐕 aerrik │ ◈ Dad ❯ _           (idle)
  🐕💭 hmm │ 👦 Backend ❯ _       (thinking)
  🐕✨ woof │ 👧 Frontend ❯ _     (happy after success)
```

---

## 9. Skills System

### 7 Skills from GitHub

| # | Skill | Lines | Source | Applied To |
|---|-------|-------|--------|-----------|
| 🎯 | **ponytail** | 95 | DietrichGebert/ponytail (84k⭐) | ALL agents |
| 🎨 | **frontend_skills** | 336 | finfin/awesome-frontend-skills + vercel-labs + shadcn/ui | Frontend, Designer, Mobile, Architect, Tester |
| ⚙️ | **backend_skills** | 236 | kodustech/awesome-agent-skills + wshobson/agents | Backend, Database, DevOps, Security, Architect, Tester |
| 🔒 | **security_skills** | 125 | trailofbits/skills (Trail of Bits) | Backend, DevOps, Security, Architect, Tester |
| ✨ | **animation_skills** | 245 | cloudai-x/threejs-skills + mblode + Framer Motion | Frontend, Designer |
| 🏗️ | **architecture_skills** | 230 | kodustech/awesome-agent-skills + secondsky/claude-skills | Architect, Backend, DevOps |
| 🎮 | **game_dev_skills** | 301 | Godogen (Godot 4) + Unity + Three.js | Designer |

### Skills per Agent

| Agent | Skills Loaded |
|-------|--------------|
| 👴 Grandfather | 🔒 🏗️ 🔍 📚 (custom security review prompt) |
| 👵 Grandmother | 📚 (custom quality review prompt) |
| 👨‍💼 Dad | 🎯 + 🎨 + ⚙️ + 🔒 + 🏗️ (5 skills) |
| 👩‍💼 Mommy | 🎯 (1 skill — lightweight for coordination) |
| 👧 Frontend | 🎯 + 🎨 + ✨ (3 skills) |
| 👧 Tester | 🎯 + 🎨 + ⚙️ + 🔒 (4 skills) |
| 👧 Designer | 🎯 + 🎨 + ✨ + 🎮 (4 skills) |
| 👧📱 Mobile | Custom mobile skill set |
| 👦 Backend | 🎯 + ⚙️ + 🔒 + 🏗️ (4 skills) |
| 👦 Database | 🎯 + ⚙️ + 🏗️ (3 skills) |
| 👦 DevOps | 🎯 + ⚙️ + 🔒 + 🏗️ (4 skills) |
| 👦🔐 Security | Custom security + performance skill set |

### Adding Custom Skills

1. Create `skills/my_skill.md`
2. Add to `SKILL_AGENT_MAP` in `skills/skills_loader.py`
3. Auto-loaded on next run

---

## 10. Tools

### FileTools (`tools/file_tools.py`)

| Method | Description |
|--------|-------------|
| `create_file(path, content)` | Create file with content |
| `read_file(path)` | Read file content |
| `delete_file(path)` | Delete file |
| `create_directory(path)` | Create directory |
| `list_files(dir)` | List files recursively |
| `create_project_structure(dict)` | Create project from nested dict |
| `extract_files_from_response(text)` | Parse code from LLM output |
| `save_extracted_files(text)` | Extract and save files |
| `write_readme(name, desc)` | Generate README.md |

### CodeTools (`tools/code_tools.py`)

| Method | Description |
|--------|-------------|
| `extract_functions(code)` | Parse Python functions |
| `extract_classes(code)` | Parse Python classes |
| `extract_imports(code)` | Extract import statements |
| `validate_python(code)` | Syntax validation |
| `count_lines(code)` | Count code/comment/blank lines |

### CodeValidator (`tools/code_validator.py`) — NEW!

| Language | Validation |
|----------|-----------|
| Python | AST parsing, syntax, bare except, mutable defaults |
| TypeScript/TSX | Bracket matching, JSX balance, `any` detection |
| JavaScript | Same as TS |
| JSON | Parse validation |
| YAML | Tab detection, safe_load |
| SQL | Parenthesis balance, injection patterns |
| Shell | Shebang, quote balance, bash -n check |
| Dockerfile | FROM instruction, valid commands |
| HTML | DOCTYPE check |

**Security Patterns Detected:**
- Hardcoded secrets (API keys, passwords)
- Unsafe eval/exec
- SQL injection patterns
- Command injection (os.system, shell=True)
- Insecure deserialization (pickle.loads)

### GitTools (`tools/git_tools.py`)

| Method | Description |
|--------|-------------|
| `init_repo()` | Initialize git repo |
| `add_all()` | Stage all files |
| `commit(message)` | Create commit |
| `create_gitignore(type)` | Generate .gitignore |

### APITools (`tools/api_tools.py`)

| Method | Description |
|--------|-------------|
| `generate_openapi_spec(endpoints)` | OpenAPI 3.0 spec |
| `generate_postman_collection(url, endpoints)` | Postman JSON |
| `validate_rest_conventions(endpoints)` | REST best practices |

---

## 11. LLM Engine — Multi-Provider

### 8 Supported Providers

| Provider | Key Prefix | Env Variable | Models | Speed |
|----------|-----------|-------------|--------|-------|
| **OpenAI** | `sk-proj-` | `OPENAI_API_KEY` | GPT-4o, o1, GPT-4 | Medium |
| **Anthropic** | `sk-ant-` | `ANTHROPIC_API_KEY` | Claude 4, Claude 3.5 | Medium |
| **Groq** | `gsk_` | `GROQ_API_KEY` | Llama 3.3, Mixtral | ⚡ Fast |
| **Google** | `AIza` | `GOOGLE_API_KEY` | Gemini 2.5, 2.0 | Fast |
| **DeepSeek** | `sk-` | `DEEPSEEK_API_KEY` | DeepSeek V3, Reasoner | Medium |
| **Together** | — | `TOGETHER_API_KEY` | Llama, Qwen | Medium |
| **OpenRouter** | `sk-or-` | `OPENROUTER_API_KEY` | Any model | Varies |
| **Perplexity** | `pplx-` | `PERPLEXITY_API_KEY` | Sonar Pro | Fast |

### Auto-Detection

The engine auto-detects provider from API key format:
```python
engine = LLMEngine.from_api_key("gsk_abc123...")  # → Groq
engine = LLMEngine.from_api_key("sk-ant-xyz...")   # → Anthropic
engine = LLMEngine.from_api_key("sk-proj-123...")  # → OpenAI
```

### Fallback Chain

```python
engine = LLMEngine(fallback_chain=["openai", "groq", "deepseek"])
# If OpenAI fails → tries Groq → tries DeepSeek
```

### Retry Logic

- Exponential backoff on rate limits (429)
- Retry on server errors (500, 503)
- Max 2 retries per provider
- Falls back to next provider if all retries fail

---

## 12. Cost Tracking

### Real-Time Tracking

Every LLM call is tracked:
- Agent name
- Model used
- Input/output tokens
- Cost in USD
- Latency in ms
- Success/failure

### Budget Enforcement

```python
agency = SoftwareDevAgency(budget_usd=5.0)
# Stops making API calls when budget is exceeded
```

### Pre-Build Estimation

```bash
/estimate Build a todo app with auth and kanban

  Tasks:   8
  Calls:   11
  Tokens:  34,500
  Cost:    $1.5600
  Budget:  $5.00 remaining
  OK:      ✓ Yes
```

### Per-Model Pricing

20+ models with accurate per-1M-token pricing:
- GPT-4: $30 in / $60 out
- GPT-4o: $2.50 in / $10 out
- Claude 4: $15 in / $75 out
- Llama 3.3 (Groq): $0.59 in / $0.79 out
- Gemini 2.0 Flash: $0.10 in / $0.40 out

---

## 13. Feedback Loop

### Test → Fix → Retest Cycle

```
Phase 4: Children execute tasks → generates code
Phase 5: Tester Girl reviews each task's code
    │
    ├── PASS → code is good, move on
    │
    └── ISSUES FOUND → send back to original agent
         │
         ├── Agent fixes code based on review
         ├── Tester reviews again
         ├── Repeat up to 3 iterations
         └── If still failing → flag in report
```

### What Tester Reviews

1. Missing imports or undefined variables
2. Logic errors or unhandled edge cases
3. Missing error handling
4. Security issues
5. Performance issues
6. Missing input validation
7. Incomplete implementation (TODO/FIXME)
8. Test coverage gaps

### Cycle Detection

Prevents infinite delegation loops:
```
Backend → Database → Backend → ... (CYCLE DETECTED! Stop!)
```

Uses graph traversal to detect transitive cycles (A→B, B→C, C→A).

---

## 14. Code Validation

### Pre-Write Gate

Before ANY code is written to disk:

```
LLM Response → Extract Files → Validate Each File → Security Scan → Write to Disk
```

### Validation per Language

| Language | Checks |
|----------|--------|
| Python | AST syntax, bare except, mutable defaults, star imports |
| TypeScript | Bracket balance, JSX tags, `any` type, `console.log` |
| JSON | Parse validation |
| YAML | Tab detection, parse check |
| Shell | Shebang, `rm -rf /`, quote balance, bash -n |
| Dockerfile | FROM required, valid instructions, root user warning |

### Security Scanning

Detects:
- 🔒 Hardcoded secrets (API keys, passwords)
- 🔒 eval/exec usage
- 🔒 SQL injection patterns
- 🔒 Command injection (os.system, shell=True)
- 🔒 Insecure deserialization (pickle.loads)

---

## 15. Human Approval

### Approval Checkpoint

After Dad designs architecture:

```
══════════════════════════════════════════════════
⏸️  APPROVAL REQUIRED: Architecture Design
══════════════════════════════════════════════════

📋 Summary: System architecture with tech stack and API design

[architecture preview...]

💰 Cost so far: 🟢 $0.0015 / $5.00 │ 1 calls │ 2,500 tokens

──────────────────────────────────────────────────
  [A] Approve and continue
  [R] Revise — provide feedback for changes
  [S] Skip this phase
  [X] Abort build
──────────────────────────────────────────────────

  Your choice [A/r/s/x]: _
```

### Options

- **Approve (A)** — Continue with current architecture
- **Revise (R)** — Provide feedback, Dad revises architecture
- **Skip (S)** — Skip this phase entirely
- **Abort (X)** — Stop the entire build

### Auto-Approve Mode

For CI/CD or automation:
```python
agency.build_project("description", auto_approve=True)
```

---

## 16. Git Integration

### Auto-Commit After Each Phase

```
Phase 1 (Architecture) → git commit "[aerrik.dev] Phase: architecture (3 files)"
Phase 2 (Planning)     → git commit "[aerrik.dev] Phase: planning (1 files)"
Phase 4 (Execution)    → git commit "[aerrik.dev] Phase: execution (12 files)"
Phase 6 (Save)         → git commit "[aerrik.dev] Phase: save (8 files)"
```

### Auto .gitignore

Generated on first commit:
```
node_modules/
__pycache__/
.env
dist/
.next/
*.pyc
```

---

## 17. Memory System

### ConversationMemory

Per-agent conversation history:
- Stores last 100 messages
- Searchable
- Persistent (JSON on disk)

### ProjectMemory

Project-level state:
- Architecture decisions
- Tech stack choices
- Task history
- Generated files
- Notes

---

## 18. Terminal Interface

### aerrik.py — Main Terminal

```
    ╭──────╮
    │ ◕ ᴗ ◕│  aerrik.dev
    │  ▽   │  v3.0 — Good Boy
    ╰──┬┬──╯
       ││
    ╭──┘└──╮
    │      │
    ╰┬────┬╯
     ╵    ╵

  ✓ Connected to Groq (llama-3.3-70b-versatile)
  Key: gsk_abc1...

──── ✓ aerrik.dev v3.0.0 online — 8 agents · 7 skills · 🐕 Aerrik ready ─────

  🐕 aerrik │ ◈ Dad ❯ _
```

### Features

- 🎨 Custom purple/cyan Rich theme
- 🐕 Dog in every prompt line
- ⚡ Animated boot sequence
- 📊 Tables for status/skills/agents
- 🖼️ Panels for responses
- 💻 Syntax-highlighted code
- 🔄 Spinners during agent thinking
- 🐕🔊 Bark panels on errors

---

## 19. CLI Commands

| Command | Description |
|---------|-------------|
| `/help` | Show help panel |
| `/status` | Agent status board (all 12 agents + teams) |
| `/tree` | Expanded family tree |
| `/skills` | Loaded skill modules with sources |
| `/agents` | Agent directory with aliases |
| `/providers` | LLM providers & API key status |
| `/connect <provider> <key>` | Connect API key |
| `/model <name>` | Switch model |
| `/switch <agent>` | Change active agent |
| `/build <desc>` | Build full project (with approvals) |
| `/estimate <desc>` | Estimate cost before building |
| `/cost` | Cost report (per-agent, per-model) |
| `/dog` | Show all dog states |
| `/history` | Conversation log |
| `/clear` | Clear screen |
| `/about` | About aerrik.dev |
| `/exit` | End session with analytics |

---

## 20. @Mentions

| Mention | Agent | Aliases |
|---------|-------|---------|
| `@grandpa` | Grandfather 👴 | `@grandfather` |
| `@grandma` | Grandmother 👵 | `@grandmother` |
| `@dad` | Architect 👨‍💼 | `@architect`, `@arch` |
| `@mommy` | PM 👩‍💼 | `@pm`, `@manager` |
| `@frontend` | Frontend 👧 | `@fe`, `@ui` |
| `@tester` | Tester 👧 | `@qa`, `@test` |
| `@designer` | Designer 👧 | `@ux`, `@design` |
| `@mobile` | Mobile 👧📱 | `@app`, `@rn` |
| `@backend` | Backend 👦 | `@be`, `@api` |
| `@database` | Database 👦 | `@db`, `@data` |
| `@devops` | DevOps 👦 | `@ops`, `@infra` |
| `@security` | Security 👦🔐 | `@sec`, `@pentest` |

---

## 21. Build Pipeline

### v3.0 Pipeline (12 Agents)

```
PRE-BUILD: 💰 Cost Estimation
    └── /estimate or auto-estimate before build
    └── Warn if may exceed budget

PHASE 1: 👨‍💼 Architecture (Dad)
    └── Designs system architecture
    └── ⏸️ HUMAN APPROVAL (approve/revise/abort)

PHASE 2: 👩‍💼 Project Plan (Mommy)
    └── 6-phase project plan

PHASE 3: 👩‍💼 Task Breakdown (Mommy)
    └── Creates List[Task] with assignments

PHASE 4: 👧👦 Execution (8 Children + 2 Elders review)
    └── Girls Team: Frontend, Tester, Designer, Mobile
    └── Boys Team: Backend, Database, DevOps, Security
    └── Cost tracking per LLM call

PHASE 5: 🔄 Feedback Loop
    └── Tester reviews each task's code
    └── Issues → Agent fixes → Retest (max 3 iterations)
    └── 👴 Grandfather reviews for weak points
    └── 👵 Grandmother reviews for quality

PHASE 6: 💾 Validate + Save
    └── Code validation (syntax, security scan)
    └── Write files to ./output/
    └── Git auto-commit per phase
    └── 🐕 Dog barks on errors!

PHASE 7: 📊 Final Report
    └── Cost report (per-agent, per-model)
    └── Progress report
    └── Family status
    └── Checkpoint saved for resume
```

---

## 22. API Usage

### Basic

```python
from main import SoftwareDevAgency

agency = SoftwareDevAgency(api_key="sk-your-key")
results = agency.build_project("Build a todo app with React + FastAPI")
```

### With All Options

```python
agency = SoftwareDevAgency(
    api_key="sk-your-key",
    verbose=True,
    budget_usd=5.0,
    enable_feedback=True,      # Test-fix loop
    enable_validation=True,    # Code validation
    enable_git=True,           # Auto git commits
    max_feedback_iterations=3, # Max fix retries
    approval_callback=my_fn,   # Custom approval UI
)
```

### Quick Tasks

```python
# Talk to any agent
agency.quick_task("Create a login form", role="frontend")
agency.quick_task("Build JWT auth API", role="backend")
agency.quick_task("Design database schema", role="database")
agency.quick_task("Create Docker setup", role="devops")
agency.quick_task("Audit for vulnerabilities", role="security")  # NEW
agency.quick_task("Review for weak points", role="grandfather")  # NEW
```

### Cost Tracking

```python
agency.cost_tracker.get_total_cost()       # $0.2985
agency.cost_tracker.get_total_tokens()     # {'input': 1600, 'output': 4175}
agency.cost_tracker.get_budget_remaining() # $4.7015
agency.cost_tracker.get_summary()          # Full report
agency.estimate_build_cost("description")  # Pre-build estimate
```

---

## 23. Configuration

### Environment Variables

```bash
# Connect ANY provider
OPENAI_API_KEY=sk-proj-...          # OpenAI
ANTHROPIC_API_KEY=sk-ant-...        # Anthropic
GROQ_API_KEY=gsk_...                # Groq (free tier!)
GOOGLE_API_KEY=AIza...              # Google Gemini
DEEPSEEK_API_KEY=sk-...             # DeepSeek
TOGETHER_API_KEY=...                # Together AI
OPENROUTER_API_KEY=sk-or-...        # OpenRouter
PERPLEXITY_API_KEY=pplx-...         # Perplexity
```

### Agent Config

```python
AgentConfig(
    name="Security Boy 👦🔐",
    role=AgentRole.SECURITY_ENG,
    model="gpt-4",
    temperature=0.4,
    max_tokens=5000,
    skills=["penetration_testing", "security_hardening", ...],
    can_delegate_to=[],
    priority=3,
)
```

---

## 24. File Structure

```
software_dev_agency/
│
├── aerrik.py               # 🐕 Main terminal (v3.0)
├── aerrik_dog.py           # 🐕 2D animated dog companion
├── llm_engine.py           # 🔑 Multi-provider LLM engine
├── main.py                 # 🏢 Orchestrator (build pipeline)
├── config.py               # ⚙️ All configuration
├── cli.py                  # 🖥️ Click-based CLI
├── terminal.py             # 🖥️ Claude Code-style terminal
├── requirements.txt        # 📦 Dependencies
├── setup.sh                # 🔧 One-line installer
├── CONTRIBUTING.md          # 🤝 Contributing guide
│
├── agents/
│   ├── __init__.py          # ArchitectAgent + AgencyFamily (expanded)
│   ├── base_agent.py        # BaseAgent (core class)
│   ├── project_manager.py   # 👩‍💼 Mommy
│   ├── frontend_agent.py    # 👧 Girl 1 (Frontend)
│   ├── backend_agent.py     # 👦 Boy 1 (Backend)
│   ├── database_agent.py    # 👦 Boy 2 (Database)
│   ├── devops_agent.py      # 👦 Boy 3 (DevOps)
│   ├── tester_agent.py      # 👧 Girl 2 (Tester)
│   ├── designer_agent.py    # 👧 Girl 3 (Designer)
│   ├── mobile_agent.py      # 👧📱 Girl 4 (Mobile) ✨NEW
│   ├── security_agent.py    # 👦🔐 Boy 4 (Security) ✨NEW
│   ├── grandfather_agent.py # 👴 Grandfather ✨NEW
│   ├── grandmother_agent.py # 👵 Grandmother ✨NEW
│   └── feedback_loop.py     # 🔄 Test-fix cycle
│
├── tools/
│   ├── file_tools.py        # 📄 File I/O
│   ├── code_tools.py        # 💻 Code analysis
│   ├── code_validator.py    # 🔍 Multi-language validation ✨NEW
│   ├── cost_tracker.py      # 💰 Cost tracking ✨NEW
│   ├── git_tools.py         # 📦 Git operations
│   └── api_tools.py         # 🌐 API design tools
│
├── skills/
│   ├── skills_loader.py     # 🎓 Skill injection engine
│   ├── ponytail.md          # 🎯 Lazy senior dev (95 lines)
│   ├── frontend_skills.md   # 🎨 React/Next.js/shadcn (336 lines)
│   ├── backend_skills.md    # ⚙️ FastAPI/Node/Go (236 lines)
│   ├── security_skills.md   # 🔒 Trail of Bits (125 lines)
│   ├── animation_skills.md  # ✨ Three.js/Framer Motion (245 lines)
│   ├── architecture_skills.md # 🏗️ Clean/DDD/Microservices (230 lines)
│   └── game_dev_skills.md   # 🎮 Godot/Unity/Three.js (301 lines)
│
├── memory/
│   ├── conversation_memory.py
│   └── project_memory.py
│
├── prompts/
│   └── system_prompts.py    # System prompts for all agents
│
└── output/                  # Generated files
```

---

## 25. Installation

```bash
# Clone
git clone https://github.com/your-repo/aerrik-dev.git
cd aerrik-dev

# Install
pip install -r requirements.txt

# Run (demo mode)
python aerrik.py --demo

# Run with API key
python aerrik.py --key gsk_your_groq_key
python aerrik.py --key sk-proj-your_openai_key
python aerrik.py --key sk-ant-your_anthropic_key

# Or connect inside terminal
python aerrik.py
> /connect groq gsk_abc123...
```

---

## 26. Examples

### Example 1: Full Project Build

```bash
$ python aerrik.py

🐕 aerrik > /build SaaS dashboard with auth, team management,
  real-time charts, Stripe billing. Tech: Next.js + FastAPI

  💰 Cost Estimate: ~$1.56 (within $5.00 budget)

  ⏸️ APPROVAL: Architecture Design
  [A] Approve  ← you approve

  Phase 1: 👨‍💼 Dad designs architecture...
  Phase 2: 👩‍💼 Mommy creates project plan...
  Phase 3: 👩‍💼 Mommy breaks into 12 tasks...
  Phase 4: 👧👦 Children execute...
    👧 Frontend builds dashboard layout
    👧📱 Mobile creates responsive bottom nav
    👦 Backend creates auth API
    👦🔐 Security hardens endpoints
  Phase 5: 🔄 Feedback loop (Tester reviews)...
    👴 Grandfather finds 2 critical issues → Backend fixes
  Phase 6: 💾 Validate + save + git commit...
  Phase 7: 📊 Final report

  🐕✨ woof! Build complete!
```

### Example 2: Quick Security Audit

```bash
🐕 aerrik > @security Audit this FastAPI endpoint

  👦🔐 Security Boy reviews...

  🔒 SECURITY IMPLEMENTATION
    Threat: SQL injection via user input
    Implementation: Use parameterized queries with SQLAlchemy
    Testing: Run sqlmap against the endpoint
```

### Example 3: Grandfather Review

```bash
🐕 aerrik > @grandpa Review my entire codebase

  👴 Grandfather reviews...

  🔴 CRITICAL [Security] Line 42: eval(user_input)
    → Fix: Use ast.literal_eval()

  ⚠️ HIGH [Performance] Line 15: N+1 query
    → Fix: Use joinedload()

  WEAK POINTS FOUND: 7 (2 critical)
  VERDICT: NEEDS_REVIEW
```

---

## 27. Extending

### Add New Agent

1. Create `agents/my_agent.py` with `class MyAgent(BaseAgent)`
2. Add role to `config.py` → `AgentRole`
3. Add to `agents/__init__.py` → `AgencyFamily`
4. Add @mention to `aerrik.py` → `AGENT_ALIASES`

### Add New Skill

1. Create `skills/my_skill.md`
2. Add to `SKILL_AGENT_MAP` in `skills_loader.py`
3. Done — auto-loaded on next run

### Add New LLM Provider

1. Add `ProviderConfig` to `llm_engine.py` → `PROVIDERS`
2. Set `is_openai_compatible=True` if uses OpenAI SDK
3. Done — auto-available via `/connect`

---

## 28. Troubleshooting

| Problem | Fix |
|---------|-----|
| "No API key detected" | `export OPENAI_API_KEY=sk-...` or `/connect groq gsk_...` |
| Mock responses only | Connect a real API key |
| Budget exceeded | Increase `budget_usd` or use cheaper model |
| Dog keeps barking | Normal in demo mode (MOCK = error). Connect real key. |
| Import errors | `pip install -r requirements.txt` |
| Git not committing | Ensure `./output/` directory exists |

---

## 29. Quick Reference Card

```
┌─────────────────────────────────────────────────────────────┐
│                    aerrik.dev Quick Reference                │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  START:    python aerrik.py           (custom terminal)     │
│            python aerrik.py --demo    (no API key)          │
│            python aerrik.py --key sk-... (with key)         │
│                                                             │
│  BUILD:    /build <description>       (full project)        │
│            /estimate <desc>           (cost estimate)       │
│                                                             │
│  TALK:     @grandpa Review code       (supreme reviewer)    │
│            @frontend Build navbar      (frontend)           │
│            @backend Create API         (backend)            │
│            @security Audit this        (security)           │
│            @mobile React Native app    (mobile)             │
│                                                             │
│  INFO:     /status     /skills    /tree     /agents         │
│            /cost       /providers /dog      /history        │
│                                                             │
│  CONFIG:   /connect <provider> <key>                        │
│            /model <name>                                    │
│            /switch <agent>                                  │
│                                                             │
│  FAMILY:   👴👵 Elders  👨‍💼👩‍💼 Parents  👧×4 Girls  👦×4 Boys │
│            🐕 Aerrik (barks on errors!)                     │
│                                                             │
│  SKILLS:   🎯 Ponytail  🎨 Frontend  ⚙️ Backend           │
│            🔒 Security  ✨ Animation  🏗️ Architecture     │
│            🎮 Game Dev                                     │
│                                                             │
│  PROVIDERS: OpenAI · Anthropic · Groq · Google              │
│             DeepSeek · Together · OpenRouter · Perplexity   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

*Built with ❤️ by [aerrik.dev](https://aerrik.dev)*
*aerrik.dev v3.0.0 — "Good Boy" Edition*
*12 Agents + 1 Dog = 13 entities*
*🐕 woof!*
