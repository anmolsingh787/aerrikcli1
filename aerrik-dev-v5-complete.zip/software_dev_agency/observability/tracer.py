"""
📊 aerrik.dev — Observability Layer

Traces every operation through the runtime:
- Task routing decisions
- Agent executions
- Tool calls
- Risk score changes
- Cost accumulation
- Validation results
- Errors and escalations

This data is Aerrik's future superpower.
"""
import time
import json
import os
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum


class SpanKind(Enum):
    TASK = "task"
    ROUTING = "routing"
    RISK_ANALYSIS = "risk_analysis"
    AGENT_EXECUTION = "agent_execution"
    TOOL_CALL = "tool_call"
    VALIDATION = "validation"
    REVIEW = "review"
    BUILD_PHASE = "build_phase"
    FEEDBACK_LOOP = "feedback_loop"
    BUG_HUNT = "bug_hunt"
    MCP_CALL = "mcp_call"


@dataclass
class Span:
    """A single traced operation"""
    id: str
    kind: SpanKind
    name: str
    parent_id: Optional[str] = None
    agent: str = ""
    status: str = "ok"          # ok, error, timeout
    duration_ms: float = 0
    metadata: Dict[str, Any] = field(default_factory=dict)
    started_at: str = field(default_factory=lambda: datetime.now().isoformat())
    tags: Dict[str, str] = field(default_factory=dict)

    def set_error(self, error: str):
        self.status = "error"
        self.metadata["error"] = error

    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "kind": self.kind.value,
            "name": self.name,
            "parent_id": self.parent_id,
            "agent": self.agent,
            "status": self.status,
            "duration_ms": round(self.duration_ms, 1),
            "metadata": self.metadata,
            "started_at": self.started_at,
            "tags": self.tags,
        }


class Tracer:
    """
    📊 Distributed tracer for Aerrik operations.

    Usage:
        tracer = Tracer()

        with tracer.span("routing", "Task Classification") as span:
            result = routing_engine.classify(task)
            span.tags["complexity"] = result.policy.value
            span.tags["score"] = str(result.final_score)
    """

    def __init__(self, session_id: str = "", storage_dir: str = ".aerrik/traces"):
        self.session_id = session_id
        self.storage_dir = storage_dir
        self._spans: List[Span] = []
        self._counter = 0

    def span(self, kind: str, name: str, agent: str = "", parent_id: str = None) -> 'SpanContext':
        """Create a new span (use as context manager)"""
        self._counter += 1
        span = Span(
            id=f"span_{self.session_id}_{self._counter:04d}",
            kind=SpanKind(kind),
            name=name,
            agent=agent,
            parent_id=parent_id,
        )
        return SpanContext(self, span)

    def record(self, span: Span):
        """Record a completed span"""
        self._spans.append(span)

    def get_trace(self, task_id: str = None) -> List[Dict]:
        """Get trace for a task or all spans"""
        spans = self._spans
        if task_id:
            spans = [s for s in spans if s.parent_id == task_id or s.id == task_id]
        return [s.to_dict() for s in spans]

    def get_summary(self) -> Dict:
        """Get trace summary statistics"""
        total = len(self._spans)
        errors = sum(1 for s in self._spans if s.status == "error")
        total_ms = sum(s.duration_ms for s in self._spans)

        # Per-kind breakdown
        by_kind: Dict[str, Dict] = {}
        for s in self._spans:
            k = s.kind.value
            if k not in by_kind:
                by_kind[k] = {"count": 0, "total_ms": 0, "errors": 0}
            by_kind[k]["count"] += 1
            by_kind[k]["total_ms"] += s.duration_ms
            if s.status == "error":
                by_kind[k]["errors"] += 1

        # Per-agent breakdown
        by_agent: Dict[str, Dict] = {}
        for s in self._spans:
            if s.agent:
                if s.agent not in by_agent:
                    by_agent[s.agent] = {"count": 0, "total_ms": 0}
                by_agent[s.agent]["count"] += 1
                by_agent[s.agent]["total_ms"] += s.duration_ms

        return {
            "session_id": self.session_id,
            "total_spans": total,
            "total_errors": errors,
            "total_duration_ms": round(total_ms, 1),
            "by_kind": by_kind,
            "by_agent": by_agent,
        }

    def save(self, filepath: str = None):
        """Save trace to disk"""
        if filepath is None:
            os.makedirs(self.storage_dir, exist_ok=True)
            filepath = os.path.join(self.storage_dir, f"trace_{self.session_id}.json")

        data = {
            "session_id": self.session_id,
            "spans": [s.to_dict() for s in self._spans],
            "summary": self.get_summary(),
            "saved_at": datetime.now().isoformat(),
        }
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)

    def format_trace(self, task_id: str = None) -> str:
        """Format trace for terminal display"""
        spans = self._spans if not task_id else [
            s for s in self._spans if s.parent_id == task_id or s.id == task_id
        ]

        lines = ["", "  ╭─── TRACE ───────────────────────────────────────────────╮"]
        for s in spans[:30]:
            icon = "✓" if s.status == "ok" else "✗"
            agent_str = f" [{s.agent}]" if s.agent else ""
            lines.append(
                f"  │ {icon} {s.kind.value:<16s} {s.name:<25s}{agent_str:<15s} {s.duration_ms:>6.0f}ms │"
            )
        if len(spans) > 30:
            lines.append(f"  │ ... and {len(spans) - 30} more spans{' ' * 30}│")
        lines.append("  ╰──────────────────────────────────────────────────────────╯")

        return "\n".join(lines)


class SpanContext:
    """Context manager for spans"""

    def __init__(self, tracer: Tracer, span: Span):
        self.tracer = tracer
        self.span = span
        self._start = 0

    def __enter__(self):
        self._start = time.time()
        return self.span

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.span.duration_ms = (time.time() - self._start) * 1000
        if exc_type:
            self.span.set_error(str(exc_val))
        self.tracer.record(self.span)
        return False  # Don't suppress exceptions


class MetricsCollector:
    """
    📈 Collects runtime metrics for dashboards/alerts.
    """

    def __init__(self):
        self._counters: Dict[str, int] = {}
        self._gauges: Dict[str, float] = {}
        self._histograms: Dict[str, List[float]] = {}

    def increment(self, name: str, value: int = 1):
        self._counters[name] = self._counters.get(name, 0) + value

    def gauge(self, name: str, value: float):
        self._gauges[name] = value

    def observe(self, name: str, value: float):
        if name not in self._histograms:
            self._histograms[name] = []
        self._histograms[name].append(value)

    def get_all(self) -> Dict:
        result = {
            "counters": self._counters.copy(),
            "gauges": self._gauges.copy(),
        }
        for name, values in self._histograms.items():
            if values:
                result[f"{name}_avg"] = round(sum(values) / len(values), 2)
                result[f"{name}_p95"] = round(sorted(values)[int(len(values) * 0.95)] if len(values) > 1 else values[0], 2)
                result[f"{name}_count"] = len(values)
        return result

    def reset(self):
        self._counters.clear()
        self._gauges.clear()
        self._histograms.clear()


class AuditLog:
    """
    📝 Immutable audit log for security-sensitive operations.
    """

    def __init__(self, storage_dir: str = ".aerrik/audit"):
        self.storage_dir = storage_dir
        os.makedirs(storage_dir, exist_ok=True)
        self._entries: List[Dict] = []

    def log(
        self,
        action: str,
        actor: str = "",
        resource: str = "",
        details: Dict = None,
        risk_level: str = "low",
    ):
        entry = {
            "timestamp": datetime.now().isoformat(),
            "action": action,
            "actor": actor,
            "resource": resource,
            "risk_level": risk_level,
            "details": details or {},
        }
        self._entries.append(entry)

    def get_entries(self, action: str = None, last_n: int = 50) -> List[Dict]:
        entries = self._entries
        if action:
            entries = [e for e in entries if e["action"] == action]
        return entries[-last_n:]

    def save(self):
        filepath = os.path.join(self.storage_dir, f"audit_{datetime.now().strftime('%Y%m%d')}.json")
        with open(filepath, 'w') as f:
            json.dump(self._entries, f, indent=2)
