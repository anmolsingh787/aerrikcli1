# Browser Visual Validation Skill

**Inspired by:** [agent-browser (Vercel)](https://github.com/vercel-labs/agent-browser) + [AgentVision](https://github.com/anthropics/agentvision)

## Pipeline

```
Frontend Agent generates code
        ↓
Dev Server starts (next dev / vite)
        ↓
Browser opens page
        ↓
Accessibility snapshot (a11y tree)
        ↓
Screenshot (full page + viewport)
        ↓
Visual analysis (vision model or deterministic checks)
        ↓
Issues found?
    YES → Send back to Frontend Agent with screenshot + issues
    NO  → Mark as validated ✓
```

## Deterministic Checks (No LLM needed)

1. **Blank render** — page has < 50 text chars → BROKEN
2. **Console errors** — any JS errors → flag
3. **404 assets** — broken images, fonts, scripts
4. **WCAG contrast** — text/background contrast ratio < 4.5:1
5. **Viewport test** — render at 375px, 768px, 1440px
6. **Interactive elements** — buttons/links have min 44px touch target
7. **Missing alt text** — images without alt attribute
8. **Focus trap** — keyboard tab through all interactive elements
9. **Lighthouse score** — performance, a11y, best practices

## Vision Model Checks (LLM needed)

1. **Layout correctness** — does the layout match the wireframe?
2. **Visual hierarchy** — heading sizes, spacing consistency
3. **Color consistency** — are brand colors used correctly?
4. **Responsive behavior** — does it look right on mobile?
5. **Dark mode** — if applicable, does dark mode look correct?

## Implementation (Python)

```python
# Requires: playwright, pillow
# pip install playwright pillow
# playwright install chromium

import subprocess
from playwright.sync_api import sync_playwright

class BrowserValidator:
    def __init__(self, base_url="http://localhost:3000"):
        self.base_url = base_url

    def validate_page(self, path="/"):
        """Full validation pipeline"""
        results = {
            "screenshots": [],
            "console_errors": [],
            "a11y_issues": [],
            "visual_issues": [],
            "viewports_tested": [],
            "passed": True,
        }

        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            page = browser.new_page()

            # Navigate
            page.goto(f"{self.base_url}{path}")
            page.wait_for_load_state("networkidle")

            # 1. Console errors
            errors = []
            page.on("console", lambda msg: errors.append(msg.text)
                     if msg.type == "error" else None)

            # 2. Multi-viewport screenshots
            for width, name in [(375, "mobile"), (768, "tablet"), (1440, "desktop")]:
                page.set_viewport_size({"width": width, "height": 800})
                screenshot_path = f"./output/screenshots/{name}.png"
                page.screenshot(path=screenshot_path, full_page=True)
                results["screenshots"].append(screenshot_path)
                results["viewports_tested"].append(name)

            # 3. Accessibility snapshot
            snapshot = page.accessibility.snapshot()
            results["a11y_snapshot"] = snapshot

            # 4. Blank render check
            text_content = page.inner_text("body")
            if len(text_content.strip()) < 50:
                results["visual_issues"].append("BLANK RENDER: < 50 chars of text")
                results["passed"] = False

            # 5. Console errors
            results["console_errors"] = errors
            if errors:
                results["passed"] = False

            browser.close()

        return results
```

## Integration with Aerrik

```python
# In the build pipeline, after Frontend Agent generates code:
if task.assigned_to == "frontend":
    # Start dev server
    subprocess.Popen(["npm", "run", "dev"], cwd="./output")
    time.sleep(5)  # Wait for server

    # Run visual validation
    validator = BrowserValidator()
    results = validator.validate_page("/")

    if not results["passed"]:
        # Send back to Frontend Agent with feedback
        feedback = format_visual_feedback(results)
        fixed_code = frontend_agent.think(f"""
Visual validation failed:
{feedback}

Fix these issues and provide updated code.
""")
```

## When to Use

- After Frontend Agent generates pages/components
- After Designer Agent creates design system
- During feedback loop (visual regression check)
- Before deployment (final visual QA)

## Limitations

- Requires running dev server
- Vision model checks need multimodal LLM (GPT-4o, Claude 3.5)
- Deterministic checks catch 80% of issues without LLM cost
- Not suitable for API-only tasks (skip for backend)
