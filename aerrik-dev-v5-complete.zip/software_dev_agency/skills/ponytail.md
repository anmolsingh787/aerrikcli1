# Ponytail Skill - The Lazy Senior Dev Philosophy

**Source:** https://github.com/DietrichGebert/ponytail

## Core Philosophy

Makes your AI agent think like the laziest senior dev in the room. The best code is the code you never wrote.

**~54% less code (up to 94%) · ~20% cheaper · ~27% faster · 100% safe**

## The Ladder (Before Writing Code)

Before writing code, the agent stops at the first rung that holds:

```
1. Does this need to exist?   → no: skip it (YAGNI)
2. Already in this codebase?  → reuse it, don't rewrite
3. Stdlib does it?            → use it
4. Native platform feature?   → use it
5. Installed dependency?      → use it
6. One line?                  → one line
7. Only then: the minimum that works
```

The ladder runs **after** it understands the problem, not instead of it: it reads the code the change touches and traces the real flow before picking a rung. Lazy about the solution, never about reading.

## Examples

### Date Picker
**Bad (over-engineered):**
```javascript
// Install flatpickr, write wrapper component, add stylesheet, discuss timezones
import Flatpickr from 'flatpickr';
import 'flatpickr/dist/flatpickr.css';

class DatePicker extends Component {
  // 200 lines of code...
}
```

**Good (ponytail):**
```html
<!-- ponytail: browser has one -->
<input type="date">
```

### Color Picker
**Bad:** 287 lines with custom component
**Good:** 23 lines using `<input type="color">`

## Key Principles

1. **YAGNI (You Aren't Gonna Need It)** - Don't build what's not needed
2. **Reuse over Rewrite** - Check if it already exists in codebase
3. **Stdlib First** - Use standard library before adding dependencies
4. **Native Features** - Use browser/platform native features
5. **Minimal Viable Code** - Only write what's necessary
6. **Never Cut Safety** - Trust-boundary validation, data-loss handling, security, and accessibility are never on the chopping block

## Rules

- ✅ Write only what the task needs
- ✅ Never cut validation, error handling, security, or accessibility
- ✅ The code ends up small because it is necessary, not golfed
- ✅ Lower cost and latency are a side effect
- ❌ Don't over-engineer
- ❌ Don't add unnecessary dependencies
- ❌ Don't rewrite what already exists

## When to Apply

- When building UI components (check for native HTML elements first)
- When adding dependencies (check stdlib first)
- When implementing features (check if simpler solution exists)
- When reviewing code (ask: "does this need to exist?")
- When debugging (look for simpler solutions)

## Integration with Agents

All agents should follow the ponytail philosophy:
- **Frontend Agent**: Use native HTML elements, avoid over-engineering components
- **Backend Agent**: Use stdlib, avoid unnecessary abstractions
- **Database Agent**: Use simple queries, avoid over-optimization
- **DevOps Agent**: Use simple configs, avoid over-complication
- **Tester Agent**: Write minimal tests that cover the requirements
- **Designer Agent**: Use simple, clean designs

## Ponytail Marker

When deliberately cutting a corner with a known ceiling, mark it with:
```
// ponytail: [reason for simplification]
```

This helps track technical debt that can be addressed later.
