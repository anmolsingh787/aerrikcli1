# Frontend Development Skills

**Sources:**
- [finfin/awesome-frontend-skills](https://github.com/finfin/awesome-frontend-skills) — React, Angular, Vue, Next.js, Nuxt, Svelte, TanStack
- [thongdn-it/react-agent-skills](https://github.com/thongdn-it/react-agent-skills) — 19-skill React ecosystem
- [mattbx/shadcn-skills](https://github.com/mattbx/shadcn-skills) — shadcn/ui component discovery
- [vercel-labs/next-skills](https://github.com/vercel-labs/next-skills) — Official Next.js 15+ skills
- [vercel/components.build](https://github.com/vercel/components.build) — Vercel component building guide

## shadcn/ui (Official Skill)

### Project Detection (auto-activates on `components.json`)
```json
{
  "$schema": "https://ui.shadcn.com/schema.json",
  "style": "new-york",
  "rsc": true,
  "tsx": true,
  "tailwind": {
    "config": "",
    "css": "src/app/globals.css",
    "baseColor": "neutral",
    "cssVariables": true
  }
}
```

### Component Composition Rules
```tsx
// ✅ Good: Use FieldGroup for form fields
import { FieldGroup, Field, Label, Input, FieldError } from "@/components/ui/field";

<FieldGroup>
  <Field>
    <Label htmlFor="email">Email</Label>
    <Input id="email" type="email" {...register("email")} />
    <FieldError>{errors.email?.message}</FieldError>
  </Field>
</FieldGroup>

// ✅ Good: Semantic color tokens (never hardcode colors)
<div className="bg-destructive/10 text-destructive">Error</div>
<div className="bg-primary text-primary-foreground">Action</div>

// ❌ Bad: Hardcoded colors
<div className="bg-red-500 text-white">Error</div>
```

### CLI Workflow
```bash
# Add components
npx shadcn@latest add button card dialog form input select table

# Add with specific variant
npx shadcn@latest add button --variant=outline

# Diff against registry (see what changed)
npx shadcn@latest diff
```

## Next.js 15+ (Official Vercel Skills)

### File Conventions
```
app/
├── layout.tsx          # Root layout (html, body)
├── page.tsx            # Homepage (/)
├── loading.tsx         # Loading UI (Suspense fallback)
├── error.tsx           # Error boundary ('use client')
├── not-found.tsx       # 404 page
├── (marketing)/        # Route group (no URL segment)
│   ├── about/page.tsx  # /about
│   └── pricing/page.tsx
├── (app)/              # Authenticated app group
│   ├── layout.tsx      # Shared app layout with sidebar
│   ├── dashboard/page.tsx
│   └── settings/page.tsx
└── api/
    └── webhook/route.ts  # Route handler
```

### RSC Boundaries
```tsx
// Server Component (default) — no 'use client'
async function ProductList() {
  const products = await db.product.findMany(); // Direct DB access
  return <ul>{products.map(p => <ProductCard key={p.id} product={p} />)}</ul>;
}

// Client Component — only when needed
'use client';
function AddToCartButton({ productId }: { productId: string }) {
  const [loading, setLoading] = useState(false);
  return <button onClick={() => addToCart(productId)} disabled={loading}>Add</button>;
}
```

### Async Params (Next.js 15+)
```tsx
// ✅ Next.js 15: params is now a Promise
export default async function Page({
  params,
}: {
  params: Promise<{ slug: string }>
}) {
  const { slug } = await params;
  const post = await getPost(slug);
  return <article>{post.content}</article>;
}
```

### Runtime Selection
```tsx
// Force Node.js runtime (for DB, fs, etc.)
export const runtime = 'nodejs';

// Force Edge runtime (for fast, lightweight)
export const runtime = 'edge';

// Dynamic rendering (no caching)
export const dynamic = 'force-dynamic';

// Static generation with revalidation
export const revalidate = 3600; // Revalidate every hour
```

## Tailwind CSS v4 (CSS-First Config)

### New CSS-First Theme
```css
/* globals.css — Tailwind v4 */
@import "tailwindcss";

@theme {
  --color-primary: oklch(0.75 0.15 250);
  --color-primary-foreground: oklch(0.98 0 0);
  --color-accent: oklch(0.85 0.12 150);
  
  --font-heading: "Inter", system-ui, sans-serif;
  --font-body: "Inter", system-ui, sans-serif;
  --font-mono: "JetBrains Mono", monospace;
  
  --radius-sm: 0.25rem;
  --radius-md: 0.5rem;
  --radius-lg: 0.75rem;
  
  --animate-fade-in: fade-in 0.3s ease-out;
  --animate-slide-up: slide-up 0.3s ease-out;
}

@keyframes fade-in {
  from { opacity: 0; }
  to { opacity: 1; }
}

@keyframes slide-up {
  from { opacity: 0; transform: translateY(8px); }
  to { opacity: 1; transform: translateY(0); }
}
```

### CVA (Class Variance Authority)
```tsx
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center rounded-md font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 disabled:pointer-events-none disabled:opacity-50",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground hover:bg-primary/90",
        destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
        outline: "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline",
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-9 rounded-md px-3",
        lg: "h-11 rounded-md px-8",
        icon: "h-10 w-10",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
);

type ButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> &
  VariantProps<typeof buttonVariants>;

function Button({ className, variant, size, ...props }: ButtonProps) {
  return (
    <button
      className={cn(buttonVariants({ variant, size, className }))}
      {...props}
    />
  );
}
```

## React Ecosystem (19 Skills)

### Forms with React Hook Form + Zod
```tsx
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

const schema = z.object({
  email: z.string().email("Invalid email"),
  password: z.string().min(8, "Min 8 characters"),
  remember: z.boolean().optional(),
});

type FormData = z.infer<typeof schema>;

function LoginForm() {
  const { register, handleSubmit, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
  });

  const onSubmit = async (data: FormData) => {
    const result = await signIn(data.email, data.password);
    if (!result.ok) setError("root", { message: result.error });
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <Input {...register("email")} error={errors.email?.message} />
      <Input {...register("password")} type="password" error={errors.password?.message} />
      <Checkbox {...register("remember")} label="Remember me" />
      <Button type="submit">Sign In</Button>
    </form>
  );
}
```

### TanStack Query (Server State)
```tsx
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

function useProducts() {
  return useQuery({
    queryKey: ["products"],
    queryFn: () => fetch("/api/products").then(r => r.json()),
    staleTime: 5 * 60 * 1000, // 5 minutes
  });
}

function useCreateProduct() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: CreateProductInput) =>
      fetch("/api/products", { method: "POST", body: JSON.stringify(data) }).then(r => r.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["products"] });
    },
  });
}
```

### URL State with nuqs
```tsx
import { useQueryState, parseAsString, parseAsInteger } from "nuqs";

function ProductFilters() {
  const [search, setSearch] = useQueryState("q", parseAsString.withDefault(""));
  const [page, setPage] = useQueryState("page", parseAsInteger.withDefault(1));
  const [sort, setSort] = useQueryState("sort", parseAsString.withDefault("newest"));

  return (
    <div>
      <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search..." />
      <Select value={sort} onValueChange={setSort}>
        <SelectItem value="newest">Newest</SelectItem>
        <SelectItem value="price-asc">Price: Low to High</SelectItem>
      </Select>
    </div>
  );
}
```

## Other Frameworks

### Angular (Standalone Components)
```typescript
@Component({
  selector: 'app-user-card',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <div class="card">
      <h3>{{ user().name }}</h3>
      <p>{{ user().email }}</p>
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class UserCardComponent {
  user = input.required<User>();
}
```

### Vue 3 + Pinia
```vue
<script setup lang="ts">
import { useCartStore } from '@/stores/cart';

const cart = useCartStore();
const { addItem, total } = storeToRefs(cart);
</script>

<template>
  <button @click="addItem(product)">Add to Cart ({{ total }})</button>
</template>
```

### SvelteKit 2 + Svelte 5
```svelte
<script lang="ts">
  let { data } = $props();
  let count = $state(0);
  
  function increment() {
    count += 1;
  }
</script>

<button onclick={increment}>
  Clicked {count} times
</button>
```
