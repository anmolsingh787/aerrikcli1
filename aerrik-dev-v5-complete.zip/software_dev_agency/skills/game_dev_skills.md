# Game Development Skills

**Sources:**
- Godogen — Godot 4 project generation from game descriptions
- Unity automation skills — 431 Unity automation skills
- Three.js game development patterns

## Godot 4 Development

### Project Structure
```
game/
├── project.godot           # Project configuration
├── scenes/                 # Scene files (.tscn)
│   ├── main.tscn
│   ├── player/
│   │   ├── player.tscn
│   │   └── player.gd
│   └── enemies/
├── scripts/                # Shared scripts
│   ├── autoload/           # Singleton managers
│   │   ├── game_manager.gd
│   │   ├── audio_manager.gd
│   │   └── save_manager.gd
│   ├── components/         # Reusable components
│   │   ├── health_component.gd
│   │   └── hitbox_component.gd
│   └── utils/
├── assets/
│   ├── sprites/
│   ├── audio/
│   ├── fonts/
│   └── tilesets/
└── addons/                 # Plugins
```

### GDScript Best Practices
```gdscript
# Use @export for editor-configurable properties
@export var speed: float = 200.0
@export var max_health: int = 100

# Use signals for decoupled communication
signal health_changed(new_health: int)
signal died

# Type everything
var _health: int
var _velocity: Vector2 = Vector2.ZERO

func _ready() -> void:
    _health = max_health

func _physics_process(delta: float) -> void:
    _handle_input(delta)
    _apply_movement(delta)

func take_damage(amount: int) -> void:
    _health = max(0, _health - amount)
    health_changed.emit(_health)
    if _health <= 0:
        died.emit()
```

### State Machine Pattern
```gdscript
class_name StateMachine extends Node

var _current_state: State
var _states: Dictionary = {}

func _ready() -> void:
    for child in get_children():
        if child is State:
            _states[child.name.to_lower()] = child
            child.transitioned.connect(_on_transition)
    
    if _states.size() > 0:
        _current_state = _states.values()[0]
        _current_state.enter()

func _on_transition(new_state_name: String) -> void:
    var new_state = _states.get(new_state_name.to_lower())
    if new_state == null or new_state == _current_state:
        return
    
    _current_state.exit()
    _current_state = new_state
    _current_state.enter()
```

## Unity C# Patterns

### Component Architecture
```csharp
// Health Component
public class HealthComponent : MonoBehaviour
{
    [SerializeField] private int _maxHealth = 100;
    
    public int CurrentHealth { get; private set; }
    public bool IsDead => CurrentHealth <= 0;
    
    public event Action<int, int> OnHealthChanged;
    public event Action OnDeath;
    
    private void Awake() => CurrentHealth = _maxHealth;
    
    public void TakeDamage(int amount)
    {
        if (IsDead) return;
        
        int oldHealth = CurrentHealth;
        CurrentHealth = Mathf.Max(0, CurrentHealth - amount);
        OnHealthChanged?.Invoke(CurrentHealth, _maxHealth);
        
        if (IsDead) OnDeath?.Invoke();
    }
}
```

### ScriptableObject for Data
```csharp
[CreateAssetMenu(menuName = "Game/Weapon Data")]
public class WeaponData : ScriptableObject
{
    public string weaponName;
    public int damage = 10;
    public float fireRate = 0.5f;
    public float range = 10f;
    public Sprite icon;
    public AudioClip fireSound;
    public GameObject projectilePrefab;
}
```

### Object Pooling
```csharp
public class ObjectPool : MonoBehaviour
{
    [SerializeField] private GameObject _prefab;
    [SerializeField] private int _initialSize = 10;
    
    private Queue<GameObject> _pool = new();
    
    private void Awake()
    {
        for (int i = 0; i < _initialSize; i++)
        {
            var obj = Instantiate(_prefab, transform);
            obj.SetActive(false);
            _pool.Enqueue(obj);
        }
    }
    
    public GameObject Get()
    {
        if (_pool.Count == 0)
        {
            var obj = Instantiate(_prefab, transform);
            obj.SetActive(false);
            _pool.Enqueue(obj);
        }
        
        var pooled = _pool.Dequeue();
        pooled.SetActive(true);
        return pooled;
    }
    
    public void Return(GameObject obj)
    {
        obj.SetActive(false);
        _pool.Enqueue(obj);
    }
}
```

## Three.js Game Development

### Game Loop
```javascript
class Game {
    constructor() {
        this.scene = new THREE.Scene();
        this.camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        this.renderer = new THREE.WebGLRenderer({ antialias: true });
        this.clock = new THREE.Clock();
        this.entities = [];
        
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        document.body.appendChild(this.renderer.domElement);
    }
    
    update(delta) {
        for (const entity of this.entities) {
            entity.update(delta);
        }
    }
    
    render() {
        this.renderer.render(this.scene, this.camera);
    }
    
    loop() {
        const delta = this.clock.getDelta();
        this.update(delta);
        this.render();
        requestAnimationFrame(() => this.loop());
    }
}
```

### Physics (Cannon.js)
```javascript
import * as CANNON from 'cannon-es';

// Setup physics world
const world = new CANNON.World({
    gravity: new CANNON.Vec3(0, -9.82, 0)
});

// Create physics body
const body = new CANNON.Body({
    mass: 1,
    shape: new CANNON.Box(new CANNON.Vec3(0.5, 0.5, 0.5)),
    position: new CANNON.Vec3(0, 5, 0)
});
world.addBody(body);

// Sync with Three.js mesh
function updatePhysics(delta) {
    world.step(1/60, delta, 3);
    mesh.position.copy(body.position);
    mesh.quaternion.copy(body.quaternion);
}
```

### Collision Detection
```javascript
// Raycasting for collision
const raycaster = new THREE.Raycaster();
const direction = new THREE.Vector3(0, -1, 0);

function checkGrounded(object) {
    raycaster.set(object.position, direction);
    raycaster.far = 1.1; // Slightly more than half height
    
    const intersects = raycaster.intersectObjects(groundObjects);
    return intersects.length > 0;
}
```

### Particle Systems
```javascript
class ParticleSystem {
    constructor(scene, count = 1000) {
        const geometry = new THREE.BufferGeometry();
        const positions = new Float32Array(count * 3);
        const velocities = new Float32Array(count * 3);
        
        for (let i = 0; i < count * 3; i++) {
            positions[i] = (Math.random() - 0.5) * 10;
            velocities[i] = (Math.random() - 0.5) * 0.1;
        }
        
        geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
        
        const material = new THREE.PointsMaterial({
            size: 0.1,
            color: 0xffffff,
            transparent: true,
            opacity: 0.8
        });
        
        this.points = new THREE.Points(geometry, material);
        this.velocities = velocities;
        scene.add(this.points);
    }
    
    update(delta) {
        const positions = this.points.geometry.attributes.position.array;
        for (let i = 0; i < positions.length; i += 3) {
            positions[i] += this.velocities[i] * delta * 60;
            positions[i+1] += this.velocities[i+1] * delta * 60;
            positions[i+2] += this.velocities[i+2] * delta * 60;
        }
        this.points.geometry.attributes.position.needsUpdate = true;
    }
}
```

## Game Design Patterns

1. **Entity-Component-System (ECS)** — Data-oriented design for performance
2. **State Machine** — Manage game/entity states cleanly
3. **Observer Pattern** — Event-driven communication (signals)
4. **Object Pooling** — Reuse objects instead of creating/destroying
5. **Command Pattern** — Decouple input from actions (replay, undo)
6. **Spatial Partitioning** — Efficient collision detection (quadtree, octree)
7. **Singleton Managers** — Game, Audio, Save, Input managers
8. **Decorator Pattern** — Stackable effects (buffs, debuffs)
