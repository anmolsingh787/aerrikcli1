"""
Skills Loader - Load skills from local files and GitHub repos
Integrates skills into agent system prompts

Sources:
- Ponytail (DietrichGebert/ponytail)
- Frontend (finfin/awesome-frontend-skills, vercel-labs/next-skills, shadcn/ui)
- Backend (kodustech/awesome-agent-skills, wshobson/agents)
- Security (trailofbits/skills)
- Animation (cloudai-x/threejs-skills, mblode/agent-skills)
- Architecture (kodustech, secondsky/claude-skills)
- Game Dev (Godogen, Unity automation)
"""
import os
from typing import Dict, List, Optional
from pathlib import Path


# ─── Skill injection map (which skills go to which agents) ───
SKILL_AGENT_MAP = {
    "ponytail":           ["architect", "project_manager", "frontend_developer",
                           "backend_developer", "database_expert", "devops_engineer",
                           "tester", "ui_ux_designer"],
    "frontend_skills":    ["architect", "frontend_developer", "tester", "ui_ux_designer"],
    "backend_skills":     ["architect", "backend_developer", "database_expert",
                           "devops_engineer", "tester"],
    "security_skills":    ["architect", "backend_developer", "devops_engineer", "tester"],
    "animation_skills":   ["frontend_developer", "ui_ux_designer"],
    "architecture_skills": ["architect", "backend_developer", "devops_engineer"],
    "game_dev_skills":    ["frontend_developer", "ui_ux_designer"],
}


class SkillsLoader:
    """
    🎓 Skills Loader

    Loads skills from:
    1. Local markdown files (skills/*.md)
    2. GitHub repositories (future feature)

    Integrates skills into agent prompts based on SKILL_AGENT_MAP.
    """

    def __init__(self, skills_dir: str = None):
        if skills_dir is None:
            skills_dir = os.path.dirname(__file__)
        self.skills_dir = skills_dir
        self.skills: Dict[str, str] = {}
        self._load_skills()

    def _load_skills(self):
        """Load all skill files from the skills directory"""
        skills_path = Path(self.skills_dir)
        for md_file in skills_path.glob("*.md"):
            skill_name = md_file.stem
            with open(md_file, 'r', encoding='utf-8') as f:
                self.skills[skill_name] = f.read()

    def get_skill(self, name: str) -> Optional[str]:
        """Get a specific skill by name"""
        return self.skills.get(name)

    def list_skills(self) -> List[str]:
        """List all available skills"""
        return list(self.skills.keys())

    def get_skills_for_role(self, role: str) -> List[str]:
        """Get list of skill names applicable to a given role"""
        result = []
        for skill_name, roles in SKILL_AGENT_MAP.items():
            if role in roles and skill_name in self.skills:
                result.append(skill_name)
        return result

    # ─── Summary extractors ──────────────────────────────

    def _extract_rules(self, skill_name: str, max_lines: int = 80) -> str:
        """Extract key rules section from a skill (first max_lines)"""
        content = self.skills.get(skill_name, "")
        if not content:
            return ""
        lines = content.splitlines()
        return "\n".join(lines[:max_lines])

    def get_ponytail_rules(self) -> str:
        return """
🎯 PONYTAIL RULES (Apply to ALL code you write):
Before writing code, stop at the first rung that holds:
1. Does this need to exist? → no: skip it (YAGNI)
2. Already in this codebase? → reuse it, don't rewrite
3. Stdlib does it? → use it
4. Native platform feature? → use it
5. Installed dependency? → use it
6. One line? → one line
7. Only then: the minimum that works

NEVER cut: validation, error handling, security, or accessibility.
Mark deliberate simplifications with: // ponytail: [reason]
"""

    def get_frontend_summary(self) -> str:
        return """
🎨 FRONTEND SKILLS (React 19+ / Next.js 15+ / TypeScript / TailwindCSS v4 / shadcn/ui):

COMPONENT ARCHITECTURE:
- Server Components by default, 'use client' only when needed
- Composition over inheritance, colocate styles/tests/types
- shadcn/ui for components (check components.json, use CLI to add)
- CVA (class-variance-authority) for component variants

STATE MANAGEMENT:
- URL state with nuqs for shareable data (filters, pagination)
- TanStack Query for server state (not global state)
- useState for local UI-only state, Jotai for shared client state

NEXT.JS 15+:
- params is now a Promise (await params)
- App Router with route groups (marketing)/ and (app)/
- Runtime selection: 'nodejs' vs 'edge'
- Revalidation: export const revalidate = 3600

TAILWIND v4:
- CSS-first config with @theme (no tailwind.config.js)
- Use oklch() colors, CSS custom properties
- Dark mode with dark: prefix

FORMS: React Hook Form + Zod validation
ACCESSIBILITY: Semantic HTML first, ARIA only when needed
FILE STRUCTURE: app/ → (groups)/ → layout.tsx, page.tsx, loading.tsx, error.tsx
"""

    def get_backend_summary(self) -> str:
        return """
⚙️ BACKEND SKILLS (FastAPI / Python 3.12+ / Node.js / Go / Async SQLAlchemy):

API DESIGN:
- REST: proper methods, status codes, cursor-based pagination
- Response format: { data: ..., meta: { page, total } }
- Error format: { error: { code, message, details } }
- Versioned APIs (/api/v1/)

ARCHITECTURE:
- Clean Architecture: domain → use_cases → adapters → infrastructure
- Dependency Rule: inner layers NEVER know about outer layers
- Repository pattern for data access
- Service layer for business logic (thin controllers)

DATABASE:
- Async SQLAlchemy with connection pooling (pool_size=20, max_overflow=10)
- Proper indexing (composite, partial, covering)
- Avoid N+1 queries (use eager loading or batch loading)
- Alembic for migrations

AUTH: JWT with refresh token rotation, bcrypt, rate limiting
SECURITY: Input validation, CORS, SQL injection prevention, env secrets
OBSERVABILITY: Structured logging (structlog), Prometheus metrics, OpenTelemetry
BACKGROUND: Celery with Redis or FastAPI BackgroundTasks
REAL-TIME: WebSocket with connection manager + Redis Pub/Sub for scaling
"""

    def get_security_summary(self) -> str:
        return """
🔒 SECURITY SKILLS (Trail of Bits / OWASP):

STATIC ANALYSIS:
- CodeQL for semantic code analysis
- Semgrep for custom rule-based scanning
- SARIF output parsing for tool integration

VULNERABILITY CHECKLIST:
□ SQL injection (no string concatenation in queries)
□ XSS (sanitize all user input in HTML output)
□ CSRF (token validation on state-changing requests)
□ Path traversal (sanitize file paths)
□ Command injection (never shell=True with user input)
□ Insecure deserialization (no pickle.loads on untrusted data)
□ SSRF (validate user-controlled URLs)
□ Hardcoded secrets (use env vars / vault)

VARIANT ANALYSIS: Find one vuln → abstract pattern → scan codebase → fix all
CODE REVIEW: Read diff → check boundaries → removed checks? → new deps? → edge cases
DEPENDENCY SECURITY: pip-audit, npm audit, snyk, gitleaks, trivy
"""

    def get_animation_summary(self) -> str:
        return """
✨ ANIMATION SKILLS (CSS / Framer Motion / Three.js):

CORE RULES:
1. Only animate transform and opacity (GPU-composited)
2. 200-300ms for micro-interactions, 300-500ms for transitions
3. Always respect prefers-reduced-motion
4. CSS-first, use JS libraries only when needed

CSS: transition for simple, @keyframes for complex, View Transitions API for pages
FRAMER MOTION: variants for reusable, staggerChildren for lists, AnimatePresence for mount/unmount
THREE.JS: AnimationMixer + AnimationClip, skeletal animation, morph targets, animation blending
"""

    def get_architecture_summary(self) -> str:
        return """
🏗️ ARCHITECTURE SKILLS (Clean / Hexagonal / DDD / Microservices):

CLEAN ARCHITECTURE: domain → use_cases → adapters → infrastructure
HEXAGONAL: Ports (interfaces) + Adapters (implementations)
DDD: Entities, Value Objects, Aggregates, Repositories, Domain Events
CQRS: Separate read/write models, event sourcing for audit trail
MICROSERVICES: Service boundaries (DDD), event bus (Kafka/NATS), circuit breakers
RESILIENCE: Circuit breaker, retry with backoff, bulkhead, timeout
TECH STACK DECISIONS: Match stack to requirements (real-time → WebSocket, ML → FastAPI, etc.)
"""

    def get_game_dev_summary(self) -> str:
        return """
🎮 GAME DEV SKILLS (Godot 4 / Unity / Three.js):

GODOT 4: GDScript with typed variables, @export for editor, signals for communication
UNITY: Component architecture, ScriptableObject for data, object pooling, ECS
THREE.JS: Game loop (update/render), Cannon.js physics, raycasting, particle systems
PATTERNS: State machine, observer, command pattern, spatial partitioning, object pooling
"""

    # ─── Main injection method ───────────────────────────

    def inject_skills_into_prompt(self, base_prompt: str, role: str) -> str:
        """Inject relevant skill summaries into an agent's system prompt"""

        skills_section = "\n\n" + "=" * 60 + "\n"
        skills_section += "🎯 INTEGRATED SKILLS & PHILOSOPHIES\n"
        skills_section += "=" * 60 + "\n"

        # Always add ponytail (universal)
        skills_section += self.get_ponytail_rules()

        # Add role-specific skills
        role_skills = {
            "frontend_developer": [
                self.get_frontend_summary(),
                self.get_animation_summary(),
            ],
            "ui_ux_designer": [
                self.get_frontend_summary(),
                self.get_animation_summary(),
                self.get_game_dev_summary(),
            ],
            "backend_developer": [
                self.get_backend_summary(),
                self.get_security_summary(),
                self.get_architecture_summary(),
            ],
            "database_expert": [
                self.get_backend_summary(),
                self.get_architecture_summary(),
            ],
            "devops_engineer": [
                self.get_backend_summary(),
                self.get_security_summary(),
                self.get_architecture_summary(),
            ],
            "architect": [
                self.get_frontend_summary(),
                self.get_backend_summary(),
                self.get_security_summary(),
                self.get_architecture_summary(),
            ],
            "tester": [
                self.get_frontend_summary(),
                self.get_backend_summary(),
                self.get_security_summary(),
            ],
            "project_manager": [],
        }

        for skill_text in role_skills.get(role, []):
            skills_section += "\n" + skill_text

        skills_section += "\n" + "=" * 60 + "\n"
        return base_prompt + skills_section

    # ─── Display helpers ─────────────────────────────────

    def get_skill_summary(self) -> str:
        """Get a summary of all loaded skills"""
        summary = "🎓 LOADED SKILLS:\n"
        summary += "=" * 50 + "\n"
        for name, content in self.skills.items():
            first_line = content.split('\n')[0].replace('#', '').strip()
            line_count = len(content.splitlines())
            summary += f"  ✅ {name}: {first_line} ({line_count} lines)\n"
        return summary

    def get_skill_sources(self) -> Dict[str, str]:
        """Get source repos for each skill"""
        return {
            "ponytail":            "DietrichGebert/ponytail (84k⭐)",
            "frontend_skills":     "finfin/awesome-frontend-skills + vercel-labs/next-skills + shadcn/ui",
            "backend_skills":      "kodustech/awesome-agent-skills + wshobson/agents + sickn33/agentic-awesome-skills",
            "security_skills":     "trailofbits/skills (Trail of Bits)",
            "animation_skills":    "cloudai-x/threejs-skills + mblode/agent-skills + Framer Motion",
            "architecture_skills": "kodustech/awesome-agent-skills + secondsky/claude-skills + wshobson/agents",
            "game_dev_skills":     "Godogen (Godot 4) + Unity automation + Three.js patterns",
        }
