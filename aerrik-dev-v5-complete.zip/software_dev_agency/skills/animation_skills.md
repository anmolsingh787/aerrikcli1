# Animation Skills

**Sources:**
- [cloudai-x/threejs-skills](https://github.com/cloudai-x/threejs-skills) — Three.js animation system
- [mblode/agent-skills](https://github.com/mblode/agent-skills) — UI animation rules
- [patricio0312rev/skills](https://github.com/patricio0312rev/skills) — Framer Motion animator

## UI Animation Principles

### Core Rules
1. **Only animate `transform` and `opacity`** — these are GPU-composited, no layout/paint
2. **200-300ms for micro-interactions** — fast enough to feel responsive
3. **300-500ms for page transitions** — visible but not sluggish
4. **Always respect `prefers-reduced-motion`** — accessibility first
5. **CSS-first** — use CSS transitions/animations before JS libraries
6. **Use `will-change` sparingly** — only when you know what will change

### CSS Transitions (Preferred)
```css
.button {
  transition: transform 200ms ease-out, opacity 200ms ease-out;
}
.button:hover {
  transform: translateY(-2px);
}
.button:active {
  transform: translateY(0);
}
```

### CSS Keyframe Animations
```css
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(8px); }
  to { opacity: 1; transform: translateY(0); }
}

.card {
  animation: fadeIn 300ms ease-out forwards;
}
```

### Reduced Motion Support
```css
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
}
```

### View Transitions API (Modern)
```css
/* Page-level transitions */
::view-transition-old(root) {
  animation: fade-out 200ms ease-out;
}
::view-transition-new(root) {
  animation: fade-in 200ms ease-out;
}

/* Element-level transitions */
.hero-image {
  view-transition-name: hero;
}
```

```javascript
// Trigger view transition
document.startViewTransition(() => {
  // Update DOM here
  updatePage();
});
```

## Framer Motion (React)

### Basic Animations
```tsx
import { motion } from 'framer-motion';

// Simple fade-in
<motion.div
  initial={{ opacity: 0, y: 20 }}
  animate={{ opacity: 1, y: 0 }}
  transition={{ duration: 0.3 }}
>
  Content
</motion.div>
```

### Variants (Reusable Animations)
```tsx
const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
};

const containerVariants = {
  hidden: {},
  visible: {
    transition: { staggerChildren: 0.1 }
  }
};

<motion.div variants={containerVariants} initial="hidden" animate="visible">
  {items.map(item => (
    <motion.div key={item.id} variants={itemVariants}>
      {item.content}
    </motion.div>
  ))}
</motion.div>
```

### Page Transitions
```tsx
const pageVariants = {
  initial: { opacity: 0, x: -20 },
  animate: { opacity: 1, x: 0 },
  exit: { opacity: 0, x: 20 },
};

<AnimatePresence mode="wait">
  <motion.div
    key={route}
    variants={pageVariants}
    initial="initial"
    animate="animate"
    exit="exit"
    transition={{ duration: 0.2 }}
  >
    <Page />
  </motion.div>
</AnimatePresence>
```

### Gesture Animations
```tsx
<motion.button
  whileHover={{ scale: 1.05 }}
  whileTap={{ scale: 0.95 }}
  transition={{ type: "spring", stiffness: 400, damping: 17 }}
>
  Click me
</motion.button>
```

### Scroll-triggered Animations
```tsx
<motion.div
  initial={{ opacity: 0, y: 50 }}
  whileInView={{ opacity: 1, y: 0 }}
  viewport={{ once: true, amount: 0.3 }}
  transition={{ duration: 0.5 }}
>
  Revealed on scroll
</motion.div>
```

## Three.js Animation System

### AnimationClip & AnimationMixer
```javascript
// Create animation mixer
const mixer = new THREE.AnimationMixer(model);

// Play animation clip
const action = mixer.clipAction(clip);
action.play();

// Update in render loop
function animate() {
  const delta = clock.getDelta();
  mixer.update(delta);
  renderer.render(scene, camera);
  requestAnimationFrame(animate);
}
```

### Skeletal Animation
```javascript
// Load model with skeleton
const loader = new GLTFLoader();
loader.load('character.glb', (gltf) => {
  const model = gltf.scene;
  scene.add(model);

  const mixer = new THREE.AnimationMixer(model);
  
  // Play idle animation
  const idle = mixer.clipAction(gltf.animations[0]);
  idle.play();
  
  // Crossfade to walk animation
  const walk = mixer.clipAction(gltf.animations[1]);
  idle.crossFadeTo(walk, 0.5);
  walk.play();
});
```

### Morph Targets (Shape Keys)
```javascript
// Morph target animation
const mesh = gltf.scene.children[0];
mesh.morphTargetInfluences[0] = 0; // neutral
mesh.morphTargetInfluences[1] = 1; // smile

// Animate morph influence
function animate() {
  mesh.morphTargetInfluences[0] = Math.sin(Date.now() * 0.001) * 0.5 + 0.5;
}
```

### Animation Blending
```javascript
// Blend between two animations
const action1 = mixer.clipAction(clip1);
const action2 = mixer.clipAction(clip2);

action1.setEffectiveWeight(0.7);
action2.setEffectiveWeight(0.3);
action1.play();
action2.play();
```

### Animation Events
```javascript
// Listen for animation events
mixer.addEventListener('loop', (e) => {
  console.log('Animation looped:', e.action.getClip().name);
});

mixer.addEventListener('finished', (e) => {
  console.log('Animation finished:', e.action.getClip().name);
});
```

### Performance Tips
1. **Limit bone count** — 50-75 bones for characters, fewer for props
2. **Use LOD** — Lower detail animations for distant objects
3. **Batch animations** — Use InstancedMesh for repeated animations
4. **Pool actions** — Reuse AnimationActions instead of creating new ones
5. **Reduce update frequency** — Not everything needs 60fps animation
