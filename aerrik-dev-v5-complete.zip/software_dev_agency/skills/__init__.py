"""
Skills Package - Load and integrate skills from GitHub and local files
"""
from skills.skills_loader import SkillsLoader

__all__ = ["SkillsLoader"]
