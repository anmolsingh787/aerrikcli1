# Software Architecture Skills

**Sources:**
- [kodustech/awesome-agent-skills](https://github.com/kodustech/awesome-agent-skills) — `senior-architect`, `senior-backend`
- [wshobson/agents](https://github.com/wshobson/agents) — 175 skills (architecture-patterns, microservices-patterns, CQRS, event-store)
- [secondsky/claude-skills](https://github.com/secondsky/claude-skills) — Clean Architecture, Hexagonal, DDD

## Architecture Patterns

### Clean Architecture

```
app/
├── domain/              # Entities & business rules
│   ├── entities/        # Core business objects
│   ├── value_objects/   # Immutable value types
│   └── interfaces/      # Abstract interfaces (ports)
├── use_cases/           # Application business rules
│   ├── commands/        # Write operations
│   └── queries/         # Read operations
├── adapters/            # Interface implementations
│   ├── repositories/    # Database adapters
│   ├── controllers/     # HTTP/WebSocket adapters
│   └── gateways/        # External service adapters
└── infrastructure/      # Framework & external concerns
    ├── database/        # DB connections, migrations
    ├── web/             # Web framework setup
    └── config/          # Configuration
```

**Dependency Rule:** Inner layers NEVER know about outer layers. Dependencies point inward.

### Hexagonal Architecture (Ports & Adapters)

```
                    ┌─────────────────┐
                    │   Application   │
                    │     Core        │
                    │                 │
    Input Ports ───►│   Domain Logic  │◄─── Output Ports
                    │                 │
                    └─────────────────┘
                         │        │
                    ┌────┘        └────┐
                    │                  │
              ┌─────┴─────┐    ┌──────┴──────┐
              │  Driving   │    │   Driven    │
              │  Adapters  │    │   Adapters  │
              │  (HTTP,    │    │  (DB, Email,│
              │   CLI, MQ) │    │   Payments) │
              └────────────┘    └─────────────┘
```

### Domain-Driven Design (DDD)

```python
# Value Object (immutable)
@dataclass(frozen=True)
class Email:
    value: str
    
    def __post_init__(self):
        if "@" not in self.value:
            raise ValueError("Invalid email")

# Entity (has identity)
class User:
    def __init__(self, id: UUID, email: Email, name: str):
        self._id = id
        self._email = email
        self._name = name
        self._events: list = []
    
    def change_email(self, new_email: Email):
        self._email = new_email
        self._events.append(UserEmailChanged(self._id, new_email))

# Aggregate Root (consistency boundary)
class Order:
    def __init__(self, id: UUID, customer_id: UUID):
        self._id = id
        self._items: list[OrderItem] = []
        self._status = OrderStatus.DRAFT
    
    def add_item(self, product_id: UUID, quantity: int, price: Money):
        if self._status != OrderStatus.DRAFT:
            raise OrderAlreadyPlaced()
        self._items.append(OrderItem(product_id, quantity, price))
    
    def place(self):
        if not self._items:
            raise EmptyOrder()
        self._status = OrderStatus.PLACED
        self._events.append(OrderPlaced(self._id))

# Repository (abstract interface in domain)
class OrderRepository(Protocol):
    async def save(self, order: Order) -> None: ...
    async def find_by_id(self, id: UUID) -> Order | None: ...
    async def find_by_customer(self, customer_id: UUID) -> list[Order]: ...
```

## Microservices Patterns

### Service Boundaries (DDD Bounded Contexts)
```
┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐
│   User Service   │  │  Order Service  │  │ Payment Service │
│                  │  │                 │  │                 │
│ • Registration   │  │ • Cart          │  │ • Charges       │
│ • Authentication │  │ • Checkout      │  │ • Refunds       │
│ • Profile        │  │ • Order History │  │ • Webhooks      │
│ • Preferences    │  │ • Returns       │  │ • Invoices      │
└─────────────────┘  └─────────────────┘  └─────────────────┘
        │                    │                     │
        └────────────────────┼─────────────────────┘
                             │
                    ┌────────┴────────┐
                    │   Event Bus     │
                    │  (Kafka/NATS)   │
                    └─────────────────┘
```

### Communication Patterns

1. **Synchronous (REST/gRPC)** — Request/response, real-time
   - Use for: queries, simple commands, user-facing operations
   - Avoid for: long-running processes, cross-service transactions

2. **Asynchronous (Event-driven)** — Fire and forget, eventual consistency
   - Use for: notifications, saga orchestration, background processing
   - Tools: Kafka, RabbitMQ, NATS, Redis Streams

### Resilience Patterns

```python
# Circuit Breaker
class CircuitBreaker:
    def __init__(self, failure_threshold=5, recovery_timeout=60):
        self._failures = 0
        self._threshold = failure_threshold
        self._timeout = recovery_timeout
        self._state = "CLOSED"  # CLOSED, OPEN, HALF_OPEN
    
    async def call(self, func, *args, **kwargs):
        if self._state == "OPEN":
            if time.time() - self._last_failure > self._timeout:
                self._state = "HALF_OPEN"
            else:
                raise CircuitOpenError()
        
        try:
            result = await func(*args, **kwargs)
            self._on_success()
            return result
        except Exception as e:
            self._on_failure()
            raise

# Retry with Exponential Backoff
async def retry_with_backoff(func, max_retries=3, base_delay=1):
    for attempt in range(max_retries):
        try:
            return await func()
        except RetryableError:
            if attempt == max_retries - 1:
                raise
            delay = base_delay * (2 ** attempt) + random.uniform(0, 1)
            await asyncio.sleep(delay)
```

## CQRS (Command Query Responsibility Segregation)

```python
# Command (write side)
@dataclass
class CreateOrderCommand:
    customer_id: UUID
    items: list[OrderItemDTO]

class CreateOrderHandler:
    def __init__(self, repo: OrderRepository, bus: EventBus):
        self._repo = repo
        self._bus = bus
    
    async def handle(self, cmd: CreateOrderCommand) -> UUID:
        order = Order.create(cmd.customer_id, cmd.items)
        await self._repo.save(order)
        await self._bus.publish(order.events)
        return order.id

# Query (read side)
class OrderReadModel:
    def __init__(self, db: AsyncSession):
        self._db = db
    
    async def get_order_summary(self, order_id: UUID) -> OrderSummary:
        # Read from optimized read model (materialized view)
        result = await self._db.execute(
            select(OrderSummaryView).where(OrderSummaryView.id == order_id)
        )
        return result.scalar_one()
```

## Tech Stack Decision Framework

| Requirement | Recommended Stack |
|-------------|------------------|
| Real-time chat | WebSocket + Redis Pub/Sub + PostgreSQL |
| E-commerce | Next.js + FastAPI + Stripe + PostgreSQL |
| Social media | React + GraphQL + MongoDB + Redis |
| SaaS dashboard | Next.js + tRPC + Prisma + PostgreSQL |
| IoT platform | Go + MQTT + TimescaleDB + Grafana |
| ML pipeline | FastAPI + Celery + Redis + S3 + PostgreSQL |
| Mobile app | React Native + Firebase + Supabase |
| Video streaming | Node.js + HLS + CDN + S3 + PostgreSQL |

## Architecture Diagrams (Text-based)

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   Frontend   │────►│   API GW    │────►│  Services   │
│  (Next.js)   │     │  (Nginx)    │     │ (FastAPI)   │
└─────────────┘     └──────┬──────┘     └──────┬──────┘
                           │                    │
                    ┌──────┴──────┐     ┌──────┴──────┐
                    │   Auth      │     │  Database   │
                    │  (JWT/Redis)│     │ (PostgreSQL)│
                    └─────────────┘     └─────────────┘
```
