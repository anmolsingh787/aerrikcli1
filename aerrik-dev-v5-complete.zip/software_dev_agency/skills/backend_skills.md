# Backend Development Skills

**Sources:**
- [kodustech/awesome-agent-skills](https://github.com/kodustech/awesome-agent-skills) — `senior-backend`, `senior-architect`
- [wshobson/agents](https://github.com/wshobson/agents) — API design, microservices, CQRS, event-store
- [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) — `fastapi-pro`, `backend-dev-guidelines`
- [steipete/agent-rules](https://github.com/steipete/agent-rules)

## Senior Backend Development

### Multi-Language Backend Stack

| Language | Framework | Best For |
|----------|-----------|----------|
| Python | FastAPI | Async APIs, ML backends, rapid prototyping |
| Node.js | Express / Fastify / Hono | Real-time, I/O heavy, shared frontend/backend |
| Go | Gin / Fiber / Echo | High performance, microservices, CLI tools |
| Rust | Actix / Axum | Maximum performance, systems integration |
| Java | Spring Boot | Enterprise, large teams, long-term projects |

### API Design Principles

1. **REST Best Practices**
   ```
   GET    /api/v1/users          → List users (paginated)
   GET    /api/v1/users/:id      → Get single user
   POST   /api/v1/users          → Create user (201 Created)
   PUT    /api/v1/users/:id      → Full replace
   PATCH  /api/v1/users/:id      → Partial update
   DELETE /api/v1/users/:id      → Delete (204 No Content)
   
   GET    /api/v1/users/:id/orders       → Nested resources
   POST   /api/v1/users/:id/orders       → Create order for user
   ```

2. **Response Format**
   ```json
   // Success
   { "data": { ... }, "meta": { "page": 1, "total": 42 } }
   
   // Error
   { "error": { "code": "VALIDATION_ERROR", "message": "...", "details": [...] } }
   ```

3. **Pagination (Cursor-based for scale)**
   ```json
   {
     "data": [...],
     "pagination": {
       "next_cursor": "eyJpZCI6MTAwfQ==",
       "has_more": true,
       "limit": 20
     }
   }
   ```

### Database Optimization

1. **Indexing Strategy**
   ```sql
   -- Composite index for common queries
   CREATE INDEX idx_users_email_active ON users(email) WHERE active = true;
   
   -- Partial index (only index what you query)
   CREATE INDEX idx_orders_pending ON orders(created_at) WHERE status = 'pending';
   
   -- Covering index (avoid table lookup)
   CREATE INDEX idx_products_search ON products(name, price, category);
   ```

2. **Query Optimization**
   ```python
   # ❌ N+1 query
   users = session.query(User).all()
   for user in users:
       orders = session.query(Order).filter_by(user_id=user.id).all()
   
   # ✅ Eager loading
   users = session.query(User).options(joinedload(User.orders)).all()
   
   # ✅ Batch loading
   user_ids = [u.id for u in users]
   orders = session.query(Order).filter(Order.user_id.in_(user_ids)).all()
   orders_by_user = groupby(orders, key=lambda o: o.user_id)
   ```

3. **Connection Pooling**
   ```python
   # FastAPI + SQLAlchemy
   engine = create_async_engine(
       settings.database_url,
       pool_size=20,           # Keep 20 connections open
       max_overflow=10,        # Allow 10 more under load
       pool_pre_ping=True,     # Verify connection before use
       pool_recycle=3600,      # Recycle after 1 hour
       pool_timeout=30,        # Wait 30s for connection
   )
   ```

### Authentication & Security

1. **JWT with Refresh Token Rotation**
   ```python
   class TokenService:
       def create_token_pair(self, user_id: UUID) -> TokenPair:
           access = self._create_token(user_id, "access", minutes=15)
           refresh = self._create_token(user_id, "refresh", days=7)
           
           # Store refresh token hash for rotation
           await self.redis.setex(
               f"refresh:{user_id}",
               timedelta(days=7),
               hash_token(refresh)
           )
           return TokenPair(access=access, refresh=refresh)
       
       async def rotate_refresh_token(self, old_token: str) -> TokenPair:
           payload = jwt.decode(old_token, SECRET_KEY, algorithms=["HS256"])
           user_id = UUID(payload["sub"])
           
           # Verify and invalidate old token
           stored = await self.redis.get(f"refresh:{user_id}")
           if not stored or not verify_token(old_token, stored):
               raise InvalidTokenError("Token already used or expired")
           
           # Issue new pair
           return await self.create_token_pair(user_id)
   ```

2. **Rate Limiting**
   ```python
   # Redis-based sliding window rate limiter
   async def rate_limit(key: str, limit: int, window: int) -> bool:
       now = time.time()
       pipe = redis.pipeline()
       pipe.zremrangebyscore(key, 0, now - window)
       pipe.zadd(key, {str(now): now})
       pipe.zcard(key)
       pipe.expire(key, window)
       _, _, count, _ = await pipe.execute()
       return count <= limit
   ```

### Background Jobs

```python
# Celery with Redis broker
from celery import Celery

celery = Celery("tasks", broker="redis://localhost:6379/0")

@celery.task(bind=True, max_retries=3)
def send_email(self, to: str, subject: str, body: str):
    try:
        smtp_client.send(to, subject, body)
    except SMTPError as exc:
        # Exponential backoff retry
        raise self.retry(exc=exc, countdown=2 ** self.request.retries)

# FastAPI background tasks (simpler)
from fastapi import BackgroundTasks

@router.post("/register")
async def register(data: UserCreate, bg: BackgroundTasks):
    user = await create_user(data)
    bg.add_task(send_welcome_email, user.email)
    bg.add_task(analytics.track, "user_registered", {"id": str(user.id)})
    return user
```

### WebSocket & Real-time

```python
# FastAPI WebSocket
from fastapi import WebSocket, WebSocketDisconnect

class ConnectionManager:
    def __init__(self):
        self.active: dict[str, list[WebSocket]] = {}
    
    async def connect(self, room: str, ws: WebSocket):
        await ws.accept()
        self.active.setdefault(room, []).append(ws)
    
    async def broadcast(self, room: str, message: dict):
        for ws in self.active.get(room, []):
            try:
                await ws.send_json(message)
            except WebSocketDisconnect:
                self.active[room].remove(ws)

@router.websocket("/ws/{room}")
async def ws_endpoint(ws: WebSocket, room: str):
    manager = get_manager()
    await manager.connect(room, ws)
    try:
        while True:
            data = await ws.receive_json()
            await manager.broadcast(room, {"user": data["user"], "msg": data["msg"]})
    except WebSocketDisconnect:
        pass
```

### Observability

```python
# Structured logging
import structlog

logger = structlog.get_logger()

@router.get("/users/{user_id}")
async def get_user(user_id: UUID):
    logger.info("fetching_user", user_id=str(user_id))
    user = await user_service.get(user_id)
    if not user:
        logger.warning("user_not_found", user_id=str(user_id))
        raise HTTPException(404)
    return user

# Metrics (Prometheus)
from prometheus_client import Counter, Histogram

REQUEST_COUNT = Counter("http_requests_total", "Total requests", ["method", "endpoint", "status"])
REQUEST_LATENCY = Histogram("http_request_duration_seconds", "Request latency", ["endpoint"])

# Distributed tracing (OpenTelemetry)
from opentelemetry import trace

tracer = trace.get_tracer(__name__)

async def process_order(order_id: UUID):
    with tracer.start_as_current_span("process_order") as span:
        span.set_attribute("order.id", str(order_id))
        # ... process order
```
