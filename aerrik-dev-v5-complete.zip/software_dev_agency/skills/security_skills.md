# Security Skills

**Source:** [trailofbits/skills](https://github.com/trailofbits/skills) — Professional security-focused skills for code auditing and vulnerability detection

## Trail of Bits Security Toolkit

### Static Analysis (CodeQL + Semgrep)

1. **CodeQL Setup**
   ```bash
   # Install CodeQL CLI
   codeql database create my-db --language=python --source-root=.
   codeql database analyze my-db python-security-and-quality.qls
   ```

2. **Semgrep Rules**
   ```yaml
   # semgrep-rule.yaml
   rules:
     - id: sql-injection
       patterns:
         - pattern: cursor.execute($QUERY, ...)
         - metavariable-regex:
             metavariable: $QUERY
             regex: (f"|.*\+|.*%s)
       message: "Possible SQL injection"
       severity: ERROR
       languages: [python]
   ```

3. **Common Vulnerability Patterns**
   - SQL injection (string concatenation in queries)
   - XSS (unsanitized user input in HTML)
   - CSRF (missing token validation)
   - Path traversal (unsanitized file paths)
   - Command injection (shell=True with user input)
   - Insecure deserialization (pickle.loads on untrusted data)
   - SSRF (user-controlled URLs in server requests)
   - Hardcoded secrets (API keys, passwords in code)

### Variant Analysis

When you find one vulnerability, look for similar patterns across the codebase:

1. **Identify the pattern** — What makes it vulnerable?
2. **Abstract the pattern** — Remove specifics, keep the dangerous shape
3. **Search codebase** — Find all matches
4. **Verify each match** — Is it actually vulnerable?
5. **Fix systematically** — Apply the same fix pattern everywhere

### Code Audit Checklist

```
□ Authentication: proper password hashing, session management, MFA
□ Authorization: RBAC, resource-level permissions, privilege escalation
□ Input Validation: all user input validated and sanitized
□ Output Encoding: HTML, SQL, URL, LDAP, OS command encoding
□ Cryptography: proper algorithms, key management, random generation
□ Error Handling: no information leakage, proper logging
□ Dependencies: known CVEs, outdated packages
□ Configuration: secure defaults, no debug mode in production
□ Secrets Management: no hardcoded secrets, proper env handling
□ API Security: rate limiting, CORS, authentication on all endpoints
```

### Differential Code Review

When reviewing code changes (PRs/commits):

1. **Read the diff first** — What changed and why?
2. **Check boundaries** — New inputs? New trust boundaries?
3. **Look for removed security checks** — Was validation removed?
4. **Check for new dependencies** — Any risky new packages?
5. **Verify error handling** — New code paths, new error cases?
6. **Test edge cases** — What happens with empty, null, very large input?

### SARIF Parsing

```python
# Parse SARIF output from static analysis tools
import json

def parse_sarif(sarif_path):
    with open(sarif_path) as f:
        data = json.load(f)
    
    findings = []
    for run in data.get("runs", []):
        for result in run.get("results", []):
            findings.append({
                "rule": result["ruleId"],
                "message": result["message"]["text"],
                "severity": result["level"],
                "location": result["locations"][0]["physicalLocation"]
            })
    return findings
```

### Security Testing Patterns

1. **Fuzzing** — Generate random inputs to find crashes
2. **Property-based testing** — Define invariants, test with random data
3. **Penetration testing** — OWASP Top 10 checklist
4. **Dependency scanning** — `pip-audit`, `npm audit`, `snyk`
5. **Container scanning** — `trivy`, `grype`
6. **Secret scanning** — `gitleaks`, `trufflehog`

### Smart Contract Security

- Reentrancy guards on state-changing functions
- Input validation on all external calls
- Access control (onlyOwner, onlyRole patterns)
- Overflow/underflow checks (SafeMath or Solidity 0.8+)
- Front-running protection (commit-reveal schemes)
- Gas optimization without sacrificing security

### Fix Verification

When verifying a security fix:

1. Does the fix address the root cause, not just the symptom?
2. Are there other instances of the same vulnerability?
3. Does the fix introduce new vulnerabilities?
4. Is the fix backward compatible?
5. Are there tests that prevent regression?
