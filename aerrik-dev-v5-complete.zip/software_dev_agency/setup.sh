#!/bin/bash
# aerrik.dev — One-line installer
set -e

echo ""
echo "     █████╗ ███████╗██████╗ ██████╗ ██╗██╗  ██╗"
echo "    ██╔══██╗██╔════╝██╔══██╗██╔══██╗██║██║ ██╔╝"
echo "    ███████║█████╗  ██████╔╝██████╔╝██║█████╔╝"
echo "    ██╔══██║██╔══╝  ██╔══██╗██╔══██╗██║██╔═██╗"
echo "    ██║  ██║███████╗██║  ██║██║  ██║██║██║  ██╗"
echo "    ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚═╝  ╚═╝"
echo "                    .dev installer"
echo ""

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is required. Install it first."
    exit 1
fi

# Install dependencies
echo "◆ Installing dependencies..."
pip install -q rich click openai pydantic python-dotenv 2>/dev/null

# Create global command
INSTALL_DIR="$(cd "$(dirname "$0")" && pwd)"

# Create wrapper script
cat > /tmp/aerrik << EOF
#!/bin/bash
cd "$INSTALL_DIR" && python3 aerrik.py "\$@"
EOF

if [ -w /usr/local/bin ]; then
    sudo cp /tmp/aerrik /usr/local/bin/aerrik
    sudo chmod +x /usr/local/bin/aerrik
    echo "✓ Installed 'aerrik' command globally"
else
    mkdir -p "$HOME/.local/bin"
    cp /tmp/aerrik "$HOME/.local/bin/aerrik"
    chmod +x "$HOME/.local/bin/aerrik"
    echo "✓ Installed to ~/.local/bin/aerrik"
    echo "  Add to PATH: export PATH=\$HOME/.local/bin:\$PATH"
fi

echo ""
echo "✓ aerrik.dev is ready!"
echo ""
echo "  Run:    aerrik"
echo "  Demo:   aerrik --demo"
echo "  Help:   aerrik --help"
echo ""
