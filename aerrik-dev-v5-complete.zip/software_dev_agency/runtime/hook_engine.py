"""
🪝 aerrik.dev — Hook / Event Engine

Lifecycle hooks that fire at key moments:

  BeforeTool    → Before any tool executes
  AfterTool     → After tool completes
  BeforeWrite   → Before file write
  AfterWrite    → After file write
  BeforeBuild   → Before project build
  AfterBuild    → After project build
  OnError       → When an error occurs
  OnComplete    → When task completes
  OnBudgetWarn  → When budget warning triggers

Hooks can:
  - Run shell commands (lint, format, test)
  - Trigger other agents
  - Block execution
  - Log events
  - Fire the dog 🐕
"""
import subprocess
from typing import Dict, List, Callable, Optional, Any
from dataclasses import dataclass, field
from enum import Enum


class HookEvent(Enum):
    BEFORE_TOOL = "before_tool"
    AFTER_TOOL = "after_tool"
    BEFORE_WRITE = "before_write"
    AFTER_WRITE = "after_write"
    BEFORE_BUILD = "before_build"
    AFTER_BUILD = "after_build"
    ON_ERROR = "on_error"
    ON_COMPLETE = "on_complete"
    ON_BUDGET_WARN = "on_budget_warn"
    ON_DOG_BARK = "on_dog_bark"


@dataclass
class Hook:
    """A registered hook"""
    name: str
    event: HookEvent
    handler: Optional[Callable] = None    # Python function
    command: Optional[str] = None          # Shell command
    match: Optional[str] = None            # Only fire if tool/file matches
    priority: int = 50                     # Lower = fires first
    enabled: bool = True
    block_on_failure: bool = False         # Block execution if hook fails


@dataclass
class HookResult:
    """Result of a hook execution"""
    hook_name: str = ""
    success: bool = True
    output: str = ""
    block: bool = False           # Should block the action?
    reason: str = ""
    latency_ms: float = 0


class HookEngine:
    """
    🪝 Hook Engine — Lifecycle event system.

    Example hooks:
    - AfterWrite → run ESLint on .tsx files
    - AfterWrite → run Black on .py files
    - OnError → dog bark + log
    - BeforeTool → permission check
    - AfterBuild → run test suite
    """

    def __init__(self, working_dir: str = "."):
        self.working_dir = working_dir
        self._hooks: List[Hook] = []
        self._history: List[Dict] = []
        self._register_defaults()

    def _register_defaults(self):
        """Register default hooks"""
        # Dog bark on error
        self.register(Hook(
            name="dog_bark_on_error",
            event=HookEvent.ON_ERROR,
            handler=self._dog_bark_handler,
            priority=10,
        ))

        # Log all tool calls
        self.register(Hook(
            name="audit_log",
            event=HookEvent.AFTER_TOOL,
            handler=self._audit_handler,
            priority=100,
        ))

    def register(self, hook: Hook):
        """Register a hook"""
        self._hooks.append(hook)
        self._hooks.sort(key=lambda h: h.priority)

    def unregister(self, name: str):
        """Remove a hook by name"""
        self._hooks = [h for h in self._hooks if h.name != name]

    def fire(self, event: str, context: Dict) -> Optional[Dict]:
        """
        Fire all hooks for an event.

        Returns the first blocking result, or None.
        """
        try:
            event_enum = HookEvent(event)
        except ValueError:
            return None

        results = []

        for hook in self._hooks:
            if not hook.enabled or hook.event != event_enum:
                continue

            # Check match filter
            if hook.match:
                tool = context.get("tool", "")
                path = context.get("path", "")
                if hook.match not in tool and hook.match not in path:
                    continue

            # Execute hook
            result = self._execute_hook(hook, context)
            results.append(result)

            self._history.append({
                "event": event,
                "hook": hook.name,
                "success": result.success,
                "block": result.block,
            })

            # If hook blocks, return immediately
            if result.block:
                return {
                    "block": True,
                    "reason": result.reason,
                    "hook": hook.name,
                }

        return None

    def _execute_hook(self, hook: Hook, context: Dict) -> HookResult:
        """Execute a single hook"""
        result = HookResult(hook_name=hook.name)

        try:
            if hook.handler:
                # Python handler
                handler_result = hook.handler(context)
                if isinstance(handler_result, dict):
                    result.block = handler_result.get("block", False)
                    result.reason = handler_result.get("reason", "")
                    result.output = handler_result.get("output", "")
                elif isinstance(handler_result, bool):
                    result.block = not handler_result  # False = block

            elif hook.command:
                # Shell command
                import time
                start = time.time()
                proc = subprocess.run(
                    hook.command,
                    shell=True,
                    cwd=self.working_dir,
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                result.latency_ms = (time.time() - start) * 1000
                result.output = proc.stdout + proc.stderr
                result.success = proc.returncode == 0

                if proc.returncode != 0 and hook.block_on_failure:
                    result.block = True
                    result.reason = f"Hook '{hook.name}' failed: {proc.stderr[:200]}"

        except Exception as e:
            result.success = False
            result.output = str(e)
            if hook.block_on_failure:
                result.block = True
                result.reason = f"Hook error: {str(e)}"

        return result

    # ─── Default Handlers ──────────────────────────────

    def _dog_bark_handler(self, context: Dict) -> Dict:
        """🐕 Bark on error"""
        error = context.get("error", "Unknown error")
        return {
            "block": False,
            "output": f"🐕🔊 WOOF! Error: {error[:100]}",
        }

    def _audit_handler(self, context: Dict) -> Dict:
        """Log tool execution"""
        tool = context.get("tool", "unknown")
        success = context.get("success", True)
        return {
            "block": False,
            "output": f"📝 {tool} {'✅' if success else '❌'}",
        }

    # ─── Lint Hooks (add per project) ──────────────────

    def add_lint_hook(self, file_ext: str, command: str):
        """Add a lint hook for a file type"""
        self.register(Hook(
            name=f"lint_{file_ext}",
            event=HookEvent.AFTER_WRITE,
            command=command,
            match=file_ext,
            priority=50,
            block_on_failure=False,  # Warn but don't block
        ))

    def add_test_hook(self, command: str):
        """Add a test hook after builds"""
        self.register(Hook(
            name="run_tests",
            event=HookEvent.AFTER_BUILD,
            command=command,
            priority=50,
            block_on_failure=True,  # Block if tests fail
        ))

    def get_history(self) -> List[Dict]:
        return self._history

    def get_stats(self) -> Dict:
        """Get hook statistics"""
        total = len(self._history)
        blocked = sum(1 for h in self._history if h.get("block"))
        failed = sum(1 for h in self._history if not h.get("success"))
        return {
            "total_fired": total,
            "blocked": blocked,
            "failed": failed,
            "registered_hooks": len(self._hooks),
        }
