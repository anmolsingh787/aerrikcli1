"""
🛠️ aerrik.dev — First-Class Tool System

Each tool is a first-class primitive, NOT buried in a mega-class.

Tools:
  📄 read     — Read file contents
  ✍️ write    — Write/create file
  ✏️ edit     — Edit existing file (search & replace)
  🔍 glob     — Find files by pattern
  🔎 grep     — Search file contents
  💻 shell    — Execute shell commands
  📦 git      — Git operations
  🌐 fetch    — HTTP requests

Inspired by Claude Code's tool architecture where each tool
is independently permissioned, hookable, and observable.
"""
import os
import re
import glob as glob_module
import subprocess
import json
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path


class ToolPermission(Enum):
    """Permission level for a tool"""
    SAFE = "safe"           # Auto-approve (read, glob, grep)
    MODERATE = "moderate"   # Ask user (write, edit)
    DANGEROUS = "dangerous" # Hard block or explicit approval (shell rm, git push --force)


@dataclass
class ToolSchema:
    """Tool definition for LLM function calling"""
    name: str
    description: str
    parameters: Dict
    permission: ToolPermission = ToolPermission.SAFE


class ToolRegistry:
    """
    🛠️ Tool Registry — First-class tool management.

    Each tool is:
    - Independently registered with schema
    - Permission-classified (SAFE/MODERATE/DANGEROUS)
    - Hookable (before/after execution)
    - Observable (input/output logged)
    """

    def __init__(self, working_dir: str = "."):
        self.working_dir = os.path.abspath(working_dir)
        self._tools: Dict[str, Callable] = {}
        self._schemas: Dict[str, ToolSchema] = {}
        self._register_builtins()

    def _register_builtins(self):
        """Register all built-in tools"""
        self.register(
            name="read",
            func=self._tool_read,
            schema=ToolSchema(
                name="read",
                description="Read the contents of a file. Returns file content as text.",
                parameters={
                    "type": "object",
                    "properties": {
                        "path": {"type": "string", "description": "File path relative to project root"},
                        "offset": {"type": "integer", "description": "Start line (0-indexed)", "default": 0},
                        "limit": {"type": "integer", "description": "Max lines to read", "default": 500},
                    },
                    "required": ["path"],
                },
                permission=ToolPermission.SAFE,
            ),
        )

        self.register(
            name="write",
            func=self._tool_write,
            schema=ToolSchema(
                name="write",
                description="Write content to a file. Creates parent directories if needed. Overwrites existing files.",
                parameters={
                    "type": "object",
                    "properties": {
                        "path": {"type": "string", "description": "File path relative to project root"},
                        "content": {"type": "string", "description": "Full file content to write"},
                    },
                    "required": ["path", "content"],
                },
                permission=ToolPermission.MODERATE,
            ),
        )

        self.register(
            name="edit",
            func=self._tool_edit,
            schema=ToolSchema(
                name="edit",
                description="Edit a file by replacing exact text. Use for surgical changes without rewriting the whole file.",
                parameters={
                    "type": "object",
                    "properties": {
                        "path": {"type": "string", "description": "File path"},
                        "old_text": {"type": "string", "description": "Exact text to find (must match exactly)"},
                        "new_text": {"type": "string", "description": "Replacement text"},
                    },
                    "required": ["path", "old_text", "new_text"],
                },
                permission=ToolPermission.MODERATE,
            ),
        )

        self.register(
            name="glob",
            func=self._tool_glob,
            schema=ToolSchema(
                name="glob",
                description="Find files matching a glob pattern. Returns list of file paths.",
                parameters={
                    "type": "object",
                    "properties": {
                        "pattern": {"type": "string", "description": "Glob pattern (e.g., '**/*.py', 'src/**/*.tsx')"},
                        "path": {"type": "string", "description": "Base directory", "default": "."},
                    },
                    "required": ["pattern"],
                },
                permission=ToolPermission.SAFE,
            ),
        )

        self.register(
            name="grep",
            func=self._tool_grep,
            schema=ToolSchema(
                name="grep",
                description="Search file contents for a pattern. Returns matching lines with file paths and line numbers.",
                parameters={
                    "type": "object",
                    "properties": {
                        "pattern": {"type": "string", "description": "Search pattern (regex supported)"},
                        "path": {"type": "string", "description": "Directory to search", "default": "."},
                        "include": {"type": "string", "description": "File glob filter (e.g., '*.py')", "default": "*"},
                        "max_results": {"type": "integer", "description": "Max results", "default": 50},
                    },
                    "required": ["pattern"],
                },
                permission=ToolPermission.SAFE,
            ),
        )

        self.register(
            name="shell",
            func=self._tool_shell,
            schema=ToolSchema(
                name="shell",
                description="Execute a shell command. Use for builds, tests, installs. Commands run in project directory.",
                parameters={
                    "type": "object",
                    "properties": {
                        "command": {"type": "string", "description": "Shell command to execute"},
                        "timeout": {"type": "integer", "description": "Timeout in seconds", "default": 30},
                    },
                    "required": ["command"],
                },
                permission=ToolPermission.MODERATE,  # Upgraded by PermissionEngine for dangerous commands
            ),
        )

        self.register(
            name="git",
            func=self._tool_git,
            schema=ToolSchema(
                name="git",
                description="Execute git commands (status, diff, log, add, commit).",
                parameters={
                    "type": "object",
                    "properties": {
                        "command": {"type": "string", "description": "Git subcommand (status, diff, log, add, commit, branch)"},
                        "args": {"type": "string", "description": "Additional arguments", "default": ""},
                    },
                    "required": ["command"],
                },
                permission=ToolPermission.MODERATE,
            ),
        )

    def register(self, name: str, func: Callable, schema: ToolSchema):
        """Register a tool"""
        self._tools[name] = func
        self._schemas[name] = schema

    def execute(self, name: str, arguments: Dict) -> str:
        """Execute a tool by name"""
        if name not in self._tools:
            return f"Error: Unknown tool '{name}'. Available: {list(self._tools.keys())}"

        try:
            result = self._tools[name](**arguments)
            return str(result) if result is not None else ""
        except TypeError as e:
            return f"Error: Invalid arguments for {name}: {str(e)}"
        except Exception as e:
            return f"Error executing {name}: {str(e)}"

    def get_schemas(self) -> List[Dict]:
        """Get all tool schemas for LLM function calling"""
        return [
            {
                "type": "function",
                "function": {
                    "name": s.name,
                    "description": s.description,
                    "parameters": s.parameters,
                },
            }
            for s in self._schemas.values()
        ]

    def get_permission(self, name: str) -> ToolPermission:
        """Get permission level for a tool"""
        schema = self._schemas.get(name)
        return schema.permission if schema else ToolPermission.DANGEROUS

    # ═══════════════════════════════════════════════════
    #  TOOL IMPLEMENTATIONS
    # ═══════════════════════════════════════════════════

    def _resolve_path(self, path: str) -> str:
        """Resolve path relative to working directory"""
        if os.path.isabs(path):
            return path
        return os.path.join(self.working_dir, path)

    def _tool_read(self, path: str, offset: int = 0, limit: int = 500) -> str:
        """📄 Read file contents"""
        full_path = self._resolve_path(path)

        if not os.path.exists(full_path):
            return f"Error: File not found: {path}"

        if not os.path.isfile(full_path):
            return f"Error: Not a file: {path}"

        try:
            with open(full_path, 'r', encoding='utf-8', errors='replace') as f:
                lines = f.readlines()

            total = len(lines)
            selected = lines[offset:offset + limit]

            # Add line numbers
            numbered = []
            for i, line in enumerate(selected, start=offset + 1):
                numbered.append(f"{i:5d} | {line.rstrip()}")

            header = f"File: {path} ({total} lines, showing {offset+1}-{min(offset+limit, total)})\n"
            return header + "\n".join(numbered)

        except Exception as e:
            return f"Error reading {path}: {str(e)}"

    def _tool_write(self, path: str, content: str) -> str:
        """✍️ Write file"""
        full_path = self._resolve_path(path)

        try:
            # Create parent directories
            os.makedirs(os.path.dirname(full_path), exist_ok=True)

            with open(full_path, 'w', encoding='utf-8') as f:
                f.write(content)

            lines = content.count('\n') + 1
            size = len(content)
            return f"✅ Written {lines} lines ({size} bytes) to {path}"

        except Exception as e:
            return f"Error writing {path}: {str(e)}"

    def _tool_edit(self, path: str, old_text: str, new_text: str) -> str:
        """✏️ Edit file (search & replace)"""
        full_path = self._resolve_path(path)

        if not os.path.exists(full_path):
            return f"Error: File not found: {path}"

        try:
            with open(full_path, 'r', encoding='utf-8') as f:
                content = f.read()

            if old_text not in content:
                # Try fuzzy match
                return (
                    f"Error: Text not found in {path}. "
                    f"Make sure old_text matches exactly. "
                    f"First 100 chars of file: {content[:100]}"
                )

            # Count occurrences
            count = content.count(old_text)
            if count > 1:
                return (
                    f"Error: Found {count} occurrences of old_text in {path}. "
                    f"Provide more context to make the match unique."
                )

            new_content = content.replace(old_text, new_text, 1)

            with open(full_path, 'w', encoding='utf-8') as f:
                f.write(new_content)

            return f"✅ Edited {path} (1 replacement)"

        except Exception as e:
            return f"Error editing {path}: {str(e)}"

    def _tool_glob(self, pattern: str, path: str = ".") -> str:
        """🔍 Find files by pattern"""
        base = self._resolve_path(path)
        full_pattern = os.path.join(base, pattern)

        try:
            matches = glob_module.glob(full_pattern, recursive=True)

            # Filter out __pycache__ and hidden dirs
            matches = [
                m for m in matches
                if '__pycache__' not in m and '/.git/' not in m
            ]

            # Make relative to working dir
            rel_matches = [
                os.path.relpath(m, self.working_dir)
                for m in sorted(matches)
            ]

            if not rel_matches:
                return f"No files matching '{pattern}' in {path}"

            # Limit output
            if len(rel_matches) > 100:
                return (
                    f"Found {len(rel_matches)} files (showing first 100):\n"
                    + "\n".join(rel_matches[:100])
                )

            return f"Found {len(rel_matches)} files:\n" + "\n".join(rel_matches)

        except Exception as e:
            return f"Error: {str(e)}"

    def _tool_grep(
        self, pattern: str, path: str = ".", include: str = "*", max_results: int = 50
    ) -> str:
        """🔎 Search file contents"""
        base = self._resolve_path(path)
        results = []

        try:
            regex = re.compile(pattern, re.IGNORECASE)
        except re.error:
            regex = re.compile(re.escape(pattern), re.IGNORECASE)

        file_pattern = os.path.join(base, "**", include)
        files = glob_module.glob(file_pattern, recursive=True)

        for filepath in files:
            if not os.path.isfile(filepath):
                continue
            if any(skip in filepath for skip in ['__pycache__', '.git/', 'node_modules/']):
                continue

            try:
                with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
                    for line_num, line in enumerate(f, 1):
                        if regex.search(line):
                            rel_path = os.path.relpath(filepath, self.working_dir)
                            results.append(f"{rel_path}:{line_num}: {line.rstrip()}")
                            if len(results) >= max_results:
                                return (
                                    f"Found {max_results}+ matches (truncated):\n"
                                    + "\n".join(results)
                                )
            except Exception:
                continue

        if not results:
            return f"No matches for '{pattern}' in {path}"

        return f"Found {len(results)} matches:\n" + "\n".join(results)

    def _tool_shell(self, command: str, timeout: int = 30) -> str:
        """💻 Execute shell command"""
        try:
            result = subprocess.run(
                command,
                shell=True,
                cwd=self.working_dir,
                capture_output=True,
                text=True,
                timeout=timeout,
            )

            output = ""
            if result.stdout:
                output += result.stdout
            if result.stderr:
                output += f"\n[stderr]\n{result.stderr}"

            # Truncate large output
            if len(output) > 10000:
                output = (
                    output[:5000]
                    + f"\n\n... [{len(output) - 10000} chars truncated] ...\n\n"
                    + output[-5000:]
                )

            exit_info = f"\n[exit code: {result.returncode}]"
            return output.strip() + exit_info

        except subprocess.TimeoutExpired:
            return f"Error: Command timed out after {timeout}s"
        except Exception as e:
            return f"Error: {str(e)}"

    def _tool_git(self, command: str, args: str = "") -> str:
        """📦 Git operations"""
        # Safety: block dangerous git commands
        dangerous = ["push --force", "push -f", "reset --hard", "clean -fd"]
        for d in dangerous:
            if d in f"{command} {args}".lower():
                return f"⛔ Blocked dangerous git command: git {command} {args}"

        full_cmd = f"git {command} {args}".strip()
        return self._tool_shell(full_cmd)
