"""
🧠 aerrik.dev — Context Engine

Manages what the LLM sees. The most underrated part of any agent.

Components:
- ContextBuilder: Assembles context from multiple sources
- ContextBudget: Tracks and enforces token budget
- ContextCompactor: Summarizes old context when budget fills
- RelevanceFilter: Only sends relevant files/info (not everything)
- ProjectRules: Loads AERRIK.md project rules

Key principle:
    ❌ Never show the LLM everything
    ✅ Show only what's relevant to the current task
"""
import os
import json
from typing import Dict, List, Optional, Set
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class ContextItem:
    """A piece of context"""
    source: str          # "system", "rules", "file", "memory", "tool"
    content: str
    priority: int = 5    # 1 (highest) to 10 (lowest)
    tokens: int = 0
    tags: Set[str] = field(default_factory=set)
    removable: bool = True  # Can be removed during compaction


class ContextBudget:
    """
    📊 Context Budget Manager

    Tracks token usage and warns when approaching limit.
    """

    def __init__(self, max_tokens: int = 100000):
        self.max_tokens = max_tokens
        self.used_tokens = 0
        self.history: List[Dict] = []

    @property
    def remaining(self) -> int:
        return max(0, self.max_tokens - self.used_tokens)

    @property
    def usage_pct(self) -> float:
        if self.max_tokens == 0:
            return 0
        return (self.used_tokens / self.max_tokens) * 100

    def allocate(self, tokens: int) -> bool:
        """Try to allocate tokens. Returns False if over budget."""
        if self.used_tokens + tokens > self.max_tokens:
            return False
        self.used_tokens += tokens
        return True

    def release(self, tokens: int):
        """Release tokens (after compaction)"""
        self.used_tokens = max(0, self.used_tokens - tokens)

    def should_compact(self, threshold: float = 0.8) -> bool:
        """Check if context needs compaction"""
        return self.usage_pct >= (threshold * 100)

    def estimate_tokens(self, text: str) -> int:
        """Estimate token count (~4 chars per token)"""
        return max(1, len(text) // 4)


class ContextBuilder:
    """
    🧠 Context Builder — Assembles what the LLM sees.

    Priority order (highest first):
    1. System prompt (agent identity)
    2. Project rules (AERRIK.md)
    3. Current task description
    4. Relevant files (read by tools)
    5. Tool results
    6. Memory/skills (on-demand)
    7. Conversation history
    """

    def __init__(
        self,
        budget: ContextBudget = None,
        project_dir: str = ".",
    ):
        self.budget = budget or ContextBudget()
        self.project_dir = project_dir
        self.items: List[ContextItem] = []
        self.files_read: Set[str] = set()
        self.project_rules: str = ""

    def load_project_rules(self) -> str:
        """
        Load AERRIK.md (project rules file).
        Equivalent to Claude Code's CLAUDE.md.
        """
        rules_paths = [
            os.path.join(self.project_dir, "AERRIK.md"),
            os.path.join(self.project_dir, ".aerrik", "rules.md"),
            os.path.join(self.project_dir, "CLAUDE.md"),
        ]

        for path in rules_paths:
            if os.path.exists(path):
                with open(path, 'r') as f:
                    self.project_rules = f.read()
                return self.project_rules

        return ""

    def add_system_prompt(self, prompt: str) -> ContextItem:
        """Add system prompt (highest priority, not removable)"""
        item = ContextItem(
            source="system",
            content=prompt,
            priority=1,
            tokens=self.budget.estimate_tokens(prompt),
            removable=False,
        )
        self.items.insert(0, item)
        return item

    def add_project_rules(self, rules: str = None) -> Optional[ContextItem]:
        """Add project rules"""
        if rules is None:
            rules = self.load_project_rules()

        if not rules:
            return None

        item = ContextItem(
            source="rules",
            content=f"## Project Rules (AERRIK.md)\n{rules}",
            priority=2,
            tokens=self.budget.estimate_tokens(rules),
            tags={"rules", "project"},
            removable=False,
        )
        self.items.append(item)
        return item

    def add_task(self, task: str) -> ContextItem:
        """Add user task"""
        item = ContextItem(
            source="task",
            content=task,
            priority=2,
            tokens=self.budget.estimate_tokens(task),
            removable=False,
        )
        self.items.append(item)
        return item

    def add_file_content(self, path: str, content: str) -> ContextItem:
        """Add file content to context"""
        self.files_read.add(path)
        item = ContextItem(
            source="file",
            content=f"## File: {path}\n```\n{content}\n```",
            priority=5,
            tokens=self.budget.estimate_tokens(content),
            tags={"file", path},
            removable=True,
        )
        self.items.append(item)
        return item

    def add_tool_result(self, tool_name: str, result: str) -> ContextItem:
        """Add tool result"""
        item = ContextItem(
            source="tool",
            content=f"[{tool_name} result]\n{result}",
            priority=6,
            tokens=self.budget.estimate_tokens(result),
            tags={"tool", tool_name},
            removable=True,
        )
        self.items.append(item)
        return item

    def add_memory(self, key: str, content: str) -> ContextItem:
        """Add memory/skill content"""
        item = ContextItem(
            source="memory",
            content=content,
            priority=7,
            tokens=self.budget.estimate_tokens(content),
            tags={"memory", key},
            removable=True,
        )
        self.items.append(item)
        return item

    def add_skill(self, skill_name: str, content: str, on_demand: bool = True) -> ContextItem:
        """
        Add skill content.

        Progressive disclosure:
        - At startup: only skill description (~50 tokens)
        - On demand: full skill content when task matches
        """
        item = ContextItem(
            source="skill",
            content=content,
            priority=8 if on_demand else 4,
            tokens=self.budget.estimate_tokens(content),
            tags={"skill", skill_name},
            removable=True,
        )
        self.items.append(item)
        return item

    def build(self) -> str:
        """Build final context string, sorted by priority"""
        sorted_items = sorted(self.items, key=lambda x: x.priority)

        parts = []
        total_tokens = 0

        for item in sorted_items:
            if total_tokens + item.tokens > self.budget.max_tokens:
                break  # Budget exceeded
            parts.append(item.content)
            total_tokens += item.tokens

        self.budget.used_tokens = total_tokens
        return "\n\n".join(parts)

    def get_relevant_files(self, task: str, max_files: int = 10) -> List[str]:
        """
        Determine which files are relevant to the current task.
        Uses keyword matching + file type heuristics.
        NOT everything — only what matters.
        """
        task_lower = task.lower()
        relevant = []

        # File type hints from task
        type_hints = {
            "react": ["*.tsx", "*.jsx"],
            "component": ["*.tsx", "*.jsx", "*.vue", "*.svelte"],
            "api": ["*.py", "*.ts", "*.js"],
            "database": ["*.sql", "*.py"],
            "style": ["*.css", "*.scss", "*.tsx"],
            "test": ["*test*.py", "*test*.ts", "*spec*"],
            "docker": ["Dockerfile", "docker-compose*"],
            "config": ["*.json", "*.yaml", "*.yml", "*.toml"],
        }

        patterns = set()
        for keyword, globs in type_hints.items():
            if keyword in task_lower:
                patterns.update(globs)

        if not patterns:
            patterns = {"*.py", "*.ts", "*.tsx", "*.js"}

        # Find matching files
        import glob as glob_module
        for pattern in patterns:
            matches = glob_module.glob(
                os.path.join(self.project_dir, "**", pattern),
                recursive=True,
            )
            for m in matches:
                rel = os.path.relpath(m, self.project_dir)
                if not any(skip in rel for skip in [
                    'node_modules', '__pycache__', '.git', 'dist', 'build'
                ]):
                    relevant.append(rel)

        return relevant[:max_files]

    def compact(self, keep_last: int = 5) -> str:
        """
        Compact context by removing low-priority removable items.

        Keep:
        ✅ System prompt (priority 1, not removable)
        ✅ Project rules (priority 2, not removable)
        ✅ User task (priority 2, not removable)
        ✅ Last N items (recent context)

        Remove:
        ❌ Old file contents
        ❌ Old tool results
        ❌ Old memory items
        """
        # Separate keep vs removable
        keep = []
        removable = []

        for item in self.items:
            if not item.removable:
                keep.append(item)
            else:
                removable.append(item)

        # Keep last N removable items
        kept_removable = removable[-keep_last:] if len(removable) > keep_last else removable
        removed = removable[:-keep_last] if len(removable) > keep_last else []

        # Calculate tokens freed
        tokens_freed = sum(item.tokens for item in removed)
        self.budget.release(tokens_freed)

        # Rebuild items list
        self.items = keep + kept_removable

        return (
            f"Compacted: removed {len(removed)} items, "
            f"freed ~{tokens_freed} tokens"
        )

    def get_stats(self) -> Dict:
        """Get context statistics"""
        return {
            "items": len(self.items),
            "tokens_used": self.budget.used_tokens,
            "tokens_remaining": self.budget.remaining,
            "usage_pct": round(self.budget.usage_pct, 1),
            "files_read": list(self.files_read),
            "sources": {
                source: sum(1 for i in self.items if i.source == source)
                for source in set(i.source for i in self.items)
            },
        }
