"""
🔁 aerrik.dev — Agent Runtime Loop

The ACTUAL brain. Claude Code-level agentic loop:

    while not task_complete:
        response = model(messages)
        if response.tool_calls:
            for tool_call in response.tool_calls:
                result = execute_tool(tool_call)
                messages.append(result)
        else:
            break  # Final answer

This is what separates a prompt wrapper from a real agent.
"""
import time
import uuid
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime


class LoopState(Enum):
    IDLE = "idle"
    THINKING = "thinking"
    TOOL_CALL = "tool_call"
    TOOL_RESULT = "tool_result"
    VERIFYING = "verifying"
    COMPACTING = "compacting"
    COMPLETE = "complete"
    ERROR = "error"
    STOPPED = "stopped"


@dataclass
class ToolCall:
    """A tool call requested by the LLM"""
    id: str = field(default_factory=lambda: f"call_{uuid.uuid4().hex[:12]}")
    name: str = ""
    arguments: Dict[str, Any] = field(default_factory=dict)
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class ToolResult:
    """Result from executing a tool"""
    call_id: str = ""
    name: str = ""
    output: str = ""
    error: str = ""
    success: bool = True
    tokens_saved: int = 0       # From observation masking
    latency_ms: float = 0
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class LoopMessage:
    """Message in the agent loop context"""
    role: str                   # system, user, assistant, tool
    content: str = ""
    tool_calls: List[ToolCall] = field(default_factory=list)
    tool_call_id: str = ""
    name: str = ""
    metadata: Dict = field(default_factory=dict)
    tokens: int = 0
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class LoopStats:
    """Statistics for the current loop"""
    iterations: int = 0
    total_tool_calls: int = 0
    total_llm_calls: int = 0
    total_tokens: int = 0
    tokens_saved_by_masking: int = 0
    total_latency_ms: float = 0
    tools_used: Dict[str, int] = field(default_factory=dict)
    errors: int = 0
    compactions: int = 0
    started_at: str = field(default_factory=lambda: datetime.now().isoformat())


class AgentRuntimeLoop:
    """
    🔁 The Core Agent Loop — Aerrik's actual brain.

    Features:
    - Think → Tool → Result → Think loop
    - Tool call batching
    - Observation masking (save tokens on large outputs)
    - Context compaction (summarize when too long)
    - Permission checking before tool execution
    - Hook system (before/after tool, before/after write)
    - Verification loop (write → test → fix)
    - Session checkpointing for resume
    - Max iteration guard (prevent infinite loops)
    """

    def __init__(
        self,
        llm_engine=None,
        tool_registry=None,
        context_engine=None,
        permission_engine=None,
        hook_engine=None,
        cost_tracker=None,
        max_iterations: int = 50,
        context_budget: int = 100000,  # tokens
        compaction_threshold: float = 0.8,  # 80% of budget
        observation_mask_threshold: int = 2000,  # chars
        verbose: bool = True,
    ):
        self.llm = llm_engine
        self.tools = tool_registry
        self.context = context_engine
        self.permissions = permission_engine
        self.hooks = hook_engine
        self.cost = cost_tracker

        self.max_iterations = max_iterations
        self.context_budget = context_budget
        self.compaction_threshold = compaction_threshold
        self.observation_mask_threshold = observation_mask_threshold
        self.verbose = verbose

        # State
        self.state = LoopState.IDLE
        self.messages: List[LoopMessage] = []
        self.stats = LoopStats()
        self.session_id = f"session_{uuid.uuid4().hex[:12]}"

    # ═══════════════════════════════════════════════════
    #  MAIN LOOP
    # ═══════════════════════════════════════════════════

    def run(
        self,
        task: str,
        system_prompt: str = "",
        initial_context: str = "",
        resume_from: Optional[Dict] = None,
    ) -> str:
        """
        Execute the agent loop until completion.

        Args:
            task: The user's task description
            system_prompt: Agent's system prompt
            initial_context: Pre-loaded context (project rules, etc.)
            resume_from: Checkpoint to resume from

        Returns:
            Final response text
        """
        # ─── Setup ──────────────────────────────────────
        if resume_from:
            self._restore_checkpoint(resume_from)
        else:
            self._init_messages(system_prompt, initial_context, task)

        self.state = LoopState.THINKING
        self.stats = LoopStats()

        if self.verbose:
            self._log("🔁 Agent loop started")

        # ─── Main Loop ─────────────────────────────────
        while self.stats.iterations < self.max_iterations:
            self.stats.iterations += 1

            try:
                # ── Check context budget ────────────────
                if self._should_compact():
                    self._compact_context()

                # ── Call LLM ────────────────────────────
                self.state = LoopState.THINKING
                response = self._call_llm()
                self.stats.total_llm_calls += 1

                # ── Check for tool calls ────────────────
                tool_calls = self._extract_tool_calls(response)

                if not tool_calls:
                    # No tool calls → final answer
                    self.state = LoopState.COMPLETE
                    final_text = self._extract_text(response)
                    self.messages.append(LoopMessage(
                        role="assistant",
                        content=final_text,
                    ))
                    if self.verbose:
                        self._log(f"✅ Complete after {self.stats.iterations} iterations")
                    return final_text

                # ── Execute tool calls ──────────────────
                self.state = LoopState.TOOL_CALL
                assistant_msg = LoopMessage(
                    role="assistant",
                    content=self._extract_text(response),
                    tool_calls=tool_calls,
                )
                self.messages.append(assistant_msg)

                for tool_call in tool_calls:
                    result = self._execute_tool(tool_call)
                    self.stats.total_tool_calls += 1
                    self.stats.tools_used[tool_call.name] = (
                        self.stats.tools_used.get(tool_call.name, 0) + 1
                    )

                    # ── Observation masking ─────────────
                    masked_output, saved = self._mask_observation(result.output)
                    result.output = masked_output
                    result.tokens_saved = saved
                    self.stats.tokens_saved_by_masking += saved

                    # ── Add tool result to context ──────
                    self.state = LoopState.TOOL_RESULT
                    self.messages.append(LoopMessage(
                        role="tool",
                        content=result.output,
                        tool_call_id=tool_call.id,
                        name=tool_call.name,
                        metadata={
                            "success": result.success,
                            "error": result.error,
                            "latency_ms": result.latency_ms,
                        },
                    ))

                    if not result.success:
                        self.stats.errors += 1

            except Exception as e:
                self.state = LoopState.ERROR
                self._log(f"❌ Loop error: {str(e)}")
                if self.stats.iterations >= self.max_iterations:
                    break
                # Add error to context and continue
                self.messages.append(LoopMessage(
                    role="system",
                    content=f"[Error in previous step: {str(e)[:200]}]. "
                            f"Please recover and continue.",
                ))

        # ─── Max iterations reached ─────────────────────
        self.state = LoopState.STOPPED
        self._log(f"⚠️ Max iterations ({self.max_iterations}) reached")
        return self._force_completion()

    # ═══════════════════════════════════════════════════
    #  LLM INTERACTION
    # ═══════════════════════════════════════════════════

    def _call_llm(self) -> Any:
        """Call the LLM with current messages"""
        start = time.time()

        # Build messages for LLM
        llm_messages = self._build_llm_messages()

        # Call LLM engine
        if self.llm:
            response = self.llm.generate_with_tools(
                messages=llm_messages,
                tools=self.tools.get_schemas() if self.tools else [],
            )
        else:
            # Mock response for testing
            response = self._mock_llm_response(llm_messages)

        latency = (time.time() - start) * 1000
        self.stats.total_latency_ms += latency

        # Track cost
        if self.cost and hasattr(response, 'usage'):
            self.cost.record_call(
                agent_name="runtime",
                model=getattr(response, 'model', 'unknown'),
                input_text=str(llm_messages),
                output_text=str(response),
                latency_ms=latency,
            )

        return response

    def _build_llm_messages(self) -> List[Dict]:
        """Convert LoopMessages to LLM API format"""
        messages = []
        for msg in self.messages:
            if msg.role == "tool":
                messages.append({
                    "role": "tool",
                    "content": msg.content,
                    "tool_call_id": msg.tool_call_id,
                })
            elif msg.role == "assistant" and msg.tool_calls:
                m = {"role": "assistant", "content": msg.content or ""}
                m["tool_calls"] = [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {
                            "name": tc.name,
                            "arguments": str(tc.arguments),
                        },
                    }
                    for tc in msg.tool_calls
                ]
                messages.append(m)
            else:
                messages.append({
                    "role": msg.role,
                    "content": msg.content,
                })
        return messages

    def _extract_tool_calls(self, response: Any) -> List[ToolCall]:
        """Extract tool calls from LLM response"""
        calls = []

        if hasattr(response, 'tool_calls') and response.tool_calls:
            for tc in response.tool_calls:
                calls.append(ToolCall(
                    id=tc.id if hasattr(tc, 'id') else f"call_{uuid.uuid4().hex[:12]}",
                    name=tc.function.name if hasattr(tc, 'function') else str(tc),
                    arguments=self._parse_args(tc),
                ))
        elif isinstance(response, dict) and "tool_calls" in response:
            for tc in response["tool_calls"]:
                calls.append(ToolCall(
                    id=tc.get("id", f"call_{uuid.uuid4().hex[:12]}"),
                    name=tc.get("name", tc.get("function", {}).get("name", "")),
                    arguments=tc.get("arguments", {}),
                ))

        return calls

    def _extract_text(self, response: Any) -> str:
        """Extract text content from LLM response"""
        if hasattr(response, 'content'):
            return response.content or ""
        if hasattr(response, 'choices'):
            return response.choices[0].message.content or ""
        if isinstance(response, dict):
            return response.get("content", response.get("text", ""))
        return str(response)

    def _parse_args(self, tool_call: Any) -> Dict:
        """Parse tool call arguments"""
        try:
            if hasattr(tool_call, 'function') and hasattr(tool_call.function, 'arguments'):
                args = tool_call.function.arguments
                if isinstance(args, str):
                    import json
                    return json.loads(args)
                return args
            return {}
        except Exception:
            return {}

    def _mock_llm_response(self, messages: List[Dict]) -> Dict:
        """Mock LLM response for testing without API key"""
        last_msg = messages[-1] if messages else {}
        content = last_msg.get("content", "")

        return {
            "content": f"[Mock] Processed: {content[:100]}...",
            "tool_calls": [],
        }

    # ═══════════════════════════════════════════════════
    #  TOOL EXECUTION
    # ═══════════════════════════════════════════════════

    def _execute_tool(self, tool_call: ToolCall) -> ToolResult:
        """Execute a tool call with permission check and hooks"""
        start = time.time()

        if self.verbose:
            self._log(f"🔧 Tool: {tool_call.name}({self._format_args(tool_call.arguments)})")

        # ── Permission check ────────────────────────────
        if self.permissions:
            perm = self.permissions.check(tool_call.name, tool_call.arguments)
            if perm.blocked:
                return ToolResult(
                    call_id=tool_call.id,
                    name=tool_call.name,
                    error=f"⛔ Permission denied: {perm.reason}",
                    success=False,
                    latency_ms=(time.time() - start) * 1000,
                )
            if perm.needs_approval:
                # In interactive mode, this would prompt the user
                # For now, auto-approve if not strict
                if self.verbose:
                    self._log(f"⚠️ Approval needed for {tool_call.name}: {perm.reason}")

        # ── BeforeTool hook ─────────────────────────────
        if self.hooks:
            hook_result = self.hooks.fire("before_tool", {
                "tool": tool_call.name,
                "args": tool_call.arguments,
            })
            if hook_result and hook_result.get("block"):
                return ToolResult(
                    call_id=tool_call.id,
                    name=tool_call.name,
                    error=f"Blocked by hook: {hook_result.get('reason', '')}",
                    success=False,
                )

        # ── Execute ─────────────────────────────────────
        result = ToolResult(call_id=tool_call.id, name=tool_call.name)

        try:
            if self.tools:
                output = self.tools.execute(tool_call.name, tool_call.arguments)
                result.output = str(output) if output is not None else ""
                result.success = True
            else:
                result.output = f"[No tool registry] Cannot execute {tool_call.name}"
                result.success = False
        except Exception as e:
            result.error = str(e)
            result.success = False
            result.output = f"Error: {str(e)}"

        result.latency_ms = (time.time() - start) * 1000

        # ── AfterTool hook ──────────────────────────────
        if self.hooks:
            self.hooks.fire("after_tool", {
                "tool": tool_call.name,
                "result": result.output[:500],
                "success": result.success,
            })

        return result

    # ═══════════════════════════════════════════════════
    #  OBSERVATION MASKING (Token Optimization)
    # ═══════════════════════════════════════════════════

    def _mask_observation(self, output: str) -> tuple:
        """
        Mask large tool outputs to save tokens.

        Instead of sending 5000 lines of npm install output,
        send a compact summary + save full output for reference.

        Returns: (masked_output, tokens_saved)
        """
        if len(output) <= self.observation_mask_threshold:
            return output, 0

        # Extract key information
        lines = output.splitlines()
        total_lines = len(lines)

        # Keep first 10 lines + last 10 lines + error lines
        kept_lines = []
        kept_lines.extend(lines[:10])

        # Find error/warning lines
        for i, line in enumerate(lines):
            if any(kw in line.lower() for kw in ["error", "fail", "warning", "exception"]):
                kept_lines.append(f"[line {i+1}] {line}")

        kept_lines.extend(lines[-10:])

        # Build compact output
        masked = (
            f"[Output truncated: {total_lines} lines → "
            f"{len(kept_lines)} key lines]\n\n"
            + "\n".join(kept_lines)
            + f"\n\n[Full output saved: .aerrik/tool-results/{uuid.uuid4().hex[:8]}]"
        )

        # Estimate tokens saved (~4 chars per token)
        saved = max(0, (len(output) - len(masked)) // 4)

        return masked, saved

    # ═══════════════════════════════════════════════════
    #  CONTEXT COMPACTION
    # ═══════════════════════════════════════════════════

    def _should_compact(self) -> bool:
        """Check if context needs compaction"""
        total_tokens = sum(m.tokens for m in self.messages)
        if total_tokens == 0:
            # Estimate: ~4 chars per token
            total_tokens = sum(len(m.content) for m in self.messages) // 4
        return total_tokens > (self.context_budget * self.compaction_threshold)

    def _compact_context(self):
        """
        Compact old context while preserving important info.

        Keep:
        ✅ System prompt (always)
        ✅ User's original task
        ✅ Architecture decisions
        ✅ File paths modified
        ✅ Errors and fixes
        ✅ Last 5 messages (recent context)

        Remove/Summarize:
        ❌ Old tool outputs (replace with summaries)
        ❌ Repeated explanations
        ❌ Verbose intermediate results
        """
        if self.verbose:
            self._log("🗜️ Compacting context...")

        self.stats.compactions += 1

        if len(self.messages) <= 10:
            return  # Nothing to compact

        # Keep system + user task + last 5 messages
        keep_start = []
        keep_end = self.messages[-5:]

        for msg in self.messages[:3]:
            if msg.role in ("system", "user"):
                keep_start.append(msg)

        # Summarize middle messages
        middle = self.messages[3:-5]
        summary = self._summarize_messages(middle)

        compacted = keep_start + [LoopMessage(
            role="system",
            content=f"[Context compacted — {len(middle)} messages summarized]\n{summary}",
            metadata={"compacted": True, "original_count": len(middle)},
        )] + keep_end

        self.messages = compacted

        if self.verbose:
            before = sum(len(m.content) for m in self.messages) // 4
            self._log(f"🗜️ Compacted → ~{before} tokens remaining")

    def _summarize_messages(self, messages: List[LoopMessage]) -> str:
        """Summarize a batch of messages"""
        tool_results = []
        decisions = []
        errors = []
        files_modified = []

        for msg in messages:
            if msg.role == "tool":
                # Extract key info from tool results
                if msg.name in ("write", "edit", "create_file"):
                    files_modified.append(msg.metadata.get("path", "unknown"))
                if msg.metadata.get("error"):
                    errors.append(f"{msg.name}: {msg.metadata['error'][:100]}")
                elif msg.success if hasattr(msg, 'success') else True:
                    tool_results.append(f"✅ {msg.name}")
                else:
                    tool_results.append(f"❌ {msg.name}")

            elif msg.role == "assistant":
                # Keep decision text
                if msg.content and len(msg.content) > 20:
                    decisions.append(msg.content[:200])

        parts = []
        if tool_results:
            parts.append(f"Tools executed: {', '.join(tool_results[-10:])}")
        if files_modified:
            parts.append(f"Files modified: {', '.join(files_modified[-10:])}")
        if errors:
            parts.append(f"Errors: {'; '.join(errors[-5:])}")
        if decisions:
            parts.append(f"Key decisions: {'; '.join(decisions[-3:])}")

        return "\n".join(parts) if parts else "No significant actions."

    # ═══════════════════════════════════════════════════
    #  SESSION PERSISTENCE / RESUME
    # ═══════════════════════════════════════════════════

    def save_checkpoint(self, filepath: str = None) -> str:
        """Save current loop state for resume"""
        import json

        if filepath is None:
            filepath = f".aerrik/checkpoints/{self.session_id}.json"

        import os
        os.makedirs(os.path.dirname(filepath), exist_ok=True)

        checkpoint = {
            "session_id": self.session_id,
            "state": self.state.value,
            "iteration": self.stats.iterations,
            "messages": [
                {
                    "role": m.role,
                    "content": m.content,
                    "tool_call_id": m.tool_call_id,
                    "name": m.name,
                    "metadata": m.metadata,
                    "timestamp": m.timestamp,
                }
                for m in self.messages
            ],
            "stats": {
                "iterations": self.stats.iterations,
                "total_tool_calls": self.stats.total_tool_calls,
                "total_llm_calls": self.stats.total_llm_calls,
                "total_tokens": self.stats.total_tokens,
                "tokens_saved_by_masking": self.stats.tokens_saved_by_masking,
                "tools_used": self.stats.tools_used,
                "errors": self.stats.errors,
                "compactions": self.stats.compactions,
            },
            "saved_at": datetime.now().isoformat(),
        }

        with open(filepath, 'w') as f:
            json.dump(checkpoint, f, indent=2)

        if self.verbose:
            self._log(f"💾 Checkpoint saved: {filepath}")

        return filepath

    def _restore_checkpoint(self, checkpoint: Dict):
        """Restore loop state from checkpoint"""
        self.session_id = checkpoint.get("session_id", self.session_id)

        self.messages = []
        for m in checkpoint.get("messages", []):
            self.messages.append(LoopMessage(
                role=m["role"],
                content=m.get("content", ""),
                tool_call_id=m.get("tool_call_id", ""),
                name=m.get("name", ""),
                metadata=m.get("metadata", {}),
                timestamp=m.get("timestamp", ""),
            ))

        stats = checkpoint.get("stats", {})
        self.stats.iterations = stats.get("iterations", 0)
        self.stats.total_tool_calls = stats.get("total_tool_calls", 0)
        self.stats.total_llm_calls = stats.get("total_llm_calls", 0)

        if self.verbose:
            self._log(
                f"♻️ Resumed from checkpoint "
                f"(iteration {self.stats.iterations})"
            )

    # ═══════════════════════════════════════════════════
    #  INITIALIZATION
    # ═══════════════════════════════════════════════════

    def _init_messages(self, system: str, context: str, task: str):
        """Initialize message list for a new run"""
        self.messages = []

        # System prompt
        if system:
            self.messages.append(LoopMessage(role="system", content=system))

        # Project context (AERRIK.md, etc.)
        if context:
            self.messages.append(LoopMessage(
                role="system",
                content=f"Project context:\n{context}",
            ))

        # User task
        self.messages.append(LoopMessage(role="user", content=task))

    def _force_completion(self) -> str:
        """Force a completion when max iterations reached"""
        return (
            f"[Agent loop stopped after {self.stats.iterations} iterations. "
            f"Tools used: {self.stats.tools_used}. "
            f"Errors: {self.stats.errors}. "
            f"Tokens saved by masking: {self.stats.tokens_saved_by_masking}.]"
        )

    # ═══════════════════════════════════════════════════
    #  UTILITIES
    # ═══════════════════════════════════════════════════

    def _log(self, msg: str):
        """Log a message"""
        ts = datetime.now().strftime("%H:%M:%S")
        print(f"  [{ts}] {msg}")

    def _format_args(self, args: Dict) -> str:
        """Format arguments for display"""
        parts = []
        for k, v in args.items():
            v_str = str(v)[:50]
            parts.append(f"{k}={v_str}")
        return ", ".join(parts)

    def get_stats(self) -> Dict:
        """Get loop statistics"""
        return {
            "session_id": self.session_id,
            "state": self.state.value,
            "iterations": self.stats.iterations,
            "llm_calls": self.stats.total_llm_calls,
            "tool_calls": self.stats.total_tool_calls,
            "tokens_saved": self.stats.tokens_saved_by_masking,
            "compactions": self.stats.compactions,
            "errors": self.stats.errors,
            "tools_used": self.stats.tools_used,
            "latency_ms": round(self.stats.total_latency_ms, 1),
        }
