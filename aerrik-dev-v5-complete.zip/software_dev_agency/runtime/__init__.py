"""
runtime/ — aerrik.dev Agent Runtime

The foundation that makes everything work:

    ┌─────────────────────────────────────────────┐
    │           Agent Runtime Loop                  │
    │  Think → Tool → Result → Think → ...         │
    ├─────────────────────────────────────────────┤
    │  Tool Registry  │  Context Engine            │
    │  read, write,   │  builder, budget,          │
    │  edit, search,  │  compaction, relevance     │
    │  shell, git     │                            │
    ├─────────────────┼────────────────────────────┤
    │  Permission     │  Hook Engine               │
    │  Engine         │  before/after tool,        │
    │  SAFE/MODERATE  │  before/after write,       │
    │  /DANGEROUS     │  on_error, on_complete     │
    ├─────────────────┴────────────────────────────┤
    │  Auth & BYOK │ Token Opt │ Session Resume     │
    └─────────────────────────────────────────────┘
"""
from runtime.agent_loop import AgentRuntimeLoop, LoopState, LoopStats
from runtime.tool_registry import ToolRegistry, ToolPermission
from runtime.context_engine import ContextBuilder, ContextBudget
from runtime.permission_engine import PermissionEngine, PermissionLevel
from runtime.hook_engine import HookEngine, HookEvent, Hook

__all__ = [
    "AgentRuntimeLoop", "LoopState", "LoopStats",
    "ToolRegistry", "ToolPermission",
    "ContextBuilder", "ContextBudget",
    "PermissionEngine", "PermissionLevel",
    "HookEngine", "HookEvent", "Hook",
]
