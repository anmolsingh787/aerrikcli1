"""
🔍 aerrik.dev — Bug Hunter: Adversarial Bug Detection Pipeline

Inspired by: codexstar69/bug-hunter

Pipeline:
    🐺 Hunter     → Finds potential bugs
    🧐 Skeptic    → Challenges each finding (is this actually a bug?)
    ⚖️ Referee    → Final decision (confirmed / false positive / needs-human)
    🛠️ Fixer      → Auto-fixes confirmed bugs
    🧪 Tester     → Verifies the fix
    🔁 Re-scanner → Confirms no regressions

Key principle:
    Tester  = "Does the feature work?"
    Hunter  = "Where can this code break?"

These are DIFFERENT concerns. Keep them separate.
"""
import re
import os
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime


# ═══════════════════════════════════════════════════════
#  DATA MODELS
# ═══════════════════════════════════════════════════════

class Severity(Enum):
    CRITICAL = "critical"   # Security vulnerability, data loss
    HIGH = "high"           # Logic error, crash potential
    MEDIUM = "medium"       # Performance issue, bad practice
    LOW = "low"             # Style issue, minor concern
    INFO = "info"           # Suggestion, not a bug


class FindingStatus(Enum):
    CANDIDATE = "candidate"       # Found by Hunter
    CONFIRMED = "confirmed"       # Verified by Referee
    FALSE_POSITIVE = "false_positive"  # Rejected by Skeptic/Referee
    FIXED = "fixed"               # Fixed and verified
    NEEDS_HUMAN = "needs_human"   # Requires human review
    ESCALATED = "escalated"       # 3+ failures, escalated


@dataclass
class BugFinding:
    """A single bug finding through the pipeline"""
    id: str
    file_path: str
    line_number: int
    severity: Severity
    category: str           # "security", "logic", "performance", "reliability"
    title: str
    description: str
    evidence: str           # Code snippet showing the bug
    suggested_fix: str = ""
    hunter_confidence: float = 0.0     # 0-1
    skeptic_challenge: str = ""        # Skeptic's counter-argument
    referee_decision: str = ""         # Final decision reasoning
    status: FindingStatus = FindingStatus.CANDIDATE
    fix_applied: bool = False
    fix_verified: bool = False
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def __str__(self):
        icon = {
            Severity.CRITICAL: "🔴",
            Severity.HIGH: "🟠",
            Severity.MEDIUM: "🟡",
            Severity.LOW: "🔵",
            Severity.INFO: "⚪",
        }.get(self.severity, "❓")
        return f"{icon} [{self.severity.value.upper()}] {self.file_path}:{self.line_number} — {self.title}"


@dataclass
class HuntReport:
    """Complete report from a bug hunt"""
    target: str                     # File or directory scanned
    total_findings: int = 0
    confirmed: int = 0
    false_positives: int = 0
    fixed: int = 0
    needs_human: int = 0
    escalated: int = 0
    findings: List[BugFinding] = field(default_factory=list)
    duration_ms: float = 0
    started_at: str = field(default_factory=lambda: datetime.now().isoformat())

    @property
    def precision(self) -> float:
        """What % of candidates were real bugs"""
        if self.total_findings == 0:
            return 0
        return self.confirmed / self.total_findings

    def summary(self) -> str:
        return (
            f"Hunt Report: {self.target}\n"
            f"  Found: {self.total_findings} | "
            f"Confirmed: {self.confirmed} | "
            f"False positives: {self.false_positives} | "
            f"Fixed: {self.fixed} | "
            f"Human review: {self.needs_human}\n"
            f"  Precision: {self.precision:.0%}"
        )


# ═══════════════════════════════════════════════════════
#  🐺 HUNTER — Bug Discovery Engine
# ═══════════════════════════════════════════════════════

class BugHunter:
    """
    🐺 Hunter — Finds potential bugs using static analysis patterns.

    Scans for:
    - Security vulnerabilities (injection, XSS, hardcoded secrets)
    - Logic errors (off-by-one, null deref, race conditions)
    - Resource leaks (unclosed files, connections)
    - Error handling gaps (bare except, swallowed errors)
    - Performance issues (N+1 queries, unnecessary allocations)
    """

    # ─── Pattern Database ──────────────────────────────
    PATTERNS = {
        # Security
        "hardcoded_secret": {
            "regex": r'(?i)(password|secret|api_key|apikey|token|private_key)\s*=\s*["\'][^"\']{8,}["\']',
            "severity": Severity.CRITICAL,
            "category": "security",
            "title": "Hardcoded secret/credential",
            "description": "Sensitive credential appears to be hardcoded in source. Should use environment variables or a secrets manager.",
            "fix_hint": "Replace with os.getenv('VAR_NAME') or a secrets manager reference.",
        },
        "eval_usage": {
            "regex": r'\beval\s*\(',
            "severity": Severity.CRITICAL,
            "category": "security",
            "title": "eval() usage — code injection risk",
            "description": "eval() executes arbitrary code. If any part of the input is user-controlled, this is a remote code execution vulnerability.",
            "fix_hint": "Replace with ast.literal_eval() for data, or a safe parser for the specific use case.",
        },
        "exec_usage": {
            "regex": r'\bexec\s*\(',
            "severity": Severity.CRITICAL,
            "category": "security",
            "title": "exec() usage — code injection risk",
            "description": "exec() executes arbitrary code. Extremely dangerous with any external input.",
            "fix_hint": "Avoid exec(). Use structured alternatives.",
        },
        "sql_injection_fstring": {
            "regex": r'(?:execute|cursor\.execute)\s*\(\s*f["\']',
            "severity": Severity.CRITICAL,
            "category": "security",
            "title": "SQL injection via f-string",
            "description": "String formatting in SQL queries allows injection. Use parameterized queries.",
            "fix_hint": "Use cursor.execute('SELECT ... WHERE id = %s', (user_id,))",
        },
        "sql_injection_concat": {
            "regex": r'(?:execute|cursor\.execute)\s*\([^)]*\+',
            "severity": Severity.CRITICAL,
            "category": "security",
            "title": "SQL injection via string concatenation",
            "description": "String concatenation in SQL queries allows injection.",
            "fix_hint": "Use parameterized queries with placeholders.",
        },
        "shell_injection": {
            "regex": r'(?:os\.system|subprocess\.call|subprocess\.Popen)\s*\([^)]*shell\s*=\s*True',
            "severity": Severity.HIGH,
            "category": "security",
            "title": "Shell injection risk (shell=True)",
            "description": "Using shell=True with dynamic input allows command injection.",
            "fix_hint": "Use shell=False with a list of arguments, or shlex.quote() for user input.",
        },
        "pickle_loads": {
            "regex": r'pickle\.loads?\s*\(',
            "severity": Severity.HIGH,
            "category": "security",
            "title": "Insecure deserialization (pickle)",
            "description": "pickle can execute arbitrary code during deserialization. Never unpickle untrusted data.",
            "fix_hint": "Use json, msgpack, or a safe serialization format for untrusted data.",
        },
        "xss_innerHTML": {
            "regex": r'\.innerHTML\s*=',
            "severity": Severity.HIGH,
            "category": "security",
            "title": "XSS risk via innerHTML",
            "description": "Setting innerHTML with unsanitized content allows cross-site scripting.",
            "fix_hint": "Use textContent for plain text, or DOMPurify for HTML content.",
        },

        # Logic errors
        "bare_except": {
            "regex": r'except\s*:',
            "severity": Severity.MEDIUM,
            "category": "logic",
            "title": "Bare except catches everything including SystemExit/KeyboardInterrupt",
            "description": "Bare except catches SystemExit and KeyboardInterrupt, making the program hard to stop.",
            "fix_hint": "Use 'except Exception:' instead of bare 'except:'.",
        },
        "swallowed_exception": {
            "regex": r'except\s+\w+.*:\s*\n\s*pass\s*$',
            "severity": Severity.MEDIUM,
            "category": "logic",
            "title": "Swallowed exception (except + pass)",
            "description": "Exception is caught and silently ignored. Bugs will be invisible.",
            "fix_hint": "At minimum, log the exception. Better: handle it or re-raise.",
        },
        "mutable_default_arg": {
            "regex": r'def\s+\w+\s*\([^)]*(?:=\s*\[\]|=\s*\{\}|=\s*set\(\))',
            "severity": Severity.MEDIUM,
            "category": "logic",
            "title": "Mutable default argument",
            "description": "Mutable default arguments (list, dict, set) are shared across calls, causing unexpected state.",
            "fix_hint": "Use None as default and create the mutable inside: def f(x=None): x = x or []",
        },
        "is_not_none_comparison": {
            "regex": r'(?:if|while)\s+.*(?:==\s*None|!=\s*None)',
            "severity": Severity.LOW,
            "category": "logic",
            "title": "Use 'is None' / 'is not None' instead of == / !=",
            "description": "PEP 8 recommends 'is' for None comparisons since None is a singleton.",
            "fix_hint": "Replace == None with 'is None' and != None with 'is not None'.",
        },

        # Resource leaks
        "unclosed_file": {
            "regex": r'(?<!with\s)open\s*\([^)]*\)\s*$',
            "severity": Severity.MEDIUM,
            "category": "reliability",
            "title": "File opened without context manager",
            "description": "File opened without 'with' statement may not be closed if an exception occurs.",
            "fix_hint": "Use 'with open(...) as f:' for automatic cleanup.",
        },

        # Performance
        "string_concat_in_loop": {
            "regex": r'for\s+.*:.*\n.*\+=\s*["\']',
            "severity": Severity.LOW,
            "category": "performance",
            "title": "String concatenation in loop",
            "description": "Repeated string concatenation creates new objects each iteration. O(n²) complexity.",
            "fix_hint": "Use a list and ''.join() instead.",
        },

        # TypeScript/JS specific
        "ts_any_type": {
            "regex": r':\s*any\b',
            "severity": Severity.LOW,
            "category": "logic",
            "title": "TypeScript 'any' type defeats type safety",
            "description": "Using 'any' disables TypeScript's type checking, hiding potential bugs.",
            "fix_hint": "Use a specific type, unknown, or a generic type parameter.",
        },
        "ts_ignore": {
            "regex": r'@ts-ignore|@ts-nocheck',
            "severity": Severity.MEDIUM,
            "category": "logic",
            "title": "TypeScript error suppression",
            "description": "@ts-ignore suppresses type errors that might indicate real bugs.",
            "fix_hint": "Fix the underlying type error instead of suppressing it.",
        },
        "console_log_production": {
            "regex": r'console\.log\s*\(',
            "severity": Severity.LOW,
            "category": "reliability",
            "title": "console.log in production code",
            "description": "Debug logging should use a proper logger, not console.log.",
            "fix_hint": "Use a structured logger (winston, pino, Python logging).",
        },
    }

    def hunt(self, file_path: str, content: str = None) -> List[BugFinding]:
        """
        Scan a file for potential bugs.

        Returns a list of BugFinding candidates (not yet verified).
        """
        if content is None:
            if not os.path.exists(file_path):
                return []
            with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
                content = f.read()

        findings = []
        lines = content.splitlines()

        for pattern_id, pattern_info in self.PATTERNS.items():
            regex = pattern_info["regex"]
            try:
                for match in re.finditer(regex, content, re.MULTILINE):
                    # Find line number
                    line_num = content[:match.start()].count('\n') + 1
                    line_content = lines[line_num - 1].strip() if line_num <= len(lines) else ""

                    # Confidence scoring
                    confidence = self._score_confidence(pattern_id, line_content, content)

                    finding = BugFinding(
                        id=f"HUNT-{len(findings)+1:04d}",
                        file_path=file_path,
                        line_number=line_num,
                        severity=pattern_info["severity"],
                        category=pattern_info["category"],
                        title=pattern_info["title"],
                        description=pattern_info["description"],
                        evidence=line_content,
                        suggested_fix=pattern_info["fix_hint"],
                        hunter_confidence=confidence,
                        status=FindingStatus.CANDIDATE,
                    )
                    findings.append(finding)
            except re.error:
                continue

        return findings

    def hunt_directory(self, directory: str, extensions: List[str] = None) -> List[BugFinding]:
        """Scan all files in a directory"""
        if extensions is None:
            extensions = ['.py', '.ts', '.tsx', '.js', '.jsx']

        all_findings = []
        for root, dirs, files in os.walk(directory):
            # Skip common non-source directories
            dirs[:] = [d for d in dirs if d not in {
                '__pycache__', 'node_modules', '.git', 'dist',
                'build', '.venv', 'venv', '.next'
            }]

            for fname in files:
                if any(fname.endswith(ext) for ext in extensions):
                    fpath = os.path.join(root, fname)
                    findings = self.hunt(fpath)
                    all_findings.extend(findings)

        return all_findings

    def _score_confidence(self, pattern_id: str, line: str, full_content: str) -> float:
        """Score how confident we are this is a real bug (0-1)"""
        base = 0.5

        # Higher confidence for critical patterns
        if pattern_id in ("hardcoded_secret", "eval_usage", "sql_injection_fstring"):
            base = 0.7

        # Lower confidence if in a comment
        if line.strip().startswith('#') or line.strip().startswith('//'):
            base *= 0.3

        # Lower confidence if in a test file
        if 'test' in line.lower() or 'spec' in line.lower():
            base *= 0.6

        # Higher confidence if "password" appears near actual assignment
        if "password" in pattern_id and "=" in line:
            base = min(1.0, base + 0.2)

        return round(min(1.0, base), 2)


# ═══════════════════════════════════════════════════════
#  🧐 SKEPTIC — Finding Verification Engine
# ═══════════════════════════════════════════════════════

class BugSkeptic:
    """
    🧐 Skeptic — Challenges every finding.

    For each candidate bug, the Skeptic asks:
    1. Is this actually reachable in production?
    2. Is there already a guard/mitigation we missed?
    3. Could this be intentional (test code, mock data)?
    4. What's the actual blast radius if triggered?

    The Skeptic's job is to REDUCE false positives.
    """

    def challenge(self, finding: BugFinding, full_content: str = None) -> BugFinding:
        """
        Challenge a finding. Add skeptic's counter-argument.

        Returns the finding with skeptic_challenge populated.
        """
        challenges = []

        # 1. Check if in test/mock context
        if self._is_test_context(finding, full_content):
            challenges.append(
                "This appears to be in test/mock code where the risk is controlled."
            )

        # 2. Check for existing guards
        if self._has_existing_guard(finding, full_content):
            challenges.append(
                "There may be an existing guard or validation that mitigates this."
            )

        # 3. Check if in comment/docstring
        if self._is_in_comment(finding, full_content):
            challenges.append(
                "This pattern appears in a comment or docstring, not executable code."
            )

        # 4. Check blast radius
        blast = self._assess_blast_radius(finding)
        if blast == "minimal":
            challenges.append(
                "Even if triggered, the blast radius appears minimal."
            )

        # 5. Check for intentional patterns
        if self._is_intentional_pattern(finding, full_content):
            challenges.append(
                "This may be an intentional pattern (e.g., example code, documentation)."
            )

        finding.skeptic_challenge = " | ".join(challenges) if challenges else "No counter-arguments found."
        return finding

    def _is_test_context(self, finding: BugFinding, content: str) -> bool:
        """Check if the finding is in test/mock code"""
        path_lower = finding.file_path.lower()
        test_indicators = ['test_', '_test.', '_spec.', 'conftest', 'fixtures', 'mock']
        return any(ind in path_lower for ind in test_indicators)

    def _has_existing_guard(self, finding: BugFinding, content: str) -> bool:
        """Check if there's already a guard around the finding"""
        if not content:
            return False

        lines = content.splitlines()
        start = max(0, finding.line_number - 5)
        end = min(len(lines), finding.line_number + 3)
        context = "\n".join(lines[start:end]).lower()

        guard_patterns = [
            "if __name__", "try:", "sanitize", "validate",
            "escape", "quote", "parameterize", "prepared",
        ]
        return any(p in context for p in guard_patterns)

    def _is_in_comment(self, finding: BugFinding, content: str) -> bool:
        """Check if the match is in a comment"""
        if not content:
            return False
        lines = content.splitlines()
        if finding.line_number <= len(lines):
            line = lines[finding.line_number - 1].strip()
            return line.startswith('#') or line.startswith('//') or line.startswith('*')
        return False

    def _assess_blast_radius(self, finding: BugFinding) -> str:
        """Assess the blast radius of the finding"""
        if finding.severity == Severity.CRITICAL:
            return "high"
        elif finding.severity == Severity.HIGH:
            return "medium"
        elif finding.category == "performance":
            return "minimal"
        return "low"

    def _is_intentional_pattern(self, finding: BugFinding, content: str) -> bool:
        """Check if this might be intentional"""
        if not content:
            return False

        lines = content.splitlines()
        if finding.line_number <= len(lines):
            line = lines[finding.line_number - 1].lower()
            intentional_markers = ['example', 'demo', 'sample', 'documentation', 'tutorial']
            return any(m in line for m in intentional_markers)
        return False


# ═══════════════════════════════════════════════════════
#  ⚖️ REFEREE — Finding Decision Engine
# ═══════════════════════════════════════════════════════

class BugReferee:
    """
    ⚖️ Referee — Makes the final decision on each finding.

    Considers:
    - Hunter's confidence score
    - Skeptic's challenges
    - Severity level
    - Code context

    Decisions:
    - CONFIRMED: Real bug, proceed to fix
    - FALSE_POSITIVE: Not a real issue
    - NEEDS_HUMAN: Too ambiguous, escalate to human
    """

    def decide(self, finding: BugFinding) -> BugFinding:
        """Make a final decision on a finding"""
        confidence = finding.hunter_confidence
        has_challenge = bool(finding.skeptic_challenge) and finding.skeptic_challenge != "No counter-arguments found."
        severity = finding.severity

        # Decision matrix
        if severity == Severity.CRITICAL and confidence >= 0.6:
            if has_challenge:
                finding.status = FindingStatus.NEEDS_HUMAN
                finding.referee_decision = (
                    f"Critical finding with counter-arguments. "
                    f"Needs human review. Skeptic says: {finding.skeptic_challenge}"
                )
            else:
                finding.status = FindingStatus.CONFIRMED
                finding.referee_decision = "Critical severity + high confidence = confirmed."

        elif severity == Severity.HIGH and confidence >= 0.7:
            if has_challenge:
                finding.status = FindingStatus.NEEDS_HUMAN
                finding.referee_decision = f"High severity but challenged. Needs review."
            else:
                finding.status = FindingStatus.CONFIRMED
                finding.referee_decision = "High severity + high confidence = confirmed."

        elif confidence >= 0.8 and not has_challenge:
            finding.status = FindingStatus.CONFIRMED
            finding.referee_decision = "High confidence with no challenges = confirmed."

        elif has_challenge and confidence < 0.5:
            finding.status = FindingStatus.FALSE_POSITIVE
            finding.referee_decision = f"Low confidence + challenged = likely false positive."

        elif severity in (Severity.LOW, Severity.INFO):
            if has_challenge:
                finding.status = FindingStatus.FALSE_POSITIVE
                finding.referee_decision = "Low severity + challenged = skip."
            else:
                finding.status = FindingStatus.CONFIRMED
                finding.referee_decision = "Low severity but unchallenged = confirmed (informational)."

        else:
            finding.status = FindingStatus.NEEDS_HUMAN
            finding.referee_decision = "Ambiguous — needs human judgment."

        return finding


# ═══════════════════════════════════════════════════════
#  🛠️ FIXER — Remediation Engine
# ═══════════════════════════════════════════════════════

class BugFixer:
    """
    🛠️ Fixer — Applies safe fixes to confirmed bugs.

    Safety measures:
    - Creates a safe branch before modifying
    - Per-fix commits for easy rollback
    - Only applies deterministic fixes (no LLM guessing)
    - Rollback on test failure
    """

    # Deterministic fix rules (no LLM needed)
    FIX_RULES = {
        "bare_except": {
            "pattern": r'(\s*)except\s*:',
            "replacement": r'\1except Exception:',
            "description": "Replace bare except with except Exception",
        },
        "is_not_none_comparison": {
            "pattern": r'==\s*None',
            "replacement": 'is None',
            "description": "Replace == None with 'is None'",
        },
        "console_log_production": {
            "pattern": r'console\.log\(',
            "replacement": 'logger.info(',
            "description": "Replace console.log with logger.info",
        },
    }

    def fix(self, finding: BugFinding) -> Tuple[bool, str]:
        """
        Attempt to fix a confirmed finding.

        Returns: (success, message)
        """
        if finding.status != FindingStatus.CONFIRMED:
            return False, f"Cannot fix: status is {finding.status.value}"

        # Check if we have a deterministic fix
        for rule_id, rule in self.FIX_RULES.items():
            if rule_id in finding.title.lower() or rule_id in finding.description.lower():
                return self._apply_fix(finding, rule)

        # No deterministic fix available — suggest manual fix
        return False, f"No auto-fix available. Suggested: {finding.suggested_fix}"

    def _apply_fix(self, finding: BugFinding, rule: Dict) -> Tuple[bool, str]:
        """Apply a deterministic fix to a file"""
        try:
            with open(finding.file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            lines = content.splitlines()
            if finding.line_number > len(lines):
                return False, "Line number out of range"

            original_line = lines[finding.line_number - 1]
            fixed_line = re.sub(rule["pattern"], rule["replacement"], original_line)

            if fixed_line == original_line:
                return False, "Fix pattern did not match"

            lines[finding.line_number - 1] = fixed_line
            new_content = "\n".join(lines)

            with open(finding.file_path, 'w', encoding='utf-8') as f:
                f.write(new_content)

            finding.fix_applied = True
            finding.status = FindingStatus.FIXED

            return True, f"Fixed: {rule['description']}"

        except Exception as e:
            return False, f"Fix failed: {str(e)}"


# ═══════════════════════════════════════════════════════
#  🔍 BUG HUNT PIPELINE (orchestrator)
# ═══════════════════════════════════════════════════════

class BugHuntPipeline:
    """
    🔍 Full adversarial bug hunt pipeline.

    Orchestrates: Hunter → Skeptic → Referee → Fixer → Re-scan

    Usage:
        pipeline = BugHuntPipeline()
        report = pipeline.hunt("src/")
        print(report.summary())
    """

    def __init__(self, auto_fix: bool = False, max_findings: int = 100):
        self.hunter = BugHunter()
        self.skeptic = BugSkeptic()
        self.referee = BugReferee()
        self.fixer = BugFixer()
        self.auto_fix = auto_fix
        self.max_findings = max_findings

    def hunt(self, target: str, content: str = None) -> HuntReport:
        """
        Run the full adversarial pipeline on a target.

        Args:
            target: File path or directory
            content: Optional file content (if already loaded)

        Returns:
            HuntReport with all findings and statistics
        """
        import time
        start = time.time()

        report = HuntReport(target=target)

        # ─── Stage 1: Hunter finds candidates ──────────
        if os.path.isdir(target):
            candidates = self.hunter.hunt_directory(target)
        else:
            candidates = self.hunter.hunt(target, content)

        # Limit findings
        candidates = candidates[:self.max_findings]
        report.total_findings = len(candidates)

        # Load file content for skeptic
        file_contents = {}
        for finding in candidates:
            if finding.file_path not in file_contents:
                try:
                    with open(finding.file_path, 'r', encoding='utf-8', errors='replace') as f:
                        file_contents[finding.file_path] = f.read()
                except Exception:
                    file_contents[finding.file_path] = None

        # ─── Stage 2: Skeptic challenges each ────────
        for finding in candidates:
            fc = file_contents.get(finding.file_path)
            self.skeptic.challenge(finding, fc)

        # ─── Stage 3: Referee decides ────────────────
        for finding in candidates:
            self.referee.decide(finding)

        # ─── Stage 4: Fix confirmed bugs (if auto_fix) ─
        if self.auto_fix:
            for finding in candidates:
                if finding.status == FindingStatus.CONFIRMED:
                    success, msg = self.fixer.fix(finding)
                    if success:
                        finding.fix_verified = True

        # ─── Compile report ──────────────────────────
        report.findings = candidates
        report.confirmed = sum(1 for f in candidates if f.status == FindingStatus.CONFIRMED)
        report.false_positives = sum(1 for f in candidates if f.status == FindingStatus.FALSE_POSITIVE)
        report.fixed = sum(1 for f in candidates if f.status == FindingStatus.FIXED)
        report.needs_human = sum(1 for f in candidates if f.status == FindingStatus.NEEDS_HUMAN)
        report.duration_ms = (time.time() - start) * 1000

        return report

    def format_report(self, report: HuntReport) -> str:
        """Format report for terminal display"""
        lines = [
            "",
            "╭──────────────────────────────────────────────────────────────╮",
            f"│  🔍 BUG HUNT REPORT — {report.target[:40]:<40s}│",
            "╰──────────────────────────────────────────────────────────────╯",
            "",
            f"  Found: {report.total_findings} │ Confirmed: {report.confirmed} │ "
            f"False positives: {report.false_positives} │ Fixed: {report.fixed} │ "
            f"Human review: {report.needs_human}",
            f"  Precision: {report.precision:.0%} │ Duration: {report.duration_ms:.0f}ms",
            "",
        ]

        if report.findings:
            # Group by status
            for status in [FindingStatus.CONFIRMED, FindingStatus.NEEDS_HUMAN, FindingStatus.FIXED]:
                status_findings = [f for f in report.findings if f.status == status]
                if status_findings:
                    lines.append(f"  ── {status.value.upper()} ({len(status_findings)}) ──")
                    for f in status_findings[:10]:
                        lines.append(f"  {f}")
                    if len(status_findings) > 10:
                        lines.append(f"  ... and {len(status_findings) - 10} more")
                    lines.append("")

        return "\n".join(lines)
