"""
⚖️ aerrik.dev — Policy & Decision Engine

The ACTUAL BRAIN of aerrik.dev.

Takes inputs from:
  - Routing Engine (complexity)
  - Risk Scorer (file/code risk)
  - Cost Engine (budget remaining)
  - Validation Engine (tool findings)

Makes decisions:
  - Which agents to activate
  - Whether to block writes
  - Whether to downgrade model
  - Whether to require human approval
  - Whether to skip elder review
  - Whether to stop the build

This is what separates a toy from a framework.
"""
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime


class Decision(Enum):
    """Possible decisions the engine can make"""
    PROCEED = "proceed"               # All clear, continue
    PROCEED_WITH_REVIEW = "review"    # Proceed but add elder review
    DOWNGRADE_MODEL = "downgrade"     # Use cheaper model (budget)
    BLOCK_WRITE = "block"             # Security tool failed, don't write
    REQUIRE_HUMAN = "human"           # Must get human approval
    SKIP_ELDERS = "skip_elders"       # Low risk, save tokens
    STOP_BUILD = "stop"               # Budget exceeded or critical failure
    RETRY = "retry"                   # Transient error, retry


@dataclass
class PolicyInput:
    """All inputs the decision engine needs"""
    # From Routing Engine
    task_complexity: str = "medium"     # simple, medium, complex
    complexity_score: float = 0.0

    # From Risk Scorer
    risk_score: float = 0.0            # 0-10
    risk_level: str = "low"            # low, medium, high, critical
    security_tool_failed: bool = False
    security_findings: List[str] = field(default_factory=list)

    # From Cost Engine
    budget_remaining: float = 5.0      # USD
    estimated_cost: float = 0.0        # USD for next action
    total_spent: float = 0.0
    budget_warning_triggered: bool = False

    # From Validation Engine
    validation_passed: bool = True
    validation_errors: List[str] = field(default_factory=list)
    validation_level: int = 1          # 1, 2, or 3

    # Context
    file_path: str = ""
    agent_name: str = ""
    iteration: int = 0                 # Feedback loop iteration
    max_iterations: int = 3


@dataclass
class PolicyDecision:
    """The engine's decision with reasoning"""
    decision: Decision
    reasoning: str = ""
    actions: List[str] = field(default_factory=list)
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

    # Specific flags
    activate_grandfather: bool = False
    activate_grandmother: bool = False
    require_human_approval: bool = False
    use_cheaper_model: bool = False
    suggested_model: str = ""
    block_file_write: bool = False
    skip_elder_review: bool = False

    def __str__(self):
        return f"[PolicyEngine] {self.decision.value}: {self.reasoning}"


class PolicyEngine:
    """
    ⚖️ The Decision Engine — Aerrik's actual brain.

    Rule priority (highest first):
    1. Security tool failure → BLOCK WRITE
    2. Critical risk → REQUIRE HUMAN APPROVAL
    3. Budget exceeded → STOP BUILD
    4. Budget warning → DOWNGRADE MODEL
    5. High risk → PROCEED WITH REVIEW (elders)
    6. Medium risk → PROCEED (grandmother only)
    7. Low risk → SKIP ELDERS (save tokens)
    8. Validation failed in feedback loop → RETRY or STOP
    """

    def __init__(
        self,
        budget_usd: float = 5.0,
        auto_approve: bool = False,
        strict_security: bool = True,
    ):
        self.budget_usd = budget_usd
        self.auto_approve = auto_approve
        self.strict_security = strict_security
        self.decision_log: List[PolicyDecision] = []

    def decide(self, inputs: PolicyInput) -> PolicyDecision:
        """
        Make a decision based on all available inputs.

        This is the core logic — the actual brain.
        """
        d = PolicyDecision(decision=Decision.PROCEED)

        # ═══════════════════════════════════════════════
        # RULE 1: Security tool failure → BLOCK
        # ═══════════════════════════════════════════════
        if inputs.security_tool_failed and self.strict_security:
            d.decision = Decision.BLOCK_WRITE
            d.block_file_write = True
            d.reasoning = (
                f"Security tool failed on {inputs.file_path}: "
                f"{'; '.join(inputs.security_findings[:3])}"
            )
            d.actions.append("block_write")
            d.actions.append("alert_user")
            self._log(d)
            return d

        # ═══════════════════════════════════════════════
        # RULE 2: Critical risk → HUMAN APPROVAL
        # ═══════════════════════════════════════════════
        if inputs.risk_score >= 9:
            d.decision = Decision.REQUIRE_HUMAN
            d.require_human_approval = True
            d.activate_grandfather = True
            d.activate_grandmother = True
            d.reasoning = (
                f"Critical risk ({inputs.risk_score}/10) on {inputs.file_path}. "
                f"Human approval required."
            )
            d.actions.append("require_human")
            d.actions.append("activate_grandfather")
            d.actions.append("activate_grandmother")

            if self.auto_approve:
                # In auto mode, log warning but proceed
                d.decision = Decision.PROCEED_WITH_REVIEW
                d.require_human_approval = False
                d.reasoning += " (auto-approved)"
            self._log(d)
            return d

        # ═══════════════════════════════════════════════
        # RULE 3: Budget exceeded → STOP
        # ═══════════════════════════════════════════════
        if inputs.budget_remaining <= 0:
            d.decision = Decision.STOP_BUILD
            d.reasoning = (
                f"Budget exhausted. Spent ${inputs.total_spent:.4f} "
                f"of ${self.budget_usd:.2f} budget."
            )
            d.actions.append("stop_build")
            d.actions.append("save_checkpoint")
            self._log(d)
            return d

        # ═══════════════════════════════════════════════
        # RULE 4: Budget warning → DOWNGRADE MODEL
        # ═══════════════════════════════════════════════
        if inputs.budget_remaining < inputs.estimated_cost * 1.5:
            d.use_cheaper_model = True
            d.suggested_model = self._suggest_cheaper_model(inputs)
            d.decision = Decision.DOWNGRADE_MODEL
            d.reasoning = (
                f"Budget tight (${inputs.budget_remaining:.2f} remaining). "
                f"Suggesting {d.suggested_model} instead."
            )
            d.actions.append(f"downgrade_to_{d.suggested_model}")

        # ═══════════════════════════════════════════════
        # RULE 5: High risk → ELDER REVIEW
        # ═══════════════════════════════════════════════
        if inputs.risk_score >= 6:
            d.decision = Decision.PROCEED_WITH_REVIEW
            d.activate_grandfather = True
            d.activate_grandmother = True
            d.reasoning = (
                f"High risk ({inputs.risk_score}/10). "
                f"Both elders reviewing."
            )
            d.actions.append("activate_grandfather")
            d.actions.append("activate_grandmother")
            self._log(d)
            return d

        # ═══════════════════════════════════════════════
        # RULE 6: Medium risk → GRANDMOTHER ONLY
        # ═══════════════════════════════════════════════
        if inputs.risk_score >= 3:
            d.decision = Decision.PROCEED_WITH_REVIEW
            d.activate_grandmother = True
            d.skip_elder_review = False
            d.reasoning = (
                f"Medium risk ({inputs.risk_score}/10). "
                f"Grandmother reviewing (Grandfather skipped to save tokens)."
            )
            d.actions.append("activate_grandmother")
            d.actions.append("skip_grandfather")
            self._log(d)
            return d

        # ═══════════════════════════════════════════════
        # RULE 7: Low risk → SKIP ELDERS
        # ═══════════════════════════════════════════════
        if inputs.risk_score < 3:
            d.decision = Decision.SKIP_ELDERS
            d.skip_elder_review = True
            d.reasoning = (
                f"Low risk ({inputs.risk_score}/10). "
                f"Elder review skipped (target: 60-80% review reduction)."
            )
            d.actions.append("skip_all_elders")
            self._log(d)
            return d

        # ═══════════════════════════════════════════════
        # RULE 8: Feedback loop exhausted → STOP or WARN
        # ═══════════════════════════════════════════════
        if (not inputs.validation_passed
                and inputs.iteration >= inputs.max_iterations):
            d.decision = Decision.STOP_BUILD
            d.reasoning = (
                f"Feedback loop exhausted ({inputs.iteration}/{inputs.max_iterations}). "
                f"Errors: {'; '.join(inputs.validation_errors[:3])}"
            )
            d.actions.append("stop_feedback_loop")
            self._log(d)
            return d

        if not inputs.validation_passed:
            d.decision = Decision.RETRY
            d.reasoning = (
                f"Validation failed (iteration {inputs.iteration}). Retrying."
            )
            d.actions.append("retry_with_fixes")
            self._log(d)
            return d

        # ═══════════════════════════════════════════════
        # DEFAULT: PROCEED
        # ═══════════════════════════════════════════════
        d.decision = Decision.PROCEED
        d.reasoning = "All checks passed."
        self._log(d)
        return d

    def _suggest_cheaper_model(self, inputs: PolicyInput) -> str:
        """Suggest a cheaper model based on task complexity"""
        if inputs.task_complexity == "simple":
            return "gpt-4o-mini"      # ~$0.15/M tokens
        elif inputs.task_complexity == "medium":
            return "gpt-4o-mini"      # Still capable for medium tasks
        else:
            return "gpt-4o"           # Keep quality for complex tasks

    def _log(self, decision: PolicyDecision):
        """Log decision for audit trail"""
        self.decision_log.append(decision)

    def get_audit_trail(self) -> str:
        """Get formatted audit trail of all decisions"""
        if not self.decision_log:
            return "  No decisions logged yet."

        lines = ["\n⚖️ POLICY ENGINE AUDIT TRAIL\n" + "═" * 50]
        for i, d in enumerate(self.decision_log, 1):
            icon = {
                Decision.PROCEED: "✅",
                Decision.PROCEED_WITH_REVIEW: "🔍",
                Decision.DOWNGRADE_MODEL: "⬇️",
                Decision.BLOCK_WRITE: "🚫",
                Decision.REQUIRE_HUMAN: "⛔",
                Decision.SKIP_ELDERS: "⏭️",
                Decision.STOP_BUILD: "🛑",
                Decision.RETRY: "🔄",
            }.get(d.decision, "❓")

            lines.append(
                f"  {icon} [{d.timestamp[11:19]}] "
                f"{d.decision.value:12s} — {d.reasoning[:60]}"
            )
        return "\n".join(lines)

    def get_stats(self) -> Dict[str, int]:
        """Get decision statistics"""
        stats: Dict[str, int] = {}
        for d in self.decision_log:
            key = d.decision.value
            stats[key] = stats.get(key, 0) + 1
        return stats
