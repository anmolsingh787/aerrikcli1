"""
🔒 aerrik.dev — Dynamic Risk Scoring Engine

Risk is NOT static per file.

RISK SCORE =
    File Sensitivity      × 0.30
  + Code Findings         × 0.30
  + Dependency Exposure   × 0.15
  + Data Sensitivity      × 0.15
  + Change Impact         × 0.10

Example:
  auth.py with bcrypt → score 6 (HIGH)
  auth.py with eval() → score 9 (CRITICAL)
  Same file, different code, different risk.
"""
import os
import re
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum


class RiskLevel(Enum):
    LOW = "low"           # 0-2.9
    MEDIUM = "medium"     # 3-5.9
    HIGH = "high"         # 6-8.9
    CRITICAL = "critical" # 9-10


@dataclass
class RiskBreakdown:
    """Detailed risk breakdown"""
    file_path: str
    file_sensitivity: float = 0.0     # × 0.30
    code_findings: float = 0.0        # × 0.30
    dependency_exposure: float = 0.0  # × 0.15
    data_sensitivity: float = 0.0     # × 0.15
    change_impact: float = 0.0        # × 0.10
    final_score: float = 0.0
    level: RiskLevel = RiskLevel.LOW
    findings: List[str] = field(default_factory=list)

    def __str__(self):
        return (
            f"{self.file_path}: {self.final_score:.1f}/10 ({self.level.value}) "
            f"[file={self.file_sensitivity:.0f} code={self.code_findings:.0f} "
            f"dep={self.dependency_exposure:.0f} data={self.data_sensitivity:.0f} "
            f"impact={self.change_impact:.0f}]"
        )


class RiskEngine:
    """
    🔒 Dynamic Risk Scoring Engine

    Every file gets scored based on:
    1. What TYPE of file it is (file sensitivity)
    2. What the CODE actually contains (code findings)
    3. What DEPENDENCIES it imports (dependency exposure)
    4. What DATA it handles (data sensitivity)
    5. How BROKEN things get if it fails (change impact)
    """

    # ─── File type base sensitivity (0-10) ─────────────
    FILE_SENSITIVITY = {
        # Minimal risk
        ".md": 0, ".txt": 0, ".svg": 0, ".png": 0, ".jpg": 0,
        ".css": 1, ".scss": 1,
        ".json": 1, ".yaml": 1, ".yml": 1, ".toml": 1, ".ini": 1,

        # Low risk — UI components
        ".html": 2, ".vue": 2, ".svelte": 2,
        ".tsx": 2, ".jsx": 2,

        # Medium risk — logic
        ".ts": 3, ".js": 3,
        ".py": 4, ".go": 4, ".rs": 4, ".java": 4, ".rb": 4,

        # High risk — infrastructure
        ".sql": 6, ".sh": 6, ".bash": 6,
        ".tf": 7, ".hcl": 7,

        # Critical risk
        ".env": 8,
    }

    FILENAME_SENSITIVITY = {
        "dockerfile": 6, "docker-compose": 5,
        "nginx.conf": 5, ".htaccess": 4,
        "makefile": 3, "rakefile": 3,
        ".gitignore": 0, ".dockerignore": 1,
        "requirements.txt": 2, "package.json": 2,
        "webpack.config": 2, "vite.config": 2,
        "tailwind.config": 1, "tsconfig": 1,
    }

    # ─── Code patterns that increase risk (0-10) ──────
    CODE_PATTERNS = {
        # Critical (8-10)
        r'\beval\s*\(': 10,
        r'\bexec\s*\(': 9,
        r'os\.system\s*\(': 9,
        r'subprocess.*shell\s*=\s*True': 9,
        r'pickle\.loads?\s*\(': 8,
        r'marshal\.loads?\s*\(': 8,
        r'yaml\.load\s*\([^,)]*\)': 8,  # No safe Loader
        r'__import__\s*\(': 8,

        # High (6-7)
        r'(?i)(password|secret|api_key|apikey|token)\s*=\s*["\'][^"\']{8,}["\']': 7,
        r'(?i)sk-[a-zA-Z0-9]{20,}': 7,
        r'(?i)AKIA[0-9A-Z]{16}': 7,
        r'(?i)ghp_[a-zA-Z0-9]{36}': 7,
        r'(?i)BEGIN (RSA |EC )?PRIVATE KEY': 9,
        r'(?i)AES\.MODE_ECB': 8,
        r'(?i)md5\s*\(': 6,
        r'(?i)sha1\s*\(': 6,
        r'(?i)random\.random\s*\(\)': 6,  # Not cryptographically secure

        # Medium (4-5)
        r'cursor\.execute\s*\(\s*f["\']': 5,       # f-string SQL
        r'cursor\.execute\s*\([^?]*\+': 5,          # concat SQL
        r'cursor\.execute\s*\([^?]*%': 5,           # % format SQL
        r'innerHTML\s*=': 5,                         # XSS risk
        r'document\.write\s*\(': 5,
        r'(?i)dangerouslySetInnerHTML': 5,
        r'(?i)@ts-ignore': 4,
        r'(?i)@ts-nocheck': 4,
        r'(?i)\bany\b': 3,                          # TypeScript any

        # Low (1-3)
        r'console\.log\s*\(': 2,
        r'\bprint\s*\(': 1,
        r'(?i)TODO': 1,
        r'(?i)FIXME': 2,
        r'(?i)HACK': 2,
        r'\bpass\s*$': 2,                           # Empty implementation
        r'except\s*:': 3,                           # Bare except
    }

    # ─── Dependency risk (imported modules) ────────────
    RISKY_IMPORTS = {
        # Python
        "pickle": 7, "marshal": 7, "shelve": 5,
        "subprocess": 4, "os": 3, "shutil": 3,
        "socket": 5, "ftplib": 6, "telnetlib": 7,
        "ctypes": 6, "cffi": 5,
        "xml.etree": 4, "lxml": 4,                  # XXE risk
        "tempfile": 2,

        # JS/TS
        "child_process": 7, "vm": 8,
        "fs": 3, "path": 1,
        "crypto": 4, "tls": 5, "net": 5,
        "eval": 10, "Function": 9,
    }

    # ─── Data sensitivity patterns ─────────────────────
    DATA_PATTERNS = {
        # Critical (8-10)
        r'(?i)credit.?card': 10,
        r'(?i)ssn|social.?security': 10,
        r'(?i)bank.?account': 9,
        r'(?i)health.?record|medical|hipaa': 10,
        r'(?i)passport|national.?id': 8,

        # High (6-7)
        r'(?i)password|passwd|pwd': 7,
        r'(?i)private.?key|secret.?key': 8,
        r'(?i)email': 5,
        r'(?i)phone': 5,
        r'(?i)address': 5,
        r'(?i)date.?of.?birth|dob': 6,
        r'(?i)ip.?address': 4,

        # Medium (3-5)
        r'(?i)user.?name|username': 3,
        r'(?i)profile': 3,
        r'(?i)preference': 2,
        r'(?i)session': 4,
        r'(?i)cookie': 4,
        r'(?i)jwt|token': 5,
    }

    # ─── Change impact patterns ────────────────────────
    IMPACT_PATTERNS = {
        # High impact (7-10) — if broken, things crash badly
        r'(?i)payment|charge|refund|billing': 9,
        r'(?i)delete|drop|truncate|destroy': 8,
        r'(?i)migration|alter.?table': 7,
        r'(?i)deploy|release|production': 8,
        r'(?i)backup|restore': 7,
        r'(?i)webhook|callback': 6,
        r'(?i)queue|worker|job': 5,

        # Medium impact (3-6)
        r'(?i)create|insert|update': 4,
        r'(?i)send.?email|notify|notification': 5,
        r'(?i)auth|login|permission': 6,
        r'(?i)cache|invalidate': 4,

        # Low impact (1-2)
        r'(?i)read|get|fetch|list': 2,
        r'(?i)display|render|show': 1,
        r'(?i)format|style|theme': 1,
    }

    # ═══════════════════════════════════════════════════
    #  MAIN SCORING
    # ═══════════════════════════════════════════════════

    def score(self, file_path: str, content: str, context: str = "") -> RiskBreakdown:
        """
        Score a file dynamically using the weighted formula.

        RISK = file × 0.30 + code × 0.30 + deps × 0.15
             + data × 0.15 + impact × 0.10
        """
        breakdown = RiskBreakdown(file_path=file_path)
        findings = []

        # 1. File sensitivity
        breakdown.file_sensitivity = self._score_file_type(file_path)

        # 2. Code findings
        code_score, code_findings = self._score_code(content)
        breakdown.code_findings = code_score
        findings.extend(code_findings)

        # 3. Dependency exposure
        breakdown.dependency_exposure = self._score_dependencies(content)

        # 4. Data sensitivity
        data_score, data_findings = self._score_data(content)
        breakdown.data_sensitivity = data_score
        findings.extend(data_findings)

        # 5. Change impact
        combined_text = content + " " + context
        breakdown.change_impact = self._score_impact(combined_text)

        # ═══ Weighted formula ══════════════════════════
        final = (
            breakdown.file_sensitivity  * 0.30
            + breakdown.code_findings   * 0.30
            + breakdown.dependency_exposure * 0.15
            + breakdown.data_sensitivity    * 0.15
            + breakdown.change_impact       * 0.10
        )
        breakdown.final_score = round(min(final, 10.0), 1)
        breakdown.findings = findings

        # Determine level
        if breakdown.final_score < 3:
            breakdown.level = RiskLevel.LOW
        elif breakdown.final_score < 6:
            breakdown.level = RiskLevel.MEDIUM
        elif breakdown.final_score < 9:
            breakdown.level = RiskLevel.HIGH
        else:
            breakdown.level = RiskLevel.CRITICAL

        return breakdown

    def score_batch(self, files: Dict[str, str]) -> List[RiskBreakdown]:
        """Score multiple files"""
        return [self.score(fp, content) for fp, content in files.items()]

    def get_max_risk(self, files: Dict[str, str]) -> RiskBreakdown:
        """Get the highest-risk file from a batch"""
        scores = self.score_batch(files)
        if not scores:
            return RiskBreakdown(file_path="none")
        return max(scores, key=lambda s: s.final_score)

    # ═══════════════════════════════════════════════════
    #  SCORING COMPONENTS
    # ═══════════════════════════════════════════════════

    def _score_file_type(self, path: str) -> float:
        """Score based on file extension and name"""
        ext = os.path.splitext(path)[1].lower()
        basename = os.path.basename(path).lower()

        # Check extension
        score = self.FILE_SENSITIVITY.get(ext, 2)

        # Check filename (overrides if higher)
        for name, s in self.FILENAME_SENSITIVITY.items():
            if name in basename:
                score = max(score, s)

        # Special path-based scoring
        path_lower = path.lower()
        if any(p in path_lower for p in ["auth", "security", "crypto"]):
            score = max(score, 5)
        if any(p in path_lower for p in ["payment", "billing", "stripe"]):
            score = max(score, 7)
        if any(p in path_lower for p in ["test", "spec", "__test"]):
            score = max(0, score - 2)  # Tests are lower risk

        return min(score, 10)

    def _score_code(self, content: str) -> Tuple[float, List[str]]:
        """Score based on code patterns found"""
        max_score = 0.0
        findings = []

        for pattern, risk in self.CODE_PATTERNS.items():
            matches = re.findall(pattern, content)
            if matches:
                max_score = max(max_score, risk)
                # Find line number
                for i, line in enumerate(content.splitlines(), 1):
                    if re.search(pattern, line):
                        severity = "🔴" if risk >= 8 else "⚠️" if risk >= 5 else "ℹ️"
                        findings.append(
                            f"{severity} Line {i}: risk={risk} — {pattern[:40]}"
                        )
                        break

        return min(max_score, 10), findings

    def _score_dependencies(self, content: str) -> float:
        """Score based on imported modules"""
        max_score = 0.0

        # Python imports
        for match in re.finditer(r'(?:import|from)\s+(\w+)', content):
            module = match.group(1)
            risk = self.RISKY_IMPORTS.get(module, 0)
            max_score = max(max_score, risk)

        # JS/TS imports
        for match in re.finditer(r'(?:require|import.*from)\s*\(?["\']([^"\']+)["\']', content):
            module = match.group(1)
            # Check base module name
            base = module.split("/")[0]
            risk = self.RISKY_IMPORTS.get(base, 0)
            max_score = max(max_score, risk)

        return min(max_score, 10)

    def _score_data(self, content: str) -> Tuple[float, List[str]]:
        """Score based on data sensitivity patterns"""
        max_score = 0.0
        findings = []

        for pattern, risk in self.DATA_PATTERNS.items():
            if re.search(pattern, content):
                max_score = max(max_score, risk)
                if risk >= 6:
                    findings.append(f"🔒 Data: {pattern} (risk={risk})")

        return min(max_score, 10), findings

    def _score_impact(self, text: str) -> float:
        """Score based on change impact patterns"""
        max_score = 0.0

        for pattern, risk in self.IMPACT_PATTERNS.items():
            if re.search(pattern, text):
                max_score = max(max_score, risk)

        return min(max_score, 10)

    # ═══════════════════════════════════════════════════
    #  ELDER ACTIVATION
    # ═══════════════════════════════════════════════════

    def should_review(self, score: float) -> Dict[str, bool]:
        """Determine which reviewers to activate"""
        level = self._score_to_level(score)
        return {
            "grandfather": level in (RiskLevel.HIGH, RiskLevel.CRITICAL),
            "grandmother": level in (RiskLevel.MEDIUM, RiskLevel.HIGH, RiskLevel.CRITICAL),
            "human_approval": level == RiskLevel.CRITICAL,
            "tester": level.value >= RiskLevel.MEDIUM.value if hasattr(level, 'value') else score >= 3,
        }

    def _score_to_level(self, score: float) -> RiskLevel:
        if score < 3:
            return RiskLevel.LOW
        elif score < 6:
            return RiskLevel.MEDIUM
        elif score < 9:
            return RiskLevel.HIGH
        return RiskLevel.CRITICAL
