"""
engines/ — aerrik.dev Runtime Intelligence

Public UX:     Family names (Grandpa, Mommy, etc.)
Internal logs: Professional engine names
"""
from engines.routing_engine import (
    TaskComplexity, ActivationPolicy, ComplexityBreakdown,
)
from engines.risk_engine import (
    RiskEngine, RiskBreakdown, RiskLevel,
)
from engines.policy_engine import (
    PolicyEngine, PolicyInput, PolicyDecision, Decision,
)

# Internal engine names (for system logs)
ENGINE_NAMES = {
    "routing":    "Complexity-Aware Routing Engine",
    "risk":       "Dynamic Risk Scoring Engine",
    "policy":     "Policy & Decision Engine",
    "validation": "Deterministic Validation Engine",
    "cost":       "Budget-Aware Cost Engine",
    "memory":     "Context Memory Engine",
    "approval":   "Human-in-the-Loop Approval Engine",
    "review":     "Risk-Aware Review Engine",
    "planning":   "Task Decomposition Engine",
    "execution":  "Multi-Agent Execution Engine",
}

__all__ = [
    "TaskComplexity", "ActivationPolicy", "ComplexityBreakdown",
    "RiskEngine", "RiskBreakdown", "RiskLevel",
    "PolicyEngine", "PolicyInput", "PolicyDecision", "Decision",
    "ENGINE_NAMES",
]
