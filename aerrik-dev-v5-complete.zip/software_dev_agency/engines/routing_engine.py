"""
🧠 aerrik.dev — Multi-Factor Task Complexity Classifier

Complexity is NOT just keyword matching.

Task Complexity =
    Scope               (how many components/systems)
  + Security Sensitivity (auth, crypto, payments)  ← HEAVY MULTIPLIER
  + Files Affected      (estimated)
  + Dependency Count    (external integrations)
  + Data Sensitivity    (PII, financial, health)

Security sensitivity is a 2x multiplier.
A simple-looking task with auth = COMPLEX.
"""
from typing import Dict, Optional
from dataclasses import dataclass
from enum import Enum


class ActivationPolicy(Enum):
    """How deep the orchestration goes"""
    SIMPLE  = "simple"    # 1 LLM call + deterministic validation
    MEDIUM  = "medium"    # Agent + validation + risk check (3-4 calls)
    COMPLEX = "complex"   # Full family pipeline (10-20 calls)


@dataclass
class ComplexityBreakdown:
    """Detailed breakdown of why a task got its classification"""
    scope: float = 0.0            # 0-10
    security: float = 0.0         # 0-10 (HEAVY multiplier)
    files: float = 0.0            # 0-10
    dependencies: float = 0.0     # 0-10
    data_sensitivity: float = 0.0 # 0-10
    raw_score: float = 0.0
    final_score: float = 0.0
    policy: ActivationPolicy = ActivationPolicy.MEDIUM
    reasoning: str = ""


class TaskComplexity:
    """
    🧠 Multi-factor complexity classifier.

    Not keyword matching — actual weighted scoring.
    Security sensitivity acts as a 2x multiplier.
    """

    # ─── Scope signals ─────────────────────────────────
    SCOPE_SIGNALS = {
        # Low scope (1-2)
        "button": 1, "card": 1, "icon": 1, "badge": 1, "tooltip": 1,
        "modal": 2, "form": 2, "input": 2, "table": 2, "list": 2,
        "navbar": 2, "sidebar": 2, "footer": 1, "header": 1,
        "function": 1, "hook": 1, "util": 1, "helper": 1,
        "fix": 1, "bug": 1, "typo": 1, "update": 1,

        # Medium scope (3-5)
        "page": 3, "route": 3, "screen": 3, "view": 3,
        "component": 3, "layout": 3, "dashboard": 4,
        "api": 3, "endpoint": 3, "router": 3,
        "middleware": 3, "service": 4, "module": 4,
        "schema": 3, "migration": 3, "model": 3,
        "docker": 4, "pipeline": 4, "ci/cd": 4,
        "test suite": 4, "test plan": 3,
        "auth": 4, "authentication": 4, "login": 3,
        "jwt": 4, "oauth": 4, "rbac": 4,
        "refresh token": 4, "session": 3,
        "build": 3, "implement": 3, "create": 2,
        "compose": 4, "container": 4, "kubernetes": 5,

        # High scope (6-10)
        "full": 7, "complete": 7, "entire": 7,
        "platform": 8, "system": 7, "architecture": 8,
        "microservice": 8, "monorepo": 8,
        "e-commerce": 9, "saas": 9, "marketplace": 9,
        "real-time": 6, "distributed": 8,
        "multi-tenant": 8, "enterprise": 9,
        "design": 5,
    }

    # ─── Security signals (HEAVY multiplier) ──────────
    SECURITY_SIGNALS = {
        # Low (1-3)
        "cors": 2, "rate limit": 2, "input validation": 2,
        "sanitize": 2, "csrf": 3,

        # Medium (4-6)
        "auth": 5, "authentication": 5, "login": 5,
        "register": 5, "session": 5, "cookie": 4,
        "jwt": 6, "token": 5, "oauth": 6,
        "password": 6, "hash": 5, "bcrypt": 5,
        "rbac": 6, "permission": 5, "role": 4,
        "api key": 5, "webhook": 4,

        # High (7-10)
        "encrypt": 8, "decrypt": 8, "crypto": 9,
        "private key": 9, "certificate": 7, "tls": 7, "ssl": 7,
        "payment": 9, "stripe": 9, "billing": 8,
        "credit card": 10, "pci": 10,
        "pii": 8, "gdpr": 8, "hipaa": 10,
        "ssn": 10, "social security": 10,
        "secret": 7, "vault": 7,
        "penetration": 8, "vulnerability": 7,
        "2fa": 7, "mfa": 7, "totp": 7,
    }

    # ─── Data sensitivity ─────────────────────────────
    DATA_SIGNALS = {
        "user data": 5, "profile": 3, "email": 4,
        "database": 4, "postgres": 4, "mongodb": 4,
        "redis": 3, "cache": 2,
        "file upload": 5, "image": 2, "document": 3,
        "analytics": 3, "metrics": 2, "logs": 2,
        "financial": 8, "transaction": 8, "invoice": 7,
        "health": 9, "medical": 9,
        "government": 8, "legal": 7,
        "backup": 5, "restore": 5, "migration": 4,
    }

    # ─── Dependency signals ───────────────────────────
    DEPENDENCY_SIGNALS = {
        # External integrations
        "stripe": 3, "twilio": 3, "sendgrid": 2,
        "aws": 4, "gcp": 4, "azure": 4, "s3": 3,
        "firebase": 3, "supabase": 3,
        "github": 2, "gitlab": 2,
        "slack": 2, "discord": 2,
        "elasticsearch": 4, "kafka": 5, "rabbitmq": 4,
        "graphql": 3, "websocket": 3, "grpc": 4,
        "redis": 2, "celery": 3, "bull": 3,
        "docker": 2, "kubernetes": 5, "terraform": 4,
        "cdn": 2, "cloudflare": 3,
    }

    @staticmethod
    def classify(description: str) -> ActivationPolicy:
        """Classify → returns just the policy (backward compatible)"""
        breakdown = TaskComplexity.classify_detailed(description)
        return breakdown.policy

    @staticmethod
    def classify_detailed(description: str) -> ComplexityBreakdown:
        """
        Full multi-factor classification with breakdown.

        Formula:
            raw = scope + files + dependencies + data
            security_multiplier = 1.0 + (security / 10)   # up to 2x
            final = raw × security_multiplier

        Thresholds:
            final < 8   → SIMPLE  (1 LLM call + deterministic validation)
            final < 20  → MEDIUM  (agent + validation + risk)
            final >= 20 → COMPLEX (full pipeline)
        """
        desc = description.lower()
        words = desc.split()
        word_count = len(words)

        # ─── Score each factor ─────────────────────────

        # Scope (0-10)
        scope = 0.0
        for signal, weight in TaskComplexity.SCOPE_SIGNALS.items():
            if signal in desc:
                scope = max(scope, weight)
        # Word count bonus
        if word_count > 50:
            scope = max(scope, 7)
        elif word_count > 30:
            scope = max(scope, 5)
        elif word_count > 15:
            scope = max(scope, 3)

        # Security (0-10) — HEAVY multiplier
        security = 0.0
        security_count = 0
        for signal, weight in TaskComplexity.SECURITY_SIGNALS.items():
            if signal in desc:
                security = max(security, weight)
                security_count += 1
        # Bonus for multiple security signals (compound complexity)
        if security_count >= 3:
            security = min(10, security + 2)

        # Files (0-10) — estimated from description
        files = 1.0  # minimum 1 file
        file_keywords = {
            "component": 2, "page": 2, "route": 2,
            "api": 3, "endpoint": 3, "schema": 2,
            "model": 2, "migration": 2, "test": 2,
            "docker": 3, "pipeline": 4, "config": 2,
            "full": 8, "complete": 8, "entire": 8,
            "platform": 10, "system": 8,
        }
        for kw, count in file_keywords.items():
            if kw in desc:
                files = max(files, count)

        # Dependencies (0-10)
        dependencies = 0.0
        for signal, weight in TaskComplexity.DEPENDENCY_SIGNALS.items():
            if signal in desc:
                dependencies += weight
        dependencies = min(dependencies, 10)

        # Data sensitivity (0-10)
        data = 0.0
        for signal, weight in TaskComplexity.DATA_SIGNALS.items():
            if signal in desc:
                data = max(data, weight)

        # ─── Calculate final score ─────────────────────

        raw = scope + (files * 0.5) + (dependencies * 0.5) + (data * 0.5)

        # Security is a MULTIPLIER (up to 2x)
        security_multiplier = 1.0 + (security / 10.0)
        final = raw * security_multiplier

        # ─── Classify ──────────────────────────────────

        if final < 6:
            policy = ActivationPolicy.SIMPLE
        elif final < 15:
            policy = ActivationPolicy.MEDIUM
        else:
            policy = ActivationPolicy.COMPLEX

        # Override: very high scope (>=8) always at least MEDIUM
        if scope >= 8 and policy == ActivationPolicy.SIMPLE:
            policy = ActivationPolicy.MEDIUM

        # Override: very high scope (>=9) always COMPLEX
        if scope >= 9:
            policy = ActivationPolicy.COMPLEX

        # Override: high scope + security always COMPLEX
        if scope >= 7 and security >= 5:
            policy = ActivationPolicy.COMPLEX

        # Override: very high security (>=8) always COMPLEX
        # (auth + crypto + payments = complex regardless of scope)
        if security >= 8:
            policy = ActivationPolicy.COMPLEX

        # Build reasoning
        reasons = []
        if scope >= 6:
            reasons.append(f"large scope ({scope:.0f}/10)")
        if security >= 5:
            reasons.append(f"HIGH security ({security:.0f}/10, {security_multiplier:.1f}x multiplier)")
        if files >= 5:
            reasons.append(f"many files (~{files:.0f})")
        if dependencies >= 4:
            reasons.append(f"external deps ({dependencies:.0f}/10)")
        if data >= 5:
            reasons.append(f"sensitive data ({data:.0f}/10)")

        reasoning = "; ".join(reasons) if reasons else "lightweight task"

        return ComplexityBreakdown(
            scope=scope,
            security=security,
            files=files,
            dependencies=dependencies,
            data_sensitivity=data,
            raw_score=round(raw, 1),
            final_score=round(final, 1),
            policy=policy,
            reasoning=reasoning,
        )
