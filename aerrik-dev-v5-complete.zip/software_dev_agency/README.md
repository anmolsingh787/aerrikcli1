# 🏢 Software Development Agency - Multi-Agent AI Framework

> A complete **family-based multi-agent** software development system where AI agents collaborate like a real dev team!

## 🏠 Family Structure

```
👨‍💼 Dad (Architect) ─── HEAD OF FAMILY
  │
  └── 👩‍💼 Mommy (Project Manager) ─── COORDINATOR
      │
      ├── 👧 Frontend Girl (React, Next.js, TypeScript)
      │    └── 👧 Designer Girl (UI/UX, Wireframes)
      │
      ├── 👦 Backend Boy (Python, FastAPI, Node.js)
      │    └── 👦 Database Boy (PostgreSQL, Redis)
      │
      ├── 👦 DevOps Boy (Docker, CI/CD, AWS)
      │
      └── 👧 Tester Girl (pytest, Jest, Playwright)
```

## 📁 Project Structure

```
software_dev_agency/
├── main.py                  # Entry Point
├── config.py                # Configuration
├── requirements.txt         # Dependencies
├── .env.example             # Environment variables template
│
├── agents/
│   ├── __init__.py          # ArchitectAgent + AgencyFamily
│   ├── base_agent.py        # Dad (Base/Parent Class)
│   ├── project_manager.py   # Mommy (Manager/Coordinator)
│   ├── frontend_agent.py    # Girl Child (Frontend Dev)
│   ├── backend_agent.py     # Boy Child (Backend Dev)
│   ├── database_agent.py    # Boy Child 2 (DB Expert)
│   ├── devops_agent.py      # Boy Child 3 (DevOps)
│   ├── tester_agent.py      # Girl Child 2 (QA Tester)
│   └── designer_agent.py    # Girl Child 3 (UI/UX)
│
├── tools/
│   ├── file_tools.py        # File creation/extraction
│   ├── code_tools.py        # Code analysis
│   ├── git_tools.py         # Git operations
│   └── api_tools.py         # API design tools
│
├── memory/
│   ├── conversation_memory.py
│   └── project_memory.py
│
├── prompts/
│   └── system_prompts.py    # All agent system prompts
│
└── output/                  # Generated projects go here
```

## 🚀 Quick Start

### 1. Install Dependencies

```bash
cd software_dev_agency
pip install -r requirements.txt
```

### 2. Set Up API Key

```bash
# Copy the template
cp .env.example .env

# Add your OpenAI API key
export OPENAI_API_KEY="sk-your-key-here"
```

### 3. Run the Agency

**Professional CLI (Recommended):**

```bash
# Show help
python cli.py --help

# Interactive mode with beautiful UI
python cli.py interactive

# Build a project
python cli.py build "Task management app with auth and kanban"

# Ask a specific agent
python cli.py ask frontend "How to create a responsive navbar?"

# Assign task to agent
python cli.py task backend "Create user authentication API"

# Show family status
python cli.py status

# Show family tree
python cli.py tree

# Chat with Dad (Architect)
python cli.py chat "Design a microservices architecture for e-commerce"

# Demo mode (no API key)
python cli.py --demo status
```

**Basic CLI (Alternative):**

```bash
# Interactive mode (default)
python main.py

# Demo mode (no API key - mock responses)
python main.py --demo

# Build a specific project
python main.py --build "Build a task management app with auth and kanban board"

# With explicit API key
python main.py --key sk-your-key-here
```

## 🎯 Usage Examples

### Programmatic Usage

```python
from main import SoftwareDevAgency

# Initialize agency
agency = SoftwareDevAgency(api_key="sk-your-key")

# ====== Build a complete project ======
results = agency.build_project("""
Build a Task Management Application with:
- User authentication (register, login, forgot password)
- Create, edit, delete tasks
- Drag & drop Kanban board
- Real-time notifications
- Dashboard with analytics
- Dark/Light mode

Tech: Next.js 14 + FastAPI + PostgreSQL + Redis
""")

# ====== Quick single tasks ======
frontend_code = agency.quick_task(
    "Create a beautiful Kanban board component with drag & drop",
    role="frontend"
)

backend_code = agency.quick_task(
    "Create CRUD API for tasks with authentication",
    role="backend"
)

schema = agency.quick_task(
    "Design database schema for users, tasks, and labels",
    role="database"
)

docker = agency.quick_task(
    "Create Docker setup for Next.js + FastAPI + PostgreSQL",
    role="devops"
)
```

### Interactive CLI

```
🏢 Agency > build Create an e-commerce platform with payments
🏢 Agency > ask frontend Create a product card component
🏢 Agency > task backend Create payment processing API
🏢 Agency > ask database Design schema for products and orders
🏢 Agency > task devops Setup CI/CD pipeline with GitHub Actions
🏢 Agency > task tester Write integration tests for auth flow
🏢 Agency > task designer Create design system with color palette
🏢 Agency > status
🏢 Agency > tree
🏢 Agency > quit
```

### 🎨 Professional CLI Commands (`cli.py`)

```bash
# Full help
python cli.py --help

# Build complete project (with progress bars!)
python cli.py build "E-commerce platform with Stripe payments" --tech "Next.js + FastAPI"

# Ask any agent directly
python cli.py ask frontend "Create a dark mode toggle component"
python cli.py ask backend "Implement JWT refresh token flow"
python cli.py ask database "Design schema for multi-tenant app"
python cli.py ask devops "Create Kubernetes deployment manifests"
python cli.py ask tester "Write E2E tests for checkout flow"
python cli.py ask designer "Create a design system for fintech app"

# Assign tasks
python cli.py task frontend "Build dashboard with charts"
python cli.py task backend "Create WebSocket notification system"

# Chat with architect
python cli.py chat "What's the best architecture for a real-time chat app?"

# See status & tree
python cli.py status
python cli.py tree

# View loaded skills
python cli.py skills
python cli.py skills --detail
python cli.py skills --skill ponytail

# Interactive mode (combines everything)
python cli.py interactive
```

### Available Roles

| Role | Agent | Skills |
|------|-------|--------|
| `architect` | Dad 👨‍💼 | System design, architecture, tech decisions |
| `pm` | Mommy 👩‍💼 | Task management, planning, coordination |
| `frontend` | Frontend Girl 👧 | React, Next.js, TypeScript, TailwindCSS |
| `backend` | Backend Boy 👦 | Python, FastAPI, Node.js, APIs |
| `database` | Database Boy 👦 | PostgreSQL, MongoDB, Redis, schemas |
| `devops` | DevOps Boy 👦 | Docker, CI/CD, Nginx, AWS |
| `tester` | Tester Girl 👧 | pytest, Jest, Playwright, QA |
| `designer` | Designer Girl 👧 | UI/UX, wireframes, design systems |

## 🏗️ How It Works

### Project Build Flow

```
USER REQUEST ──→ 👨‍💼 DAD (Architect)
                    │ Designs architecture
                    ▼
                 👩‍💼 MOMMY (PM)
                    │ Breaks into tasks
                    ├──→ 👧 Frontend (UI components, pages)
                    ├──→ 👦 Backend (APIs, logic)
                    ├──→ 👦 Database (schemas, migrations)
                    ├──→ 👦 DevOps (Docker, CI/CD)
                    ├──→ 👧 Tester (tests, QA)
                    └──→ 👧 Designer (wireframes, specs)
                    │
                    ▼
              💾 OUTPUT FILES (in ./output/)
```

### Key Features

- ✅ **Family hierarchy** — Dad → Mommy → Children delegation chain
- ✅ **Task management** — Break, assign, track, report
- ✅ **Inter-agent communication** — Messages between agents
- ✅ **Per-agent memory** — Conversation + project state
- ✅ **Tool system** — File I/O, code analysis, git, API tools
- ✅ **File extraction** — Auto-extracts code from LLM responses
- ✅ **Interactive CLI** — Chat with any agent directly
- ✅ **Mock mode** — Works without API key (for testing)
- ✅ **Progress tracking** — Sprint reports, status dashboards

## 🔧 Configuration

### Agent Config (`config.py`)

```python
AgentConfig(
    name="Backend Boy 👦",
    role=AgentRole.BACKEND_DEV,
    model="gpt-4",
    temperature=0.6,
    skills=["python", "fastapi", "nodejs"],
    can_delegate_to=[AgentRole.DATABASE_EXPERT],
    priority=3
)
```

### Switching LLM Providers

```python
# OpenAI (default)
agency = SoftwareDevAgency(api_key="sk-...")

# For Anthropic/Groq, modify base_agent.py _init_llm_client()
```

## 📊 Output Example

```
🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥
STEP 1: 👨‍💼 Dad is designing the architecture...
🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥
📐 Architecture designed!
────────────────────────────────────────────────────────────────

🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥
STEP 3: 👩‍💼 Mommy is breaking into tasks...
🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥
📋 Created 6 tasks:
   - [TASK-a1b2c3] Setup FastAPI backend -> backend_developer
   - [TASK-d4e5f6] Design database schema -> database_expert
   - [TASK-g7h8i9] Create React components -> frontend_developer
   - [TASK-j1k2l3] Setup Docker -> devops_engineer
   - [TASK-m4n5o6] Write tests -> tester
   - [TASK-p7q8r9] Design UI system -> ui_ux_designer
```

## 🔌 Extending the Framework

### Add a New Agent

1. Create `agents/new_agent.py`:
```python
from agents.base_agent import BaseAgent, Task, TaskStatus
from config import AgentRole, AGENT_CONFIGS

class NewAgent(BaseAgent):
    def __init__(self, api_key="", verbose=True):
        super().__init__(
            config=AGENT_CONFIGS[AgentRole.NEW_ROLE],
            role=AgentRole.NEW_ROLE,
            api_key=api_key,
            verbose=verbose
        )

    def execute_task(self, task: Task) -> str:
        # Your implementation
        return self.think(task.description)
```

2. Add role to `config.py`
3. Add prompt to `prompts/system_prompts.py`
4. Register in `agents/__init__.py`

### Add a New Tool

```python
# In main.py _register_tools():
def my_custom_tool(param1, param2):
    return f"Result: {param1} + {param2}"

for agent in self.family.get_all_agents().values():
    agent.register_tool("my_tool", my_custom_tool)
```

## 📝 License

MIT — Use freely for your projects!

---

Built with ❤️ — **Software Development Agency** 🏢

## 🎓 Integrated Skills (from GitHub)

All agents are enhanced with battle-tested skills from popular GitHub repositories:

### 🎯 Ponytail - The Lazy Senior Dev Philosophy
**Source:** [DietrichGebert/ponytail](https://github.com/DietrichGebert/ponytail) (84.4k ⭐)

Makes your AI agent write **54% less code** (up to 94%) while maintaining 100% safety.

**The Ladder (Before Writing Code):**
1. Does this need to exist? → no: skip it (YAGNI)
2. Already in this codebase? → reuse it, don't rewrite
3. Stdlib does it? → use it
4. Native platform feature? → use it
5. Installed dependency? → use it
6. One line? → one line
7. Only then: the minimum that works

**Applied to:** All agents

### 🎨 Frontend Skills
**Sources:** 
- [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills) (1,900+ skills)
- [PatrickJS/awesome-cursorrules](https://github.com/PatrickJS/awesome-cursorrules)

**Includes:**
- React 19+ & Next.js 15+ best practices
- TypeScript patterns (discriminated unions, generics)
- TailwindCSS with CVA (class-variance-authority)
- State management (URL state, React Query, local state)
- Performance (lazy loading, image optimization)
- Accessibility (semantic HTML, keyboard navigation)
- Testing (Testing Library, Playwright)

**Applied to:** Frontend Agent, Designer Agent, Architect, Tester

### ⚙️ Backend Skills
**Sources:**
- [sickn33/agentic-awesome-skills](https://github.com/sickn33/agentic-awesome-skills)
- [steipete/agent-rules](https://github.com/steipete/agent-rules)
- [ciembor/agent-rules-books](https://github.com/ciembor/agent-rules-books) (Clean Architecture, DDD)

**Includes:**
- FastAPI pro patterns (async, dependency injection)
- Pydantic schemas (Create/Update/Response separation)
- JWT authentication with refresh tokens
- Async SQLAlchemy with connection pooling
- Repository pattern & service layer
- Error handling (custom exceptions)
- Testing (pytest + httpx)
- Clean Architecture principles

**Applied to:** Backend Agent, Database Agent, DevOps Agent, Architect, Tester

### Skills per Agent

| Agent | Skills Applied |
|-------|---------------|
| 👨‍💼 Dad (Architect) | ✅ Ponytail + ✅ Frontend + ✅ Backend |
| 👩‍💼 Mommy (PM) | ✅ Ponytail |
| 👧 Frontend Girl | ✅ Ponytail + ✅ Frontend Skills |
| 👦 Backend Boy | ✅ Ponytail + ✅ Backend Skills |
| 👦 Database Boy | ✅ Ponytail + ✅ Backend Skills |
| 👦 DevOps Boy | ✅ Ponytail + ✅ Backend Skills |
| 👧 Tester Girl | ✅ Ponytail + ✅ Frontend + ✅ Backend |
| 👧 Designer Girl | ✅ Ponytail + ✅ Frontend Skills |

### Adding Custom Skills

1. Create a markdown file in `skills/` directory:
   ```bash
   touch skills/my_custom_skill.md
   ```

2. Add your skill content:
   ```markdown
   # My Custom Skill
   
   ## Core Principles
   - Rule 1
   - Rule 2
   
   ## Examples
   ...
   ```

3. The skill will be automatically loaded and available via:
   ```python
   from skills.skills_loader import SkillsLoader
   loader = SkillsLoader()
   content = loader.get_skill('my_custom_skill')
   ```

4. To inject into specific agents, update `skills_loader.py` → `inject_skills_into_prompt()`
