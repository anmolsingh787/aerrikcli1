"""
🚀 SOFTWARE DEVELOPMENT AGENCY — Main Orchestrator
aerrik.dev v2.0

Now with:
✅ Human approval checkpoints (/approve, /revise)
✅ Cost/token tracking with budget enforcement
✅ Feedback loop (Tester → Agent → re-test)
✅ Git auto-commits per phase
✅ Delegation cycle detection
✅ Code validation before disk write
✅ Checkpoint/resume for interrupted builds
✅ Multi-provider LLM fallback
"""
import os
import sys
import json
import time
from typing import Optional, Dict, List, Callable
from datetime import datetime
from pathlib import Path

from agents import AgencyFamily, ArchitectAgent
from agents.base_agent import Task, TaskStatus, BaseAgent
from agents.feedback_loop import FeedbackLoop
from config import AgentRole, ProjectConfig
from constants import (
    TOTAL_AGENTS, SKILLS_COUNT, LLM_PROVIDERS_COUNT,
    ActivationPolicy, TaskComplexity, RiskScorer, ValidationLevel,
    VERSION as FRAMEWORK_VERSION, CODENAME,
)
from tools.file_tools import FileTools
from tools.cost_tracker import CostTracker
from tools.code_validator import CodeValidator


class SoftwareDevAgency:
    """
    🏢 THE SOFTWARE DEVELOPMENT AGENCY v2.0

    Complete agent-based software development system with:
    - Iterative feedback loops
    - Human-in-the-loop approval
    - Cost tracking and budget enforcement
    - Code validation gates
    - Git integration
    - Checkpoint/resume
    """

    def __init__(
        self,
        api_key: str = "",
        verbose: bool = True,
        budget_usd: float = 5.0,
        enable_feedback: bool = True,
        enable_validation: bool = True,
        enable_git: bool = True,
        max_feedback_iterations: int = 3,
        approval_callback: Optional[Callable] = None,
    ):
        self.api_key = api_key
        self.verbose = verbose
        self.enable_feedback = enable_feedback
        self.enable_validation = enable_validation
        self.enable_git = enable_git

        # ─── Build the family ────────────────────────────
        self.family = AgencyFamily(api_key=api_key, verbose=verbose)

        # ─── Tools ───────────────────────────────────────
        self.file_tools = FileTools(base_dir="./output")
        self.cost_tracker = CostTracker(budget_usd=budget_usd)
        self.code_validator = CodeValidator()
        self.feedback_loop = FeedbackLoop(
            self.family,
            max_iterations=max_feedback_iterations,
            verbose=verbose,
        )

        # ─── State ───────────────────────────────────────
        self.approval_callback = approval_callback
        self._checkpoint: Dict = {}
        self._build_phase: str = ""

        # ─── Register tools & patch LLM calls ────────────
        self._register_tools()
        self._patch_agents_for_tracking()

        if verbose:
            print(f"\n🏢 aerrik.dev v2.0 READY!")
            print(f"   Budget: ${budget_usd:.2f}")
            print(f"   Feedback loop: {'ON' if enable_feedback else 'OFF'}")
            print(f"   Code validation: {'ON' if enable_validation else 'OFF'}")
            print(f"   Git integration: {'ON' if enable_git else 'OFF'}")
            print("=" * 60)

    # ═════════════════════════════════════════════════════
    #  LLM CALL TRACKING (monkey-patch agents)
    # ═════════════════════════════════════════════════════

    def _patch_agents_for_tracking(self):
        """Wrap each agent's _call_llm to track cost"""
        for name, agent in self.family.get_all_agents().items():
            original_call = agent._call_llm
            agent_name = agent.name

            def make_tracked_call(orig, a_name, model_name):
                def tracked_call(messages):
                    start = time.time()

                    # Check budget before calling
                    if self.cost_tracker.is_budget_exceeded():
                        return (
                            "[BUDGET EXCEEDED] Cannot make more API calls. "
                            f"Budget: ${self.cost_tracker.budget_usd:.2f}, "
                            f"Spent: ${self.cost_tracker.get_total_cost():.4f}"
                        )

                    # Build input text for token estimation
                    input_text = "\n".join(m.get("content", "") for m in messages)

                    # Call the original LLM
                    response = orig(messages)

                    # Record the call
                    latency = (time.time() - start) * 1000
                    self.cost_tracker.record_call(
                        agent_name=a_name,
                        model=model_name,
                        input_text=input_text,
                        output_text=response,
                        latency_ms=latency,
                    )

                    return response
                return tracked_call

            agent._call_llm = make_tracked_call(
                original_call, agent_name, agent.config.model
            )

    # ═════════════════════════════════════════════════════
    #  TOOL REGISTRATION
    # ═════════════════════════════════════════════════════

    def _register_tools(self):
        """Register tools with all agents"""
        for agent in self.family.get_all_agents().values():
            agent.register_tool("create_file", self.file_tools.create_file)
            agent.register_tool("read_file", self.file_tools.read_file)
            agent.register_tool("list_files", self.file_tools.list_files)
            agent.register_tool("validate_code", self.code_validator.validate)

    # ═════════════════════════════════════════════════════
    #  HUMAN APPROVAL CHECKPOINT
    # ═════════════════════════════════════════════════════

    def request_approval(
        self,
        phase: str,
        content: str,
        summary: str = "",
    ) -> str:
        """
        Request human approval before proceeding.

        Returns: "approve", "revise", or "abort"

        If approval_callback is set, uses it.
        Otherwise prints to console and reads input.
        """
        if self.approval_callback:
            return self.approval_callback(phase, content, summary)

        if not self.verbose:
            return "approve"  # Auto-approve in non-verbose mode

        # ─── Console approval flow ───────────────────────
        print(f"\n{'═' * 60}")
        print(f"⏸️  APPROVAL REQUIRED: {phase}")
        print(f"{'═' * 60}")

        if summary:
            print(f"\n📋 Summary: {summary}")

        # Show content preview (first 1000 chars)
        preview = content[:1000]
        if len(content) > 1000:
            preview += f"\n... ({len(content) - 1000} more chars)"
        print(f"\n{preview}")

        # Show cost so far
        print(f"\n💰 Cost so far: {self.cost_tracker.get_compact_summary()}")

        print(f"\n{'─' * 60}")
        print("  [A] Approve and continue")
        print("  [R] Revise — provide feedback for changes")
        print("  [S] Skip this phase")
        print("  [X] Abort build")
        print(f"{'─' * 60}")

        while True:
            try:
                choice = input("\n  Your choice [A/r/s/x]: ").strip().lower()
                if choice in ("", "a", "approve", "yes"):
                    print("  ✅ Approved!")
                    return "approve"
                elif choice in ("r", "revise"):
                    feedback = input("  Revision feedback: ").strip()
                    return f"revise:{feedback}"
                elif choice in ("s", "skip"):
                    print("  ⏭️ Skipped")
                    return "skip"
                elif choice in ("x", "abort", "q"):
                    print("  🛑 Aborted")
                    return "abort"
                else:
                    print("  ❓ Invalid choice. Use A/R/S/X")
            except (EOFError, KeyboardInterrupt):
                return "abort"

    def _handle_revision(
        self,
        agent: BaseAgent,
        original_output: str,
        feedback: str,
        task_description: str,
    ) -> str:
        """Handle revision request from human"""
        prompt = f"""
The user has reviewed your output and requested changes.

ORIGINAL OUTPUT:
{original_output[:2000]}

USER FEEDBACK:
{feedback}

ORIGINAL TASK:
{task_description}

Please revise your output based on the user's feedback.
Provide the complete revised output.
"""
        return agent.think(prompt)

    # ═════════════════════════════════════════════════════
    #  CODE VALIDATION GATE
    # ═════════════════════════════════════════════════════

    def validate_and_save(self, llm_response: str, phase: str = "") -> List[str]:
        """
        Validate code before writing to disk.
        Returns list of saved file paths.
        """
        files = self.file_tools.extract_files_from_response(llm_response)
        saved = []
        skipped = []
        warnings = []

        for filepath, content in files.items():
            if not content.strip():
                continue

            # ─── Validate ────────────────────────────────
            if self.enable_validation:
                result = self.code_validator.validate(filepath, content)

                if not result.valid:
                    # Code has syntax errors — try to still save but warn
                    warnings.append(
                        f"⚠️ {filepath}: {len(result.errors)} errors — "
                        f"{'; '.join(result.errors[:2])}"
                    )
                    if self.verbose:
                        print(f"   ⚠️ Validation: {filepath} has {len(result.errors)} errors")

                if result.has_security_issues:
                    warnings.append(
                        f"🔒 {filepath}: Security issues — "
                        f"{'; '.join(result.security_warnings[:2])}"
                    )
                    if self.verbose:
                        for sw in result.security_warnings:
                            print(f"   🔒 Security: {sw}")

            # ─── Save ────────────────────────────────────
            msg = self.file_tools.create_file(filepath, content)
            saved.append(msg)
            if self.verbose:
                print(f"   📄 {msg}")

        # ─── Git commit ──────────────────────────────────
        if self.enable_git and saved and phase:
            self._git_commit(phase, len(saved))

        return saved

    def _git_commit(self, phase: str, file_count: int):
        """Auto-commit after each phase"""
        try:
            from tools.git_tools import GitTools
            git = GitTools(repo_path="./output")

            # Init repo if needed
            if not os.path.exists("./output/.git"):
                git.init_repo()
                git.create_gitignore("fullstack")

            git.add_all()
            result = git.commit(f"[aerrik.dev] Phase: {phase} ({file_count} files)")
            if self.verbose and "error" not in result.lower():
                print(f"   📦 Git: committed ({phase})")
        except Exception as e:
            if self.verbose:
                print(f"   ⚠️ Git: {str(e)[:80]}")

    # ═════════════════════════════════════════════════════
    #  CHECKPOINT / RESUME
    # ═════════════════════════════════════════════════════

    def save_checkpoint(self, phase: str, data: Dict):
        """Save build checkpoint for resume capability"""
        self._checkpoint[phase] = {
            "timestamp": datetime.now().isoformat(),
            "data": data,
            "cost_so_far": self.cost_tracker.get_total_cost(),
        }

        # Persist to disk
        checkpoint_path = os.path.join("./output", ".aerrik_checkpoint.json")
        os.makedirs("./output", exist_ok=True)
        try:
            serializable = {}
            for k, v in self._checkpoint.items():
                serializable[k] = {
                    "timestamp": v["timestamp"],
                    "cost_so_far": v["cost_so_far"],
                    "data_keys": list(v["data"].keys()) if isinstance(v["data"], dict) else str(type(v["data"])),
                }
            with open(checkpoint_path, 'w') as f:
                json.dump(serializable, f, indent=2)
        except Exception:
            pass

    def has_checkpoint(self, phase: str) -> bool:
        """Check if a checkpoint exists for a phase"""
        return phase in self._checkpoint

    # ═════════════════════════════════════════════════════
    #  COST ESTIMATION (before build)
    # ═════════════════════════════════════════════════════

    def estimate_build_cost(self, description: str, model: str = "gpt-4") -> Dict:
        """Estimate cost before starting a build"""
        return self.cost_tracker.estimate_project_cost(description, model)

    # ═════════════════════════════════════════════════════
    #  MAIN BUILD PIPELINE (v2.0)
    # ═════════════════════════════════════════════════════

    def build_project(
        self,
        project_description: str,
        auto_approve: bool = False,
        model: str = "gpt-4",
    ) -> Dict:
        """
        🚀 Build a complete software project (v2.0)

        New features over v1.0:
        - Cost estimation BEFORE build
        - Human approval after architecture
        - Code validation before disk write
        - Feedback loop (test → fix → re-test)
        - Git auto-commits per phase
        - Checkpoint/resume on crash
        - Budget enforcement

        Args:
            project_description: What to build
            auto_approve: Skip approval checkpoints (for automation)
            model: LLM model to use

        Returns:
            Dict with architecture, plan, tasks, results, files, cost
        """
        results = {
            "architecture": "",
            "project_plan": "",
            "tasks": [],
            "results": {},
            "feedback": {},
            "files_created": [],
            "validation_warnings": [],
            "cost_report": "",
            "status": "started",
            "phases_completed": [],
        }

        try:
            # ─── PRE-BUILD: Cost Estimation ──────────────
            estimate = self.estimate_build_cost(project_description, model)
            results["cost_estimate"] = estimate

            if self.verbose:
                print(f"\n💰 COST ESTIMATE")
                print(f"   Model:          {estimate['model']}")
                print(f"   Estimated tasks: {estimate['estimated_tasks']}")
                print(f"   Estimated calls: {estimate['estimated_calls']}")
                print(f"   Estimated cost:  ${estimate['estimated_cost_usd']:.4f}")
                print(f"   Budget:          ${self.cost_tracker.budget_usd:.2f}")
                within = "✅ Yes" if estimate["within_budget"] else "❌ May exceed budget"
                print(f"   Within budget:   {within}")

            if not estimate["within_budget"] and not auto_approve:
                choice = self.request_approval(
                    "Cost Estimate",
                    json.dumps(estimate, indent=2),
                    f"Estimated ${estimate['estimated_cost_usd']:.4f} may exceed budget ${self.cost_tracker.budget_usd:.2f}",
                )
                if choice == "abort":
                    results["status"] = "aborted: cost estimate exceeded budget"
                    return results

            # ═════════════════════════════════════════════
            # PHASE 1: Architecture (Dad)
            # ═════════════════════════════════════════════
            if self.verbose:
                print(f"\n{'🔥' * 30}")
                print("PHASE 1: 👨‍💼 Dad is designing the architecture...")
                print(f"{'🔥' * 30}")

            self._build_phase = "architecture"
            architecture = self.family.dad.design_architecture(project_description)
            results["architecture"] = architecture
            self.save_checkpoint("architecture", {"architecture": architecture[:200]})

            if self.verbose:
                print(f"\n📐 Architecture designed!")
                print(f"{'─' * 60}")
                print(architecture[:500] + ("..." if len(architecture) > 500 else ""))
                print(f"\n💰 {self.cost_tracker.get_compact_summary()}")

            # ─── APPROVAL CHECKPOINT ─────────────────────
            if not auto_approve:
                choice = self.request_approval(
                    "Architecture Design",
                    architecture,
                    f"System architecture with tech stack and API design",
                )

                if choice == "abort":
                    results["status"] = "aborted: user rejected architecture"
                    return results
                elif choice == "skip":
                    results["status"] = "skipped: architecture phase"
                    return results
                elif choice.startswith("revise:"):
                    feedback = choice.split(":", 1)[1]
                    if self.verbose:
                        print(f"\n🔄 Revising architecture based on feedback...")
                    architecture = self._handle_revision(
                        self.family.dad, architecture, feedback, project_description
                    )
                    results["architecture"] = architecture

            results["phases_completed"].append("architecture")

            # ═════════════════════════════════════════════
            # PHASE 2: Project Plan (Mommy)
            # ═════════════════════════════════════════════
            if self.verbose:
                print(f"\n{'🔥' * 30}")
                print("PHASE 2: 👩‍💼 Mommy is creating the project plan...")
                print(f"{'🔥' * 30}")

            self._build_phase = "planning"
            project_plan = self.family.mommy.create_project_plan(architecture)
            results["project_plan"] = project_plan
            self.save_checkpoint("planning", {})

            if self.verbose:
                print(f"\n💰 {self.cost_tracker.get_compact_summary()}")

            results["phases_completed"].append("planning")

            # ═════════════════════════════════════════════
            # PHASE 3: Task Breakdown (Mommy)
            # ═════════════════════════════════════════════
            if self.verbose:
                print(f"\n{'🔥' * 30}")
                print("PHASE 3: 👩‍💼 Mommy is breaking into tasks...")
                print(f"{'🔥' * 30}")

            self._build_phase = "task_breakdown"
            tasks = self.family.mommy.break_into_tasks(
                f"Architecture:\n{architecture}\n\nProject Plan:\n{project_plan}"
            )
            results["tasks"] = [
                {
                    "id": t.id,
                    "title": t.title,
                    "assigned_to": t.assigned_to.value if t.assigned_to else None,
                    "priority": t.priority,
                }
                for t in tasks
            ]

            if self.verbose:
                print(f"\n💰 {self.cost_tracker.get_compact_summary()}")

            results["phases_completed"].append("task_breakdown")

            # ═════════════════════════════════════════════
            # PHASE 4: Execution (Children)
            # ═════════════════════════════════════════════
            if self.verbose:
                print(f"\n{'🔥' * 30}")
                print(f"PHASE 4: 👧👦 Children executing {len(tasks)} tasks...")
                print(f"{'🔥' * 30}")

            self._build_phase = "execution"
            task_results = self.family.mommy.assign_and_execute(tasks)
            results["results"] = task_results
            self.save_checkpoint("execution", {})

            results["phases_completed"].append("execution")

            # ═════════════════════════════════════════════
            # PHASE 5: Feedback Loop (Tester → Agents)
            # ═════════════════════════════════════════════
            if self.enable_feedback and task_results:
                if self.verbose:
                    print(f"\n{'🔥' * 30}")
                    print("PHASE 5: 🔄 Running feedback loop (Tester reviews code)...")
                    print(f"{'🔥' * 30}")

                self._build_phase = "feedback"

                # Build agent map for feedback loop
                agent_map = {
                    role.value: agent
                    for role, agent in [
                        (r, a) for r, a in zip(
                            [AgentRole.FRONTEND_DEV, AgentRole.BACKEND_DEV,
                             AgentRole.DATABASE_EXPERT, AgentRole.DEVOPS,
                             AgentRole.TESTER, AgentRole.DESIGNER],
                            [self.family.frontend_girl, self.family.backend_boy,
                             self.family.database_boy, self.family.devops_boy,
                             self.family.tester_girl, self.family.designer_girl]
                        )
                    ]
                }
                task_map = {t.id: t for t in tasks}

                feedback_results = self.feedback_loop.run_batch_review(
                    task_results, task_map, agent_map
                )

                results["feedback"] = {
                    task_id: {
                        "passed": fr.passed,
                        "iterations": fr.iterations,
                        "issues": fr.history[-1]["issues"] if fr.history else [],
                    }
                    for task_id, fr in feedback_results.items()
                }

                passed = sum(1 for fr in feedback_results.values() if fr.passed)
                total = len(feedback_results)
                if self.verbose:
                    print(f"\n🔄 Feedback: {passed}/{total} tasks passed review")
                    print(f"💰 {self.cost_tracker.get_compact_summary()}")

                results["phases_completed"].append("feedback")

            # ═════════════════════════════════════════════
            # PHASE 6: Validate & Save Files
            # ═════════════════════════════════════════════
            if self.verbose:
                print(f"\n{'🔥' * 30}")
                print("PHASE 6: 💾 Validating and saving files...")
                print(f"{'🔥' * 30}")

            self._build_phase = "save"
            all_files = []
            all_warnings = []

            for task_id, result_text in task_results.items():
                saved = self.validate_and_save(result_text, phase=f"task-{task_id}")
                all_files.extend(saved)

            results["files_created"] = all_files
            results["validation_warnings"] = all_warnings
            results["phases_completed"].append("save")

            # ═════════════════════════════════════════════
            # PHASE 7: Final Report
            # ═════════════════════════════════════════════
            if self.verbose:
                print(f"\n{'🔥' * 30}")
                print("PHASE 7: 📊 Final Report")
                print(f"{'🔥' * 30}")

            # Cost report
            results["cost_report"] = self.cost_tracker.get_summary()
            if self.verbose:
                print(results["cost_report"])
                print(self.family.mommy.get_progress_report())
                print(self.family.get_family_status())

            # Save cost report to disk
            self.cost_tracker.save()

            results["status"] = "completed"
            results["phases_completed"].append("report")

        except Exception as e:
            results["status"] = f"error: {str(e)}"
            results["cost_report"] = self.cost_tracker.get_summary()
            if self.verbose:
                print(f"\n❌ ERROR: {str(e)}")
                import traceback
                traceback.print_exc()

            # Save checkpoint for resume
            self.save_checkpoint("error", {"error": str(e)})

        return results

    # ═════════════════════════════════════════════════════
    #  SMART ROUTING (Complexity-Aware)
    # ═════════════════════════════════════════════════════

    def quick_task(
        self,
        task_description: str,
        role: str = "backend",
        auto_policy: bool = True,
    ) -> str:
        """
        Quick single task execution with smart routing.

        🧠 Agent Activation Policy:
        - SIMPLE tasks → Direct to agent (2 LLM calls)
        - MEDIUM tasks → Agent + validation (3-4 calls)
        - COMPLEX tasks → Full pipeline (Dad → Mommy → Agent → Test)

        Not every task deserves the whole family.
        """
        role_map = {
            "architect": self.family.dad,
            "grandfather": self.family.grandfather,
            "grandmother": self.family.grandmother,
            "pm": self.family.mommy,
            "frontend": self.family.frontend_girl,
            "backend": self.family.backend_boy,
            "database": self.family.database_boy,
            "devops": self.family.devops_boy,
            "tester": self.family.tester_girl,
            "designer": self.family.designer_girl,
            "mobile": self.family.mobile_girl,
            "security": self.family.security_boy,
        }

        agent = role_map.get(role.lower())
        if not agent:
            return f"❌ Unknown role: {role}. Available: {list(role_map.keys())}"

        # ─── Classify complexity ─────────────────────────
        if auto_policy:
            policy = TaskComplexity.classify(task_description)
        else:
            policy = ActivationPolicy.SIMPLE

        if self.verbose:
            print(f"  🧠 Policy: {policy.value} (auto-detected)")

        task = Task(title=task_description[:50], description=task_description)

        # ─── SIMPLE: Direct execution ────────────────────
        if policy == ActivationPolicy.SIMPLE:
            result = agent.execute_task(task)

        # ─── MEDIUM: Execute + validate ──────────────────
        elif policy == ActivationPolicy.MEDIUM:
            result = agent.execute_task(task)

            # Run Level 1+2 validation on result
            if self.enable_validation:
                files = self.file_tools.extract_files_from_response(result)
                for fp, content in files.items():
                    vr = self.code_validator.validate(fp, content)
                    if not vr.valid and self.verbose:
                        print(f"  ⚠️ Validation: {fp}: {vr.errors[:2]}")

        # ─── COMPLEX: Full mini-pipeline ─────────────────
        else:
            # Quick architecture check from Dad
            if self.verbose:
                print(f"  📐 Dad reviewing approach...")
            arch_input = agent.think(
                f"Quick architecture review: {task_description}. "
                f"Provide brief guidance (3-5 bullet points)."
            )
            # Then execute with context
            result = agent.think(
                f"Architecture guidance:\n{arch_input[:500]}\n\n"
                f"Now implement: {task_description}"
            )

        # ─── Risk-based Elder review ─────────────────────
        if self.enable_feedback:
            files = self.file_tools.extract_files_from_response(result)
            if files:
                max_risk = max(
                    (RiskScorer.score_file(fp, c) for fp, c in files.items()),
                    default=0
                )
                elders = RiskScorer.should_review_elders(max_risk)

                if elders["grandfather"] and self.verbose:
                    print(f"  👴 Risk score {max_risk}/10 — Grandfather reviewing...")
                    review = self.family.grandfather.review_code(
                        list(files.values())[0][:2000],
                        context=task_description
                    )
                    result += f"\n\n--- 👴 Grandfather Review ---\n{review[:500]}"

                elif elders["grandmother"] and self.verbose:
                    print(f"  👵 Risk score {max_risk}/10 — Grandmother reviewing...")

        if self.verbose:
            print(f"\n💰 {self.cost_tracker.get_compact_summary()}")

        return result

    def chat(self, message: str) -> str:
        """Chat with Dad (Architect)"""
        return self.family.dad.process_request(message)

    # ═════════════════════════════════════════════════════
    #  INTERACTIVE MODE (v2.0)
    # ═════════════════════════════════════════════════════

    def interactive_mode(self):
        """Interactive CLI mode with all v2.0 features"""
        print("\n" + "=" * 60)
        print("🏢 aerrik.dev v2.0 — Interactive Mode")
        print("=" * 60)
        print("""
Commands:
  build <description>  - Build a complete project (with approvals)
  quick <role> <task>  - Quick single-agent task
  cost                 - Show cost report
  estimate <desc>      - Estimate build cost before starting
  status               - Show family status
  tree                 - Show family tree
  skills               - Show loaded skills
  help                 - Show this help
  quit                 - Exit
""")
        while True:
            try:
                user_input = input(f"\n💰 {self.cost_tracker.get_compact_summary()}\n🏢 > ").strip()

                if not user_input:
                    continue
                if user_input.lower() in ('quit', 'exit', 'q'):
                    print(f"\n{self.cost_tracker.get_summary()}")
                    print("👋 Goodbye!")
                    break
                elif user_input.lower() == 'cost':
                    print(self.cost_tracker.get_summary())
                elif user_input.lower() == 'status':
                    print(self.family.get_family_status())
                elif user_input.lower() == 'tree':
                    self.family.print_family_tree()
                elif user_input.lower() == 'help':
                    print("Commands: build, quick, cost, estimate, status, tree, skills, quit")
                elif user_input.lower().startswith('estimate '):
                    desc = user_input[9:]
                    est = self.estimate_build_cost(desc)
                    print(f"\n💰 Cost Estimate:")
                    print(f"   Tasks: {est['estimated_tasks']}")
                    print(f"   Calls: {est['estimated_calls']}")
                    print(f"   Cost:  ${est['estimated_cost_usd']:.4f}")
                    print(f"   Budget: ${est['budget_remaining']:.2f} remaining")
                    print(f"   Within budget: {'✅' if est['within_budget'] else '❌'}")
                elif user_input.lower().startswith('build '):
                    desc = user_input[6:]
                    self.build_project(desc, auto_approve=False)
                elif user_input.lower().startswith('quick '):
                    parts = user_input[6:].split(' ', 1)
                    if len(parts) == 2:
                        role, task = parts
                        print(self.quick_task(task, role))
                    else:
                        print("Usage: quick <role> <description>")
                else:
                    print(self.chat(user_input))

            except KeyboardInterrupt:
                print(f"\n{self.cost_tracker.get_summary()}")
                print("\n👋 Goodbye!")
                break
            except Exception as e:
                print(f"❌ Error: {str(e)}")


# ═══════════════════════════════════════════════════════════
#  MAIN
# ═══════════════════════════════════════════════════════════

def main():
    """Main entry point"""
    api_key = os.getenv("OPENAI_API_KEY", "")

    if len(sys.argv) > 1:
        if sys.argv[1] == "--key" and len(sys.argv) > 2:
            api_key = sys.argv[2]
        elif sys.argv[1] == "--demo":
            api_key = ""

    agency = SoftwareDevAgency(
        api_key=api_key,
        verbose=True,
        budget_usd=5.0,
        enable_feedback=True,
        enable_validation=True,
        enable_git=True,
    )

    if len(sys.argv) > 1 and sys.argv[1] == "--build":
        description = " ".join(sys.argv[2:])
        agency.build_project(description)
    else:
        agency.interactive_mode()


if __name__ == "__main__":
    main()
