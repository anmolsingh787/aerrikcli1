"""
🧠 Skill Memory & Self-Improvement Engine

Inspired by:
- Memento-Skills: Task → Execute → Reflect → Skill Update
- Acontext: Skill IS Memory, Memory IS Skill

After each task:
1. Agent executes
2. Tester validates (pass/fail)
3. Reflector analyzes WHY (if failed)
4. Skill Memory updates with learned patterns
5. Next execution uses improved skill

No model retraining needed.
"""
import os
import json
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path


@dataclass
class LearnedPattern:
    """A pattern learned from experience"""
    pattern: str                  # The actual rule/pattern
    source_task: str              # What task triggered this
    category: str                 # e.g., "frontend", "backend", "security"
    confidence: float = 0.5       # 0-1, increases with repeated success
    times_applied: int = 0        # How many times this was used
    times_succeeded: int = 0      # How many times it helped
    times_failed: int = 0         # How many times it failed
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    last_used: str = field(default_factory=lambda: datetime.now().isoformat())

    @property
    def success_rate(self) -> float:
        total = self.times_succeeded + self.times_failed
        if total == 0:
            return 0.5
        return self.times_succeeded / total


@dataclass
class TaskReflection:
    """Reflection on a completed task"""
    task_id: str
    task_description: str
    agent: str
    outcome: str                  # "success", "partial", "failure"
    issues_found: List[str] = field(default_factory=list)
    root_causes: List[str] = field(default_factory=list)
    lessons: List[str] = field(default_factory=list)
    patterns_extracted: List[str] = field(default_factory=list)
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


class SkillMemory:
    """
    🧠 Skill Memory — Persistent learning from experience

    Structure:
    memory/skills/
    ├── frontend/
    │   ├── successful_patterns.md
    │   ├── failed_patterns.md
    │   └── learned_rules.json
    ├── backend/
    │   ├── successful_patterns.md
    │   ├── failed_patterns.md
    │   └── learned_rules.json
    └── ...
    """

    def __init__(self, storage_dir: str = "./memory/skills"):
        self.storage_dir = storage_dir
        os.makedirs(storage_dir, exist_ok=True)

        # In-memory cache
        self.patterns: Dict[str, List[LearnedPattern]] = {}
        self.reflections: List[TaskReflection] = []

        # Load existing
        self._load_all()

    # ═══════════════════════════════════════════════════
    #  LEARN (after task completion)
    # ═══════════════════════════════════════════════════

    def reflect(
        self,
        task_id: str,
        task_description: str,
        agent: str,
        outcome: str,
        result_text: str = "",
        test_feedback: str = "",
    ) -> TaskReflection:
        """
        Reflect on a completed task and extract learnings.

        This is the "Reflector" component.
        """
        reflection = TaskReflection(
            task_id=task_id,
            task_description=task_description,
            agent=agent,
            outcome=outcome,
        )

        # ─── Analyze outcome ───────────────────────────
        if outcome == "failure":
            # Extract issues from test feedback
            if test_feedback:
                reflection.issues_found = self._extract_issues(test_feedback)
                reflection.root_causes = self._analyze_root_causes(
                    reflection.issues_found, task_description
                )
                reflection.lessons = self._extract_lessons(
                    reflection.root_causes, agent
                )
                # Convert lessons to patterns
                for lesson in reflection.lessons:
                    pattern = self._lesson_to_pattern(lesson, agent)
                    if pattern:
                        reflection.patterns_extracted.append(pattern)
                        self.add_pattern(pattern, agent, task_description)

        elif outcome == "success":
            # Reinforce successful patterns
            category = self._agent_to_category(agent)
            for p in self.patterns.get(category, []):
                if self._pattern_matches_task(p.pattern, task_description):
                    p.times_applied += 1
                    p.times_succeeded += 1
                    p.confidence = min(1.0, p.confidence + 0.1)
                    p.last_used = datetime.now().isoformat()

        self.reflections.append(reflection)
        self._save_reflection(reflection)
        return reflection

    def add_pattern(
        self, pattern: str, agent: str, source_task: str
    ) -> LearnedPattern:
        """Add a new learned pattern"""
        category = self._agent_to_category(agent)

        # Check if pattern already exists
        for existing in self.patterns.get(category, []):
            if self._patterns_similar(existing.pattern, pattern):
                # Reinforce existing
                existing.times_applied += 1
                existing.confidence = min(1.0, existing.confidence + 0.05)
                self._save_patterns(category)
                return existing

        # New pattern
        lp = LearnedPattern(
            pattern=pattern,
            source_task=source_task,
            category=category,
            confidence=0.3,  # Start low, grow with evidence
        )

        if category not in self.patterns:
            self.patterns[category] = []
        self.patterns[category].append(lp)
        self._save_patterns(category)
        return lp

    # ═══════════════════════════════════════════════════
    #  RECALL (before task execution)
    # ═══════════════════════════════════════════════════

    def recall(
        self, agent: str, task_description: str, max_patterns: int = 5
    ) -> List[LearnedPattern]:
        """
        Recall relevant patterns for a new task.

        Returns patterns sorted by relevance × confidence.
        """
        category = self._agent_to_category(agent)
        patterns = self.patterns.get(category, [])

        # Score relevance
        scored = []
        for p in patterns:
            relevance = self._pattern_relevance(p.pattern, task_description)
            if relevance > 0:
                score = relevance * p.confidence * p.success_rate
                scored.append((score, p))

        # Sort by score, return top N
        scored.sort(key=lambda x: x[0], reverse=True)
        result = [p for _, p in scored[:max_patterns]]

        # Update last_used
        for p in result:
            p.last_used = datetime.now().isoformat()
            p.times_applied += 1

        return result

    def get_context_prompt(
        self, agent: str, task_description: str
    ) -> str:
        """
        Generate a context prompt with recalled patterns.

        This gets injected into the agent's prompt before execution.
        """
        patterns = self.recall(agent, task_description)
        if not patterns:
            return ""

        lines = [
            "\n🧠 LEARNED PATTERNS (from previous experience):",
            "Apply these rules when relevant:\n",
        ]
        for i, p in enumerate(patterns, 1):
            confidence_pct = int(p.confidence * 100)
            lines.append(
                f"  {i}. [{confidence_pct}% confidence] {p.pattern}"
            )

        return "\n".join(lines)

    # ═══════════════════════════════════════════════════
    #  ANALYSIS HELPERS
    # ═══════════════════════════════════════════════════

    def _extract_issues(self, feedback: str) -> List[str]:
        """Extract issues from test/review feedback"""
        issues = []
        for line in feedback.splitlines():
            line = line.strip()
            if any(marker in line for marker in ["❌", "ISSUE", "ERROR", "FAIL", "- "]):
                clean = line.lstrip("- ❌•·").strip()
                if clean and len(clean) > 5:
                    issues.append(clean[:200])
        return issues[:10]

    def _analyze_root_causes(
        self, issues: List[str], task: str
    ) -> List[str]:
        """Analyze root causes from issues"""
        causes = []
        for issue in issues:
            il = issue.lower()
            if "responsive" in il or "viewport" in il or "mobile" in il:
                causes.append("Missing responsive design handling")
            if "import" in il or "undefined" in il:
                causes.append("Missing or incorrect imports")
            if "type" in il or "any" in il:
                causes.append("Type safety issues")
            if "auth" in il or "permission" in il:
                causes.append("Authentication/authorization gap")
            if "error" in il and "handl" in il:
                causes.append("Insufficient error handling")
            if "test" in il or "assert" in il:
                causes.append("Test coverage gap")
            if "sql" in il or "injection" in il:
                causes.append("SQL injection vulnerability")
            if "xss" in il or "sanitiz" in il:
                causes.append("XSS vulnerability — missing input sanitization")
        return list(set(causes))[:5]

    def _extract_lessons(
        self, causes: List[str], agent: str
    ) -> List[str]:
        """Convert root causes to actionable lessons"""
        lessons = []
        for cause in causes:
            lesson = f"When working on {agent} tasks: {cause}. Always verify before submission."
            lessons.append(lesson)
        return lessons

    def _lesson_to_pattern(self, lesson: str, agent: str) -> str:
        """Convert a lesson to a reusable pattern"""
        # Simple extraction — in production, this would use an LLM
        return lesson.replace(
            f"When working on {agent} tasks: ", ""
        ).replace(". Always verify before submission.", "")

    def _agent_to_category(self, agent: str) -> str:
        """Map agent name to skill category"""
        agent_lower = agent.lower()
        if any(w in agent_lower for w in ["frontend", "designer", "mobile"]):
            return "frontend"
        elif any(w in agent_lower for w in ["backend", "database", "devops"]):
            return "backend"
        elif any(w in agent_lower for w in ["security"]):
            return "security"
        elif any(w in agent_lower for w in ["tester", "test"]):
            return "testing"
        return "general"

    def _pattern_matches_task(self, pattern: str, task: str) -> bool:
        """Check if a pattern is relevant to a task"""
        pattern_words = set(pattern.lower().split())
        task_words = set(task.lower().split())
        overlap = pattern_words & task_words
        return len(overlap) >= 2

    def _pattern_relevance(self, pattern: str, task: str) -> float:
        """Score pattern relevance to task (0-1)"""
        pattern_words = set(pattern.lower().split())
        task_words = set(task.lower().split())
        if not pattern_words:
            return 0
        overlap = len(pattern_words & task_words)
        return min(1.0, overlap / max(len(pattern_words), 1))

    def _patterns_similar(self, a: str, b: str) -> bool:
        """Check if two patterns are similar (>70% word overlap)"""
        words_a = set(a.lower().split())
        words_b = set(b.lower().split())
        if not words_a or not words_b:
            return False
        overlap = len(words_a & words_b)
        total = len(words_a | words_b)
        return (overlap / total) > 0.7

    # ═══════════════════════════════════════════════════
    #  PERSISTENCE
    # ═══════════════════════════════════════════════════

    def _save_patterns(self, category: str):
        """Save patterns for a category to disk"""
        cat_dir = os.path.join(self.storage_dir, category)
        os.makedirs(cat_dir, exist_ok=True)

        filepath = os.path.join(cat_dir, "learned_rules.json")
        patterns = self.patterns.get(category, [])
        data = [asdict(p) for p in patterns]

        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)

        # Also save as readable markdown
        md_path = os.path.join(cat_dir, "successful_patterns.md")
        with open(md_path, 'w') as f:
            f.write(f"# Learned Patterns — {category.title()}\n\n")
            f.write(f"*Auto-generated from {len(patterns)} experiences*\n\n")
            for p in sorted(patterns, key=lambda x: x.confidence, reverse=True):
                conf = int(p.confidence * 100)
                rate = int(p.success_rate * 100)
                f.write(
                    f"- [{conf}% confidence, {rate}% success] "
                    f"{p.pattern}\n"
                )

    def _save_reflection(self, reflection: TaskReflection):
        """Save a reflection to disk"""
        filepath = os.path.join(self.storage_dir, "reflections.json")

        # Load existing
        existing = []
        if os.path.exists(filepath):
            try:
                with open(filepath) as f:
                    existing = json.load(f)
            except Exception:
                pass

        existing.append(asdict(reflection))

        # Keep last 500 reflections
        existing = existing[-500:]

        with open(filepath, 'w') as f:
            json.dump(existing, f, indent=2)

    def _load_all(self):
        """Load all patterns from disk"""
        if not os.path.exists(self.storage_dir):
            return

        for category_dir in Path(self.storage_dir).iterdir():
            if not category_dir.is_dir():
                continue
            category = category_dir.name
            filepath = category_dir / "learned_rules.json"
            if filepath.exists():
                try:
                    with open(filepath) as f:
                        data = json.load(f)
                    self.patterns[category] = [
                        LearnedPattern(**d) for d in data
                    ]
                except Exception:
                    pass

    # ═══════════════════════════════════════════════════
    #  STATS
    # ═══════════════════════════════════════════════════

    def get_stats(self) -> Dict[str, Any]:
        """Get memory statistics"""
        total_patterns = sum(len(v) for v in self.patterns.values())
        total_reflections = len(self.reflections)

        avg_confidence = 0
        if total_patterns > 0:
            all_patterns = [p for ps in self.patterns.values() for p in ps]
            avg_confidence = sum(p.confidence for p in all_patterns) / total_patterns

        return {
            "total_patterns": total_patterns,
            "total_reflections": total_reflections,
            "categories": list(self.patterns.keys()),
            "avg_confidence": round(avg_confidence, 2),
            "patterns_by_category": {
                cat: len(ps) for cat, ps in self.patterns.items()
            },
        }
