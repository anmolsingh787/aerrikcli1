"""
Project memory - stores project-level state across sessions
"""
import json
import os
from typing import Dict, List, Any, Optional
from datetime import datetime


class ProjectMemory:
    """Persistent project memory"""

    def __init__(self, project_name: str, storage_path: str = "./memory_data"):
        self.project_name = project_name
        self.storage_path = storage_path
        os.makedirs(storage_path, exist_ok=True)

        self.data: Dict[str, Any] = {
            "project_name": project_name,
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat(),
            "architecture": "",
            "tech_stack": {},
            "tasks": [],
            "files_generated": [],
            "decisions": [],
            "notes": [],
            "metadata": {}
        }

        # Try to load existing
        self._load()

    def _filepath(self) -> str:
        """Get filepath for this project"""
        safe_name = self.project_name.lower().replace(" ", "_")
        return os.path.join(self.storage_path, f"project_{safe_name}.json")

    def _load(self) -> bool:
        """Load project data from disk"""
        filepath = self._filepath()
        if os.path.exists(filepath):
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    self.data = json.load(f)
                return True
            except Exception:
                return False
        return False

    def save(self) -> str:
        """Save project data to disk"""
        self.data["updated_at"] = datetime.now().isoformat()
        filepath = self._filepath()
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(self.data, f, indent=2, ensure_ascii=False)
        return f"✅ Project saved to {filepath}"

    def set_architecture(self, architecture: str):
        """Store architecture"""
        self.data["architecture"] = architecture

    def set_tech_stack(self, tech_stack: Dict):
        """Store tech stack"""
        self.data["tech_stack"] = tech_stack

    def add_task(self, task: Dict):
        """Add a task"""
        task["added_at"] = datetime.now().isoformat()
        self.data["tasks"].append(task)

    def add_decision(self, decision: str, reason: str = ""):
        """Record a decision"""
        self.data["decisions"].append({
            "decision": decision,
            "reason": reason,
            "timestamp": datetime.now().isoformat()
        })

    def add_note(self, note: str):
        """Add a note"""
        self.data["notes"].append({
            "note": note,
            "timestamp": datetime.now().isoformat()
        })

    def add_file(self, filepath: str):
        """Record a generated file"""
        if filepath not in self.data["files_generated"]:
            self.data["files_generated"].append(filepath)

    def get_summary(self) -> str:
        """Get project summary"""
        return f"""
PROJECT: {self.data['project_name']}
CREATED: {self.data['created_at']}
UPDATED: {self.data['updated_at']}

ARCHITECTURE: {self.data['architecture'][:200]}...
TECH STACK: {json.dumps(self.data['tech_stack'], indent=2)}

TASKS: {len(self.data['tasks'])}
FILES GENERATED: {len(self.data['files_generated'])}
DECISIONS: {len(self.data['decisions'])}
NOTES: {len(self.data['notes'])}
"""
