"""
Conversation memory for agents
Stores and retrieves conversation history
"""
import json
import os
from typing import List, Dict, Optional
from datetime import datetime


class ConversationMemory:
    """Persistent conversation memory for agents"""

    def __init__(self, storage_path: str = "./memory_data", max_history: int = 100):
        self.storage_path = storage_path
        self.max_history = max_history
        self.history: List[Dict] = []
        os.makedirs(storage_path, exist_ok=True)

    def add_message(self, role: str, content: str, metadata: Dict = None) -> None:
        """Add a message to history"""
        msg = {
            "role": role,
            "content": content,
            "timestamp": datetime.now().isoformat(),
            "metadata": metadata or {}
        }
        self.history.append(msg)

        # Trim if too long
        if len(self.history) > self.max_history:
            self.history = self.history[-self.max_history:]

    def get_history(self, last_n: Optional[int] = None) -> List[Dict]:
        """Get conversation history"""
        if last_n:
            return self.history[-last_n:]
        return self.history.copy()

    def get_summary(self) -> str:
        """Get a text summary of conversation"""
        if not self.history:
            return "No conversation history."

        summary = "CONVERSATION HISTORY:\n" + "=" * 40 + "\n"
        for msg in self.history[-20:]:
            role = msg["role"].upper()
            content = msg["content"][:150]
            if len(msg["content"]) > 150:
                content += "..."
            summary += f"[{role}]: {content}\n\n"
        return summary

    def save(self, filename: str = "conversation.json") -> str:
        """Save history to file"""
        filepath = os.path.join(self.storage_path, filename)
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(self.history, f, indent=2, ensure_ascii=False)
        return f"✅ Saved to {filepath}"

    def load(self, filename: str = "conversation.json") -> bool:
        """Load history from file"""
        filepath = os.path.join(self.storage_path, filename)
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                self.history = json.load(f)
            return True
        return False

    def clear(self) -> None:
        """Clear history"""
        self.history = []

    def search(self, query: str) -> List[Dict]:
        """Search history for a query"""
        results = []
        query_lower = query.lower()
        for msg in self.history:
            if query_lower in msg["content"].lower():
                results.append(msg)
        return results
