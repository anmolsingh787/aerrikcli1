"""Memory package"""
