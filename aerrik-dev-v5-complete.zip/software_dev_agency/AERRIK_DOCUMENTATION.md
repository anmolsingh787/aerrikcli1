# aerrik.dev — Complete AI Agent Documentation

> **Version:** 1.0.0 (Genesis)
> **Website:** https://aerrik.dev
> **Stack:** Python · OpenAI · Rich · Click
> **License:** MIT

---

## Table of Contents

1. [What is aerrik.dev?](#what-is-aerrikdev)
2. [Architecture Overview](#architecture-overview)
3. [The Agent Family](#the-agent-family)
4. [Skills System](#skills-system)
5. [Tools & Capabilities](#tools--capabilities)
6. [Memory System](#memory-system)
7. [Terminal Interface](#terminal-interface)
8. [CLI Commands](#cli-commands)
9. [API & Programmatic Usage](#api--programmatic-usage)
10. [Project Build Pipeline](#project-build-pipeline)
11. [Configuration](#configuration)
12. [Extending the Framework](#extending-the-framework)
13. [File Structure](#file-structure)
14. [Examples & Workflows](#examples--workflows)
15. [Troubleshooting](#troubleshooting)

---

## What is aerrik.dev?

aerrik.dev is a **multi-agent AI software development framework** that simulates a complete software development team inside your terminal. It uses a family-based hierarchy where specialized AI agents collaborate to design, build, test, and deploy software projects.

### Core Philosophy

```
"Think like a senior dev team, not a code generator."
```

Every agent in aerrik.dev follows the **Ponytail Principle** (from the 84k⭐ GitHub repo):
> The best code is the code you never wrote. Before writing anything, the agent runs through a 7-step ladder:

1. Does this need to exist? → no: skip it (YAGNI)
2. Already in this codebase? → reuse it
3. Stdlib does it? → use it
4. Native platform feature? → use it
5. Installed dependency? → use it
6. One line? → one line
7. Only then: write the minimum that works

### What Makes It Different

| Feature | Typical AI Code Gen | aerrik.dev |
|---------|-------------------|------------|
| Agents | Single model | 8 specialized agents |
| Skills | Generic prompts | 7 GitHub-sourced skill modules |
| Architecture | No planning | Dad designs → Mommy plans → Children execute |
| Code quality | Verbose output | Ponytail: 54% less code |
| Security | Basic | Trail of Bits security audit patterns |
| Frontend | Generic React | shadcn/ui, Next.js 15+, Tailwind v4 |
| Backend | Basic API | Clean Architecture, CQRS, DDD |
| Testing | Optional | Built-in QA agent |
| DevOps | None | Docker, CI/CD, monitoring |
| Memory | None | Conversation + project memory |
| Interface | Web chat | Full terminal REPL with @mentions |

---

## Architecture Overview

### System Architecture

```
┌──────────────────────────────────────────────────────────────┐
│                    USER (Terminal / CLI)                       │
│  aerrik.py (Custom Terminal)    cli.py (Click CLI)            │
│  terminal.py (Claude-style)     main.py (Basic REPL)          │
└─────────────────────┬────────────────────────────────────────┘
                      │
                      ▼
┌──────────────────────────────────────────────────────────────┐
│              SoftwareDevAgency (Orchestrator)                   │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │              AgencyFamily (Agent Registry)                │ │
│  │                                                          │ │
│  │   ┌──────────┐                                           │ │
│  │   │ 👨‍💼 Dad    │──→ ArchitectAgent (Designs everything)   │ │
│  │   │ (Head)    │                                          │ │
│  │   └────┬─────┘                                           │ │
│  │        │ delegates                                       │ │
│  │        ▼                                                 │ │
│  │   ┌──────────┐                                           │ │
│  │   │ 👩‍💼 Mommy │──→ ProjectManagerAgent (Plans & assigns) │ │
│  │   │ (Coord.)  │                                          │ │
│  │   └────┬─────┘                                           │ │
│  │        │ delegates to all children                       │ │
│  │        ├──→ 👧 FrontendAgent (React/Next.js/TS)          │ │
│  │        │       └──→ 👧 DesignerAgent (UI/UX)              │ │
│  │        ├──→ 👦 BackendAgent (Python/FastAPI)              │ │
│  │        │       └──→ 👦 DatabaseAgent (PostgreSQL/Redis)   │ │
│  │        ├──→ 👦 DevOpsAgent (Docker/CI/CD)                │ │
│  │        └──→ 👧 TesterAgent (pytest/Jest/E2E)             │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐       │
│  │ SkillsLoader │  │  FileTools   │  │   Memory     │       │
│  │ (7 modules)  │  │  CodeTools   │  │ Conversation │       │
│  │              │  │  GitTools    │  │   Project    │       │
│  │              │  │  APITools    │  │              │       │
│  └──────────────┘  └──────────────┘  └──────────────┘       │
└──────────────────────────────────────────────────────────────┘
                      │
                      ▼
┌──────────────────────────────────────────────────────────────┐
│                    OUTPUT (./output/)                           │
│  Generated project files, code, configs, tests                │
└──────────────────────────────────────────────────────────────┘
```

### Data Flow (Build Pipeline)

```
USER REQUEST
    │
    ▼
┌─────────────────────┐
│ 👨‍💼 Dad (Architect)  │ → Analyzes requirements
│                     │ → Designs system architecture
│                     │ → Chooses tech stack
│                     │ → Defines API contracts
│                     │ → Creates component diagram
└─────────┬───────────┘
          │ architecture document
          ▼
┌─────────────────────┐
│ 👩‍💼 Mommy (PM)       │ → Creates project plan (6 phases)
│                     │ → Breaks into actionable tasks
│                     │ → Assigns to right agents
│                     │ → Manages dependencies
│                     │ → Tracks progress
└─────────┬───────────┘
          │ task list with assignments
          ▼
┌─────────────────────┐
│ 👧👦 Children        │ → Execute assigned tasks
│ (6 specialist       │ → Generate code with file paths
│  agents)            │ → Follow skill-specific patterns
└─────────┬───────────┘
          │ generated code
          ▼
┌─────────────────────┐
│ FileTools           │ → Extract files from LLM response
│                     │ → Create directory structure
│                     │ → Write files to ./output/
└─────────────────────┘
```

### Agent Communication Model

```
Agent A ──Message──→ Agent B
           │
           ├── id: "abc123"
           ├── sender: "Architect Dad"
           ├── receiver: "Backend Boy"
           ├── type: DELEGATION
           ├── content: "Create user auth API..."
           ├── metadata: {task_id: "TASK-xyz"}
           └── timestamp: "2026-07-16T..."
```

Each agent has:
- **Inbox:** Messages received
- **Outbox:** Messages sent
- **Memory:** Conversation history + context + files generated
- **Tools:** Registered functions (create_file, read_file, etc.)

---

## The Agent Family

### 👨‍💼 Dad — Architect Agent

**Role:** Chief Software Architect / Head of Family
**File:** `agents/__init__.py` → `ArchitectAgent`
**Priority:** 1 (highest)

**Responsibilities:**
- Analyze project requirements thoroughly
- Design high-level and low-level system architecture
- Choose appropriate tech stack with justification
- Define complete folder structure
- Create component diagrams (text-based)
- Set coding standards and patterns
- Define API contracts
- Review and approve all major decisions
- Break down the project into modules

**Skills Applied:** 🎯 Ponytail + 🎨 Frontend + ⚙️ Backend + 🔒 Security + 🏗️ Architecture

**Delegation:** Can delegate to ALL agents (through Mommy)

**Output Format:**
```
1. HIGH-LEVEL ARCHITECTURE
   - System components
   - How they interact
   - Data flow

2. TECH STACK DECISION
   - Frontend / Backend / Database / DevOps

3. FOLDER STRUCTURE

4. API DESIGN
   - Main endpoints
   - Request/Response format

5. DATABASE SCHEMA OVERVIEW

6. SECURITY CONSIDERATIONS

7. SCALABILITY PLAN
```

---

### 👩‍💼 Mommy — Project Manager Agent

**Role:** Project Manager / Coordinator
**File:** `agents/project_manager.py` → `ProjectManagerAgent`
**Priority:** 2

**Responsibilities:**
- Break architect's vision into actionable tasks
- Assign tasks to appropriate developers
- Track progress and manage timelines
- Coordinate between team members
- Handle dependencies between tasks
- Report status to the Architect
- Resolve conflicts and blockers

**Skills Applied:** 🎯 Ponytail

**Delegation:** Can delegate to Frontend, Backend, Database, DevOps, Tester, Designer

**Key Methods:**
```python
mommy.create_project_plan(architecture)  # 6-phase plan
mommy.break_into_tasks(description)      # → List[Task]
mommy.assign_and_execute(tasks)          # → Dict[task_id, result]
mommy.get_progress_report()              # → Status report
```

---

### 👧 Frontend Girl — Frontend Developer Agent

**Role:** Senior Frontend Developer
**File:** `agents/frontend_agent.py` → `FrontendAgent`
**Priority:** 3

**Specialties:**
- React 19+ / Next.js 15+ / TypeScript
- TailwindCSS v4 / shadcn/ui
- State management (TanStack Query, Jotai, nuqs)
- React Hook Form + Zod validation
- Responsive design, accessibility (a11y)
- Framer Motion animations

**Skills Applied:** 🎯 Ponytail + 🎨 Frontend + ✨ Animation

**Task Routing (auto-detects type):**
| Keywords | Method |
|----------|--------|
| component, button, card, modal, form | `_create_component()` |
| page, route, screen, view | `_create_page()` |
| layout, header, footer, sidebar | `_create_layout()` |
| hook, context, state, store | `_create_hook_or_state()` |
| api, fetch, service, client | `_create_api_service()` |
| setup, config, init, project | `_setup_frontend_project()` |

**Delegation:** Can delegate to Designer Girl for UI/UX questions

---

### 👦 Backend Boy — Backend Developer Agent

**Role:** Senior Backend Developer
**File:** `agents/backend_agent.py` → `BackendAgent`
**Priority:** 3

**Specialties:**
- Python / FastAPI / Django
- Node.js / Express / Hono
- JWT / OAuth2 authentication
- Async SQLAlchemy / Prisma
- Redis / Celery
- WebSockets
- GraphQL (optional)

**Skills Applied:** 🎯 Ponytail + ⚙️ Backend + 🔒 Security + 🏗️ Architecture

**Task Routing:**
| Keywords | Method |
|----------|--------|
| api, endpoint, route, router | `_create_api_endpoint()` |
| model, schema, pydantic | `_create_model()` |
| auth, login, register, jwt | `_create_auth_system()` |
| middleware, cors, rate limit | `_create_middleware()` |
| setup, config, init, main | `_setup_backend_project()` |
| websocket, socket, realtime | `_create_websocket()` |
| celery, task, queue | `_create_background_task()` |

**Delegation:** Can delegate to Database Boy for schema/query tasks

---

### 👦 Database Boy — Database Expert Agent

**Role:** Database Expert
**File:** `agents/database_agent.py` → `DatabaseAgent`
**Priority:** 4

**Specialties:**
- PostgreSQL / MySQL / MongoDB
- Redis (caching layer)
- SQLAlchemy / Alembic migrations
- Query optimization & indexing
- Schema design & normalization
- Connection pooling
- Backup strategies

**Skills Applied:** 🎯 Ponytail + ⚙️ Backend + 🏗️ Architecture

**Task Routing:**
| Keywords | Method |
|----------|--------|
| schema, design, model, table | `_design_schema()` |
| migration, alembic | `_create_migration()` |
| seed, sample, dummy | `_create_seed_data()` |
| query, optimize, index | `_optimize_queries()` |
| setup, connection | `_setup_database()` |

---

### 👦 DevOps Boy — DevOps Engineer Agent

**Role:** DevOps Engineer
**File:** `agents/devops_agent.py` → `DevOpsAgent`
**Priority:** 4

**Specialties:**
- Docker / Docker Compose (multi-stage builds)
- GitHub Actions / GitLab CI
- Nginx / Caddy reverse proxy
- AWS / GCP / DigitalOcean
- SSL/TLS configuration
- Prometheus / Grafana monitoring
- Kubernetes (basic)

**Skills Applied:** 🎯 Ponytail + ⚙️ Backend + 🔒 Security + 🏗️ Architecture

**Task Routing:**
| Keywords | Method |
|----------|--------|
| docker, container, compose | `_create_docker_config()` |
| ci, cd, pipeline, github action | `_create_ci_cd()` |
| nginx, proxy | `_create_nginx_config()` |
| deploy, production | `_create_deployment()` |
| monitor, log, prometheus | `_create_monitoring()` |

---

### 👧 Tester Girl — QA/Test Engineer Agent

**Role:** QA / Test Engineer
**File:** `agents/tester_agent.py` → `TesterAgent`
**Priority:** 4

**Specialties:**
- pytest / unittest (Python)
- Jest / Vitest (JavaScript)
- React Testing Library
- Cypress / Playwright (E2E)
- Coverage analysis
- Mock/Stub/Spy patterns
- Security testing basics

**Skills Applied:** 🎯 Ponytail + 🎨 Frontend + ⚙️ Backend + 🔒 Security

**Task Routing:**
| Keywords | Method |
|----------|--------|
| unit, pytest, jest | `_write_unit_tests()` |
| integration, api test | `_write_integration_tests()` |
| e2e, cypress, playwright | `_write_e2e_tests()` |
| plan, strategy | `_create_test_plan()` |

---

### 👧 Designer Girl — UI/UX Designer Agent

**Role:** UI/UX Designer
**File:** `agents/designer_agent.py` → `DesignerAgent`
**Priority:** 4

**Specialties:**
- Wireframes (ASCII/text-based)
- Design systems & tokens
- Color palettes (hex codes, oklch)
- Typography scales
- Component specifications
- TailwindCSS theme configuration
- Animation definitions
- User flow diagrams

**Skills Applied:** 🎯 Ponytail + 🎨 Frontend + ✨ Animation + 🎮 Game Dev

**Task Routing:**
| Keywords | Method |
|----------|--------|
| wireframe, mockup, layout | `_create_wireframe()` |
| design system, theme, token | `_create_design_system()` |
| color, palette, typography | `_create_color_typography()` |
| component, spec | `_create_component_spec()` |

---

## Skills System

### Overview

The skills system loads markdown files from the `skills/` directory and injects relevant knowledge into each agent's system prompt. Skills are sourced from battle-tested GitHub repositories.

### Loaded Skills

| Skill | Lines | Source | Applied To |
|-------|-------|--------|-----------|
| 🎯 **ponytail** | 95 | DietrichGebert/ponytail (84k⭐) | ALL agents |
| 🎨 **frontend_skills** | 336 | finfin/awesome-frontend-skills + vercel-labs/next-skills + shadcn/ui | Frontend, Designer, Architect, Tester |
| ⚙️ **backend_skills** | 236 | kodustech/awesome-agent-skills + wshobson/agents | Backend, Database, DevOps, Architect, Tester |
| 🔒 **security_skills** | 125 | trailofbits/skills (Trail of Bits) | Backend, DevOps, Architect, Tester |
| ✨ **animation_skills** | 245 | cloudai-x/threejs-skills + mblode/agent-skills + Framer Motion | Frontend, Designer |
| 🏗️ **architecture_skills** | 230 | kodustech/awesome-agent-skills + secondsky/claude-skills | Architect, Backend, DevOps |
| 🎮 **game_dev_skills** | 301 | Godogen (Godot 4) + Unity + Three.js | Designer |

### Skill Injection Process

```python
# When an agent is initialized:
1. BaseAgent.__init__() loads the base system prompt
2. SkillsLoader is lazily initialized
3. inject_skills_into_prompt() is called with the agent's role
4. Relevant skill summaries are appended to the system prompt
5. The enhanced prompt is used for all LLM calls
```

### Skill-Agent Mapping

```python
SKILL_AGENT_MAP = {
    "ponytail":            ALL agents,
    "frontend_skills":     ["architect", "frontend", "tester", "designer"],
    "backend_skills":      ["architect", "backend", "database", "devops", "tester"],
    "security_skills":     ["architect", "backend", "devops", "tester"],
    "animation_skills":    ["frontend", "designer"],
    "architecture_skills": ["architect", "backend", "devops"],
    "game_dev_skills":     ["frontend", "designer"],
}
```

### Adding Custom Skills

1. Create `skills/my_skill.md`
2. Write your skill content in markdown
3. It's automatically loaded on next run
4. Add to `SKILL_AGENT_MAP` in `skills_loader.py` to control which agents get it

---

## Tools & Capabilities

### FileTools (`tools/file_tools.py`)

| Method | Description |
|--------|-------------|
| `create_file(path, content)` | Create a file with content |
| `read_file(path)` | Read a file's content |
| `delete_file(path)` | Delete a file |
| `create_directory(path)` | Create a directory |
| `list_files(dir)` | List all files recursively |
| `create_project_structure(dict)` | Create full project from nested dict |
| `extract_files_from_response(text)` | Parse code blocks from LLM output |
| `save_extracted_files(text)` | Extract and save files from response |
| `write_readme(name, desc)` | Generate README.md |

### CodeTools (`tools/code_tools.py`)

| Method | Description |
|--------|-------------|
| `extract_functions(code)` | Parse Python function definitions |
| `extract_classes(code)` | Parse Python class definitions |
| `extract_imports(code)` | Extract import statements |
| `validate_python(code)` | Syntax validation |
| `count_lines(code)` | Count code/comment/blank lines |

### GitTools (`tools/git_tools.py`)

| Method | Description |
|--------|-------------|
| `init_repo()` | Initialize git repository |
| `add_all()` | Stage all files |
| `commit(message)` | Create commit |
| `create_gitignore(type)` | Generate .gitignore |
| `get_status()` | Show git status |
| `get_log(n)` | Show recent commits |

### APITools (`tools/api_tools.py`)

| Method | Description |
|--------|-------------|
| `generate_openapi_spec(endpoints)` | Generate OpenAPI 3.0 spec |
| `generate_postman_collection(url, endpoints)` | Postman collection JSON |
| `validate_rest_conventions(endpoints)` | Check REST best practices |

---

## Memory System

### ConversationMemory (`memory/conversation_memory.py`)

Stores conversation history for each agent:

```python
memory = ConversationMemory(storage_path="./memory_data", max_history=100)
memory.add_message("user", "Create a login form")
memory.add_message("assistant", response)
history = memory.get_history(last_n=10)
summary = memory.get_summary()
memory.save("conversation.json")
memory.search("login")  # Search history
```

### ProjectMemory (`memory/project_memory.py`)

Persistent project-level state:

```python
project = ProjectMemory("my-app")
project.set_architecture(architecture_text)
project.set_tech_stack({"frontend": "Next.js", "backend": "FastAPI"})
project.add_task({"title": "...", "status": "done"})
project.add_decision("Use PostgreSQL", "Better for relational data")
project.add_note("Client wants dark mode")
project.add_file("src/app/page.tsx")
project.save()  # Persists to disk
```

---

## Terminal Interface

### aerrik.py — Custom Branded Terminal

The primary entry point. Features:

```
     █████╗ ███████╗██████╗ ██████╗ ██╗██╗  ██╗
    ██╔══██╗██╔════╝██╔══██╗██╔══██╗██║██║ ██╔╝
    ███████║█████╗  ██████╔╝██████╔╝██║█████╔╝
    ██╔══██║██╔══╝  ██╔══██╗██╔══██╗██║██╔═██╗
    ██║  ██║███████╗██║  ██║██║  ██║██║██║  ██╗
    ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚═╝  ╚═╝
              v1.0.0 — Genesis
```

**Features:**
- Animated boot sequence with spinner
- Custom purple/cyan theme (Rich theme system)
- Continuous REPL with prompt showing active agent
- @mention routing to switch agents inline
- /slash commands for operations
- Syntax-highlighted code in responses
- Conversation history tracking
- Session analytics on exit

### @Mention System

Type `@agent` before your message to route to a specific agent:

```
aerrik.dev │ ◈ Dad ❯ @frontend Create a responsive navbar
  → Switches to Frontend Girl
  → Sends "Create a responsive navbar" to her

aerrik.dev │ ▸ Frontend ❯ @backend Build JWT auth API
  → Switches to Backend Boy
  → Sends "Build JWT auth API" to him
```

**Available Mentions:**

| Mention | Agent | Aliases |
|---------|-------|---------|
| `@dad` | Architect | `@architect`, `@arch` |
| `@mommy` | Project Manager | `@pm`, `@manager` |
| `@frontend` | Frontend Dev | `@fe`, `@ui` |
| `@backend` | Backend Dev | `@be`, `@api` |
| `@database` | Database Expert | `@db`, `@data` |
| `@devops` | DevOps Engineer | `@ops`, `@infra` |
| `@tester` | QA Tester | `@qa`, `@test` |
| `@designer` | UI/UX Designer | `@ux`, `@design` |

---

## CLI Commands

### aerrik.py Commands

| Command | Description |
|---------|-------------|
| `/help` | Show help panel with all commands & mentions |
| `/status` | Agent status board (table with skills, tasks) |
| `/tree` | Family hierarchy visualization |
| `/skills` | Loaded skill modules with sources |
| `/agents` | Agent directory with aliases & specialties |
| `/switch <name>` | Change active agent |
| `/build <desc>` | Build complete project (with progress bars) |
| `/history` | Conversation log (last 25 messages) |
| `/clear` | Clear terminal screen |
| `/about` | About aerrik.dev (version, stack, links) |
| `/exit` | End session with analytics summary |

### cli.py Commands (Click-based)

```bash
python cli.py --help              # Full help
python cli.py build "Todo app"    # Build project
python cli.py ask frontend "..."  # Ask specific agent
python cli.py task backend "..."  # Assign task
python cli.py status              # Status table
python cli.py tree                # Family tree
python cli.py skills              # Skills overview
python cli.py skills --detail     # Full skill content
python cli.py skills -s ponytail  # Specific skill
python cli.py chat "message"      # Chat with Dad
python cli.py interactive         # Interactive REPL
python cli.py --demo <cmd>        # Demo mode (no API)
```

### main.py (Basic Mode)

```bash
python main.py                    # Interactive mode
python main.py --demo             # Mock mode
python main.py --key sk-...       # With API key
python main.py --build "..."      # Build project
```

---

## API & Programmatic Usage

### Basic Usage

```python
from main import SoftwareDevAgency

# Initialize
agency = SoftwareDevAgency(api_key="sk-your-key")

# Build a complete project
results = agency.build_project("""
Build a Task Management Application with:
- User authentication (register, login)
- CRUD tasks with categories and labels
- Drag & drop Kanban board
- Real-time notifications
- Dashboard with analytics
- Dark/Light mode

Tech: Next.js 14 + FastAPI + PostgreSQL + Redis
""")

# Access results
print(results["architecture"])     # Architecture document
print(results["project_plan"])     # Project plan
print(results["tasks"])            # Task list
print(results["results"])          # Task execution results
print(results["files_created"])    # Generated files
print(results["status"])           # "completed" or "error: ..."
```

### Quick Tasks

```python
# Ask a specific agent
result = agency.quick_task(
    "Create a beautiful Kanban board component with drag & drop",
    role="frontend"
)

result = agency.quick_task(
    "Create CRUD API for tasks with authentication",
    role="backend"
)

result = agency.quick_task(
    "Design database schema for users, tasks, and labels",
    role="database"
)

result = agency.quick_task(
    "Create Docker setup for Next.js + FastAPI + PostgreSQL",
    role="devops"
)
```

### Direct Agent Access

```python
# Access agents directly
dad = agency.family.dad
mommy = agency.family.mommy
frontend = agency.family.frontend_girl
backend = agency.family.backend_boy
database = agency.family.database_boy
devops = agency.family.devops_boy
tester = agency.family.tester_girl
designer = agency.family.designer_girl

# Use them
architecture = dad.design_architecture("E-commerce platform")
tasks = mommy.break_into_tasks(architecture)
results = mommy.assign_and_execute(tasks)

# Check status
print(agency.family.get_family_status())
agency.family.print_family_tree()
```

### Skills Loader

```python
from skills.skills_loader import SkillsLoader

loader = SkillsLoader()

# List all skills
print(loader.list_skills())
# ['ponytail', 'frontend_skills', 'backend_skills', ...]

# Get specific skill content
content = loader.get_skill("ponytail")

# Get skills for a role
skills = loader.get_skills_for_role("frontend_developer")
# ['ponytail', 'frontend_skills', 'animation_skills', 'game_dev_skills']

# Inject skills into a prompt
enhanced = loader.inject_skills_into_prompt(base_prompt, "backend_developer")

# Get skill sources
sources = loader.get_skill_sources()
```

### File Tools

```python
from tools.file_tools import FileTools

tools = FileTools(base_dir="./output")

# Create files
tools.create_file("src/app/page.tsx", "export default function Page() {...}")
tools.create_directory("src/components")

# Create full project structure
tools.create_project_structure({
    "src": {
        "components": {
            "Button.tsx": "export function Button() {...}",
            "Card.tsx": "export function Card() {...}"
        },
        "pages": {
            "index.tsx": "export default function Home() {...}"
        }
    },
    "package.json": '{"name": "my-app"}'
})

# Extract and save files from LLM response
tools.save_extracted_files(llm_response)
```

---

## Project Build Pipeline

### Step-by-Step Build Process

When you run `agency.build_project("description")` or `/build description`:

```
STEP 1: 👨‍💼 Dad designs architecture
  Input:  Project description
  Output: Architecture document (components, tech stack, API, DB, security)
  Time:   ~10-30 seconds (with API key)

STEP 2: 👩‍💼 Mommy creates project plan
  Input:  Architecture document
  Output: 6-phase project plan
  Phases: Setup → Database → Backend → Frontend → Testing → DevOps

STEP 3: 👩‍💼 Mommy breaks into tasks
  Input:  Architecture + Plan
  Output: List[Task] with assignments and priorities
  Format: TASK_TITLE, TASK_ROLE, TASK_PRIORITY, TASK_DESCRIPTION

STEP 4: 👧👦 Children execute tasks
  Input:  Individual task descriptions
  Output: Generated code with file paths
  Process:
    - Each child receives their task
    - Auto-detects task type (component/page/API/etc.)
    - Generates complete code with proper imports/exports
    - Follows skill-specific patterns

STEP 5: 💾 Save files
  Process:
    - Parse LLM responses for file paths
    - Patterns: // filepath: or # filepath: or ```lang\n// path
    - Create directory structure
    - Write files to ./output/

STEP 6: 📊 Final report
  Output: Progress report, family status, file list
```

### Build Results Structure

```python
results = {
    "architecture": "...",      # Full architecture document
    "project_plan": "...",      # 6-phase project plan
    "tasks": [                  # List of tasks created
        {"id": "TASK-abc", "title": "...", "assigned_to": "frontend_developer"},
        ...
    ],
    "results": {                # Execution results per task
        "TASK-abc": "...",
        "TASK-def": "...",
    },
    "files_created": [          # Files saved to disk
        "✅ Created: ./output/src/app/page.tsx",
        ...
    ],
    "status": "completed"       # or "error: ..."
}
```

---

## Configuration

### Agent Configuration (`config.py`)

```python
AgentConfig(
    name="Backend Boy 👦",
    role=AgentRole.BACKEND_DEV,
    model="gpt-4",              # LLM model to use
    temperature=0.6,            # Creativity (0-1)
    max_tokens=4000,            # Max response length
    skills=["python", "fastapi", "api_design"],
    can_delegate_to=[AgentRole.DATABASE_EXPERT],
    priority=3                  # 1=highest
)
```

### Environment Variables

```bash
# .env file
OPENAI_API_KEY=sk-your-key        # Required for real responses
ANTHROPIC_API_KEY=your-key        # Optional (Claude)
GROQ_API_KEY=your-key             # Optional (fast inference)
DEFAULT_MODEL=gpt-4               # Default model
DEBUG=true                        # Debug mode
LOG_LEVEL=INFO                    # Logging level
```

### Project Configuration

```python
from config import ProjectConfig, ProjectType, TechStack

config = ProjectConfig(
    name="My App",
    description="Task management with kanban board",
    project_type=ProjectType.FULLSTACK,
    tech_stack=TechStack.NEXTJS_FASTAPI,
    output_dir="./output",
    max_iterations=10,
    enable_testing=True,
    enable_ci_cd=True
)
```

### Tech Stacks Available

| Stack | Frontend | Backend |
|-------|----------|---------|
| `REACT_NODE` | React | Node.js/Express |
| `ANGULAR_DJANGO` | Angular | Django |
| `VUE_FLASK` | Vue.js | Flask |
| `NEXTJS_FASTAPI` | Next.js 14+ | FastAPI |
| `REACT_SPRING` | React | Spring Boot |

---

## Extending the Framework

### Add a New Agent

1. **Create agent file** (`agents/my_agent.py`):
```python
from agents.base_agent import BaseAgent, Task, TaskStatus
from config import AgentRole, AGENT_CONFIGS

class MyAgent(BaseAgent):
    def __init__(self, api_key="", verbose=True):
        super().__init__(
            config=AGENT_CONFIGS[AgentRole.MY_ROLE],
            role=AgentRole.MY_ROLE,
            api_key=api_key,
            verbose=verbose
        )

    def execute_task(self, task: Task) -> str:
        self.current_task = task
        task.status = TaskStatus.IN_PROGRESS
        
        # Your custom logic
        result = self.think(task.description)
        
        task.status = TaskStatus.COMPLETED
        task.result = result
        return result
```

2. **Add role to config.py**:
```python
class AgentRole(Enum):
    ...
    MY_ROLE = "my_role"

AGENT_CONFIGS[AgentRole.MY_ROLE] = AgentConfig(
    name="My Agent 🤖",
    role=AgentRole.MY_ROLE,
    skills=["skill1", "skill2"],
    can_delegate_to=[],
    priority=4
)
```

3. **Add system prompt** to `prompts/system_prompts.py`

4. **Register in `agents/__init__.py`** and add to `AgencyFamily`

### Add a New Tool

```python
# In main.py _register_tools():
def my_tool(param1: str, param2: int) -> str:
    """My custom tool"""
    return f"Result: {param1} * {param2} = {param1 * param2}"

for agent in self.family.get_all_agents().values():
    agent.register_tool("my_tool", my_tool)

# Agents can now use it:
result = agent.use_tool("my_tool", param1="hello", param2=3)
```

### Add a New Skill

1. Create `skills/my_skill.md` with markdown content
2. Add to `SKILL_AGENT_MAP` in `skills/skills_loader.py`:
```python
SKILL_AGENT_MAP = {
    ...
    "my_skill": ["frontend_developer", "backend_developer"],
}
```
3. Add summary method in `SkillsLoader`:
```python
def get_my_skill_summary(self) -> str:
    return """
🔧 MY SKILL:
- Rule 1
- Rule 2
"""
```
4. Add to `inject_skills_into_prompt()` for relevant roles

---

## File Structure

```
software_dev_agency/
│
├── aerrik.py              # 🚀 Custom branded terminal (PRIMARY)
├── terminal.py            # Claude Code-style terminal
├── cli.py                 # Click-based CLI commands
├── main.py                # Basic entry point + orchestrator
├── config.py              # All configuration (roles, stacks, agents)
├── requirements.txt       # Python dependencies
├── setup.sh               # One-line installer
├── .env.example           # Environment variable template
├── README.md              # Project documentation
│
├── agents/
│   ├── __init__.py        # ArchitectAgent + AgencyFamily
│   ├── base_agent.py      # BaseAgent (Dad) — core class
│   ├── project_manager.py # ProjectManagerAgent (Mommy)
│   ├── frontend_agent.py  # FrontendAgent (Girl Child 1)
│   ├── backend_agent.py   # BackendAgent (Boy Child 1)
│   ├── database_agent.py  # DatabaseAgent (Boy Child 2)
│   ├── devops_agent.py    # DevOpsAgent (Boy Child 3)
│   ├── tester_agent.py    # TesterAgent (Girl Child 2)
│   └── designer_agent.py  # DesignerAgent (Girl Child 3)
│
├── tools/
│   ├── __init__.py
│   ├── file_tools.py      # File creation/extraction
│   ├── code_tools.py      # Code analysis (AST parsing)
│   ├── git_tools.py       # Git operations
│   └── api_tools.py       # API design tools (OpenAPI, Postman)
│
├── memory/
│   ├── __init__.py
│   ├── conversation_memory.py  # Per-agent conversation history
│   └── project_memory.py      # Persistent project state
│
├── prompts/
│   ├── __init__.py
│   └── system_prompts.py  # System prompts for all 8 agents
│
├── skills/
│   ├── __init__.py
│   ├── skills_loader.py        # Skill loading + injection engine
│   ├── ponytail.md             # 🎯 Lazy senior dev (95 lines)
│   ├── frontend_skills.md      # 🎨 React/Next.js/shadcn (336 lines)
│   ├── backend_skills.md       # ⚙️ FastAPI/Node/Go (236 lines)
│   ├── security_skills.md      # 🔒 Trail of Bits (125 lines)
│   ├── animation_skills.md     # ✨ CSS/Framer/Three.js (245 lines)
│   ├── architecture_skills.md  # 🏗️ Clean/DDD/Microservices (230 lines)
│   └── game_dev_skills.md      # 🎮 Godot/Unity/Three.js (301 lines)
│
└── output/                # Generated project files go here
```

**Total: ~8,200 lines across 30 files**

---

## Examples & Workflows

### Example 1: Build a SaaS Dashboard

```bash
$ python aerrik.py --demo

aerrik.dev > /build SaaS analytics dashboard with user auth, 
  team management, real-time charts, billing with Stripe, 
  and admin panel. Tech: Next.js 15 + FastAPI + PostgreSQL
```

**What happens:**
1. Dad designs: monolith with Next.js App Router, FastAPI backend, PostgreSQL + Redis, Stripe webhooks
2. Mommy plans: 6 phases, 12 tasks
3. Children execute:
   - Frontend: Dashboard layout, charts with Recharts, auth pages, team settings
   - Backend: Auth API, teams CRUD, analytics endpoints, Stripe webhooks
   - Database: User, Team, Subscription, AnalyticsEvent schemas
   - DevOps: Docker Compose, GitHub Actions CI/CD
   - Tester: API integration tests, E2E auth flow
   - Designer: Color system, chart component specs

### Example 2: Quick Frontend Task

```bash
aerrik.dev > @frontend Create a data table component with 
  sorting, filtering, pagination, and row selection
```

**Frontend Girl generates:**
- `src/components/ui/data-table.tsx` — Full component with TanStack Table
- Uses shadcn/ui primitives
- TypeScript interfaces for columns and data
- Responsive design with mobile view

### Example 3: Multi-Agent Collaboration

```bash
aerrik.dev > @dad Design a real-time chat application

# Dad designs architecture...

aerrik.dev > @mommy Break this into tasks and execute

# Mommy creates plan, assigns tasks, children execute...

aerrik.dev > @tester Write tests for the auth flow

# Tester Girl writes integration + E2E tests...

aerrik.dev > @devops Create Docker and CI/CD setup

# DevOps Boy creates docker-compose.yml + GitHub Actions...
```

### Example 4: Programmatic Usage

```python
from main import SoftwareDevAgency

agency = SoftwareDevAgency(api_key="sk-...")

# Design phase
arch = agency.family.dad.design_architecture("E-commerce with AI recommendations")

# Planning phase
plan = agency.family.mommy.create_project_plan(arch)
tasks = agency.family.mommy.break_into_tasks(f"{arch}\n\n{plan}")

# Selective execution
for task in tasks:
    if task.assigned_to and task.priority <= 2:  # Only high priority
        result = agency.family.mommy.delegate_task(task, task.assigned_to)
        agency.file_tools.save_extracted_files(result)

# Report
print(agency.family.mommy.get_progress_report())
```

---

## Troubleshooting

### "LLM Error: ..." / Mock Responses

**Cause:** No API key configured
**Fix:**
```bash
export OPENAI_API_KEY="sk-your-key"
# Or create .env file with OPENAI_API_KEY=sk-...
```

### "Module not found: openai"

**Fix:**
```bash
pip install -r requirements.txt
```

### Skills not loading

**Check:**
```python
from skills.skills_loader import SkillsLoader
loader = SkillsLoader()
print(loader.list_skills())  # Should show 7 skills
```

### Agent not responding correctly

**Check system prompt:**
```python
agent = agency.family.backend_boy
print(agent.system_prompt)  # Should contain skills
print(len(agent.system_prompt))  # Should be 3000-5000 chars
```

### Files not saving

**Check:**
```python
# Ensure output directory exists
import os
os.makedirs("./output", exist_ok=True)

# Check file extraction
from tools.file_tools import FileTools
tools = FileTools()
files = tools.extract_files_from_response(response_text)
print(files)  # Should show {path: content} pairs
```

### Terminal display issues

**Fix:** Ensure terminal supports UTF-8 and true color:
```bash
export TERM=xterm-256color
export COLORTERM=truecolor
```

---

## Quick Reference Card

```
┌─────────────────────────────────────────────────────────────┐
│                    aerrik.dev Quick Reference                 │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  START:     python aerrik.py          (custom terminal)     │
│             python aerrik.py --demo   (no API key)          │
│             python cli.py <command>   (CLI mode)            │
│                                                             │
│  BUILD:     /build <description>      (full project)        │
│             agency.build_project("...")  (Python API)       │
│                                                             │
│  TALK:      @frontend <message>       (route to agent)     │
│             @backend <message>                              │
│             <message>                  (talk to @dad)       │
│                                                             │
│  INFO:      /status                   (agent board)         │
│             /skills                   (loaded skills)       │
│             /tree                     (family hierarchy)    │
│             /agents                   (agent directory)     │
│             /history                  (conversation log)    │
│                                                             │
│  SKILLS:    🎯 Ponytail  🎨 Frontend  ⚙️ Backend           │
│             🔒 Security  ✨ Animation  🏗️ Architecture     │
│             🎮 Game Dev                                    │
│                                                             │
│  AGENTS:    👨‍💼 Dad  👩‍💼 Mommy  👧 Frontend  👦 Backend   │
│             👦 Database  👦 DevOps  👧 Tester  👧 Designer │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

*Built with ❤️ by [aerrik.dev](https://aerrik.dev)*
*Multi-Agent AI Development Terminal v1.0.0 — Genesis*
