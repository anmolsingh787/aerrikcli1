"""
🎨 aerrik.dev — Centralized Theme

All colors defined in ONE place.
No hardcoded colors in components.

Design principles:
- Neutral terminal background
- High contrast text
- One primary accent (violet)
- One success accent (emerald)
- One warning accent (amber)
- One error accent (red)
- Restrained, professional, engineer-focused
"""
from rich.theme import Theme
from rich.style import Style

# ═══════════════════════════════════════════════════════
#  AERRIK THEME
# ═══════════════════════════════════════════════════════

AERRIK_THEME = Theme({
    # Brand
    "aerrik":           "#8B5CF6",      # Primary violet
    "aerrik.dim":       "#6D28D9",      # Darker violet
    "aerrik.bright":    "#A78BFA",      # Lighter violet
    "aerrik.muted":     "#7C3AED",      # Subtle violet

    # Semantic colors
    "success":          "#10B981",      # Emerald
    "success.dim":      "#059669",
    "warning":          "#F59E0B",      # Amber
    "warning.dim":      "#D97706",
    "error":            "#EF4444",      # Red
    "error.dim":        "#DC2626",
    "info":             "#3B82F6",      # Blue

    # Text
    "text":             "#E5E7EB",      # Light gray (primary text)
    "text.dim":         "#9CA3AF",      # Medium gray (secondary)
    "text.muted":       "#6B7280",      # Dark gray (tertiary)
    "text.bright":      "#F9FAFB",      # Near white (emphasis)

    # UI elements
    "border":           "#374151",      # Dark gray borders
    "border.active":    "#8B5CF6",      # Active/focused borders
    "bg":               "#111827",      # Background (if supported)
    "bg.subtle":        "#1F2937",      # Subtle background

    # Mode colors
    "mode.plan":        "#3B82F6",      # Blue for PLAN
    "mode.agent":       "#8B5CF6",      # Violet for AGENT
    "mode.build":       "#10B981",      # Green for BUILD

    # Agent team colors
    "team.elders":      "#EF4444",      # Red for elders
    "team.parents":     "#F59E0B",      # Amber for parents
    "team.girls":       "#06B6D4",      # Cyan for girls
    "team.boys":        "#10B981",      # Green for boys

    # Status
    "status.active":    "#10B981",
    "status.idle":      "#6B7280",
    "status.busy":      "#F59E0B",
    "status.error":     "#EF4444",
})


# ═══════════════════════════════════════════════════════
#  THEME HELPERS
# ═══════════════════════════════════════════════════════

def get_mode_color(mode: str) -> str:
    """Get color for a mode"""
    return {
        "plan": "#3B82F6",
        "agent": "#8B5CF6",
        "build": "#10B981",
    }.get(mode.lower(), "#9CA3AF")


def get_mode_icon(mode: str) -> str:
    """Get icon for a mode"""
    return {
        "plan": "📋",
        "agent": "🤖",
        "build": "🏗️",
    }.get(mode.lower(), "❓")


def get_severity_color(severity: str) -> str:
    """Get color for severity level"""
    return {
        "critical": "#EF4444",
        "high": "#F97316",
        "medium": "#F59E0B",
        "low": "#3B82F6",
        "info": "#6B7280",
    }.get(severity.lower(), "#9CA3AF")


def get_severity_icon(severity: str) -> str:
    """Get icon for severity level"""
    return {
        "critical": "🔴",
        "high": "🟠",
        "medium": "🟡",
        "low": "🔵",
        "info": "⚪",
    }.get(severity.lower(), "❓")


def get_tool_icon(tool_name: str) -> str:
    """Get icon for a tool"""
    icons = {
        "read": "📄", "write": "✍️", "edit": "✏️",
        "glob": "🔍", "grep": "🔎", "shell": "💻",
        "git": "📦", "browser": "🌐", "fetch": "🌐",
    }
    return icons.get(tool_name, "▸")


def get_agent_icon(agent_name: str) -> str:
    """Get icon for an agent"""
    icons = {
        "grandfather": "👴", "grandmother": "👵",
        "dad": "👨‍💼", "architect": "👨‍💼",
        "mommy": "👩‍💼", "pm": "👩‍💼",
        "frontend": "👧", "tester": "👧",
        "designer": "👧", "mobile": "👧📱",
        "backend": "👦", "database": "👦",
        "devops": "👦", "security": "👦🔐",
    }
    name_lower = agent_name.lower()
    for key, icon in icons.items():
        if key in name_lower:
            return icon
    return "🤖"


def get_team_color(agent_name: str) -> str:
    """Get team color for an agent"""
    name_lower = agent_name.lower()
    if any(x in name_lower for x in ["grandfather", "grandmother"]):
        return "#EF4444"  # Elders
    if any(x in name_lower for x in ["dad", "architect", "mommy", "pm"]):
        return "#F59E0B"  # Parents
    if any(x in name_lower for x in ["frontend", "tester", "designer", "mobile"]):
        return "#06B6D4"  # Girls
    if any(x in name_lower for x in ["backend", "database", "devops", "security"]):
        return "#10B981"  # Boys
    return "#9CA3AF"
