"""
🐕 aerrik.dev — Dog UI Layer

The dog is a UI personality layer, NOT a runtime component.
It subscribes to the Event Bus and renders subtle reactions.

Settings:
    dog = "on"       — Full personality
    dog = "minimal"  — Only success/error (default)
    dog = "off"      — No dog
"""
from typing import Optional
from ui.renderer import Renderer
from adk.events import EventBus, Event, EventType


class DogUI:
    """
    🐕 Dog personality layer (event-driven).

    Subscribes to events and renders subtle dog reactions.
    Does NOT control runtime logic.
    """

    def __init__(
        self,
        renderer: Renderer,
        event_bus: EventBus,
        mode: str = "minimal",  # on, minimal, off
    ):
        self.renderer = renderer
        self.mode = mode
        self._enabled = mode != "off"

        if self._enabled:
            self._subscribe(event_bus)

    def _subscribe(self, bus: EventBus):
        """Subscribe to relevant events"""
        bus.subscribe(EventType.TASK_COMPLETED, self._on_success)
        bus.subscribe(EventType.ERROR, self._on_error)
        bus.subscribe(EventType.RISK_ALERT, self._on_risk)
        bus.subscribe(EventType.PERMISSION_DENIED, self._on_denied)
        bus.subscribe(EventType.BUDGET_WARNING, self._on_budget)

    def _on_success(self, event: Event):
        if self.mode == "on":
            self.renderer.dog("happy", "task done!")
        elif self.mode == "minimal":
            self.renderer.dog("success")

    def _on_error(self, event: Event):
        if self.mode == "on":
            error = event.data.get("error", "")[:50]
            self.renderer.dog("error", error)
        elif self.mode == "minimal":
            self.renderer.dog("error")

    def _on_risk(self, event: Event):
        risk = event.data.get("risk_score", 0)
        if risk >= 9:
            self.renderer.dog("critical")
        elif self.mode == "on":
            self.renderer.dog("error", f"risk {risk}/10")

    def _on_denied(self, event: Event):
        self.renderer.dog("error", "blocked!")

    def _on_budget(self, event: Event):
        if self.mode == "on":
            self.renderer.dog("error", "budget warning")

    def set_mode(self, mode: str):
        self.mode = mode
        self._enabled = mode != "off"
