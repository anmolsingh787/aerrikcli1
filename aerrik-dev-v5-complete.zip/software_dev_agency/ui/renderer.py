"""
🎨 aerrik.dev — Terminal Renderer

Central rendering engine. All output goes through here.
No raw print() statements in business logic.

Usage:
    r = Renderer()
    r.header()
    r.prompt("agent")
    r.agent_response("I'll analyze the auth system...")
    r.tool_call("read", "auth/service.py", status="running")
    r.tool_call("read", "auth/service.py", status="success", duration_ms=12)
    r.status_bar(session_time="12m", agents=3, tools=18, cost="$0.042")
"""
import os
import sys
from typing import Optional, Dict, List, Any
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.rule import Rule
from rich.markdown import Markdown
from rich.syntax import Syntax
from rich.table import Table
from rich.live import Live
from rich.align import Align
from rich.columns import Columns
from rich.spinner import Spinner
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn

from ui.theme import (
    AERRIK_THEME, get_mode_color, get_mode_icon,
    get_tool_icon, get_agent_icon, get_team_color,
    get_severity_color, get_severity_icon,
)


class Renderer:
    """
    🎨 Central renderer for Aerrik CLI.

    All terminal output goes through this class.
    """

    def __init__(self, console: Console = None):
        self.console = console or Console(theme=AERRIK_THEME)
        self._width = self.console.width or 80
        self._live: Optional[Live] = None

    @property
    def width(self) -> int:
        return min(self._width, 120)  # Cap at 120 for readability

    # ═══════════════════════════════════════════════════
    #  HEADER
    # ═══════════════════════════════════════════════════

    def header(
        self,
        version: str = "5.0.0",
        mode: str = "agent",
        provider: str = "",
        model: str = "",
        byok: bool = False,
    ):
        """Render the persistent session header (shown once at start)"""
        mode_color = get_mode_color(mode)
        mode_icon = get_mode_icon(mode)
        byok_str = "[success]BYOK[/]" if byok else "[text.muted]NO-BYOK[/]"

        provider_str = f"{provider}" if provider else "[text.muted]none[/]"
        model_str = f"{model}" if model else ""

        line = (
            f"  [aerrik]aerrik[/][aerrik.dim].dev[/]  "
            f"[text.muted]v{version}[/]  "
            f"[{mode_color}]{mode_icon} {mode.upper()}[/]  "
            f"[text.muted]│[/] {provider_str} {model_str}  "
            f"[text.muted]│[/] {byok_str}"
        )
        self.console.print(line)
        self.console.print(Rule(style="#374151"))
        self.console.print()

    # ═══════════════════════════════════════════════════
    #  PROMPT
    # ═══════════════════════════════════════════════════

    def prompt_str(self, mode: str = "agent", cost: str = "") -> str:
        """Build the prompt string (for input())"""
        mode_color = get_mode_color(mode)
        mode_icon = get_mode_icon(mode)
        cost_part = f" [text.muted]{cost}[/]" if cost else ""
        return f"  [aerrik]❯[/]{cost_part} "

    # ═══════════════════════════════════════════════════
    #  MODE SWITCH
    # ═══════════════════════════════════════════════════

    def mode_switch(self, new_mode: str):
        """Render a compact mode switch notification"""
        color = get_mode_color(new_mode)
        icon = get_mode_icon(new_mode)
        self.console.print(f"  [success]✓[/] Switched to [{color}]{icon} {new_mode.upper()}[/] mode\n")

    # ═══════════════════════════════════════════════════
    #  AGENT RESPONSE
    # ═══════════════════════════════════════════════════

    def agent_response(self, content: str, agent_name: str = ""):
        """Render an agent's text response"""
        icon = get_agent_icon(agent_name) if agent_name else "🤖"
        color = get_team_color(agent_name) if agent_name else "#8B5CF6"

        # Use Markdown for rich formatting
        try:
            md = Markdown(content)
            self.console.print(Panel(
                md,
                border_style=color,
                padding=(1, 2),
                title=f" {icon} {agent_name} " if agent_name else None,
                title_align="left",
            ))
        except Exception:
            self.console.print(Panel(
                content,
                border_style=color,
                padding=(1, 2),
            ))
        self.console.print()

    # ═══════════════════════════════════════════════════
    #  TOOL CALLS
    # ═══════════════════════════════════════════════════

    def tool_call(
        self,
        tool_name: str,
        argument: str = "",
        status: str = "running",
        duration_ms: float = 0,
        output: str = "",
        error: str = "",
    ):
        """
        Render a tool call.

        status: "running", "success", "warning", "failed"
        """
        icon = get_tool_icon(tool_name)

        if status == "running":
            # Compact running indicator
            arg_display = argument[:50] if argument else ""
            self.console.print(
                f"  [text.muted]▸[/] {icon} [text]{tool_name}[/] "
                f"[text.dim]{arg_display}[/]",
                end="",
            )

        elif status == "success":
            dur = f" [text.muted]{duration_ms:.0f}ms[/]" if duration_ms else ""
            self.console.print(f"\r  [success]✓[/] {icon} [text]{tool_name}[/]{dur}")
            if output and len(output) < 200:
                self.console.print(f"    [text.dim]{output[:150]}[/]")

        elif status == "warning":
            self.console.print(f"\r  [warning]⚠[/] {icon} [text]{tool_name}[/] [warning]{error[:80]}[/]")

        elif status == "failed":
            self.console.print(f"\r  [error]✗[/] {icon} [text]{tool_name}[/] [error]{error[:80]}[/]")

    def tool_output(self, content: str, language: str = "", max_lines: int = 20):
        """Render tool output (compact)"""
        lines = content.splitlines()
        if len(lines) > max_lines:
            display = "\n".join(lines[:max_lines])
            display += f"\n  [text.muted]... ({len(lines) - max_lines} more lines)[/]"
        else:
            display = content

        if language:
            self.console.print(Syntax(display, language, theme="monokai", padding=(0, 2)))
        else:
            self.console.print(f"    [text.dim]{display}[/]")

    # ═══════════════════════════════════════════════════
    #  DIFF
    # ═══════════════════════════════════════════════════

    def diff(self, file_path: str, old: str, new: str, language: str = "python"):
        """Render a code diff"""
        self.console.print(Panel(
            f"[text.dim]─ {file_path} ─[/]\n\n"
            f"[error]- {old.strip()}[/]\n"
            f"[success]+ {new.strip()}[/]",
            border_style="#374151",
            padding=(0, 2),
        ))

    def diff_summary(self, files_changed: int, additions: int, deletions: int):
        """Render a diff summary"""
        self.console.print(
            f"  [text]Changed {files_changed} files[/]  "
            f"[success]+{additions}[/]  "
            f"[error]-{deletions}[/]"
        )

    # ═══════════════════════════════════════════════════
    #  PLAN MODE
    # ═══════════════════════════════════════════════════

    def plan_display(
        self,
        task: str,
        complexity: str,
        complexity_score: float,
        risk_score: float,
        risk_level: str,
        estimated_cost: float,
        estimated_files: int,
        steps: List[str],
        agents: List[str],
        warnings: List[str] = None,
    ):
        """Render PLAN mode output"""
        # Summary panel
        self.console.print(Panel(
            f"  [text]Task:[/]         {task}\n\n"
            f"  [text]Complexity[/]    [{get_mode_color('plan')}]{complexity.upper()}[/] "
            f"[text.muted](score: {complexity_score:.1f})[/]\n"
            f"  [text]Risk[/]         {risk_score:.1f}/10 "
            f"[{get_severity_color(risk_level)}]({risk_level})[/]\n"
            f"  [text]Est. Cost[/]    ${estimated_cost:.4f}\n"
            f"  [text]Est. Files[/]   ~{estimated_files}",
            title=" 📋 PLAN ",
            border_style="#3B82F6",
            padding=(1, 2),
        ))

        # Steps
        self.console.print()
        for i, step in enumerate(steps, 1):
            self.console.print(f"  [mode.plan]{i}.[/] {step}")

        # Warnings
        if warnings:
            self.console.print()
            for w in warnings:
                self.console.print(f"  [warning]⚠ {w}[/]")

        # Agents
        self.console.print()
        agent_str = "  ".join(
            f"{get_agent_icon(a)} {a}" for a in agents
        )
        self.console.print(f"  [text.dim]Agents:[/] {agent_str}")
        self.console.print()

    # ═══════════════════════════════════════════════════
    #  BUILD PIPELINE
    # ═══════════════════════════════════════════════════

    def build_pipeline(
        self,
        phases: List[Dict],
        current_phase: int = 0,
    ):
        """
        Render BUILD pipeline progress.

        phases: [{"name": "Routing", "status": "done", "detail": "MEDIUM"}, ...]
        """
        total = len(phases)
        self.console.print(f"\n  [mode.build]BUILDING PROJECT[/]\n")

        for i, phase in enumerate(phases):
            num = f"[{i+1}/{total}]"
            name = phase["name"]
            status = phase.get("status", "pending")
            detail = phase.get("detail", "")

            if status == "done":
                icon = "[success]✓[/]"
                detail_str = f" [text.dim]{detail}[/]" if detail else ""
                self.console.print(f"  {num} {name} {icon}{detail_str}")
            elif status == "running":
                icon = "[warning]⠋[/]"
                detail_str = f" [text]{detail}[/]" if detail else ""
                self.console.print(f"  {num} {name} {icon}{detail_str}")
            elif status == "failed":
                icon = "[error]✗[/]"
                detail_str = f" [error]{detail}[/]" if detail else ""
                self.console.print(f"  {num} {name} {icon}{detail_str}")
            else:
                icon = "[text.muted]○[/]"
                self.console.print(f"  {num} {name} {icon}")

        self.console.print()

    # ═══════════════════════════════════════════════════
    #  APPROVAL
    # ═══════════════════════════════════════════════════

    def approval_prompt(
        self,
        action: str,
        reason: str,
        risk_level: str = "medium",
        risk_score: float = 0,
    ) -> bool:
        """Render approval prompt. Returns True if approved."""
        self.console.print()
        self.console.print(Panel(
            f"  [text]Risk:[/]    [{get_severity_color(risk_level)}]"
            f"{risk_level.upper()} {risk_score:.1f}/10[/]\n\n"
            f"  [text]Action:[/]  {action}\n"
            f"  [text]Reason:[/]  {reason}",
            title="[warning] ⚠ APPROVAL REQUIRED [/]",
            border_style="#F59E0B",
            padding=(1, 2),
        ))

        from rich.prompt import Confirm
        return Confirm.ask("  Approve?", default=False)

    # ═══════════════════════════════════════════════════
    #  ERROR
    # ═══════════════════════════════════════════════════

    def error(
        self,
        title: str,
        detail: str = "",
        action: str = "",
        error_id: str = "",
    ):
        """Render a calm, actionable error"""
        parts = [f"  [text]{title}[/]"]
        if detail:
            parts.append(f"\n  [text.dim]{detail}[/]")
        if action:
            parts.append(f"\n  [text]Next:[/] {action}")
        if error_id:
            parts.append(f"\n  [text.muted]Error ID: {error_id}[/]")

        self.console.print(Panel(
            "\n".join(parts),
            title="[error] AERRIK ERROR [/]",
            border_style="#EF4444",
            padding=(1, 2),
        ))
        self.console.print()

    # ═══════════════════════════════════════════════════
    #  STATUS BAR
    # ═══════════════════════════════════════════════════

    def status_bar(
        self,
        session_time: str = "0m",
        agents: int = 0,
        tools: int = 0,
        cost: str = "$0.00",
        byok: bool = False,
    ):
        """Render compact status bar"""
        byok_str = "[success]BYOK[/]" if byok else ""
        self.console.print(Rule(style="#374151"))
        self.console.print(
            f"  [text.muted]session {session_time}[/] "
            f"[text.muted]│[/] [text.dim]{agents} agents[/] "
            f"[text.muted]│[/] [text.dim]{tools} tools[/] "
            f"[text.muted]│[/] [text.dim]{cost}[/] "
            f"[text.muted]│[/] {byok_str}"
        )
        self.console.print(Rule(style="#374151"))

    # ═══════════════════════════════════════════════════
    #  DOG
    # ═══════════════════════════════════════════════════

    def dog(self, state: str = "idle", message: str = ""):
        """Render dog state (subtle, non-intrusive)"""
        if state == "success":
            self.console.print("  [text.muted]🐕 ✓[/]")
        elif state == "error":
            self.console.print("  [warning]🐕 *bark*[/]")
        elif state == "critical":
            self.console.print("  [error]🐕 🐕 BARK![/]")
        elif state == "happy":
            self.console.print("  [text.muted]🐕 ~woof~[/]")

    # ═══════════════════════════════════════════════════
    #  COMPACT INFO
    # ═══════════════════════════════════════════════════

    def info(self, message: str):
        """Render a compact info line"""
        self.console.print(f"  [text.dim]{message}[/]")

    def success(self, message: str):
        """Render a compact success line"""
        self.console.print(f"  [success]✓[/] {message}")

    def warning(self, message: str):
        """Render a compact warning line"""
        self.console.print(f"  [warning]⚠[/] {message}")

    # ═══════════════════════════════════════════════════
    #  ACTIVITY INDICATOR
    # ═══════════════════════════════════════════════════

    def activity(self, message: str) -> 'ActivityContext':
        """Show a live activity indicator"""
        return ActivityContext(self.console, message)

    # ═══════════════════════════════════════════════════
    #  GOODBYE
    # ═══════════════════════════════════════════════════

    def goodbye(self, messages: int = 0, cost: str = "$0.00"):
        """Render goodbye message"""
        self.console.print()
        self.console.print(Rule(style="#374151"))
        self.console.print(Align.center(Text.from_markup(
            f"\n  [aerrik]aerrik[/][aerrik.dim].dev[/]  "
            f"[text.muted]session ended[/]\n"
            f"  [text.muted]💬 {messages} messages  ·  💰 {cost}[/]\n\n"
            f"  [text.dim]woof! see you soon! 🐾[/]\n"
        )))
        self.console.print(Rule(style="#374151"))
        self.console.print()


class ActivityContext:
    """Context manager for live activity indicators"""

    SPINNERS = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]

    def __init__(self, console: Console, message: str):
        self.console = console
        self.message = message
        self._idx = 0

    def __enter__(self):
        self.console.print(f"  [text.muted]⠋[/] {self.message}", end="", highlight=False)
        return self

    def update(self, message: str):
        self.message = message
        self._idx = (self._idx + 1) % len(self.SPINNERS)
        spinner = self.SPINNERS[self._idx]
        self.console.print(f"\r  [text.muted]{spinner}[/] {self.message}", end="", highlight=False)

    def __exit__(self, *args):
        self.console.print(f"\r  [success]✓[/] {self.message}")
        return False
