"""
🎨 aerrik.dev — Terminal UI Layer

Claude Code-level terminal experience.

Components:
    ui/theme.py      — Centralized color theme
    ui/renderer.py   — Main rendering engine
    ui/panels.py     — Reusable panel components
    ui/status.py     — Status bar and headers
    ui/progress.py   — Pipeline progress display
    ui/streaming.py  — Streaming text output
    ui/diff.py       — Code diff renderer
    ui/prompts.py    — Input and approval prompts
    ui/dog.py        — Dog personality layer (event-driven)
"""
