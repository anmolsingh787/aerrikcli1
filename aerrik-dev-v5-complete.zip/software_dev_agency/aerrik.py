#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════╗
║  █████╗ ███████╗██████╗ ██████╗ ██╗██╗  ██╗    🐕           ║
║ ██╔══██╗██╔════╝██╔══██╗██╔══██╗██║██║ ██╔╝                 ║
║ ███████║█████╗  ██████╔╝██████╔╝██║█████╔╝   .dev v3.0     ║
║ ██╔══██║██╔══╝  ██╔══██╗██╔══██╗██║██╔═██╗                 ║
║ ██║  ██║███████╗██║  ██║██║  ██║██║██║  ██╗                ║
║ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚═╝  ╚═╝                ║
╚══════════════════════════════════════════════════════════════╝

aerrik.dev v3.0 — AI Dev Terminal with Dog Companion
- Multi-provider LLM (OpenAI, Anthropic, Groq, Google, DeepSeek, etc.)
- Animated 2D dog companion
- Cost tracking, feedback loops, code validation
- Human approval checkpoints
"""
import os
import sys
import time

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.syntax import Syntax
from rich.markdown import Markdown
from rich.text import Text
from rich.columns import Columns
from rich.rule import Rule
from rich.align import Align
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
from rich.theme import Theme
from rich.live import Live

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from main import SoftwareDevAgency
from agents.base_agent import Task
from skills.skills_loader import SkillsLoader
from llm_engine import LLMEngine, PROVIDERS
from aerrik_dog import AerrikDog
from constants import TOTAL_AGENTS, SKILLS_COUNT, VERSION, CODENAME

# ─── Theme ──────────────────────────────────────────────
THEME = Theme({
    "brand":        "#8B5CF6",
    "brand.dim":    "#6D28D9",
    "brand.bright": "#A78BFA",
    "accent":       "#06B6D4",
    "success":      "#10B981",
    "warning":      "#F59E0B",
    "error":        "#EF4444",
    "info":         "#3B82F6",
    "muted":        "#6B7280",
    "dog":          "#F59E0B",
})
console = Console(theme=THEME)

# ─── Constants (from constants.py — single source of truth) ──
# VERSION and CODENAME imported from constants.py

DOG_ART = r"""
    ╭──────╮
    │ [dog]◕ ᴗ ◕[/] │  [brand]aerrik[/][accent].dev[/]
    │  [dog]▽[/]   │  [muted]v3.0 — {codename}[/]
    ╰──┬┬──╯
       ││
    ╭──┘└──╮
    │      │
    ╰┬────┬╯
     [dog]╵    ╵[/]
"""

HELP_TEXT = """
[brand]COMMANDS[/]
[rule]
  [accent]/help[/]                This screen
  [accent]/status[/]              Agent status board
  [accent]/tree[/]                Family hierarchy
  [accent]/skills[/]              Loaded skill modules
  [accent]/agents[/]              Agent directory
  [accent]/providers[/]            LLM providers & API keys
  [accent]/connect[/] [muted]<provider> <key>[/]  Connect API key
  [accent]/model[/]   [muted]<name>[/]       Switch model
  [accent]/switch[/]  [muted]<agent>[/]      Change active agent
  [accent]/build[/]   [muted]<desc>[/]       Build project (with approvals)
  [accent]/estimate[/] [muted]<desc>[/]      Estimate cost before build
  [accent]/cost[/]                Cost report
  [accent]/dog[/]                 Show dog states
  [accent]/history[/]              Conversation log
  [accent]/clear[/]                Clear screen
  [accent]/about[/]                About aerrik.dev
  [accent]/exit[/]                 End session

[brand]@MENTIONS[/]
[rule]
  [error]@grandpa[/] [error]@grandma[/]      Elders (review & quality)
  [accent]@dad[/] [accent]@architect[/]         System architecture
  [accent]@mommy[/] [accent]@pm[/]             Project management
  [muted]── 👧 Girls Team (Frontend) ──[/]
  [accent]@frontend[/] [accent]@fe[/]          React · Next.js
  [accent]@tester[/]  [accent]@qa[/]           Testing · QA
  [accent]@designer[/] [accent]@ux[/]          UI/UX · Wireframes
  [accent]@mobile[/]  [accent]@app[/]          React Native · PWA
  [muted]── 👦 Boys Team (Backend) ──[/]
  [accent]@backend[/]  [accent]@be[/]          FastAPI · Node.js
  [accent]@database[/] [accent]@db[/]          PostgreSQL · Redis
  [accent]@devops[/]  [accent]@ops[/]          Docker · CI/CD
  [accent]@security[/] [accent]@sec[/]         Pen testing · Hardening

[brand]EXAMPLES[/]
[rule]
  [muted]❯[/] /connect openai sk-proj-...
  [muted]❯[/] /connect groq gsk_...
  [muted]❯[/] @frontend Build a responsive navbar
  [muted]❯[/] /build Todo app with React + FastAPI
"""

AGENT_ALIASES = {
    "@grandpa": "grandfather", "@grandfather": "grandfather",
    "@grandma": "grandmother", "@grandmother": "grandmother",
    "@dad": "architect", "@architect": "architect", "@arch": "architect",
    "@mommy": "pm", "@pm": "pm", "@manager": "pm",
    "@frontend": "frontend", "@fe": "frontend", "@ui": "frontend",
    "@backend": "backend", "@be": "backend", "@api": "backend",
    "@database": "database", "@db": "database", "@data": "database",
    "@devops": "devops", "@ops": "devops", "@infra": "devops",
    "@tester": "tester", "@qa": "tester", "@test": "tester",
    "@designer": "designer", "@ux": "designer", "@design": "designer",
    "@mobile": "mobile", "@app": "mobile", "@rn": "mobile",
    "@security": "security", "@sec": "security", "@pentest": "security",
}
AGENT_ICONS = {
    "grandfather": "[error]👴[/] Grandpa", "grandmother": "[warning]👵[/] Grandma",
    "architect": "[brand]◈[/] Dad", "pm": "[accent]◇[/] Mommy",
    "frontend": "[info]▸[/] Frontend", "backend": "[success]▸[/] Backend",
    "database": "[info]▸[/] Database", "devops": "[info]▸[/] DevOps",
    "tester": "[warning]▸[/] Tester", "designer": "[brand.bright]▸[/] Designer",
    "mobile": "[info]📱[/] Mobile", "security": "[error]🔐[/] Security",
}
AGENT_COLORS = {
    "grandfather": "error", "grandmother": "warning",
    "architect": "brand", "pm": "accent", "frontend": "info",
    "backend": "success", "database": "info", "devops": "info",
    "tester": "warning", "designer": "brand.bright",
    "mobile": "info", "security": "error",
}


# ═══════════════════════════════════════════════════════
#  TERMINAL
# ═══════════════════════════════════════════════════════

class AerrikTerminal:
    """aerrik.dev v3.0 Terminal"""

    def __init__(self, api_key: str = "", provider: str = ""):
        self.api_key = api_key
        self.provider = provider
        self.llm_engine: LLMEngine = None
        self.agency = None
        self.dog = AerrikDog()
        self.active_agent = "architect"
        self.history = []
        self.msg_count = 0

    # ─── Startup ────────────────────────────────────────

    def start(self):
        console.clear()

        # Dog welcome
        console.print(Text.from_markup(
            DOG_ART.replace("{codename}", CODENAME)
        ))
        console.print()

        # Init LLM engine
        with console.status("  [dog]🐕[/] Sniffing for API keys...", spinner="dots"):
            self.llm_engine = LLMEngine(
                provider=self.provider,
                api_key=self.api_key,
            )
            time.sleep(0.3)

        # Show provider status
        info = self.llm_engine.get_info()
        available = self.llm_engine.get_available_providers()
        connected = [name for name, ok in available.items() if ok]

        if info["api_key_set"]:
            console.print(
                f"  [success]✓[/] Connected to [brand]{info['provider_name']}[/] "
                f"({info['model']})\n"
                f"  [muted]Key: {info['api_key_preview']}[/]"
            )
        else:
            console.print(
                f"  [warning]⚠[/] No API key detected — running in [accent]mock mode[/]\n"
                f"  [muted]Connect with:[/] [accent]/connect <provider> <key>[/]"
            )

        if connected:
            console.print(f"  [muted]Available providers: {', '.join(connected)}[/]")
        console.print()

        # Init agency
        with console.status("  [dog]🐕[/] Assembling agent family...", spinner="dots"):
            self.agency = SoftwareDevAgency(
                api_key=self.api_key, verbose=False
            )
            time.sleep(0.3)

        # Stats — using central constants
        skills_count = len(SkillsLoader().list_skills())
        console.print(Rule(
            f"[success]✓[/] [brand]aerrik.dev[/] v{VERSION} online — "
            f"[accent]{TOTAL_AGENTS}[/] agents · [accent]{skills_count}[/] skills · "
            f"[dog]🐕[/] Aerrik ready",
            style="brand.dim"
        ))
        console.print()

        self._repl()

    # ─── REPL ───────────────────────────────────────────

    def _repl(self):
        while True:
            try:
                prompt = self._prompt()
                text = console.input(prompt).strip()
                if not text:
                    continue
                self._dispatch(text)
            except (KeyboardInterrupt, EOFError):
                self._goodbye()
                break

    def _prompt(self) -> str:
        cost = self.agency.cost_tracker.get_compact_summary() if self.agency else ""
        icon = AGENT_ICONS.get(self.active_agent, "?")
        dog = self.dog.get_compact()
        return f"  {dog} [muted]│[/] {icon} [muted]❯[/] "

    def _dispatch(self, text: str):
        if text.startswith("/"):
            self._cmd(text)
            return

        # Check @mention
        first = text.split()[0].lower() if text.split() else ""
        target = AGENT_ALIASES.get(first)
        if target:
            self.active_agent = target
            self.dog.set_agent_mood(target, is_working=True)
            text = text.split(maxsplit=1)
            text = text[1] if len(text) > 1 else ""

        if not text.strip():
            console.print("  [warning]⚠[/] [muted]Type a message after the mention.[/]")
            return

        self._chat(text)

    # ─── Chat ───────────────────────────────────────────

    def _chat(self, message: str):
        agent_map = self._agent_map()
        agent = agent_map.get(self.active_agent)
        if not agent:
            console.print("  [error]✗[/] No active agent")
            return

        icon = AGENT_ICONS.get(self.active_agent, "")
        c = AGENT_COLORS.get(self.active_agent, "muted")

        self.history.append({
            "role": "user", "content": message,
            "agent": self.active_agent, "ts": time.time(),
        })
        self.msg_count += 1

        # Dog thinking
        self.dog.set_state("think", message=f"{agent.name} is working...")

        try:
            with console.status(
                f"  [dog]🐕💭[/] {icon} [muted]thinking...[/]",
                spinner="dots"
            ):
                task = Task(title=message[:50], description=message)
                response = agent.execute_task(task)

            # Track cost
            self.agency.cost_tracker.record_call(
                agent_name=agent.name,
                model=agent.config.model,
                input_text=message,
                output_text=response,
            )

            self.history.append({
                "role": "assistant", "content": response,
                "agent": self.active_agent, "ts": time.time(),
            })

            # Check for errors in response
            error_keywords = ["error", "❌", "failed", "exception", "traceback",
                              "MOCK RESPONSE", "BUDGET EXCEEDED"]
            has_error = any(kw.lower() in response.lower() for kw in error_keywords)

            if has_error:
                # 🐕 BARK on error!
                self.dog.error(message[:50])
                console.print()
                console.print(Panel(
                    f"[dog]🐕🔊 WOOF WOOF![/] Error detected!\n\n"
                    f"  {response[:300]}...",
                    title="[error]  🚨 Dog Alert  [/]",
                    border_style="error",
                    padding=(1, 2),
                ))
                self.dog.post_error()
            else:
                # Dog happy
                self.dog.set_state("happy")
                self._render_response(response, agent)

        except Exception as e:
            # 🐕 BARK on exception!
            self.dog.error(str(e))
            console.print()
            console.print(Panel(
                f"[dog]🐕🔊 WOOF WOOF! BARK BARK![/]\n\n"
                f"  [error]{str(e)}[/]",
                title="[error]  🚨 Dog Alert — Exception!  [/]",
                border_style="error",
                padding=(1, 2),
            ))
            self.dog.post_error()

    def _render_response(self, text: str, agent):
        icon = AGENT_ICONS.get(self.active_agent, "")
        c = AGENT_COLORS.get(self.active_agent, "muted")

        console.print()
        if "```" in text or "filepath:" in text:
            self._render_code(text, icon, c)
        else:
            console.print(Panel(
                Markdown(text),
                title=f" {icon} ",
                border_style=c,
                padding=(1, 2),
            ))
        console.print()

    def _render_code(self, text, icon, color):
        import re
        parts = re.split(r'(```\w*\n.*?```)', text, flags=re.DOTALL)
        console.print(f"  [{color}]┌─[/] {icon} [{color}]─────────────────────────┐[/]")
        for part in parts:
            if part.startswith("```"):
                m = re.match(r'```(\w*)\n(.*?)```', part, re.DOTALL)
                if m:
                    console.print(Syntax(
                        m.group(2).strip(), m.group(1) or "text",
                        theme="monokai", line_numbers=True, padding=(0, 4),
                    ))
            elif part.strip():
                for line in part.strip().splitlines():
                    console.print(f"  [white]  {line}[/]")
        console.print(f"  [{color}]└──────────────────────────────────────┘[/]")

    def _agent_map(self):
        f = self.agency.family
        return {
            "grandfather": f.grandfather, "grandmother": f.grandmother,
            "architect": f.dad, "pm": f.mommy,
            "frontend": f.frontend_girl, "backend": f.backend_boy,
            "database": f.database_boy, "devops": f.devops_boy,
            "tester": f.tester_girl, "designer": f.designer_girl,
            "mobile": f.mobile_girl, "security": f.security_boy,
        }

    # ─── Commands ───────────────────────────────────────

    def _cmd(self, raw: str):
        parts = raw.split(maxsplit=1)
        cmd = parts[0].lower()
        arg = parts[1] if len(parts) > 1 else ""

        cmds = {
            "/help": self._c_help, "/status": self._c_status,
            "/tree": self._c_tree, "/skills": self._c_skills,
            "/agents": self._c_agents, "/providers": self._c_providers,
            "/connect": self._c_connect, "/model": self._c_model,
            "/switch": self._c_switch, "/build": self._c_build,
            "/estimate": self._c_estimate, "/cost": self._c_cost,
            "/dog": self._c_dog, "/history": self._c_history,
            "/clear": self._c_clear, "/exit": self._c_exit,
            "/quit": self._c_exit, "/about": self._c_about,
        }
        handler = cmds.get(cmd)
        if handler:
            handler(arg)
        else:
            console.print(f"  [error]✗[/] Unknown command. Try [accent]/help[/]")

    def _c_help(self, a=""):
        console.print(Panel(HELP_TEXT, title="[brand]  aerrik.dev — Reference  [/]",
                            border_style="brand", padding=(1, 2)))

    def _c_about(self, a=""):
        info = self.llm_engine.get_info()
        console.print(Panel(
            f"{DOG_ART.replace('{codename}', CODENAME)}\n"
            f"[brand.bright]Version:[/]   {VERSION} ({CODENAME})\n"
            f"[brand.bright]Provider:[/]  {info['provider_name']}\n"
            f"[brand.bright]Model:[/]     {info['model']}\n"
            f"[brand.bright]Agents:[/]    8 specialized AI agents\n"
            f"[brand.bright]Skills:[/]    7 modules from GitHub\n"
            f"[brand.bright]Companion:[/] 🐕 Aerrik (your AI dev dog)\n\n"
            f"[accent]https://aerrik.dev[/]",
            title="[brand]  About  [/]", border_style="brand", padding=(1, 2),
        ))

    def _c_providers(self, a=""):
        """Show all LLM providers and connection status"""
        table = Table(title="🔑 LLM Providers", show_header=True,
                       header_style="brand", border_style="brand.dim")
        table.add_column("", width=3)
        table.add_column("Provider", style="white")
        table.add_column("Env Variable", style="accent")
        table.add_column("Models", style="muted")

        for pid, config in PROVIDERS.items():
            key = os.getenv(config.api_key_env, "")
            is_active = pid == self.llm_engine.provider and self.llm_engine.api_key
            status = "[success]●[/]" if is_active else ("[warning]○[/]" if key else "[muted]○[/]")
            models = ", ".join(config.models[:2])
            if len(config.models) > 2:
                models += f" +{len(config.models)-2}"
            table.add_row(status, config.name, config.api_key_env, models)

        console.print()
        console.print(table)
        console.print()
        console.print("  [muted]Connect:[/] [accent]/connect <provider> <api-key>[/]")
        console.print("  [muted]Example:[/] [accent]/connect groq gsk_abc123...[/]")
        console.print("  [muted]Supports:[/] openai, anthropic, groq, google, deepseek, together, openrouter, perplexity")
        console.print()

    def _c_connect(self, a=""):
        """Connect an API key to a provider"""
        parts = a.split(maxsplit=1)
        if len(parts) < 2:
            console.print("  [warning]⚠[/] Usage: [accent]/connect <provider> <api-key>[/]")
            console.print("  [muted]Providers: openai, anthropic, groq, google, deepseek, together, openrouter[/]")
            return

        provider, key = parts[0].lower(), parts[1].strip()

        if provider not in PROVIDERS:
            console.print(f"  [error]✗[/] Unknown provider: {provider}")
            console.print(f"  [muted]Available: {', '.join(PROVIDERS.keys())}[/]")
            return

        # Validate key format
        config = PROVIDERS[provider]
        if config.api_key_prefix and not key.startswith(config.api_key_prefix):
            console.print(
                f"  [warning]⚠[/] Key doesn't match {config.name} format "
                f"(expected prefix: {config.api_key_prefix})"
            )
            console.print(f"  [muted]Continuing anyway...[/]")

        # Connect
        self.llm_engine = LLMEngine(provider=provider, api_key=key)
        self.api_key = key
        self.provider = provider

        # Set env var for current session
        os.environ[config.api_key_env] = key

        info = self.llm_engine.get_info()
        console.print()
        console.print(Panel(
            f"[success]✓[/] Connected to [brand]{info['provider_name']}[/]\n"
            f"  Model: [accent]{info['model']}[/]\n"
            f"  Key:   [muted]{info['api_key_preview']}[/]\n\n"
            f"[muted]Set env var for persistence:[/]\n"
            f"  [accent]export {config.api_key_env}={key[:10]}...[/]",
            title="[success]  ✓ Connected  [/]",
            border_style="success", padding=(1, 2), expand=False,
        ))

        self.dog.set_state("bark", message="Connected! Woof!")
        console.print()

    def _c_model(self, a=""):
        """Switch model"""
        if not a:
            models = self.llm_engine.get_supported_models()
            console.print(f"  [muted]Current:[/] [accent]{self.llm_engine.model}[/]")
            console.print(f"  [muted]Available:[/] {', '.join(models[:6])}")
            console.print(f"  [muted]Usage:[/] [accent]/model <model-name>[/]")
            return

        self.llm_engine.model = a.strip()
        # Update agency agents' model
        for agent in self._agent_map().values():
            agent.config.model = a.strip()
        console.print(f"  [success]✓[/] Model switched to [accent]{a.strip()}[/]")

    def _c_status(self, a=""):
        table = Table(title="Family Status (12 Agents + 🐕)", show_header=True,
                       header_style="brand", border_style="brand.dim")
        table.add_column("", width=2)
        table.add_column("Agent", min_width=22)
        table.add_column("Team", style="muted")
        table.add_column("Skills", style="muted")
        table.add_column("Tasks", justify="right", style="muted")

        for key, agent in self._agent_map().items():
            active = "[success]●[/]" if key == self.active_agent else "[muted]○[/]"
            skills = []
            if "PONYTAIL" in agent.system_prompt: skills.append("🎯")
            if "FRONTEND" in agent.system_prompt: skills.append("🎨")
            if "BACKEND" in agent.system_prompt: skills.append("⚙️")
            if "SECURITY" in agent.system_prompt: skills.append("🔒")
            if "ARCHITECTURE" in agent.system_prompt: skills.append("🏗️")
            if "WEAK POINT" in agent.system_prompt or "REVIEWER" in agent.system_prompt:
                skills.append("🔍")
            if "QUALITY" in agent.system_prompt or "Wise" in agent.system_prompt:
                skills.append("📚")

            # Determine team
            team = "—"
            if key in ("frontend", "tester", "designer", "mobile"):
                team = "[info]👧 Girls[/]"
            elif key in ("backend", "database", "devops", "security"):
                team = "[success]👦 Boys[/]"
            elif key == "architect":
                team = "[brand]Parents[/]"
            elif key == "pm":
                team = "[brand]Parents[/]"
            elif key in ("grandfather", "grandmother"):
                team = "[error]Elders[/]"

            table.add_row(
                active,
                f"[{AGENT_COLORS.get(key, 'white')}]{agent.name}[/]",
                team,
                " ".join(skills),
                str(agent.get_status()["tasks_completed"]),
            )
        console.print()
        console.print(table)
        console.print()

    def _c_tree(self, a=""):
        console.print(Panel(
            f"""  [error]👴 Grandfather[/] ─── Supreme Reviewer
  [warning]👵 Grandmother[/] ─── Wise Advisor
    │
    [brand]◈ Dad[/] [muted](Architect)[/]
    [brand.dim]│[/]
    [brand.dim]└──[/] [accent]◇ Mommy[/] [muted](PM)[/]
        [accent.dim]│[/]
        [accent.dim]├── 👧 GIRLS TEAM (Frontend)[/]
        [accent.dim]│   ├──[/] {AGENT_ICONS["frontend"]}
        [accent.dim]│   ├──[/] {AGENT_ICONS["tester"]}
        [accent.dim]│   ├──[/] {AGENT_ICONS["designer"]}
        [accent.dim]│   └──[/] {AGENT_ICONS["mobile"]}
        [accent.dim]│[/]
        [accent.dim]└── 👦 BOYS TEAM (Backend)[/]
        [accent.dim]    ├──[/] {AGENT_ICONS["backend"]}
        [accent.dim]    ├──[/] {AGENT_ICONS["database"]}
        [accent.dim]    ├──[/] {AGENT_ICONS["devops"]}
        [accent.dim]    └──[/] {AGENT_ICONS["security"]}

  [dog]🐕 Aerrik[/] ─── Companion [muted](barks on errors!)[/]""",
            title="[brand]  Expanded Family  [/]", border_style="brand.dim", padding=(1, 2),
        ))

    def _c_skills(self, a=""):
        loader = SkillsLoader()
        table = Table(title="Skill Modules", show_header=True,
                       header_style="brand", border_style="brand.dim")
        table.add_column("Module", style="accent")
        table.add_column("Source", style="muted")
        table.add_column("Lines", justify="right")
        sources = loader.get_skill_sources()
        for name, content in loader.skills.items():
            table.add_row(name, sources.get(name, "local"),
                          str(len(content.splitlines())))
        console.print()
        console.print(table)
        console.print()

    def _c_agents(self, a=""):
        table = Table(title="Agent Directory", show_header=True,
                       header_style="brand", border_style="brand.dim")
        table.add_column("", width=2)
        table.add_column("Agent")
        table.add_column("Aliases", style="accent")
        table.add_column("Specialty", style="muted")
        info = {
            "architect": ("@dad @arch", "System design · architecture"),
            "pm":        ("@mommy @pm", "Task mgmt · coordination"),
            "frontend":  ("@frontend @fe", "React · Next.js · TypeScript"),
            "backend":   ("@backend @be", "Python · FastAPI · APIs"),
            "database":  ("@database @db", "PostgreSQL · Redis"),
            "devops":    ("@devops @ops", "Docker · CI/CD"),
            "tester":    ("@tester @qa", "pytest · Jest · E2E"),
            "designer":  ("@designer @ux", "UI/UX · wireframes"),
        }
        for key, (aliases, spec) in info.items():
            m = "[success]●[/]" if key == self.active_agent else " "
            table.add_row(m, f"[{AGENT_COLORS.get(key)}]{AGENT_ICONS.get(key)}[/]",
                          aliases, spec)
        console.print()
        console.print(table)
        console.print()

    def _c_switch(self, a=""):
        if not a:
            console.print("  [muted]Usage:[/] [accent]/switch <agent>[/]")
            return
        key = a.strip().lower().lstrip("@")
        if key in self._agent_map():
            self.active_agent = key
            console.print(f"  [success]✓[/] Switched to {AGENT_ICONS.get(key)}")
        else:
            console.print(f"  [error]✗[/] Unknown agent: {a}")

    def _c_build(self, a=""):
        if not a:
            console.print("  [muted]Usage:[/] [accent]/build <description>[/]")
            return
        console.print(Panel(f"[white]{a}[/]",
            title="[brand]  🚀 Build  [/]", border_style="brand", padding=(0, 2)))
        console.print()
        self.dog.set_state("run", message="Building project!")
        results = self.agency.build_project(a, auto_approve=True)
        self.dog.set_state("happy", message="Build complete!")
        status = results.get("status", "unknown")
        files = len(results.get("files_created", []))
        console.print(Panel(
            f"[{'success' if 'completed' in status else 'error'}]{status}[/]\n"
            f"Files: [accent]{files}[/]",
            title="[brand]  Result  [/]", border_style="brand", expand=False,
        ))
        console.print()

    def _c_estimate(self, a=""):
        if not a:
            console.print("  [muted]Usage:[/] [accent]/estimate <description>[/]")
            return
        with console.status("  [dog]🐕💭[/] Calculating...", spinner="dots"):
            est = self.agency.estimate_build_cost(a)
        within = "[success]✓[/]" if est["within_budget"] else "[error]✗[/]"
        console.print(Panel(
            f"[brand.bright]Tasks:[/]   {est['estimated_tasks']}\n"
            f"[brand.bright]Calls:[/]   {est['estimated_calls']}\n"
            f"[brand.bright]Tokens:[/]  {est['estimated_total_tokens']:,}\n"
            f"[brand.bright]Cost:[/]    [accent]${est['estimated_cost_usd']:.4f}[/]\n"
            f"[brand.bright]Budget:[/]  ${est['budget_remaining']:.2f} remaining\n"
            f"[brand.bright]OK:[/]      {within}",
            title="[brand]  💰 Estimate  [/]", border_style="brand",
            padding=(1, 2), expand=False,
        ))
        console.print()

    def _c_cost(self, a=""):
        console.print(Panel(
            self.agency.cost_tracker.get_summary().strip(),
            title="[brand]  💰 Cost Report  [/]",
            border_style="brand", padding=(1, 2),
        ))
        console.print()

    def _c_dog(self, a=""):
        """Show all dog states"""
        states = ["idle", "think", "run", "happy", "sad", "sleep", "bark"]
        from aerrik_dog import DOG_STATES
        for state in states:
            frames = DOG_STATES[state]
            console.print(f"  [dog]─── {state} ───[/]")
            console.print(f"  [dog]{frames[0]}[/]")
        console.print()

    def _c_history(self, a=""):
        if not self.history:
            console.print("  [muted]No history yet.[/]")
            return
        table = Table(title=f"History ({len(self.history)} msgs)", show_header=True,
                       header_style="brand", border_style="brand.dim")
        table.add_column("#", style="muted", width=4)
        table.add_column("", width=2)
        table.add_column("Agent", min_width=14)
        table.add_column("Message")
        for i, msg in enumerate(self.history[-20:], 1):
            icon = "[accent]→[/]" if msg["role"] == "user" else f"[{AGENT_COLORS.get(msg['agent'])}]←[/]"
            who = "you" if msg["role"] == "user" else AGENT_ICONS.get(msg["agent"], "")
            table.add_row(str(i), icon, who, msg["content"][:60])
        console.print()
        console.print(table)
        console.print()

    def _c_clear(self, a=""):
        console.clear()
        console.print(Text.from_markup(
            DOG_ART.replace("{codename}", CODENAME)
        ))
        console.print()

    def _c_exit(self, a=""):
        self._goodbye()
        sys.exit(0)

    def _goodbye(self):
        console.print()
        console.print(Rule(style="brand.dim"))
        console.print(Align.center(Text.from_markup(
            f"\n  [dog]🐕[/] [brand]aerrik[/][accent].dev[/] [muted]session ended[/]\n"
            f"  [muted]💬 {self.msg_count} messages · "
            f"💰 ${self.agency.cost_tracker.get_total_cost():.4f}[/]\n\n"
            f"  [dog]woof! see you soon! 🐾[/]\n"
        )))
        console.print(Rule(style="brand.dim"))
        console.print()


# ═══════════════════════════════════════════════════════
#  ENTRY
# ═══════════════════════════════════════════════════════

def main():
    import argparse
    parser = argparse.ArgumentParser(prog="aerrik", description="aerrik.dev v3.0")
    parser.add_argument("--key", "-k", help="API key (any provider)")
    parser.add_argument("--provider", "-p", help="Provider (openai, groq, anthropic, etc.)")
    parser.add_argument("--model", "-m", help="Model name")
    parser.add_argument("--demo", action="store_true", help="Mock mode")
    parser.add_argument("--version", action="version", version=f"aerrik.dev v{VERSION}")
    args = parser.parse_args()

    api_key = ""
    provider = args.provider or ""

    if args.demo:
        api_key = ""
    elif args.key:
        api_key = args.key
        if not provider:
            provider = LLMEngine.detect_provider(api_key)
    else:
        # Auto-detect from env
        for pid, config in PROVIDERS.items():
            key = os.getenv(config.api_key_env, "")
            if key:
                api_key = key
                provider = pid
                break

    AerrikTerminal(api_key=api_key, provider=provider).start()


if __name__ == "__main__":
    main()
