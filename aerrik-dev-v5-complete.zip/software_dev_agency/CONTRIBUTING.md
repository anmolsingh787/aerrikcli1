# Contributing to aerrik.dev

Thank you for your interest in contributing to aerrik.dev! This document provides guidelines and information for contributors.

## 🚀 Getting Started

1. Fork the repository
2. Clone your fork:
   ```bash
   git clone https://github.com/YOUR_USERNAME/aerrik-dev.git
   cd aerrik-dev
   ```
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Run in demo mode to verify:
   ```bash
   python aerrik.py --demo
   ```

## 📋 Code of Conduct

- Be respectful and inclusive
- Focus on constructive feedback
- Keep discussions technical and professional

## 🛠️ How to Contribute

### Adding a New Agent

1. Create `agents/my_agent.py` inheriting from `BaseAgent`
2. Implement `execute_task()` method
3. Add role to `config.py` → `AgentRole` enum
4. Add system prompt to `prompts/system_prompts.py`
5. Register in `agents/__init__.py` → `AgencyFamily`
6. Add to `SKILL_AGENT_MAP` in `skills/skills_loader.py`

### Adding a New Skill

1. Create `skills/my_skill.md` with structured content
2. Add to `SKILL_AGENT_MAP` in `skills/skills_loader.py`
3. Add summary method in `SkillsLoader` class
4. Update `get_skill_sources()` with GitHub source

### Adding a New Tool

1. Create method in appropriate `tools/*.py` file
2. Register in `main.py` → `_register_tools()`
3. Document in `AERRIK_DOCUMENTATION.md`

### Adding a CLI Command

1. Add handler method `_cmd_xxx()` in `aerrik.py`
2. Register in `_handle_cmd()` command dict
3. Add to `HELP_PANEL` string
4. Add equivalent in `cli.py` (Click-based)

## 📝 Coding Standards

- **Python 3.11+** with type hints
- **Docstrings** on all public methods
- **Snake_case** for functions/variables
- **PascalCase** for classes
- **UPPER_SNAKE** for constants
- Keep functions under 50 lines where possible
- Use dataclasses for structured data
- Follow the Ponytail principle — minimal code!

## 🧪 Testing

```bash
# Run demo mode tests
python aerrik.py --demo

# Test skills loading
python -c "from skills.skills_loader import SkillsLoader; print(SkillsLoader().get_skill_summary())"

# Test cost tracker
python -c "from tools.cost_tracker import CostTracker; ct = CostTracker(); print(ct.get_summary())"

# Test code validator
python -c "from tools.code_validator import CodeValidator; print(CodeValidator().validate('test.py', 'print(\"hello\")'))"
```

## 📄 License

By contributing, you agree that your contributions will be licensed under the MIT License.

## 🙏 Credits

aerrik.dev integrates skills from these amazing open-source projects:
- [DietrichGebert/ponytail](https://github.com/DietrichGebert/ponytail) — MIT
- [finfin/awesome-frontend-skills](https://github.com/finfin/awesome-frontend-skills) — MIT
- [kodustech/awesome-agent-skills](https://github.com/kodustech/awesome-agent-skills) — MIT
- [trailofbits/skills](https://github.com/trailofbits/skills) — CC-BY-SA-4.0
- [cloudai-x/threejs-skills](https://github.com/cloudai-x/threejs-skills) — MIT
- [wshobson/agents](https://github.com/wshobson/agents) — MIT

Please verify license compatibility when redistributing skill content.
