"""
🔑 Multi-Provider LLM Engine

Unified interface for any LLM provider:
- OpenAI (GPT-4, GPT-4o, GPT-4o-mini, o1, etc.)
- Anthropic (Claude 3.5, Claude 3 Opus/Haiku)
- Groq (Llama 3, Mixtral — fast & cheap)
- Google Gemini (2.0 Flash, 1.5 Pro)
- Any OpenAI-compatible endpoint (local LLMs, Together, Perplexity, etc.)

Auto-detects provider from API key format.
Supports fallback chains (try OpenAI → fall back to Groq).
"""
import os
import time
import json
from typing import Optional, Dict, List, Any
from dataclasses import dataclass, field


# ═══════════════════════════════════════════════════════
#  PROVIDER CONFIGS
# ═══════════════════════════════════════════════════════

@dataclass
class ProviderConfig:
    """Configuration for an LLM provider"""
    name: str
    api_key_env: str           # Environment variable name
    api_key_prefix: str = ""   # Key prefix for auto-detection
    base_url: str = ""
    default_model: str = ""
    models: List[str] = field(default_factory=list)
    supports_vision: bool = False
    supports_tools: bool = True
    is_openai_compatible: bool = False  # Uses OpenAI SDK


PROVIDERS = {
    "openai": ProviderConfig(
        name="OpenAI",
        api_key_env="OPENAI_API_KEY",
        api_key_prefix="sk-",
        base_url="https://api.openai.com/v1",
        default_model="gpt-4o",
        models=[
            "gpt-4o", "gpt-4o-mini", "gpt-4-turbo", "gpt-4",
            "gpt-3.5-turbo", "o1-preview", "o1-mini",
        ],
        supports_vision=True,
        is_openai_compatible=True,
    ),

    "anthropic": ProviderConfig(
        name="Anthropic",
        api_key_env="ANTHROPIC_API_KEY",
        api_key_prefix="sk-ant-",
        base_url="https://api.anthropic.com",
        default_model="claude-sonnet-4-20250514",
        models=[
            "claude-opus-4-20250514", "claude-sonnet-4-20250514",
            "claude-3-5-sonnet-20241022", "claude-3-5-haiku-20241022",
            "claude-3-opus-20240229",
        ],
        supports_vision=True,
        is_openai_compatible=False,
    ),

    "groq": ProviderConfig(
        name="Groq",
        api_key_env="GROQ_API_KEY",
        api_key_prefix="gsk_",
        base_url="https://api.groq.com/openai/v1",
        default_model="llama-3.3-70b-versatile",
        models=[
            "llama-3.3-70b-versatile", "llama-3.1-8b-instant",
            "mixtral-8x7b-32768", "gemma2-9b-it",
        ],
        supports_vision=False,
        is_openai_compatible=True,
    ),

    "google": ProviderConfig(
        name="Google",
        api_key_env="GOOGLE_API_KEY",
        api_key_prefix="AIza",
        base_url="https://generativelanguage.googleapis.com/v1beta",
        default_model="gemini-2.0-flash",
        models=[
            "gemini-2.5-pro", "gemini-2.5-flash",
            "gemini-2.0-flash", "gemini-1.5-pro",
        ],
        supports_vision=True,
        is_openai_compatible=False,
    ),

    "deepseek": ProviderConfig(
        name="DeepSeek",
        api_key_env="DEEPSEEK_API_KEY",
        api_key_prefix="sk-",
        base_url="https://api.deepseek.com/v1",
        default_model="deepseek-chat",
        models=["deepseek-chat", "deepseek-reasoner"],
        supports_vision=False,
        is_openai_compatible=True,
    ),

    "together": ProviderConfig(
        name="Together AI",
        api_key_env="TOGETHER_API_KEY",
        api_key_prefix="",
        base_url="https://api.together.xyz/v1",
        default_model="meta-llama/Llama-3.3-70B-Instruct-Turbo",
        models=[
            "meta-llama/Llama-3.3-70B-Instruct-Turbo",
            "Qwen/Qwen2.5-72B-Instruct-Turbo",
        ],
        is_openai_compatible=True,
    ),

    "perplexity": ProviderConfig(
        name="Perplexity",
        api_key_env="PERPLEXITY_API_KEY",
        api_key_prefix="pplx-",
        base_url="https://api.perplexity.ai",
        default_model="sonar-pro",
        models=["sonar-pro", "sonar", "sonar-reasoning"],
        is_openai_compatible=True,
    ),

    "openrouter": ProviderConfig(
        name="OpenRouter",
        api_key_env="OPENROUTER_API_KEY",
        api_key_prefix="sk-or-",
        base_url="https://openrouter.ai/api/v1",
        default_model="openai/gpt-4o",
        models=[
            "openai/gpt-4o", "anthropic/claude-sonnet-4",
            "google/gemini-2.0-flash", "meta-llama/llama-3.3-70b",
        ],
        is_openai_compatible=True,
    ),
}


# ═══════════════════════════════════════════════════════
#  RESPONSE DATA CLASS
# ═══════════════════════════════════════════════════════

@dataclass
class LLMResponse:
    """Unified response from any provider"""
    content: str
    provider: str
    model: str
    input_tokens: int = 0
    output_tokens: int = 0
    latency_ms: float = 0
    cost_usd: float = 0
    error: str = ""
    success: bool = True


# ═══════════════════════════════════════════════════════
#  MAIN ENGINE
# ═══════════════════════════════════════════════════════

class LLMEngine:
    """
    🔑 Universal LLM Engine

    Usage:
        # Auto-detect from env vars
        engine = LLMEngine()

        # Or specify provider + key
        engine = LLMEngine(provider="groq", api_key="gsk_...")

        # Or from any API key (auto-detects provider)
        engine = LLMEngine.from_api_key("gsk_abc123...")

        # Generate
        response = engine.generate("Hello!", system="You are helpful.")

        # With fallback
        engine = LLMEngine(fallback_chain=["openai", "groq", "deepseek"])
    """

    def __init__(
        self,
        provider: str = "",
        api_key: str = "",
        model: str = "",
        fallback_chain: Optional[List[str]] = None,
        max_retries: int = 2,
        timeout: int = 120,
    ):
        self.provider = provider
        self.api_key = api_key
        self.model = model
        self.fallback_chain = fallback_chain or []
        self.max_retries = max_retries
        self.timeout = timeout
        self._client = None

        # Auto-detect if not specified
        if not provider and not api_key:
            self._auto_detect()
        elif api_key and not provider:
            self.provider = self.detect_provider(api_key)

        # Set model
        if not model and self.provider:
            config = PROVIDERS.get(self.provider)
            if config:
                self.model = config.default_model

        # Initialize client
        self._init_client()

    @classmethod
    def from_api_key(cls, api_key: str, model: str = "") -> "LLMEngine":
        """Create engine from any API key (auto-detects provider)"""
        provider = cls.detect_provider(api_key)
        return cls(provider=provider, api_key=api_key, model=model)

    @classmethod
    def detect_provider(cls, api_key: str) -> str:
        """
        Best-effort provider detection from API key format.

        ⚠️  This is a heuristic, NOT a guarantee.
        Multiple providers may share prefixes (e.g., 'sk-' for OpenAI/DeepSeek).
        For reliable detection, always use /connect <provider> <key> explicitly.

        Priority: Longer prefixes checked first to avoid false matches.
        """
        if not api_key:
            return ""

        # Check longer prefixes first (sk-ant- before sk-)
        # Sort by prefix length descending
        sorted_providers = sorted(
            PROVIDERS.items(),
            key=lambda x: len(x[1].api_key_prefix),
            reverse=True,
        )

        for provider_id, config in sorted_providers:
            if config.api_key_prefix and api_key.startswith(config.api_key_prefix):
                return provider_id

        # Unknown — try as OpenAI-compatible
        return "openai"

    def _auto_detect(self):
        """Auto-detect provider from environment variables"""
        for provider_id, config in PROVIDERS.items():
            key = os.getenv(config.api_key_env, "")
            if key:
                self.provider = provider_id
                self.api_key = key
                self.model = config.default_model
                return

    def _init_client(self):
        """Initialize the LLM client"""
        if not self.api_key or not self.provider:
            return

        config = PROVIDERS.get(self.provider)
        if not config:
            return

        if config.is_openai_compatible:
            self._init_openai_client(config)
        elif self.provider == "anthropic":
            self._init_anthropic_client(config)
        elif self.provider == "google":
            self._init_google_client(config)

    def _init_openai_client(self, config: ProviderConfig):
        """Initialize OpenAI-compatible client"""
        try:
            from openai import OpenAI
            kwargs = {"api_key": self.api_key}
            if config.base_url:
                kwargs["base_url"] = config.base_url
            self._client = OpenAI(**kwargs)
            self._client_type = "openai"
        except ImportError:
            pass

    def _init_anthropic_client(self, config: ProviderConfig):
        """Initialize Anthropic client"""
        try:
            from anthropic import Anthropic
            self._client = Anthropic(api_key=self.api_key)
            self._client_type = "anthropic"
        except ImportError:
            pass

    def _init_google_client(self, config: ProviderConfig):
        """Initialize Google Gemini client"""
        try:
            import google.generativeai as genai
            genai.configure(api_key=self.api_key)
            self._client = genai
            self._client_type = "google"
        except ImportError:
            pass

    # ═════════════════════════════════════════════════
    #  GENERATE (unified interface)
    # ═════════════════════════════════════════════════

    def generate(
        self,
        prompt: str,
        system: str = "",
        messages: Optional[List[Dict]] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> LLMResponse:
        """
        Generate response from any provider.
        Tries primary provider, then fallback chain.
        """
        start = time.time()

        # Build messages
        if messages is None:
            messages = []
            if system:
                messages.append({"role": "system", "content": system})
            messages.append({"role": "user", "content": prompt})

        # Try primary provider
        response = self._call(messages, temperature, max_tokens)
        if response.success:
            response.latency_ms = (time.time() - start) * 1000
            return response

        # Try fallback chain
        for fallback_provider in self.fallback_chain:
            if fallback_provider == self.provider:
                continue
            fallback_engine = LLMEngine(
                provider=fallback_provider,
                model="",
                max_retries=1,
            )
            if fallback_engine.api_key:
                response = fallback_engine._call(messages, temperature, max_tokens)
                if response.success:
                    response.latency_ms = (time.time() - start) * 1000
                    return response

        # All providers failed
        return LLMResponse(
            content="",
            provider=self.provider,
            model=self.model,
            error="All providers failed",
            success=False,
            latency_ms=(time.time() - start) * 1000,
        )

    def _call(
        self,
        messages: List[Dict],
        temperature: float,
        max_tokens: int,
    ) -> LLMResponse:
        """Make the actual API call"""
        if not self._client:
            return self._mock_call(messages)

        for attempt in range(self.max_retries):
            try:
                if self._client_type == "openai":
                    return self._call_openai(messages, temperature, max_tokens)
                elif self._client_type == "anthropic":
                    return self._call_anthropic(messages, temperature, max_tokens)
                elif self._client_type == "google":
                    return self._call_google(messages, temperature, max_tokens)
            except Exception as e:
                error_str = str(e)
                # Retry on rate limit or server error
                if attempt < self.max_retries - 1 and (
                    "rate" in error_str.lower()
                    or "429" in error_str
                    or "500" in error_str
                    or "503" in error_str
                ):
                    wait = 2 ** (attempt + 1)  # Exponential backoff
                    time.sleep(wait)
                    continue
                return LLMResponse(
                    content="",
                    provider=self.provider,
                    model=self.model,
                    error=error_str,
                    success=False,
                )

        return LLMResponse(
            content="",
            provider=self.provider,
            model=self.model,
            error="Max retries exceeded",
            success=False,
        )

    def _call_openai(self, messages, temperature, max_tokens) -> LLMResponse:
        """Call OpenAI-compatible API"""
        response = self._client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        content = response.choices[0].message.content or ""
        usage = response.usage

        return LLMResponse(
            content=content,
            provider=self.provider,
            model=self.model,
            input_tokens=usage.prompt_tokens if usage else 0,
            output_tokens=usage.completion_tokens if usage else 0,
            success=True,
        )

    def _call_anthropic(self, messages, temperature, max_tokens) -> LLMResponse:
        """Call Anthropic API"""
        # Extract system message
        system_msg = ""
        chat_messages = []
        for msg in messages:
            if msg["role"] == "system":
                system_msg = msg["content"]
            else:
                chat_messages.append(msg)

        kwargs = {
            "model": self.model,
            "messages": chat_messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        if system_msg:
            kwargs["system"] = system_msg

        response = self._client.messages.create(**kwargs)

        content = ""
        for block in response.content:
            if hasattr(block, "text"):
                content += block.text

        return LLMResponse(
            content=content,
            provider=self.provider,
            model=self.model,
            input_tokens=response.usage.input_tokens,
            output_tokens=response.usage.output_tokens,
            success=True,
        )

    def _call_google(self, messages, temperature, max_tokens) -> LLMResponse:
        """Call Google Gemini API"""
        model = self._client.GenerativeModel(self.model)

        # Convert messages to Gemini format
        system_parts = [m["content"] for m in messages if m["role"] == "system"]
        user_parts = [m["content"] for m in messages if m["role"] == "user"]
        prompt = "\n\n".join(system_parts + user_parts)

        response = model.generate_content(
            prompt,
            generation_config=self._client.types.GenerationConfig(
                temperature=temperature,
                max_output_tokens=max_tokens,
            ),
        )

        return LLMResponse(
            content=response.text,
            provider=self.provider,
            model=self.model,
            success=True,
        )

    def _mock_call(self, messages) -> LLMResponse:
        """Mock response when no API key is available"""
        last_msg = messages[-1]["content"] if messages else ""
        return LLMResponse(
            content=(
                f"[MOCK RESPONSE]\n"
                f"Provider: {self.provider or 'none'}\n"
                f"Model: {self.model or 'none'}\n\n"
                f"Received: {last_msg[:300]}...\n\n"
                f"[Connect an API key to get real responses]\n"
                f"Supported: OpenAI, Anthropic, Groq, Google, DeepSeek, etc."
            ),
            provider=self.provider or "mock",
            model=self.model or "mock",
            success=True,
        )

    # ═════════════════════════════════════════════════
    #  STATUS & INFO
    # ═════════════════════════════════════════════════

    def get_info(self) -> Dict:
        """Get current engine info"""
        config = PROVIDERS.get(self.provider, None)
        return {
            "provider": self.provider or "none",
            "provider_name": config.name if config else "Not configured",
            "model": self.model or "none",
            "has_client": self._client is not None,
            "client_type": getattr(self, "_client_type", "none"),
            "api_key_set": bool(self.api_key),
            "api_key_preview": (self.api_key[:8] + "...") if self.api_key else "",
            "fallback_chain": self.fallback_chain,
        }

    def get_available_providers(self) -> Dict[str, bool]:
        """Check which providers have API keys configured"""
        result = {}
        for pid, config in PROVIDERS.items():
            key = os.getenv(config.api_key_env, "") or (
                self.api_key if pid == self.provider else ""
            )
            result[config.name] = bool(key)
        return result

    def get_supported_models(self) -> List[str]:
        """Get models available for current provider"""
        config = PROVIDERS.get(self.provider)
        return config.models if config else []

    @staticmethod
    def list_all_providers() -> str:
        """Get formatted list of all supported providers"""
        lines = []
        for pid, config in PROVIDERS.items():
            key = os.getenv(config.api_key_env, "")
            status = "🟢" if key else "⚪"
            models = ", ".join(config.models[:3])
            if len(config.models) > 3:
                models += f" (+{len(config.models)-3} more)"
            lines.append(
                f"  {status} {config.name:15s} │ {pid:12s} │ "
                f"env: {config.api_key_env}\n"
                f"    {'':15s} │ Models: {models}"
            )
        return "\n".join(lines)
