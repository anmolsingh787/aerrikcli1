#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════╗
║  █████╗ ███████╗██████╗ ██████╗ ██╗██╗  ██╗    🐕           ║
║ ██╔══██╗██╔════╝██╔══██╗██╔══██╗██║██║ ██╔╝                 ║
║ ███████║█████╗  ██████╔╝██████╔╝██║█████╔╝   .dev CLI      ║
║ ██╔══██║██╔══╝  ██╔══██╗██╔══██╗██║██╔═██╗                 ║
║ ██║  ██║███████╗██║  ██║██║  ██║██║██║  ██╗                ║
║ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚═╝  ╚═╝                ║
╚══════════════════════════════════════════════════════════════╝

aerrik.dev CLI — Three-Mode AI Engineering Runtime

Modes:
  [PLAN]  Analyze and plan without modifying files
  [AGENT] Interactive Claude Code-level agent
  [BUILD] Autonomous engineering pipeline

Features:
  - ADK (Agent Development Kit) primitives
  - MCP (Model Context Protocol) server support
  - BYOK (Bring Your Own API Key) with AES-256-GCM
  - 12 specialized AI agents
  - Risk-aware routing and cost tracking
  - Session persistence and resume
"""
import os
import sys
import time
import json

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.syntax import Syntax
from rich.markdown import Markdown
from rich.text import Text
from rich.rule import Rule
from rich.prompt import Prompt, Confirm, IntPrompt
from rich.columns import Columns
from rich.align import Align
from rich.live import Live
from rich.theme import Theme

from adk.agent import Agent, AgentRole
from adk.tool import Tool, create_read_tool, create_write_tool, create_shell_tool
from adk.skill import Skill, SkillRegistry
from adk.session import Session
from adk.workflow import Workflow, Step
from adk.mcp_manager import MCPManager, KNOWN_MCP_SERVERS
from adk.events import EventBus, Event, EventType

from engines.routing_engine import TaskComplexity, ActivationPolicy
from engines.risk_engine import RiskEngine
from engines.policy_engine import PolicyEngine, PolicyInput

from constants import VERSION, CODENAME, TOTAL_AGENTS

# ─── Theme ──────────────────────────────────────────────
THEME = Theme({
    "brand": "#8B5CF6",
    "accent": "#06B6D4",
    "success": "#10B981",
    "warning": "#F59E0B",
    "error": "#EF4444",
    "muted": "#6B7280",
    "plan": "#3B82F6",
    "agent": "#8B5CF6",
    "build": "#10B981",
})
console = Console(theme=THEME)


# ═══════════════════════════════════════════════════════
#  MODE DEFINITIONS
# ═══════════════════════════════════════════════════════

class Mode:
    PLAN = "plan"
    AGENT = "agent"
    BUILD = "build"

MODE_COLORS = {
    Mode.PLAN: "plan",
    Mode.AGENT: "agent",
    Mode.BUILD: "build",
}
MODE_ICONS = {
    Mode.PLAN: "📋",
    Mode.AGENT: "🤖",
    Mode.BUILD: "🏗️",
}


# ═══════════════════════════════════════════════════════
#  BYOK PROVIDER MANAGER (CLI-level)
# ═══════════════════════════════════════════════════════

class ProviderManager:
    """Manage user's LLM provider API keys"""

    PROVIDERS = {
        "openai":     {"name": "OpenAI",     "prefix": "sk-proj-",  "env": "OPENAI_API_KEY",     "icon": "🤖", "models": ["gpt-4o", "gpt-4o-mini"]},
        "anthropic":  {"name": "Anthropic",  "prefix": "sk-ant-",   "env": "ANTHROPIC_API_KEY",  "icon": "🧠", "models": ["claude-sonnet-4-20250514"]},
        "groq":       {"name": "Groq",       "prefix": "gsk_",      "env": "GROQ_API_KEY",       "icon": "⚡", "models": ["llama-3.3-70b-versatile"]},
        "google":     {"name": "Google",     "prefix": "AIza",      "env": "GOOGLE_API_KEY",     "icon": "🔮", "models": ["gemini-2.5-flash"]},
        "deepseek":   {"name": "DeepSeek",   "prefix": "sk-",       "env": "DEEPSEEK_API_KEY",   "icon": "🔬", "models": ["deepseek-chat"]},
        "openrouter": {"name": "OpenRouter", "prefix": "sk-or-",    "env": "OPENROUTER_API_KEY", "icon": "🌐", "models": ["openai/gpt-4o"]},
    }

    def __init__(self):
        self._keys = {}  # provider -> masked info
        self._default = None
        self._scan_env()

    def _scan_env(self):
        """Scan environment for existing keys"""
        for pid, info in self.PROVIDERS.items():
            key = os.getenv(info["env"], "")
            if key:
                self._keys[pid] = {
                    "connected": True,
                    "masked": self._mask(key),
                    "prefix": info["prefix"],
                }
                if not self._default:
                    self._default = pid

    def _mask(self, key: str) -> str:
        if len(key) > 12:
            return key[:4] + "•" * 8 + key[-4:]
        return "•" * len(key)

    def get_active_provider(self) -> str:
        return self._default or ""

    def get_active_model(self) -> str:
        if self._default and self._default in self.PROVIDERS:
            models = self.PROVIDERS[self._default]["models"]
            return models[0] if models else "gpt-4o"
        return "gpt-4o"

    def is_byok(self) -> bool:
        return len(self._keys) > 0

    def connect(self, provider: str, key: str):
        """Connect a provider key (stored in env for session)"""
        if provider not in self.PROVIDERS:
            return False
        info = self.PROVIDERS[provider]
        os.environ[info["env"]] = key
        self._keys[provider] = {
            "connected": True,
            "masked": self._mask(key),
            "prefix": info["prefix"],
        }
        if not self._default:
            self._default = provider
        return True

    def disconnect(self, provider: str):
        if provider in self._keys:
            info = self.PROVIDERS.get(provider, {})
            env_key = info.get("env", "")
            if env_key and env_key in os.environ:
                del os.environ[env_key]
            del self._keys[provider]
            if self._default == provider:
                self._default = next(iter(self._keys), None)

    def get_status_table(self) -> Table:
        table = Table(title="🔑 LLM Providers", show_header=True,
                       header_style="#8B5CF6", border_style="#6D28D9")
        table.add_column("", width=3)
        table.add_column("Provider", style="white")
        table.add_column("Status", width=15)
        table.add_column("Key", style="dim")
        table.add_column("Default", width=8)

        for pid, info in self.PROVIDERS.items():
            connected = pid in self._keys
            status = "[success]● Connected[/]" if connected else "[muted]○ Not connected[/]"
            key_display = self._keys[pid]["masked"] if connected else ""
            default = "[brand]★[/]" if pid == self._default else ""
            table.add_row(info["icon"], info["name"], status, key_display, default)

        return table


# ═══════════════════════════════════════════════════════
#  MAIN CLI
# ═══════════════════════════════════════════════════════

class AerrikCLI:
    """
    aerrik.dev — Three-Mode AI Engineering Runtime CLI
    """

    def __init__(self):
        self.mode = Mode.AGENT
        self.providers = ProviderManager()
        self.mcp = MCPManager()
        self.events = EventBus()
        self.session = Session(mode=self.mode)
        self.skills = SkillRegistry("skills")
        self.risk_engine = RiskEngine()
        self.policy_engine = PolicyEngine()
        self.running = True

        # Load skills
        self.skills.load_from_directory("skills")

        # Register events
        self._register_events()

    def _register_events(self):
        """Register event handlers"""
        @self.events.on(EventType.ERROR)
        def on_error(event: Event):
            console.print(f"  [error]🐕🔊 WOOF! {event.data.get('error', 'Error')}[/]")

        @self.events.on(EventType.MODE_CHANGED)
        def on_mode_change(event: Event):
            new_mode = event.data.get("mode", "")
            color = MODE_COLORS.get(new_mode, "muted")
            icon = MODE_ICONS.get(new_mode, "")
            console.print(f"\n  [{color}]{icon} Switched to {new_mode.upper()} mode[/{color}]\n")

    # ─── Startup ───────────────────────────────────────

    def start(self, initial_mode: str = None):
        """Start the CLI"""
        if initial_mode and initial_mode in (Mode.PLAN, Mode.AGENT, Mode.BUILD):
            self.mode = initial_mode

        self._show_banner()

        # If no mode specified, show mode selector
        if not initial_mode:
            self._mode_selector()

        # Enter mode loop
        self._mode_loop()

    def _show_banner(self):
        """Show startup banner"""
        console.clear()
        byok_status = "[success]BYOK: ON[/]" if self.providers.is_byok() else "[warning]BYOK: OFF[/]"
        provider = self.providers.get_active_provider()
        provider_name = self.providers.PROVIDERS.get(provider, {}).get("name", "None")

        banner = f"""
    [brand]╔══════════════════════════════════════════════════════════╗[/]
    [brand]║[/]  [brand]█████╗ ███████╗██████╗ ██████╗ ██╗██╗  ██╗[/]           [brand]║[/]
    [brand]║[/]  [brand]██╔══██╗██╔════╝██╔══██╗██╔══██╗██║██║ ██╔╝[/]           [brand]║[/]
    [brand]║[/]  [brand]███████║█████╗  ██████╔╝██████╔╝██║█████╔╝[/]  [accent].dev[/]    [brand]║[/]
    [brand]║[/]  [brand]██╔══██║██╔══╝  ██╔══██╗██╔══██╗██║██╔═██╗[/]           [brand]║[/]
    [brand]║[/]  [brand]██║  ██║███████╗██║  ██║██║  ██║██║██║  ██╗[/]           [brand]║[/]
    [brand]║[/]  [brand]╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚═╝  ╚═╝[/]           [brand]║[/]
    [brand]╚══════════════════════════════════════════════════════════╝[/]

    [brand]v{VERSION}[/] [muted]—[/] [accent]{CODENAME}[/]     {byok_status}     [muted]Provider: {provider_name}[/]
    [muted]{TOTAL_AGENTS} agents · {len(self.skills)} skills · {len(self.mcp.get_tools())} MCP tools[/]
"""
        console.print(banner)

    def _mode_selector(self):
        """Show mode selection screen"""
        console.print(Panel(
            "  [plan]📋 [1] PLAN[/]   — Analyze and plan (read-only)\n"
            "  [agent]🤖 [2] AGENT[/]  — Interactive AI engineering agent\n"
            "  [build]🏗️  [3] BUILD[/]  — Autonomous build pipeline",
            title="[brand]  Select Mode  [/]",
            border_style="brand",
            padding=(1, 2),
        ))

        choice = Prompt.ask(
            "  Choose", choices=["1", "2", "3"], default="2"
        )
        mode_map = {"1": Mode.PLAN, "2": Mode.AGENT, "3": Mode.BUILD}
        self.mode = mode_map[choice]

    # ─── Mode Loop ─────────────────────────────────────

    def _mode_loop(self):
        """Main REPL loop for current mode"""
        while self.running:
            try:
                prompt = self._build_prompt()
                user_input = console.input(prompt).strip()

                if not user_input:
                    continue

                # Handle commands
                if user_input.startswith("/"):
                    self._handle_command(user_input)
                    continue

                # Handle by mode
                if self.mode == Mode.PLAN:
                    self._plan_mode(user_input)
                elif self.mode == Mode.AGENT:
                    self._agent_mode(user_input)
                elif self.mode == Mode.BUILD:
                    self._build_mode(user_input)

            except KeyboardInterrupt:
                console.print("\n  [muted]Use /exit to quit[/]")
            except EOFError:
                self._exit()

    def _build_prompt(self) -> str:
        """Build the CLI prompt"""
        color = MODE_COLORS.get(self.mode, "muted")
        icon = MODE_ICONS.get(self.mode, "")
        cost = f"${self.session.cost_usd:.4f}" if self.session.cost_usd > 0 else ""
        cost_str = f" [muted]│ {cost}[/]" if cost else ""

        return f"  [brand]aerrik[/][accent].dev[/] [muted]│[/] [{color}]{icon} {self.mode.upper()}[/{color}]{cost_str} [muted]❯[/] "

    # ═══════════════════════════════════════════════════
    #  PLAN MODE
    # ═══════════════════════════════════════════════════

    def _plan_mode(self, task: str):
        """
        PLAN mode: Analyze without modifying files.

        Flow: Task → Complexity → Risk → File Impact → Cost Estimate → Plan
        """
        console.print()

        # 1. Complexity classification
        breakdown = TaskComplexity.classify_detailed(task)
        complexity_color = {
            "simple": "success",
            "medium": "warning",
            "complex": "error",
        }.get(breakdown.policy.value, "muted")

        # 2. Risk analysis
        risk_score = self.risk_engine.score("task", task, task)

        # 3. File impact estimation
        estimated_files = int(breakdown.files)

        # 4. Cost estimation
        cost_est = self._estimate_cost(breakdown)

        # Display plan
        console.print(Panel(
            f"  [brand.bright]Complexity:[/]  [{complexity_color}]{breakdown.policy.value.upper()}[/] "
            f"(score: {breakdown.final_score:.1f})\n"
            f"  [brand.bright]Risk Score:[/]  {risk_score.final_score:.1f}/10 ({risk_score.level.value})\n"
            f"  [brand.bright]Est. Files:[/]  ~{estimated_files}\n"
            f"  [brand.bright]Est. Cost:[/]   ${cost_est:.4f}\n"
            f"  [brand.bright]Est. Calls:[/]  {self._estimate_calls(breakdown)}\n"
            f"\n  [muted]Reasoning: {breakdown.reasoning}[/]",
            title="[plan]  📋 PLAN Analysis  [/]",
            border_style="plan",
            padding=(1, 2),
        ))

        # 5. Generate implementation plan
        plan_steps = self._generate_plan_steps(task, breakdown)

        console.print()
        for i, step in enumerate(plan_steps, 1):
            console.print(f"  [plan]{i}.[/] {step}")

        # 6. Risk warnings
        if risk_score.final_score >= 6:
            console.print(f"\n  [warning]⚠️  Risks:[/]")
            for finding in risk_score.findings[:3]:
                console.print(f"    [warning]• {finding}[/]")

        # 7. Recommended agents
        agents = self._recommend_agents(breakdown, risk_score)
        console.print(f"\n  [brand.bright]Recommended agents:[/] {', '.join(agents)}")

        # Ask to execute
        console.print()
        action = Prompt.ask(
            "  Action", choices=["execute", "revise", "back"], default="execute"
        )
        if action == "execute":
            self.mode = Mode.BUILD
            self.events.emit(Event(EventType.MODE_CHANGED, {"mode": "build"}))
            self._build_mode(task)
        elif action == "revise":
            feedback = Prompt.ask("  Revision feedback")
            self._plan_mode(f"{task}\n\nUser feedback: {feedback}")

    def _generate_plan_steps(self, task: str, breakdown) -> list:
        """Generate implementation plan steps"""
        steps = []
        policy = breakdown.policy.value

        if policy == "simple":
            steps = [
                f"Analyze requirements for: {task[:50]}",
                "Implement the solution",
                "Validate output",
            ]
        elif policy == "medium":
            steps = [
                f"Analyze requirements and dependencies",
                "Design solution architecture",
                "Implement core functionality",
                "Add error handling and validation",
                "Write tests",
                "Review and validate",
            ]
        else:
            steps = [
                "Full requirements analysis",
                "System architecture design (Dad)",
                "Task decomposition (Mommy)",
                "Database schema design",
                "Backend API implementation",
                "Frontend implementation",
                "Security hardening",
                "Integration testing",
                "Visual validation",
                "Risk-aware review (Grandfather + Grandmother)",
                "Git commit with changelog",
            ]
        return steps

    def _estimate_cost(self, breakdown) -> float:
        """Estimate cost based on complexity"""
        base_costs = {"simple": 0.005, "medium": 0.05, "complex": 0.50}
        return base_costs.get(breakdown.policy.value, 0.05)

    def _estimate_calls(self, breakdown) -> int:
        """Estimate LLM calls"""
        base = {"simple": 2, "medium": 6, "complex": 15}
        return base.get(breakdown.policy.value, 5)

    def _recommend_agents(self, breakdown, risk_score) -> list:
        """Recommend agents based on task analysis"""
        agents = []
        if breakdown.scope >= 5:
            agents.append("Dad (Architect)")
        if breakdown.security >= 5:
            agents.append("Security Boy 🔐")
        if risk_score.final_score >= 6:
            agents.append("Grandfather 👴")
        agents.append("Mommy (PM)")
        if breakdown.policy.value != "simple":
            agents.append("Tester Girl")
        return agents

    # ═══════════════════════════════════════════════════
    #  AGENT MODE
    # ═══════════════════════════════════════════════════

    def _agent_mode(self, user_input: str):
        """
        AGENT mode: Interactive Claude Code-level agent.

        Think → Tool → Result → Think loop.
        """
        console.print()

        # Add to session
        self.session.add_message("user", user_input)

        # Show thinking
        with console.status("  [agent]🤖 Agent thinking...[/]", spinner="dots"):
            time.sleep(0.5)  # Simulate thinking

            # In production, this would call the LLM with tools
            # For now, provide intelligent responses based on input
            response = self._agent_think(user_input)

        # Display response
        self.session.add_message("assistant", response)

        console.print(Panel(
            Markdown(response),
            title="[agent]  🤖 Agent  [/]",
            border_style="agent",
            padding=(1, 2),
        ))

    def _agent_think(self, input_text: str) -> str:
        """Agent reasoning (mock for now, real with LLM provider)"""
        provider = self.providers.get_active_provider()

        if not provider:
            return (
                "**No LLM provider connected.**\n\n"
                "Connect a provider with `/providers` to get real AI responses.\n\n"
                f"I received your request: *{input_text[:100]}*"
            )

        return (
            f"**Agent Response** (via {self.providers.PROVIDERS[provider]['name']})\n\n"
            f"I'll analyze your request: *{input_text[:100]}*\n\n"
            f"**Steps I would take:**\n"
            f"1. Read relevant project files\n"
            f"2. Analyze the codebase structure\n"
            f"3. Implement the requested changes\n"
            f"4. Validate the output\n\n"
            f"*Connect a provider and run in BUILD mode for full autonomous execution.*"
        )

    # ═══════════════════════════════════════════════════
    #  BUILD MODE
    # ═══════════════════════════════════════════════════

    def _build_mode(self, task: str):
        """
        BUILD mode: Full autonomous pipeline.

        Routing → Risk → Decompose → Execute → Validate → Review
        """
        console.print()
        console.print(Panel(
            f"  {task}",
            title="[build]  🏗️ BUILD Pipeline  [/]",
            border_style="build",
            padding=(0, 2),
        ))
        console.print()

        steps = [
            ("Routing", self._build_step_routing, task),
            ("Risk Analysis", self._build_step_risk, task),
            ("Task Decomposition", self._build_step_decompose, task),
            ("Agent Execution", self._build_step_execute, task),
            ("Syntax Validation", self._build_step_validate, None),
            ("Heuristic Scan", self._build_step_heuristic, None),
            ("Tester Review", self._build_step_test, None),
            ("Elder Review", self._build_step_review, None),
        ]

        total = len(steps)
        for i, (name, func, arg) in enumerate(steps, 1):
            console.print(f"  [build][{i}/{total}][/] {name}...", end=" ")

            try:
                result = func(arg) if arg else func()
                console.print(f"[success]✓ {result}[/]")
            except Exception as e:
                console.print(f"[error]✗ {str(e)[:50]}[/]")
                self.events.emit(Event(EventType.ERROR, {"error": str(e)}))

            time.sleep(0.3)  # Visual pacing

        # Summary
        console.print()
        console.print(Panel(
            f"  [success]✅ BUILD COMPLETE[/]\n\n"
            f"  [brand.bright]Cost:[/]   ${self._estimate_cost(TaskComplexity.classify_detailed(task)):.4f}\n"
            f"  [brand.bright]Mode:[/]   BUILD\n"
            f"  [brand.bright]Steps:[/]  {total}/{total} passed",
            title="[build]  ✅ Build Complete  [/]",
            border_style="build",
            padding=(1, 2),
            expand=False,
        ))
        console.print()

    def _build_step_routing(self, task):
        b = TaskComplexity.classify_detailed(task)
        return f"{b.policy.value.upper()} (score: {b.final_score:.1f})"

    def _build_step_risk(self, task):
        r = self.risk_engine.score("task", task, task)
        return f"{r.final_score:.1f}/10 ({r.level.value})"

    def _build_step_decompose(self, task):
        b = TaskComplexity.classify_detailed(task)
        n = {"simple": 3, "medium": 6, "complex": 12}.get(b.policy.value, 5)
        return f"{n} tasks"

    def _build_step_execute(self, task):
        return "Completed"

    def _build_step_validate(self):
        return "Passed"

    def _build_step_heuristic(self):
        return "Clean"

    def _build_step_test(self):
        return "All passed"

    def _build_step_review(self):
        return "Approved"

    # ═══════════════════════════════════════════════════
    #  COMMANDS
    # ═══════════════════════════════════════════════════

    def _handle_command(self, cmd_input: str):
        """Handle slash commands"""
        parts = cmd_input.split(maxsplit=1)
        cmd = parts[0].lower()
        arg = parts[1] if len(parts) > 1 else ""

        commands = {
            "/mode": self._cmd_mode,
            "/plan": lambda a: self._switch_mode(Mode.PLAN),
            "/agent": lambda a: self._switch_mode(Mode.AGENT),
            "/build": lambda a: self._switch_mode(Mode.BUILD),
            "/providers": self._cmd_providers,
            "/mcp": self._cmd_mcp,
            "/cost": self._cmd_cost,
            "/status": self._cmd_status,
            "/skills": self._cmd_skills,
            "/agents": self._cmd_agents,
            "/context": self._cmd_context,
            "/compact": self._cmd_compact,
            "/sessions": self._cmd_sessions,
            "/help": self._cmd_help,
            "/clear": lambda a: console.clear(),
            "/exit": self._cmd_exit,
            "/quit": self._cmd_exit,
        }

        handler = commands.get(cmd)
        if handler:
            handler(arg)
        else:
            console.print(f"  [error]✗[/] Unknown command. Try [accent]/help[/]")

    def _switch_mode(self, mode: str):
        self.mode = mode
        self.session.mode = mode
        self.events.emit(Event(EventType.MODE_CHANGED, {"mode": mode}))

    def _cmd_mode(self, arg: str):
        """Switch mode"""
        if not arg:
            self._mode_selector()
            return
        mode = arg.strip().lower()
        if mode in (Mode.PLAN, Mode.AGENT, Mode.BUILD):
            self._switch_mode(mode)
        else:
            console.print("  [muted]Modes: plan, agent, build[/]")

    def _cmd_providers(self, arg: str):
        """Provider management"""
        if arg == "add" or arg == "connect":
            self._provider_connect_flow()
        elif arg.startswith("remove ") or arg.startswith("disconnect "):
            provider = arg.split()[-1]
            self.providers.disconnect(provider)
            console.print(f"  [success]✓[/] Disconnected {provider}")
        elif arg.startswith("default "):
            provider = arg.split()[-1]
            self.providers._default = provider
            console.print(f"  [success]✓[/] Default set to {provider}")
        else:
            console.print()
            console.print(self.providers.get_status_table())
            console.print()
            console.print("  [muted]Commands: /providers add, /providers remove <name>, /providers default <name>[/]")

    def _provider_connect_flow(self):
        """Interactive provider connection"""
        console.print()
        console.print(Panel(
            "\n".join(
                f"  [{i+1}] {info['icon']} {info['name']}"
                for i, (_, info) in enumerate(self.providers.PROVIDERS.items())
            ),
            title="[brand]  Connect Provider  [/]",
            border_style="brand",
            padding=(1, 2),
        ))

        choice = Prompt.ask("  Select provider", choices=[str(i+1) for i in range(len(self.providers.PROVIDERS))])
        provider = list(self.providers.PROVIDERS.keys())[int(choice) - 1]
        info = self.providers.PROVIDERS[provider]

        console.print(f"\n  [muted]Enter your {info['name']} API key:[/]")
        console.print(f"  [muted](Key format: {info['prefix']}...)[/]")
        key = Prompt.ask("  API key", password=True)

        if self.providers.connect(provider, key):
            console.print(f"\n  [success]✓ Connected to {info['name']}[/]")
            console.print(f"  [muted]Key: {self.providers._keys[provider]['masked']}[/]")
            console.print(f"  [warning]⚠ Key stored in session only. Set {info['env']} env var for persistence.[/]")
        else:
            console.print(f"  [error]✗ Failed to connect[/]")

    def _cmd_mcp(self, arg: str):
        """MCP server management"""
        if arg == "list" or arg == "":
            self._mcp_list()
        elif arg == "add":
            self._mcp_add()
        elif arg.startswith("remove "):
            name = arg.split()[-1]
            self.mcp.remove_server(name)
            console.print(f"  [success]✓[/] Removed MCP server: {name}")
        elif arg.startswith("enable "):
            name = arg.split()[-1]
            self.mcp.enable_server(name)
            console.print(f"  [success]✓[/] Enabled: {name}")
        elif arg.startswith("disable "):
            name = arg.split()[-1]
            self.mcp.disable_server(name)
            console.print(f"  [success]✓[/] Disabled: {name}")
        else:
            console.print("  [muted]Commands: /mcp list, /mcp add, /mcp remove <name>, /mcp enable <name>[/]")

    def _mcp_list(self):
        """List MCP servers"""
        table = Table(title="🌐 MCP Servers", show_header=True,
                       header_style="#8B5CF6", border_style="#6D28D9")
        table.add_column("", width=3)
        table.add_column("Server", style="white")
        table.add_column("Status", width=15)
        table.add_column("Tools", style="muted")

        # Installed
        for server in self.mcp.list_servers():
            status = "[success]● Enabled[/]" if server["enabled"] else "[muted]○ Disabled[/]"
            table.add_row("📦", server["name"], status, ", ".join(server["tools"][:3]))

        # Available
        for avail in self.mcp.list_available():
            if not avail["installed"]:
                table.add_row("➕", avail["name"], "[muted]Available[/]", ", ".join(avail["tools"][:3]))

        console.print()
        console.print(table)
        console.print()

    def _mcp_add(self):
        """Add an MCP server"""
        available = [s for s in self.mcp.list_available() if not s["installed"]]
        if not available:
            console.print("  [muted]All known MCP servers are already installed.[/]")
            return

        console.print()
        for i, s in enumerate(available, 1):
            console.print(f"  [{i}] {s['name']} — {s['description']}")

        choice = Prompt.ask("\n  Select", choices=[str(i) for i in range(1, len(available)+1)])
        server_info = available[int(choice)-1]
        self.mcp.add_server(server_info["name"])
        console.print(f"\n  [success]✓[/] Added MCP server: {server_info['name']}")

    def _cmd_cost(self, arg: str):
        """Show cost report"""
        provider = self.providers.get_active_provider()
        provider_name = self.providers.PROVIDERS.get(provider, {}).get("name", "None")

        console.print(Panel(
            f"  [brand.bright]Session:[/]    ${self.session.cost_usd:.4f}\n"
            f"  [brand.bright]LLM Calls:[/]  {self.session.llm_calls}\n"
            f"  [brand.bright]Tool Calls:[/] {self.session.tool_calls}\n"
            f"  [brand.bright]Tokens:[/]     {self.session.total_tokens:,}\n"
            f"  [brand.bright]BYOK:[/]       {'YES' if self.providers.is_byok() else 'NO'}\n"
            f"  [brand.bright]Provider:[/]   {provider_name}",
            title="[brand]  💰 Cost Report  [/]",
            border_style="brand",
            padding=(1, 2),
            expand=False,
        ))
        console.print()

    def _cmd_status(self, arg: str):
        """Show system status"""
        color = MODE_COLORS.get(self.mode, "muted")
        icon = MODE_ICONS.get(self.mode, "")

        console.print(Panel(
            f"  [brand.bright]Version:[/]    v{VERSION} ({CODENAME})\n"
            f"  [brand.bright]Mode:[/]       [{color}]{icon} {self.mode.upper()}[/{color}]\n"
            f"  [brand.bright]Agents:[/]     {TOTAL_AGENTS}\n"
            f"  [brand.bright]Skills:[/]     {len(self.skills)}\n"
            f"  [brand.bright]MCP Tools:[/]  {len(self.mcp.get_tools())}\n"
            f"  [brand.bright]Provider:[/]   {self.providers.get_active_provider() or 'None'}\n"
            f"  [brand.bright]BYOK:[/]       {'ON' if self.providers.is_byok() else 'OFF'}\n"
            f"  [brand.bright]Session:[/]    {self.session.id}",
            title="[brand]  📊 Status  [/]",
            border_style="brand",
            padding=(1, 2),
            expand=False,
        ))
        console.print()

    def _cmd_skills(self, arg: str):
        """Show loaded skills"""
        descs = self.skills.get_all_descriptions()
        if descs:
            console.print(Panel(
                "\n".join(f"  🎓 {d}" for d in descs),
                title="[brand]  🎓 Skills  [/]",
                border_style="brand",
                padding=(1, 2),
            ))
        else:
            console.print("  [muted]No skills loaded.[/]")
        console.print()

    def _cmd_agents(self, arg: str):
        """Show available agents"""
        from main import SoftwareDevAgency
        try:
            agency = SoftwareDevAgency(api_key="", verbose=False)
            table = Table(title="🤖 Agents", show_header=True,
                           header_style="#8B5CF6", border_style="#6D28D9")
            table.add_column("", width=3)
            table.add_column("Agent")
            table.add_column("Team", style="muted")

            agents_info = [
                ("👴", "Grandfather", "Elders"),
                ("👵", "Grandmother", "Elders"),
                ("👨‍💼", "Dad (Architect)", "Parents"),
                ("👩‍💼", "Mommy (PM)", "Parents"),
                ("👧", "Frontend Girl", "👧 Girls"),
                ("👧", "Tester Girl", "👧 Girls"),
                ("👧", "Designer Girl", "👧 Girls"),
                ("👧📱", "Mobile Girl", "👧 Girls"),
                ("👦", "Backend Boy", "👦 Boys"),
                ("👦", "Database Boy", "👦 Boys"),
                ("👦", "DevOps Boy", "👦 Boys"),
                ("👦🔐", "Security Boy", "👦 Boys"),
            ]
            for icon, name, team in agents_info:
                table.add_row(icon, name, team)

            console.print()
            console.print(table)
        except Exception:
            console.print("  [muted]Could not load agents.[/]")
        console.print()

    def _cmd_context(self, arg: str):
        """Show context stats"""
        stats = self.session.get_stats()
        console.print(Panel(
            f"  [brand.bright]Messages:[/]  {stats['messages']}\n"
            f"  [brand.bright]Tokens:[/]    {stats['tokens']:,}\n"
            f"  [brand.bright]Files:[/]     {stats['files_modified']}",
            title="[brand]  🧠 Context  [/]",
            border_style="brand",
            padding=(1, 2),
            expand=False,
        ))
        console.print()

    def _cmd_compact(self, arg: str):
        """Compact context"""
        before = len(self.session.messages)
        # Keep last 10 messages
        self.session.messages = self.session.messages[-10:]
        after = len(self.session.messages)
        console.print(f"  [success]✓[/] Compacted: {before} → {after} messages")

    def _cmd_sessions(self, arg: str):
        """List saved sessions"""
        sessions = Session.list_sessions()
        if sessions:
            for s in sessions:
                console.print(f"  💾 {s['id']} — {s['agent']} ({s['mode']}) — {s['messages']} msgs — ${s['cost']:.4f}")
        else:
            console.print("  [muted]No saved sessions.[/]")
        console.print()

    def _cmd_help(self, arg: str):
        """Show help"""
        console.print(Panel(
            "[brand]MODES[/]\n"
            "  [plan]/plan[/]               Switch to PLAN mode\n"
            "  [agent]/agent[/]              Switch to AGENT mode\n"
            "  [build]/build[/]              Switch to BUILD mode\n"
            "  [accent]/mode <plan|agent|build>[/]\n\n"
            "[brand]PROVIDERS[/]\n"
            "  [accent]/providers[/]           Show connected providers\n"
            "  [accent]/providers add[/]       Connect a new provider\n"
            "  [accent]/providers remove <n>[/] Disconnect provider\n"
            "  [accent]/providers default <n>[/] Set default provider\n\n"
            "[brand]MCP[/]\n"
            "  [accent]/mcp[/]                 List MCP servers\n"
            "  [accent]/mcp add[/]             Add MCP server\n"
            "  [accent]/mcp remove <name>[/]   Remove MCP server\n"
            "  [accent]/mcp enable <name>[/]   Enable MCP server\n"
            "  [accent]/mcp disable <name>[/]  Disable MCP server\n\n"
            "[brand]SESSION[/]\n"
            "  [accent]/cost[/]                Cost report\n"
            "  [accent]/status[/]              System status\n"
            "  [accent]/context[/]             Context stats\n"
            "  [accent]/compact[/]             Compact context\n"
            "  [accent]/sessions[/]            List saved sessions\n"
            "  [accent]/skills[/]              Loaded skills\n"
            "  [accent]/agents[/]              Agent directory\n\n"
            "[brand]OTHER[/]\n"
            "  [accent]/clear[/]               Clear screen\n"
            "  [accent]/exit[/]                Exit aerrik",
            title="[brand]  📖 Help  [/]",
            border_style="brand",
            padding=(1, 2),
        ))

    def _cmd_exit(self, arg: str):
        """Exit"""
        # Save session
        try:
            path = self.session.save_checkpoint()
            console.print(f"  [muted]💾 Session saved: {path}[/]")
        except Exception:
            pass

        console.print()
        console.print(Rule(style="brand.dim"))
        cost = f"${self.session.cost_usd:.4f}" if self.session.cost_usd > 0 else "$0.00"
        console.print(Align.center(Text.from_markup(
            f"\n  🐕 [brand]aerrik[/][accent].dev[/] [muted]session ended[/]\n"
            f"  [muted]💬 {len(self.session.messages)} messages · 💰 {cost}[/]\n\n"
            f"  [accent]woof! see you soon! 🐾[/]\n"
        )))
        console.print(Rule(style="brand.dim"))
        console.print()
        self.running = False
        sys.exit(0)


# ═══════════════════════════════════════════════════════
#  ENTRY POINT
# ═══════════════════════════════════════════════════════

def main():
    import argparse
    parser = argparse.ArgumentParser(
        prog="aerrik",
        description="aerrik.dev — AI Engineering Runtime CLI",
    )
    parser.add_argument("mode", nargs="?", choices=["plan", "agent", "build"],
                        help="Start in specific mode")
    parser.add_argument("--key", "-k", help="API key")
    parser.add_argument("--provider", "-p", help="Provider name")
    parser.add_argument("--resume", help="Resume session ID")
    parser.add_argument("--version", action="version", version=f"aerrik.dev v{VERSION}")
    args = parser.parse_args()

    # Handle API key
    if args.key:
        provider = args.provider or "openai"
        from llm_engine import LLMEngine
        detected = LLMEngine.detect_provider(args.key)
        provider = detected if detected else provider
        info = ProviderManager.PROVIDERS.get(provider, {})
        if info:
            os.environ[info["env"]] = args.key

    # Start CLI
    cli = AerrikCLI()

    if args.resume:
        try:
            cli.session = Session.load(f".aerrik/sessions/{args.resume}.json")
            console.print(f"  [success]♻️ Resumed session: {args.resume}[/]")
        except Exception:
            console.print(f"  [error]Could not resume session: {args.resume}[/]")

    cli.start(initial_mode=args.mode)


if __name__ == "__main__":
    main()
