# AERRIK.md — Project Rules

> These rules are ALWAYS loaded into agent context.
> Equivalent to Claude Code's CLAUDE.md.

## Tech Stack
- Python 3.11+ for backend
- TypeScript 5+ for frontend
- FastAPI for APIs
- Next.js 15+ for frontend
- PostgreSQL for database
- Redis for caching

## Code Standards
- Use TypeScript strict mode (noImplicitAny: true)
- Never use `any` type in TypeScript
- Never use `eval()` or `exec()` in Python
- Always use type hints in Python
- Always validate inputs with Pydantic/Zod
- Always handle errors (no bare except/try-catch)

## Security
- Never hardcode secrets or API keys
- Always use environment variables for configuration
- Always encrypt sensitive data at rest
- Always use HTTPS in production
- Never log sensitive data

## Testing
- Run tests before committing
- Minimum 80% test coverage for critical paths
- Write integration tests for API endpoints

## Git
- Use conventional commits (feat:, fix:, docs:, etc.)
- Never force push to main
- Always create a branch for changes

## Architecture
- Follow Clean Architecture principles
- Keep business logic in services, not in routes
- Use dependency injection
- Prefer composition over inheritance

## API Design
- REST conventions
- Proper HTTP status codes
- Cursor-based pagination for lists
- Versioned APIs (/api/v1/)
