"""
Frontend Developer Agent - Girl Child
Builds beautiful, responsive UI
"""
from typing import Dict, List
from agents.base_agent import BaseAgent, Task, TaskStatus
from config import AgentRole, AGENT_CONFIGS


class FrontendAgent(BaseAgent):
    """
    👧 GIRL CHILD - Frontend Developer

    Creates beautiful UI components, pages, and frontend logic.
    Expert in React, Next.js, TypeScript, TailwindCSS
    """

    def __init__(self, api_key: str = "", verbose: bool = True):
        super().__init__(
            config=AGENT_CONFIGS[AgentRole.FRONTEND_DEV],
            role=AgentRole.FRONTEND_DEV,
            api_key=api_key,
            verbose=verbose
        )
        self.components_created: List[str] = []
        self.pages_created: List[str] = []

    def execute_task(self, task: Task) -> str:
        """Execute a frontend development task"""
        self.current_task = task
        task.status = TaskStatus.IN_PROGRESS

        if self.verbose:
            print(f"\n👧 {self.name} working on: {task.title}")

        task_lower = task.description.lower()

        if any(w in task_lower for w in ["component", "button", "card", "modal", "form"]):
            result = self._create_component(task)
        elif any(w in task_lower for w in ["page", "route", "screen", "view"]):
            result = self._create_page(task)
        elif any(w in task_lower for w in ["layout", "header", "footer", "sidebar", "navbar"]):
            result = self._create_layout(task)
        elif any(w in task_lower for w in ["hook", "context", "state", "store"]):
            result = self._create_hook_or_state(task)
        elif any(w in task_lower for w in ["api", "fetch", "service", "client"]):
            result = self._create_api_service(task)
        elif any(w in task_lower for w in ["setup", "config", "init", "project"]):
            result = self._setup_frontend_project(task)
        else:
            result = self._generic_frontend_task(task)

        task.status = TaskStatus.COMPLETED
        task.result = result
        self.current_task = None
        return result

    def _create_component(self, task: Task) -> str:
        """Create a React/Next.js component"""
        prompt = f"""
Create a React/Next.js component based on this requirement:

{task.description}

Requirements:
1. Use TypeScript (.tsx)
2. Use TailwindCSS for styling
3. Make it fully responsive
4. Include proper TypeScript interfaces/types
5. Include loading state if needed
6. Include error handling if needed
7. Add JSDoc comments
8. Make it reusable with props

Provide the COMPLETE code with:
- File path as first line comment (// filepath: src/components/ComponentName.tsx)
- All imports
- Types/Interfaces
- Component implementation
- Default export
"""
        result = self.think(prompt)
        self.components_created.append(task.title)
        return result

    def _create_page(self, task: Task) -> str:
        """Create a page/route"""
        prompt = f"""
Create a Next.js page based on this requirement:

{task.description}

Requirements:
1. Use TypeScript (.tsx)
2. Use TailwindCSS for styling
3. Use App Router convention (app/ directory)
4. Include metadata/SEO
5. Include loading.tsx if needed
6. Include error.tsx if needed
7. Handle data fetching (server component or client)
8. Fully responsive design

Provide COMPLETE code for:
- page.tsx (main page)
- loading.tsx (loading state)
- Any sub-components needed
"""
        result = self.think(prompt)
        self.pages_created.append(task.title)
        return result

    def _create_layout(self, task: Task) -> str:
        """Create layout components"""
        prompt = f"""
Create a layout component based on this requirement:

{task.description}

Requirements:
1. TypeScript + TailwindCSS
2. Responsive (mobile-first)
3. Accessible (ARIA labels, semantic HTML)
4. Dark mode support (optional)
5. Smooth transitions/animations

Provide complete code with file path.
"""
        return self.think(prompt)

    def _create_hook_or_state(self, task: Task) -> str:
        """Create custom hooks or state management"""
        prompt = f"""
Create React custom hook or state management based on this requirement:

{task.description}

Requirements:
1. TypeScript
2. Proper error handling
3. Loading states
4. Type-safe
5. Well documented
6. Include usage example

Provide complete code with file path.
"""
        return self.think(prompt)

    def _create_api_service(self, task: Task) -> str:
        """Create API service/client for frontend"""
        prompt = f"""
Create an API service/client for the frontend:

{task.description}

Requirements:
1. TypeScript
2. Use fetch or axios
3. Proper error handling
4. Type-safe request/response
5. Base URL configuration
6. Auth token handling
7. Request/Response interceptors

Provide complete code with file path.
"""
        return self.think(prompt)

    def _setup_frontend_project(self, task: Task) -> str:
        """Setup frontend project structure"""
        prompt = f"""
Setup a Next.js 14+ project with:

{task.description}

Provide:
1. package.json with all dependencies
2. tsconfig.json
3. tailwind.config.ts
4. next.config.js
5. Folder structure
6. Global styles (globals.css)
7. Root layout.tsx
8. Theme configuration

Provide ALL files with their paths.
"""
        return self.think(prompt)

    def _generic_frontend_task(self, task: Task) -> str:
        """Handle generic frontend tasks"""
        prompt = f"""
Complete this frontend development task:

{task.description}

Use React/Next.js with TypeScript and TailwindCSS.
Provide complete, production-ready code with file paths.
"""
        return self.think(prompt)

    def create_full_frontend(self, project_spec: str) -> Dict[str, str]:
        """Create a complete frontend from specification"""
        if self.verbose:
            print(f"\n🎨 {self.name} creating full frontend...")

        files = {}

        setup = self.think(f"""
Create the COMPLETE Next.js 14 project setup for:
{project_spec}

Include ALL config files with file paths.
""")
        files["setup"] = setup

        components = self.think(f"""
Based on this project: {project_spec}

Create ALL necessary React components.
Each component should be in its own file.
Include file paths.
""")
        files["components"] = components

        pages = self.think(f"""
Based on this project: {project_spec}

Create ALL necessary pages/routes using Next.js App Router.
Include file paths.
""")
        files["pages"] = pages

        return files
