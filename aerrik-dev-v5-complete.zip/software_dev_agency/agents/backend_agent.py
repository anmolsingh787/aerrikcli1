"""
Backend Developer Agent - Boy Child
Builds robust APIs and server-side logic
"""
from typing import Dict, List
from agents.base_agent import BaseAgent, Task, TaskStatus
from config import AgentRole, AGENT_CONFIGS


class BackendAgent(BaseAgent):
    """
    👦 BOY CHILD - Backend Developer

    Creates APIs, handles business logic, authentication, etc.
    Expert in Python, FastAPI, Node.js
    """

    def __init__(self, api_key: str = "", verbose: bool = True):
        super().__init__(
            config=AGENT_CONFIGS[AgentRole.BACKEND_DEV],
            role=AgentRole.BACKEND_DEV,
            api_key=api_key,
            verbose=verbose
        )
        self.endpoints_created: List[str] = []
        self.models_created: List[str] = []

    def execute_task(self, task: Task) -> str:
        """Execute a backend development task"""
        self.current_task = task
        task.status = TaskStatus.IN_PROGRESS

        if self.verbose:
            print(f"\n👦 {self.name} working on: {task.title}")

        task_lower = task.description.lower()

        if any(w in task_lower for w in ["api", "endpoint", "route", "router"]):
            result = self._create_api_endpoint(task)
        elif any(w in task_lower for w in ["model", "schema", "pydantic"]):
            result = self._create_model(task)
        elif any(w in task_lower for w in ["auth", "login", "register", "jwt", "token"]):
            result = self._create_auth_system(task)
        elif any(w in task_lower for w in ["middleware", "cors", "rate limit"]):
            result = self._create_middleware(task)
        elif any(w in task_lower for w in ["setup", "config", "init", "project", "main"]):
            result = self._setup_backend_project(task)
        elif any(w in task_lower for w in ["websocket", "socket", "realtime"]):
            result = self._create_websocket(task)
        elif any(w in task_lower for w in ["celery", "task", "queue", "background"]):
            result = self._create_background_task(task)
        else:
            result = self._generic_backend_task(task)

        task.status = TaskStatus.COMPLETED
        task.result = result
        self.current_task = None
        return result

    def _create_api_endpoint(self, task: Task) -> str:
        """Create API endpoints"""
        prompt = f"""
Create FastAPI endpoint(s) based on this requirement:

{task.description}

Requirements:
1. Use FastAPI with proper type hints
2. Pydantic models for request/response
3. Proper HTTP methods (GET, POST, PUT, DELETE)
4. Input validation
5. Error handling with HTTPException
6. Proper status codes
7. Docstrings for auto-documentation
8. Dependency injection where needed
9. Async handlers

Provide COMPLETE code with:
- File path as first line comment (# filepath: app/routers/resource.py)
- All imports
- Pydantic models (schemas)
- Router definition
- All endpoint handlers
- Helper functions

Example structure:
# filepath: app/routers/users.py
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.schemas.user import UserCreate, UserResponse
from app.database import get_db

router = APIRouter(prefix="/users", tags=["users"])

@router.get("/", response_model=list[UserResponse])
async def get_users(db: Session = Depends(get_db)):
    ...
"""
        result = self.think(prompt)
        self.endpoints_created.append(task.title)
        return result

    def _create_model(self, task: Task) -> str:
        """Create data models/schemas"""
        prompt = f"""
Create data models based on this requirement:

{task.description}

Provide:
1. SQLAlchemy models (for database) - filepath: app/models/
2. Pydantic schemas (for API) - filepath: app/schemas/
3. Proper relationships
4. Validations
5. Type hints

Include both the ORM model and Pydantic schema.
"""
        result = self.think(prompt)
        self.models_created.append(task.title)
        return result

    def _create_auth_system(self, task: Task) -> str:
        """Create authentication system"""
        prompt = f"""
Create a complete authentication system:

{task.description}

Include:
1. JWT token creation and validation
2. Password hashing (bcrypt)
3. Login endpoint
4. Register endpoint
5. Token refresh endpoint
6. Protected route dependency
7. User model and schema
8. Auth middleware/dependency

Files needed:
- app/auth/jwt_handler.py (JWT logic)
- app/auth/password.py (password hashing)
- app/routers/auth.py (auth endpoints)
- app/dependencies/auth.py (auth dependency)
- app/schemas/auth.py (auth schemas)

Provide ALL files with complete code.
"""
        return self.think(prompt)

    def _create_middleware(self, task: Task) -> str:
        """Create middleware"""
        prompt = f"""
Create FastAPI middleware:

{task.description}

Include:
1. CORS middleware configuration
2. Rate limiting (if needed)
3. Request logging middleware
4. Error handling middleware
5. Response time tracking

Provide complete code with file paths.
"""
        return self.think(prompt)

    def _setup_backend_project(self, task: Task) -> str:
        """Setup backend project structure"""
        prompt = f"""
Setup a complete FastAPI project:

{task.description}

Provide ALL files:
1. main.py (FastAPI app initialization)
2. requirements.txt
3. app/__init__.py
4. app/config.py (settings using pydantic-settings)
5. app/database.py (database connection)
6. app/dependencies/__init__.py
7. Folder structure explanation

Project structure:
backend/
├── main.py
├── requirements.txt
├── .env.example
├── app/
│   ├── __init__.py
│   ├── config.py
│   ├── database.py
│   ├── models/
│   ├── schemas/
│   ├── routers/
│   ├── services/
│   ├── dependencies/
│   ├── middleware/
│   └── utils/

Provide COMPLETE code for each file.
"""
        return self.think(prompt)

    def _create_websocket(self, task: Task) -> str:
        """Create WebSocket endpoints"""
        prompt = f"""
Create WebSocket implementation:

{task.description}

Include connection management, broadcasting, and error handling.
Provide complete code with file paths.
"""
        return self.think(prompt)

    def _create_background_task(self, task: Task) -> str:
        """Create background tasks"""
        prompt = f"""
Create background task system:

{task.description}

Use Celery with Redis or FastAPI BackgroundTasks.
Provide complete code with file paths.
"""
        return self.think(prompt)

    def _generic_backend_task(self, task: Task) -> str:
        """Handle generic backend tasks"""
        prompt = f"""
Complete this backend development task:

{task.description}

Use Python/FastAPI. Provide complete, production-ready code with file paths.
"""
        return self.think(prompt)

    def create_full_backend(self, project_spec: str) -> Dict[str, str]:
        """Create a complete backend from specification"""
        if self.verbose:
            print(f"\n⚙️ {self.name} creating full backend...")

        files = {}

        steps = [
            ("setup", "Create the COMPLETE FastAPI project setup"),
            ("models", "Create ALL database models and Pydantic schemas"),
            ("auth", "Create complete authentication system"),
            ("endpoints", "Create ALL API endpoints/routers"),
            ("services", "Create service layer with business logic"),
            ("middleware", "Create all necessary middleware"),
        ]

        for step_name, step_desc in steps:
            result = self.think(f"""
{step_desc} for this project:
{project_spec}

Provide complete code with file paths.
""")
            files[step_name] = result

        return files
