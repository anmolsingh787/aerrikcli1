"""
Database Expert Agent - Boy Child 2
Designs schemas, writes migrations, optimizes queries
"""
from typing import List
from agents.base_agent import BaseAgent, Task, TaskStatus
from config import AgentRole, AGENT_CONFIGS


class DatabaseAgent(BaseAgent):
    """
    👦 BOY CHILD 2 - Database Expert

    Handles everything database related.
    Expert in PostgreSQL, MongoDB, Redis, SQLAlchemy
    """

    def __init__(self, api_key: str = "", verbose: bool = True):
        super().__init__(
            config=AGENT_CONFIGS[AgentRole.DATABASE_EXPERT],
            role=AgentRole.DATABASE_EXPERT,
            api_key=api_key,
            verbose=verbose
        )
        self.schemas_created: List[str] = []

    def execute_task(self, task: Task) -> str:
        """Execute a database task"""
        self.current_task = task
        task.status = TaskStatus.IN_PROGRESS

        if self.verbose:
            print(f"\n👦 {self.name} working on: {task.title}")

        task_lower = task.description.lower()

        if any(w in task_lower for w in ["schema", "design", "model", "table"]):
            result = self._design_schema(task)
        elif any(w in task_lower for w in ["migration", "alembic", "migrate"]):
            result = self._create_migration(task)
        elif any(w in task_lower for w in ["seed", "sample", "dummy", "fixture"]):
            result = self._create_seed_data(task)
        elif any(w in task_lower for w in ["query", "optimize", "index"]):
            result = self._optimize_queries(task)
        elif any(w in task_lower for w in ["setup", "connection", "config"]):
            result = self._setup_database(task)
        else:
            result = self._generic_db_task(task)

        task.status = TaskStatus.COMPLETED
        task.result = result
        self.current_task = None
        return result

    def _design_schema(self, task: Task) -> str:
        """Design database schema"""
        prompt = f"""
Design a complete database schema:

{task.description}

Provide:
1. ER Diagram (text-based)
2. SQLAlchemy models with ALL fields, types, and relationships
3. Indexes
4. Constraints (unique, check, foreign key)
5. Many-to-many relationship tables if needed

Use this format:
# filepath: app/models/user.py
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Boolean
from sqlalchemy.orm import relationship
from app.database import Base
import datetime

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    ...

Also provide the corresponding Pydantic schemas.
"""
        result = self.think(prompt)
        self.schemas_created.append(task.title)
        return result

    def _create_migration(self, task: Task) -> str:
        """Create database migrations"""
        prompt = f"""
Create Alembic migration files:

{task.description}

Provide:
1. alembic.ini configuration
2. alembic/env.py setup
3. Migration script
4. Rollback instructions

Include complete file contents with paths.
"""
        return self.think(prompt)

    def _create_seed_data(self, task: Task) -> str:
        """Create seed/sample data"""
        prompt = f"""
Create database seed data:

{task.description}

Provide:
1. Seed script (Python)
2. Sample data for all tables
3. Proper relationships in seed data
4. Script to run seeds

File: app/seeds/seed_data.py
"""
        return self.think(prompt)

    def _optimize_queries(self, task: Task) -> str:
        """Optimize database queries"""
        prompt = f"""
Optimize database queries and provide indexing strategy:

{task.description}

Provide:
1. Optimized query examples
2. Index recommendations
3. Query explanation
4. Performance tips
"""
        return self.think(prompt)

    def _setup_database(self, task: Task) -> str:
        """Setup database connection and configuration"""
        prompt = f"""
Setup complete database configuration:

{task.description}

Provide:
1. database.py (connection setup with SQLAlchemy)
2. .env configuration for database
3. Connection pooling settings
4. Session management
5. Base model class

Files:
- app/database.py
- app/models/base.py
- .env.example (database section)
"""
        return self.think(prompt)

    def _generic_db_task(self, task: Task) -> str:
        """Handle generic database tasks"""
        return self.think(f"""
Complete this database task:
{task.description}
Provide complete code with file paths.
""")
