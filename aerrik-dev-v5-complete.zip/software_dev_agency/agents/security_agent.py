"""
👦 Boy 4 — Security & Performance Engineer

Specializes in penetration testing, security hardening, performance optimization.
Part of the Boys Team (Backend focused).
"""
from typing import Dict, List
from agents.base_agent import BaseAgent, Task, TaskStatus
from config import AgentRole, AgentConfig


SECURITY_CONFIG = AgentConfig(
    name="Security Boy 👦🔐",
    role=AgentRole.BACKEND_DEV,
    model="gpt-4",
    temperature=0.4,
    max_tokens=5000,
    skills=[
        "penetration_testing", "security_hardening", "performance_optimization",
        "load_testing", "vulnerability_scanning", "encryption",
        "rate_limiting", "waf_rules",
    ],
    can_delegate_to=[],
    priority=3,
)

SECURITY_PROMPT = """
You are **Security Boy 👦🔐 (Boy 4)** — the security and performance specialist.

Part of the Boys Team (Backend focused).

🎯 YOUR SPECIALTIES:

1. **SECURITY HARDENING**
   - OWASP Top 10 prevention
   - Input sanitization (HTML, SQL, commands)
   - Output encoding (prevent XSS)
   - CSRF protection (tokens, SameSite cookies)
   - Content Security Policy (CSP) headers
   - Security headers (HSTS, X-Frame, X-Content-Type)
   - Secrets management (vault, env vars, rotation)
   - Dependency vulnerability scanning

2. **AUTHENTICATION & AUTHORIZATION**
   - JWT implementation (short-lived access + refresh rotation)
   - OAuth2 / OIDC flows
   - RBAC / ABAC implementation
   - Multi-factor authentication
   - Session management (secure cookies, HttpOnly, Secure)
   - Password policies (bcrypt, argon2)
   - Rate limiting on auth endpoints

3. **ENCRYPTION & DATA PROTECTION**
   - TLS/SSL configuration (TLS 1.3, strong ciphers)
   - At-rest encryption (AES-256-GCM)
   - Field-level encryption for PII
   - Key management and rotation
   - Secure random generation

4. **PERFORMANCE OPTIMIZATION**
   - Database query optimization (EXPLAIN ANALYZE)
   - Caching strategies (Redis, CDN, browser cache)
   - Connection pooling
   - Load testing (k6, locust, wrk)
   - Profiling (cProfile, py-spy, Chrome DevTools)
   - CDN configuration
   - Compression (gzip, brotli)

5. **MONITORING & ALERTING**
   - Security event logging
   - Anomaly detection
   - Fail2ban / WAF rules
   - Health check endpoints
   - Uptime monitoring

6. **PENETRATION TESTING PATTERNS**
   - SQL injection testing
   - XSS vector testing
   - SSRF testing
   - Path traversal testing
   - Authentication bypass testing
   - Authorization escalation testing

📋 OUTPUT FORMAT:

For security implementations:
```
🔒 SECURITY IMPLEMENTATION
  Threat: [what attack this prevents]
  Implementation: [code with file path]
  Testing: [how to verify it works]
```

For performance optimizations:
```
⚡ OPTIMIZATION
  Before: [slow code/pattern]
  After: [optimized code/pattern]
  Impact: [measured/estimated improvement]
```

🚫 RULES:
- Security is NEVER optional
- Always use well-tested libraries (never roll your own crypto)
- Defense in depth (multiple layers)
- Log security events but never log sensitive data
- Performance without security is dangerous
"""


class SecurityAgent(BaseAgent):
    """👦🔐 BOY 4 — Security & Performance Engineer"""

    def __init__(self, api_key: str = "", verbose: bool = True):
        super().__init__(
            config=SECURITY_CONFIG,
            role=AgentRole.BACKEND_DEV,
            api_key=api_key,
            verbose=verbose,
        )
        self.name = "Security Boy 👦🔐"
        self.system_prompt = SECURITY_PROMPT
        self.audits_done: int = 0

    def execute_task(self, task: Task) -> str:
        self.current_task = task
        task.status = TaskStatus.IN_PROGRESS

        if self.verbose:
            print(f"\n👦🔐 {self.name} working on: {task.title}")

        task_lower = task.description.lower()

        if any(w in task_lower for w in ["security", "auth", "encrypt", "vulnerability"]):
            prompt = f"""
Implement security hardening for:

{task.description}

Include:
1. Input validation and sanitization
2. Output encoding
3. Security headers
4. Rate limiting
5. Secure error handling (no stack traces to users)
6. Logging security events
7. Code with file paths
"""
        elif any(w in task_lower for w in ["performance", "optimize", "speed", "cache"]):
            prompt = f"""
Optimize performance for:

{task.description}

Include:
1. Profiling results / bottlenecks
2. Caching strategy
3. Database optimization
4. Connection pooling
5. Load testing setup
6. Before/after comparison
"""
        elif any(w in task_lower for w in ["penetration", "pentest", "audit"]):
            prompt = f"""
Perform security audit for:

{task.description}

Check:
1. OWASP Top 10 vulnerabilities
2. Authentication/authorization flaws
3. Data exposure risks
4. Injection vectors
5. Configuration issues
6. Dependency vulnerabilities

Provide findings with severity and remediation.
"""
        else:
            prompt = f"""
Review security and performance for:

{task.description}

Check both security hardening and performance optimization.
"""

        result = self.think(prompt)
        self.audits_done += 1
        task.status = TaskStatus.COMPLETED
        task.result = result
        self.current_task = None
        return result
