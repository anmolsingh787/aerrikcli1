"""
Base Agent - The Father/Dad class
All other agents inherit from this.
This is the ARCHITECT agent + base for everyone.
"""
import json
import time
import uuid
from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime

# LLM imports (install: pip install openai anthropic)
try:
    from openai import OpenAI
except ImportError:
    OpenAI = None

try:
    from anthropic import Anthropic
except ImportError:
    Anthropic = None

from config import AgentConfig, AgentRole, AGENT_CONFIGS
from prompts.system_prompts import ROLE_PROMPTS

# Skills loader (lazy import to avoid circular dependency)
_skills_loader = None

def get_skills_loader():
    """Lazy load skillsLoader to avoid circular imports"""
    global _skills_loader
    if _skills_loader is None:
        from skills.skills_loader import SkillsLoader
        _skills_loader = SkillsLoader()
    return _skills_loader


# ============ DATA MODELS ============

class TaskStatus(Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    REVIEW = "review"
    COMPLETED = "completed"
    FAILED = "failed"
    BLOCKED = "blocked"


class MessageType(Enum):
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    TASK = "task"
    RESULT = "result"
    ERROR = "error"
    DELEGATION = "delegation"


@dataclass
class Message:
    """Message between agents"""
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    sender: str = ""
    receiver: str = ""
    msg_type: MessageType = MessageType.USER
    content: str = ""
    metadata: Dict = field(default_factory=dict)
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class Task:
    """Task assigned to an agent"""
    id: str = field(default_factory=lambda: f"TASK-{str(uuid.uuid4())[:6]}")
    title: str = ""
    description: str = ""
    assigned_to: Optional[AgentRole] = None
    assigned_by: Optional[AgentRole] = None
    status: TaskStatus = TaskStatus.PENDING
    priority: int = 1
    dependencies: List[str] = field(default_factory=list)
    result: str = ""
    files_created: List[str] = field(default_factory=list)
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    completed_at: Optional[str] = None
    retries: int = 0
    max_retries: int = 3


@dataclass
class AgentMemory:
    """Memory for an agent"""
    conversation_history: List[Dict] = field(default_factory=list)
    tasks_completed: List[Task] = field(default_factory=list)
    tasks_pending: List[Task] = field(default_factory=list)
    context: Dict[str, Any] = field(default_factory=dict)
    files_generated: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)


class BaseAgent(ABC):
    """
    🏠 DAD / FATHER - Base Agent Class

    This is the patriarch of the agent family.
    All agents inherit from this class.

    Family Hierarchy:
    - Dad (BaseAgent/Architect) - Makes all major decisions
    - Mommy (ProjectManager) - Coordinates and manages
    - Children (Frontend, Backend, DB, DevOps, Tester, Designer) - Execute tasks
    """

    def __init__(
        self,
        config: Optional[AgentConfig] = None,
        role: AgentRole = AgentRole.ARCHITECT,
        api_key: str = "",
        verbose: bool = True
    ):
        self.config = config or AGENT_CONFIGS.get(role)
        self.role = role
        self.name = self.config.name
        self.api_key = api_key
        self.verbose = verbose

        # Memory
        self.memory = AgentMemory()

        # System prompt - inject skills
        base_prompt = ROLE_PROMPTS.get(role.value, "")
        try:
            loader = get_skills_loader()
            self.system_prompt = loader.inject_skills_into_prompt(
                base_prompt, role.value
            )
        except Exception:
            self.system_prompt = base_prompt

        # Communication
        self.inbox: List[Message] = []
        self.outbox: List[Message] = []

        # Children (agents this agent can delegate to)
        self.children: Dict[AgentRole, 'BaseAgent'] = {}

        # Parent
        self.parent: Optional['BaseAgent'] = None

        # Tools
        self.tools: Dict[str, Callable] = {}

        # Status
        self.is_busy = False
        self.current_task: Optional[Task] = None

        # Initialize LLM client
        self._init_llm_client()

        if self.verbose:
            print(f"✅ Agent initialized: {self.name} ({self.role.value})")

    def _init_llm_client(self):
        """Initialize LLM client"""
        self.llm_client = None

        if self.api_key and OpenAI:
            try:
                self.llm_client = OpenAI(api_key=self.api_key)
                if self.verbose:
                    print(f"   🔗 LLM client connected for {self.name}")
            except Exception as e:
                print(f"   ⚠️ LLM client failed for {self.name}: {e}")

    # ============ CORE METHODS ============

    def think(self, prompt: str, context: str = "") -> str:
        """
        🧠 Core thinking method - calls LLM
        Every agent uses this to "think"
        """
        messages = [
            {"role": "system", "content": self.system_prompt},
        ]

        # Add conversation history (last 10 messages for context)
        for msg in self.memory.conversation_history[-10:]:
            messages.append(msg)

        # Add context if provided
        if context:
            messages.append({
                "role": "system",
                "content": f"CURRENT CONTEXT:\n{context}"
            })

        # Add the actual prompt
        messages.append({"role": "user", "content": prompt})

        # Call LLM
        response = self._call_llm(messages)

        # Store in memory
        self.memory.conversation_history.append(
            {"role": "user", "content": prompt}
        )
        self.memory.conversation_history.append(
            {"role": "assistant", "content": response}
        )

        return response

    def _call_llm(self, messages: List[Dict]) -> str:
        """
        Call the LLM API
        Supports: OpenAI, Anthropic, or Mock
        """
        if self.llm_client and OpenAI and isinstance(self.llm_client, OpenAI):
            try:
                response = self.llm_client.chat.completions.create(
                    model=self.config.model,
                    messages=messages,
                    temperature=self.config.temperature,
                    max_tokens=self.config.max_tokens,
                )
                return response.choices[0].message.content
            except Exception as e:
                error_msg = f"LLM Error: {str(e)}"
                self.memory.errors.append(error_msg)
                return self._mock_response(messages)
        else:
            return self._mock_response(messages)

    def _mock_response(self, messages: List[Dict]) -> str:
        """Mock response when no API key is available"""
        last_msg = messages[-1]["content"] if messages else "no message"
        return f"[MOCK RESPONSE from {self.name}]\nReceived: {last_msg[:200]}...\n\n[Note: Set API key for real responses]"

    # ============ FAMILY METHODS ============

    def add_child(self, child: 'BaseAgent'):
        """Add a child agent"""
        child.parent = self
        self.children[child.role] = child
        if self.verbose:
            print(f"   👨‍👧 {self.name} -> Added child: {child.name}")

    def get_child(self, role: AgentRole) -> Optional['BaseAgent']:
        """Get a child agent by role"""
        return self.children.get(role)

    def delegate_task(self, task: Task, target_role: AgentRole) -> str:
        """
        Delegate a task to a child agent
        Dad -> Mommy -> Children
        """
        child = self.get_child(target_role)

        if not child:
            return f"❌ No agent found with role: {target_role.value}"

        if target_role not in self.config.can_delegate_to:
            return f"❌ {self.name} cannot delegate to {target_role.value}"

        if self.verbose:
            print(f"\n📋 {self.name} -> Delegating to {child.name}")
            print(f"   Task: {task.title}")

        # Send message
        msg = Message(
            sender=self.name,
            receiver=child.name,
            msg_type=MessageType.DELEGATION,
            content=task.description,
            metadata={"task_id": task.id, "task_title": task.title}
        )
        child.receive_message(msg)

        # Child executes
        task.assigned_to = target_role
        task.assigned_by = self.role
        task.status = TaskStatus.IN_PROGRESS

        result = child.execute_task(task)

        task.result = result
        task.status = TaskStatus.COMPLETED
        task.completed_at = datetime.now().isoformat()

        # Store completed task
        self.memory.tasks_completed.append(task)

        return result

    def delegate_to_all_children(self, tasks: List[Task]) -> Dict[str, str]:
        """Delegate multiple tasks to respective children"""
        results = {}
        for task in tasks:
            if task.assigned_to:
                result = self.delegate_task(task, task.assigned_to)
                results[task.id] = result
        return results

    # ============ COMMUNICATION ============

    def send_message(self, receiver: 'BaseAgent', content: str,
                     msg_type: MessageType = MessageType.USER):
        """Send a message to another agent"""
        msg = Message(
            sender=self.name,
            receiver=receiver.name,
            msg_type=msg_type,
            content=content
        )
        receiver.receive_message(msg)
        self.outbox.append(msg)
        return msg

    def receive_message(self, message: Message):
        """Receive a message"""
        self.inbox.append(message)
        if self.verbose:
            print(f"   📨 {self.name} received message from {message.sender}")

    def broadcast(self, content: str):
        """Send message to all children"""
        for child in self.children.values():
            self.send_message(child, content)

    # ============ TASK EXECUTION ============

    @abstractmethod
    def execute_task(self, task: Task) -> str:
        """
        Execute a task - MUST be implemented by each child
        This is the main work method
        """
        pass

    def process_request(self, user_request: str) -> str:
        """
        Process a user request
        This is the main entry point for the agent
        """
        self.is_busy = True
        if self.verbose:
            print(f"\n{'='*60}")
            print(f"🚀 {self.name} processing request...")
            print(f"{'='*60}")

        result = self.think(user_request)
        self.is_busy = False
        return result

    # ============ TOOL MANAGEMENT ============

    def register_tool(self, name: str, func: Callable, description: str = ""):
        """Register a tool for this agent"""
        self.tools[name] = func
        if self.verbose:
            print(f"   🔧 {self.name} registered tool: {name}")

    def use_tool(self, tool_name: str, **kwargs) -> Any:
        """Use a registered tool"""
        if tool_name not in self.tools:
            return f"❌ Tool not found: {tool_name}"

        try:
            return self.tools[tool_name](**kwargs)
        except Exception as e:
            error = f"Tool error ({tool_name}): {str(e)}"
            self.memory.errors.append(error)
            return error

    # ============ MEMORY METHODS ============

    def remember(self, key: str, value: Any):
        """Store something in memory"""
        self.memory.context[key] = value

    def recall(self, key: str) -> Any:
        """Recall something from memory"""
        return self.memory.context.get(key)

    def get_context_summary(self) -> str:
        """Get a summary of current context"""
        summary = f"""
AGENT: {self.name}
ROLE: {self.role.value}
TASKS COMPLETED: {len(self.memory.tasks_completed)}
TASKS PENDING: {len(self.memory.tasks_pending)}
FILES GENERATED: {len(self.memory.files_generated)}
ERRORS: {len(self.memory.errors)}
CONTEXT KEYS: {list(self.memory.context.keys())}
        """
        return summary.strip()

    # ============ UTILITY METHODS ============

    def get_status(self) -> Dict:
        """Get agent status"""
        return {
            "name": self.name,
            "role": self.role.value,
            "is_busy": self.is_busy,
            "current_task": self.current_task.title if self.current_task else None,
            "tasks_completed": len(self.memory.tasks_completed),
            "tasks_pending": len(self.memory.tasks_pending),
            "children": [c.name for c in self.children.values()],
            "parent": self.parent.name if self.parent else None,
            "errors": len(self.memory.errors)
        }

    def __repr__(self):
        return f"<{self.name} | Role: {self.role.value} | Children: {len(self.children)}>"

    def __str__(self):
        return self.name
