"""
👧 Girl 4 — Mobile Frontend Developer

Specializes in React Native, Flutter UI patterns, PWA, and responsive mobile.
Part of the Girls Team (Frontend focused).
"""
from typing import Dict, List
from agents.base_agent import BaseAgent, Task, TaskStatus
from config import AgentRole, AgentConfig


MOBILE_CONFIG = AgentConfig(
    name="Mobile Girl 👧📱",
    role=AgentRole.FRONTEND_DEV,
    model="gpt-4",
    temperature=0.7,
    max_tokens=4000,
    skills=[
        "react_native", "expo", "flutter_patterns", "pwa",
        "mobile_ui", "responsive", "native_modules", "offline_first",
    ],
    can_delegate_to=[],
    priority=3,
)

MOBILE_PROMPT = """
You are **Mobile Girl 👧📱 (Girl 4)** — the mobile frontend specialist.

Part of the Girls Team (Frontend focused).

🎯 YOUR SPECIALTIES:

1. **React Native / Expo**
   - Cross-platform components (View, Text, Image, ScrollView)
   - Navigation (React Navigation, Expo Router)
   - Native modules bridging
   - Platform-specific code (Platform.OS, Platform.select)
   - Safe area handling
   - Gesture handling (react-native-gesture-handler)

2. **PWA (Progressive Web Apps)**
   - Service workers for offline support
   - Web app manifest
   - Push notifications
   - App shell architecture
   - Background sync

3. **Mobile UI Patterns**
   - Bottom sheet / modal patterns
   - Pull to refresh
   - Infinite scroll / virtualized lists
   - Touch-friendly hit areas (minimum 44px)
   - Haptic feedback
   - Skeleton loading screens
   - Safe area insets

4. **Performance (Mobile)**
   - Image optimization (resize, lazy load)
   - FlatList over ScrollView for long lists
   - useMemo / useCallback for expensive renders
   - Bundle size optimization
   - Start-up time optimization

5. **Offline First**
   - AsyncStorage / MMKV for local data
   - WatermelonDB / SQLite for complex offline
   - Sync strategies (last-write-wins, CRDT)
   - Network state detection

📋 OUTPUT FORMAT:
- Complete code with file paths
- Platform-specific handling noted
- Accessibility (VoiceOver/TalkBack) considered
- Both iOS and Android tested patterns
"""


class MobileAgent(BaseAgent):
    """👧📱 GIRL 4 — Mobile Frontend Developer"""

    def __init__(self, api_key: str = "", verbose: bool = True):
        super().__init__(
            config=MOBILE_CONFIG,
            role=AgentRole.FRONTEND_DEV,
            api_key=api_key,
            verbose=verbose,
        )
        self.name = "Mobile Girl 👧📱"
        self.system_prompt = MOBILE_PROMPT
        self.components_created: List[str] = []

    def execute_task(self, task: Task) -> str:
        self.current_task = task
        task.status = TaskStatus.IN_PROGRESS

        if self.verbose:
            print(f"\n👧📱 {self.name} working on: {task.title}")

        task_lower = task.description.lower()

        if any(w in task_lower for w in ["react native", "expo", "mobile app"]):
            prompt = f"""
Create React Native / Expo code for:

{task.description}

Requirements:
1. Use Expo SDK 51+
2. TypeScript
3. React Navigation / Expo Router
4. Safe area handling
5. Platform-specific code where needed
6. Both iOS and Android compatible
7. Accessibility (VoiceOver/TalkBack)
"""
        elif any(w in task_lower for w in ["pwa", "service worker", "offline"]):
            prompt = f"""
Create PWA implementation for:

{task.description}

Include:
1. Service worker (workbox)
2. Web app manifest
3. Offline fallback
4. Push notification setup
5. Install prompt
"""
        else:
            prompt = f"""
Create mobile-optimized code for:

{task.description}

Requirements:
1. Mobile-first responsive design
2. Touch-friendly interactions
3. Performance optimized for mobile
4. PWA capabilities where applicable
"""

        result = self.think(prompt)
        self.components_created.append(task.title)
        task.status = TaskStatus.COMPLETED
        task.result = result
        self.current_task = None
        return result
