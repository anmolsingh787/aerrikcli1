"""
DevOps Engineer Agent - Boy Child 3
Handles Docker, CI/CD, deployment
"""
from agents.base_agent import BaseAgent, Task, TaskStatus
from config import AgentRole, AGENT_CONFIGS


class DevOpsAgent(BaseAgent):
    """
    👦 BOY CHILD 3 - DevOps Engineer

    Handles infrastructure, deployment, CI/CD
    Expert in Docker, GitHub Actions, Nginx, AWS
    """

    def __init__(self, api_key: str = "", verbose: bool = True):
        super().__init__(
            config=AGENT_CONFIGS[AgentRole.DEVOPS],
            role=AgentRole.DEVOPS,
            api_key=api_key,
            verbose=verbose
        )

    def execute_task(self, task: Task) -> str:
        """Execute a DevOps task"""
        self.current_task = task
        task.status = TaskStatus.IN_PROGRESS

        if self.verbose:
            print(f"\n👦 {self.name} working on: {task.title}")

        task_lower = task.description.lower()

        if any(w in task_lower for w in ["docker", "container", "compose"]):
            result = self._create_docker_config(task)
        elif any(w in task_lower for w in ["ci", "cd", "pipeline", "github action", "workflow"]):
            result = self._create_ci_cd(task)
        elif any(w in task_lower for w in ["nginx", "proxy", "reverse"]):
            result = self._create_nginx_config(task)
        elif any(w in task_lower for w in ["deploy", "production", "staging"]):
            result = self._create_deployment(task)
        elif any(w in task_lower for w in ["monitor", "log", "prometheus", "grafana"]):
            result = self._create_monitoring(task)
        else:
            result = self._generic_devops_task(task)

        task.status = TaskStatus.COMPLETED
        task.result = result
        self.current_task = None
        return result

    def _create_docker_config(self, task: Task) -> str:
        """Create Docker configuration"""
        prompt = f"""
Create Docker configuration:

{task.description}

Provide:
1. Dockerfile for frontend (multi-stage build)
2. Dockerfile for backend
3. docker-compose.yml (with all services)
4. docker-compose.dev.yml (for development)
5. .dockerignore

Services to include:
- Frontend (Next.js)
- Backend (FastAPI)
- Database (PostgreSQL)
- Redis (caching)
- Nginx (reverse proxy)

Include:
- Health checks
- Volume mounts
- Network configuration
- Environment variables
- Restart policies
"""
        return self.think(prompt)

    def _create_ci_cd(self, task: Task) -> str:
        """Create CI/CD pipeline"""
        prompt = f"""
Create CI/CD pipeline:

{task.description}

Provide GitHub Actions workflow:
1. .github/workflows/ci.yml (test & lint)
2. .github/workflows/cd.yml (deploy)
3. .github/workflows/pr-check.yml (PR checks)

Include:
- Linting (ESLint, Black/Ruff)
- Type checking
- Unit tests
- Build verification
- Docker image build & push
- Deployment steps
- Environment secrets handling
"""
        return self.think(prompt)

    def _create_nginx_config(self, task: Task) -> str:
        """Create Nginx configuration"""
        prompt = f"""
Create Nginx configuration:

{task.description}

Include:
- Reverse proxy for frontend and backend
- SSL/TLS configuration
- Gzip compression
- Caching headers
- Rate limiting
- Security headers
- WebSocket support
"""
        return self.think(prompt)

    def _create_deployment(self, task: Task) -> str:
        """Create deployment configuration"""
        prompt = f"""
Create deployment configuration:

{task.description}

Provide:
- Deployment scripts
- Environment configuration
- SSL setup instructions
- Domain configuration
- Backup scripts
"""
        return self.think(prompt)

    def _create_monitoring(self, task: Task) -> str:
        """Create monitoring setup"""
        prompt = f"""
Create monitoring configuration:

{task.description}

Include Prometheus + Grafana setup or simple logging solution.
"""
        return self.think(prompt)

    def _generic_devops_task(self, task: Task) -> str:
        """Handle generic DevOps tasks"""
        return self.think(f"""
Complete this DevOps task:
{task.description}
Provide complete configuration files with paths.
""")
