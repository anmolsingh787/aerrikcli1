"""
QA/Test Engineer Agent - Girl Child 2
Writes tests, finds bugs, ensures quality
"""
from agents.base_agent import BaseAgent, Task, TaskStatus
from config import AgentRole, AGENT_CONFIGS


class TesterAgent(BaseAgent):
    """
    👧 GIRL CHILD 2 - QA/Test Engineer

    Writes comprehensive tests for both frontend and backend.
    Expert in pytest, Jest, Cypress
    """

    def __init__(self, api_key: str = "", verbose: bool = True):
        super().__init__(
            config=AGENT_CONFIGS[AgentRole.TESTER],
            role=AgentRole.TESTER,
            api_key=api_key,
            verbose=verbose
        )

    def execute_task(self, task: Task) -> str:
        """Execute a testing task"""
        self.current_task = task
        task.status = TaskStatus.IN_PROGRESS

        if self.verbose:
            print(f"\n👧 {self.name} working on: {task.title}")

        task_lower = task.description.lower()

        if any(w in task_lower for w in ["unit", "pytest", "jest"]):
            result = self._write_unit_tests(task)
        elif any(w in task_lower for w in ["integration", "api test"]):
            result = self._write_integration_tests(task)
        elif any(w in task_lower for w in ["e2e", "cypress", "playwright", "end to end"]):
            result = self._write_e2e_tests(task)
        elif any(w in task_lower for w in ["plan", "strategy", "test plan"]):
            result = self._create_test_plan(task)
        else:
            result = self._generic_test_task(task)

        task.status = TaskStatus.COMPLETED
        task.result = result
        self.current_task = None
        return result

    def _write_unit_tests(self, task: Task) -> str:
        """Write unit tests"""
        prompt = f"""
Write comprehensive unit tests:

{task.description}

For Python (pytest):
- Use pytest fixtures
- Use parametrize for multiple test cases
- Mock external dependencies
- Test edge cases
- Aim for >90% coverage

For JavaScript (Jest):
- Use describe/it blocks
- Use beforeEach/afterEach
- Mock modules
- Test edge cases
- Snapshot testing where applicable

Provide complete test files with file paths.
"""
        return self.think(prompt)

    def _write_integration_tests(self, task: Task) -> str:
        """Write integration tests"""
        prompt = f"""
Write integration tests:

{task.description}

Include:
- API endpoint tests (using TestClient for FastAPI)
- Database integration tests
- Auth flow tests
- Error response tests
- Test fixtures and factories

Provide complete test files with file paths.
"""
        return self.think(prompt)

    def _write_e2e_tests(self, task: Task) -> str:
        """Write E2E tests"""
        prompt = f"""
Write E2E tests using Playwright or Cypress:

{task.description}

Include:
- User flow tests
- Form submission tests
- Navigation tests
- Authentication flow tests
- Error handling tests

Provide complete test files with file paths.
"""
        return self.think(prompt)

    def _create_test_plan(self, task: Task) -> str:
        """Create test plan"""
        prompt = f"""
Create a comprehensive test plan:

{task.description}

Include:
1. Test Strategy
2. Test Cases (organized by feature)
3. Edge Cases
4. Performance Test Scenarios
5. Security Test Scenarios
6. Test Data Requirements
7. Testing Tools & Setup
"""
        return self.think(prompt)

    def _generic_test_task(self, task: Task) -> str:
        """Handle generic test tasks"""
        return self.think(f"""
Complete this testing task:
{task.description}
Provide complete test code with file paths.
""")
