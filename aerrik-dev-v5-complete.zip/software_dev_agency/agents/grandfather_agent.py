"""
👴 Grandfather Agent — The Risk-Aware Review Engine

The most experienced code reviewer in the agency.
Aggressively hunts for high-impact weaknesses before they reach production.
30+ years of coding wisdom applied through deterministic + LLM-assisted review.
"""
from typing import Dict, List, Optional
from agents.base_agent import BaseAgent, Task, TaskStatus
from config import AgentRole, AGENT_CONFIGS, AgentConfig


# Grandfather config — highest priority, all skills
GRANDFATHER_CONFIG = AgentConfig(
    name="Grandfather 👴",
    role=AgentRole.ARCHITECT,  # Uses architect role base
    model="gpt-4",
    temperature=0.3,  # Very precise, low creativity
    max_tokens=6000,
    skills=[
        "code_review", "security_audit", "performance_analysis",
        "architecture_review", "weak_point_detection", "refactoring",
        "best_practices", "anti_pattern_detection",
    ],
    can_delegate_to=[],  # Reviews only, doesn't delegate
    priority=0,  # Highest priority — above Dad
)

GRANDFATHER_PROMPT = """
You are **Grandfather 👴** — the most experienced and powerful code reviewer in the agency.

You have 30+ years of software engineering experience across every language and paradigm.
You've seen every bug, every anti-pattern, every security disaster.
Nothing gets past you.

🎯 YOUR MISSION:
Aggressively hunt for high-impact weak points.
Find critical weaknesses before they reach production.
You won't catch everything — no reviewer does — but you focus on
what could cause real damage: security holes, data loss, crashes, and race conditions.

🔍 WHAT YOU CHECK (in priority order):

1. **SECURITY VULNERABILITIES** (Critical)
   - SQL injection, XSS, CSRF, SSRF
   - Hardcoded secrets, API keys, passwords
   - Insecure deserialization (pickle, eval, exec)
   - Missing authentication/authorization checks
   - CORS misconfiguration
   - Unsafe file operations
   - Command injection
   - Path traversal
   - Missing input validation
   - Insecure crypto (MD5, SHA1, weak random)

2. **LOGIC BUGS** (Critical)
   - Off-by-one errors
   - Race conditions / TOCTOU
   - Null/undefined reference errors
   - Incorrect error handling (swallowed exceptions)
   - Missing edge cases (empty input, negative numbers, overflow)
   - Infinite loops / recursion without base case
   - Incorrect state transitions
   - Data loss scenarios

3. **PERFORMANCE ISSUES** (High)
   - N+1 queries
   - Missing database indexes
   - Unnecessary re-renders (React)
   - Missing memoization for expensive operations
   - Blocking I/O in async code
   - Memory leaks (unclosed resources, event listeners)
   - Missing pagination on list endpoints
   - O(n²) when O(n log n) is possible

4. **ARCHITECTURE PROBLEMS** (Medium)
   - Circular dependencies
   - Tight coupling between modules
   - Missing abstraction layers
   - God classes/functions (>200 lines)
   - Duplicate code (DRY violations)
   - Missing interfaces/protocols
   - Incorrect dependency direction

5. **RELIABILITY** (Medium)
   - Missing retry logic for network calls
   - No timeout configuration
   - Missing health checks
   - No graceful degradation
   - Missing idempotency on mutations
   - No circuit breaker pattern

6. **CODE QUALITY** (Low)
   - Unclear naming
   - Missing type hints / types
   - Dead code
   - TODO/FIXME markers left in production code
   - Console.log / print statements
   - Missing documentation on public APIs

📋 OUTPUT FORMAT:

For each issue found:
```
🔴 CRITICAL | ⚠️ HIGH | 🟡 MEDIUM | ℹ️ LOW

[SEVERITY] [CATEGORY] Line X: [description]
  → Impact: [what could go wrong]
  → Fix: [specific fix with code example]
```

After listing all issues:
```
WEAK POINTS FOUND: X (Y critical, Z high)
OVERALL VERDICT: PASS / NEEDS_REVIEW / REJECT
CONFIDENCE: X/10
```

🚫 RULES:
- Be BRUTALLY honest. Sugarcoating helps no one.
- Every issue must have a specific fix.
- Prioritize security > logic > performance > architecture > quality.
- If code is genuinely good, say so. Don't invent problems.
- Mark false positives as such.
"""


class GrandfatherAgent(BaseAgent):
    """
    👴 GRANDFATHER — The Supreme Reviewer

    Most powerful agent. Reviews all code. Finds all weak points.
    """

    def __init__(self, api_key: str = "", verbose: bool = True):
        super().__init__(
            config=GRANDFATHER_CONFIG,
            role=AgentRole.ARCHITECT,
            api_key=api_key,
            verbose=verbose,
        )
        self.name = "Grandfather 👴"
        self.system_prompt = GRANDFATHER_PROMPT
        self.reviews_done: int = 0
        self.critical_found: int = 0
        self.high_found: int = 0

    def execute_task(self, task: Task) -> str:
        """Review code and find weak points"""
        self.current_task = task
        task.status = TaskStatus.IN_PROGRESS

        if self.verbose:
            print(f"\n👴 {self.name} reviewing: {task.title}")

        prompt = f"""
Aggressively hunt for weak points in this code.
Find high-impact weaknesses before they reach production.

TASK: {task.title}
DESCRIPTION: {task.description}

{task.result if task.result else task.description}

Find security vulnerabilities, logic bugs, performance issues,
architecture problems, and code quality issues.
Prioritize by impact — focus on what could cause real damage.
"""
        result = self.think(prompt)
        self.reviews_done += 1

        # Count severity
        self.critical_found += result.count("🔴 CRITICAL") + result.count("CRITICAL")
        self.high_found += result.count("⚠️ HIGH") + result.count("HIGH")

        task.status = TaskStatus.COMPLETED
        task.result = result
        self.current_task = None
        return result

    def review_code(self, code: str, context: str = "") -> str:
        """Direct code review"""
        prompt = f"""
Aggressively hunt for weak points in this code:

{context}

```
{code}
```

Find high-impact security vulnerabilities, logic bugs, and performance issues.
"""
        self.reviews_done += 1
        return self.think(prompt)

    def get_review_stats(self) -> Dict:
        """Get review statistics"""
        return {
            "reviews_done": self.reviews_done,
            "critical_found": self.critical_found,
            "high_found": self.high_found,
        }
