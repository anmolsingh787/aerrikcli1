"""
🔄 Feedback Loop — Iterative test-fix cycle

When Tester Girl finds issues, code goes back to the responsible agent
for fixes. This continues until tests pass or max retries are exhausted.

Flow:
  Children execute → Tester validates → Pass? Done : Fix → Re-test → ...
"""
import re
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime

from agents.base_agent import BaseAgent, Task, TaskStatus
from config import AgentRole


@dataclass
class FeedbackResult:
    """Result of a test-fix iteration"""
    task_id: str
    task_title: str
    assigned_to: str
    iterations: int = 0
    max_iterations: int = 3
    passed: bool = False
    history: List[Dict] = field(default_factory=list)
    final_code: str = ""
    test_output: str = ""

    def add_iteration(self, code: str, test_result: str, issues: List[str]):
        """Record one iteration"""
        self.iterations += 1
        self.history.append({
            "iteration": self.iterations,
            "timestamp": datetime.now().isoformat(),
            "code_length": len(code),
            "test_result": test_result[:500],
            "issues": issues,
            "passed": len(issues) == 0,
        })
        self.final_code = code
        self.test_output = test_result
        if len(issues) == 0:
            self.passed = True


class FeedbackLoop:
    """
    🔄 Feedback Loop Manager

    Implements the iterative test-fix cycle:
    1. Agent writes code
    2. Tester validates/tests
    3. If issues found → send back with specific feedback
    4. Agent fixes code
    5. Repeat until pass or max retries

    Also handles:
    - Delegation cycle detection (prevents infinite loops)
    - Convergence tracking (is code improving?)
    - Budget awareness (skip if too expensive)
    """

    def __init__(self, family, max_iterations: int = 3, verbose: bool = True):
        self.family = family
        self.max_iterations = max_iterations
        self.verbose = verbose
        self._delegation_history: List[Tuple[str, str]] = []  # (from, to) pairs

    # ─── Cycle Detection ─────────────────────────────────

    def detect_cycle(self, from_agent: str, to_agent: str) -> bool:
        """
        Detect if adding from_agent → to_agent would create a delegation cycle.

        Example cycle: Backend → Database → Backend (infinite loop)
        """
        # Check direct reverse
        if (to_agent, from_agent) in self._delegation_history:
            return True

        # Check transitive cycles (A→B, B→C, C→A)
        visited = set()
        stack = [to_agent]
        while stack:
            current = stack.pop()
            if current == from_agent:
                return True
            if current in visited:
                continue
            visited.add(current)
            # Find all agents that 'current' delegates to
            for f, t in self._delegation_history:
                if f == current:
                    stack.append(t)

        return False

    def record_delegation(self, from_agent: str, to_agent: str):
        """Record a delegation for cycle tracking"""
        self._delegation_history.append((from_agent, to_agent))

    def reset_cycles(self):
        """Reset cycle detection history"""
        self._delegation_history.clear()

    # ─── Code Review (Tester analyzes code) ───────────────

    def review_code(self, code: str, task_description: str, language: str = "python") -> Dict:
        """
        Have Tester Girl review generated code for issues.
        Returns structured feedback without requiring an actual test run.
        """
        tester = self.family.tester_girl

        prompt = f"""
Review this {language} code for a task: "{task_description}"

CODE:
```{language}
{code[:3000]}
```

Check for:
1. Missing imports or undefined variables
2. Logic errors or edge cases not handled
3. Missing error handling (try/except, error boundaries)
4. Security issues (injection, hardcoded secrets, unsafe operations)
5. Performance issues (N+1 queries, unnecessary re-renders)
6. Missing validation on inputs
7. Incomplete implementation (TODO/FIXME/placeholder code)
8. Missing tests or test coverage gaps

Respond in this EXACT format:
ISSUES_FOUND: [YES/NO]
ISSUE_COUNT: [number]
ISSUES:
- [severity: HIGH/MEDIUM/LOW] [description]
- [severity: HIGH/MEDIUM/LOW] [description]
SUGGESTED_FIXES:
- [specific fix instruction]
- [specific fix instruction]
OVERALL: [PASS/NEEDS_FIX/FAIL]
"""
        response = tester.think(prompt)
        return self._parse_review(response)

    def _parse_review(self, response: str) -> Dict:
        """Parse tester's review response"""
        issues_found = "YES" in response.upper().split("ISSUES_FOUND:")[-1].split("\n")[0] if "ISSUES_FOUND:" in response else False
        overall = "NEEDS_FIX"
        if "OVERALL: PASS" in response.upper():
            overall = "PASS"
        elif "OVERALL: FAIL" in response.upper():
            overall = "FAIL"

        # Extract issues
        issues = []
        issue_section = False
        for line in response.splitlines():
            if line.strip().startswith("ISSUES:"):
                issue_section = True
                continue
            if line.strip().startswith("SUGGESTED_FIXES:") or line.strip().startswith("OVERALL:"):
                issue_section = False
                continue
            if issue_section and line.strip().startswith("-"):
                issues.append(line.strip().lstrip("- ").strip())

        # Extract fixes
        fixes = []
        fix_section = False
        for line in response.splitlines():
            if line.strip().startswith("SUGGESTED_FIXES:"):
                fix_section = True
                continue
            if line.strip().startswith("OVERALL:"):
                fix_section = False
                continue
            if fix_section and line.strip().startswith("-"):
                fixes.append(line.strip().lstrip("- ").strip())

        return {
            "issues_found": issues_found,
            "issue_count": len(issues),
            "issues": issues,
            "fixes": fixes,
            "overall": overall,
            "raw_response": response,
        }

    # ─── Fix Code (send back to agent) ────────────────────

    def fix_code(
        self,
        agent: BaseAgent,
        original_code: str,
        review: Dict,
        task_description: str,
    ) -> str:
        """Send code back to the original agent with review feedback"""

        issues_text = "\n".join(f"  - {issue}" for issue in review["issues"])
        fixes_text = "\n".join(f"  - {fix}" for fix in review["fixes"])

        prompt = f"""
Your previous code for "{task_description}" was reviewed and needs fixes.

ORIGINAL CODE:
```
{original_code[:3000]}
```

ISSUES FOUND:
{issues_text}

SUGGESTED FIXES:
{fixes_text}

Please provide the COMPLETE FIXED code. Requirements:
1. Address ALL issues listed above
2. Keep the same file structure and file paths
3. Don't remove existing functionality
4. Add missing error handling
5. Fix any security issues
6. Keep the code minimal (ponytail principle)

Provide the complete fixed code with file paths.
"""
        return agent.think(prompt)

    # ─── Main Feedback Loop ──────────────────────────────

    def run_feedback_loop(
        self,
        task: Task,
        agent: BaseAgent,
        initial_code: str,
        language: str = "python",
    ) -> FeedbackResult:
        """
        Run the full test-fix feedback loop for a task.

        1. Start with initial_code
        2. Tester reviews
        3. If issues → agent fixes → re-review
        4. Repeat until PASS or max_iterations
        """
        result = FeedbackResult(
            task_id=task.id,
            task_title=task.title,
            assigned_to=agent.role.value,
            max_iterations=self.max_iterations,
        )

        current_code = initial_code

        for iteration in range(self.max_iterations):
            if self.verbose:
                print(f"\n🔄 Feedback loop iteration {iteration + 1}/{self.max_iterations}")
                print(f"   Task: {task.title}")
                print(f"   Agent: {agent.name}")

            # Step 1: Review code
            review = self.review_code(current_code, task.description, language)

            # Step 2: Record iteration
            result.add_iteration(
                code=current_code,
                test_result=review["raw_response"][:500],
                issues=review["issues"],
            )

            # Step 3: Check if passed
            if review["overall"] == "PASS" or not review["issues_found"]:
                if self.verbose:
                    print(f"   ✅ Code passed review on iteration {iteration + 1}")
                result.passed = True
                break

            if review["overall"] == "FAIL":
                if self.verbose:
                    print(f"   ❌ Code failed review critically — stopping")
                break

            # Step 4: Fix code
            if self.verbose:
                print(f"   ⚠️ {review['issue_count']} issues found — sending back for fixes")
                for issue in review["issues"][:3]:
                    print(f"      - {issue}")

            current_code = self.fix_code(agent, current_code, review, task.description)

        # Final status
        if not result.passed and result.iterations >= self.max_iterations:
            if self.verbose:
                print(f"   ⚠️ Max iterations ({self.max_iterations}) reached — code may still have issues")

        return result

    # ─── Quick Static Check ──────────────────────────────

    def quick_check(self, code: str, language: str = "python") -> Dict:
        """
        Quick static check without full LLM review.
        Uses pattern matching for common issues.
        """
        issues = []

        if language == "python":
            # Check syntax
            try:
                import ast
                ast.parse(code)
            except SyntaxError as e:
                issues.append(f"Syntax error at line {e.lineno}: {e.msg}")

            # Common issues
            if "TODO" in code or "FIXME" in code:
                issues.append("Contains TODO/FIXME markers")
            if "pass\n" in code or ": pass" in code:
                issues.append("Contains empty 'pass' implementations")
            if "print(" in code:
                issues.append("Contains print statements — use logging instead")

        elif language in ("typescript", "typescript-react"):
            if ": any" in code:
                issues.append("Uses 'any' type")
            if "console.log" in code:
                issues.append("Contains console.log")
            if "// @ts-ignore" in code:
                issues.append("Contains @ts-ignore")
            if "TODO" in code or "FIXME" in code:
                issues.append("Contains TODO/FIXME markers")

        return {
            "passed": len(issues) == 0,
            "issues": issues,
            "issue_count": len(issues),
        }

    # ─── Batch Feedback Loop ─────────────────────────────

    def run_batch_review(
        self,
        task_results: Dict[str, str],
        task_map: Dict[str, Task],
        agent_map: Dict[str, BaseAgent],
    ) -> Dict[str, FeedbackResult]:
        """
        Run feedback loop on all task results.
        Only reviews tasks that produced code (skip planning tasks).
        """
        feedback_results = {}

        for task_id, result_text in task_results.items():
            task = task_map.get(task_id)
            if not task or not task.assigned_to:
                continue

            agent = agent_map.get(task.assigned_to.value)
            if not agent:
                continue

            # Detect language from result
            language = "python"
            if any(kw in result_text.lower() for kw in [".tsx", "react", "next.js", "component"]):
                language = "typescript-react"
            elif any(kw in result_text.lower() for kw in [".ts", "typescript"]):
                language = "typescript"

            # Only run feedback on code-heavy results
            if len(result_text) < 200:
                continue

            if self.verbose:
                print(f"\n{'─' * 50}")
                print(f"🔄 Reviewing: {task.title}")

            fb_result = self.run_feedback_loop(task, agent, result_text, language)
            feedback_results[task_id] = fb_result

        return feedback_results
