"""
Project Manager Agent - The Mother/Mommy
Coordinates all children, manages tasks, tracks progress
"""
import re
from typing import Dict, List
from agents.base_agent import BaseAgent, Task, TaskStatus, Message, MessageType
from config import AgentRole, AGENT_CONFIGS


class ProjectManagerAgent(BaseAgent):
    """
    👩‍💼 MOMMY - Project Manager

    She coordinates the entire family:
    - Receives architecture from Dad
    - Breaks it into tasks
    - Assigns to children
    - Tracks progress
    - Reports back to Dad
    """

    def __init__(self, api_key: str = "", verbose: bool = True):
        super().__init__(
            config=AGENT_CONFIGS[AgentRole.PROJECT_MANAGER],
            role=AgentRole.PROJECT_MANAGER,
            api_key=api_key,
            verbose=verbose
        )
        self.task_board: Dict[str, Task] = {}
        self.sprint_number: int = 0
        self.project_plan: str = ""

    def execute_task(self, task: Task) -> str:
        """Mommy executes by coordinating"""
        self.current_task = task

        if self.verbose:
            print(f"\n👩‍💼 {self.name} is coordinating task: {task.title}")

        prompt = f"""
You received this task from the Architect:

TASK: {task.title}
DESCRIPTION: {task.description}

Your job:
1. Break this into smaller sub-tasks
2. Assign each sub-task to the RIGHT team member
3. Define dependencies
4. Set priorities

Available team members:
- Frontend Girl 👧 (React, Next.js, UI components)
- Backend Boy 👦 (Python, FastAPI, APIs)
- Database Boy 👦 (PostgreSQL, schemas, migrations)
- DevOps Boy 👦 (Docker, CI/CD, deployment)
- Tester Girl 👧 (Testing, QA)
- Designer Girl 👧 (UI/UX, wireframes)

Provide a detailed task breakdown in this format:
TASK-1: [title]
ASSIGNED TO: [role]
PRIORITY: [HIGH/MEDIUM/LOW]
DEPENDS ON: [task ids or NONE]
DESCRIPTION: [what needs to be done]
---
"""
        result = self.think(prompt)
        self.current_task = None
        return result

    def create_project_plan(self, architecture: str) -> str:
        """Create a full project plan from architecture"""
        prompt = f"""
Based on this architecture, create a complete PROJECT PLAN:

ARCHITECTURE:
{architecture}

Create:
1. Phase 1: Setup & Infrastructure
2. Phase 2: Database & Models
3. Phase 3: Backend API Development
4. Phase 4: Frontend Development
5. Phase 5: Integration & Testing
6. Phase 6: DevOps & Deployment

For each phase, list specific tasks with assignments.
"""
        self.project_plan = self.think(prompt)
        self.remember("project_plan", self.project_plan)
        return self.project_plan

    def break_into_tasks(self, description: str) -> List[Task]:
        """Break a description into actionable tasks"""
        prompt = f"""
Break this into specific, actionable development tasks:

{description}

For each task provide (use EXACTLY this format):
TASK_TITLE: [clear title]
TASK_ROLE: [frontend_developer/backend_developer/database_expert/devops_engineer/tester/ui_ux_designer]
TASK_PRIORITY: [1-5, 1 being highest]
TASK_DESCRIPTION: [detailed description of what to implement]
===
"""
        response = self.think(prompt)
        return self._parse_tasks(response)

    def _parse_tasks(self, response: str) -> List[Task]:
        """Parse LLM response into Task objects"""
        tasks = []
        task_blocks = response.split("===")

        role_map = {
            "frontend_developer": AgentRole.FRONTEND_DEV,
            "backend_developer": AgentRole.BACKEND_DEV,
            "database_expert": AgentRole.DATABASE_EXPERT,
            "devops_engineer": AgentRole.DEVOPS,
            "tester": AgentRole.TESTER,
            "ui_ux_designer": AgentRole.DESIGNER,
        }

        for block in task_blocks:
            block = block.strip()
            if not block:
                continue

            task = Task()

            # Extract fields
            title_match = re.search(r'TASK_TITLE:\s*(.+)', block)
            role_match = re.search(r'TASK_ROLE:\s*(.+)', block)
            priority_match = re.search(r'TASK_PRIORITY:\s*(\d+)', block)
            desc_match = re.search(r'TASK_DESCRIPTION:\s*(.+)', block, re.DOTALL)

            if title_match:
                task.title = title_match.group(1).strip()
            if role_match:
                role_str = role_match.group(1).strip().lower()
                task.assigned_to = role_map.get(role_str)
            if priority_match:
                task.priority = int(priority_match.group(1))
            if desc_match:
                task.description = desc_match.group(1).strip()

            if task.title:
                tasks.append(task)
                self.task_board[task.id] = task

        if self.verbose:
            print(f"\n📋 Created {len(tasks)} tasks:")
            for t in tasks:
                assigned = t.assigned_to.value if t.assigned_to else "unassigned"
                print(f"   - [{t.id}] {t.title} -> {assigned}")

        return tasks

    def assign_and_execute(self, tasks: List[Task]) -> Dict[str, str]:
        """Assign tasks to children and execute them"""
        results = {}

        # Sort by priority
        sorted_tasks = sorted(tasks, key=lambda t: t.priority)

        for task in sorted_tasks:
            if task.assigned_to and task.assigned_to in self.children:
                if self.verbose:
                    print(f"\n{'─'*50}")
                    print(f"👩‍💼 Mommy assigning: {task.title}")
                    print(f"   To: {self.children[task.assigned_to].name}")

                result = self.delegate_task(task, task.assigned_to)
                results[task.id] = result
            else:
                if self.verbose:
                    print(f"\n⚠️ No agent for task: {task.title}, Mommy handles it")
                result = self.think(f"Handle this task yourself:\n{task.description}")
                results[task.id] = result

        return results

    def get_progress_report(self) -> str:
        """Generate progress report"""
        total = len(self.task_board)
        completed = sum(1 for t in self.task_board.values()
                       if t.status == TaskStatus.COMPLETED)
        in_progress = sum(1 for t in self.task_board.values()
                         if t.status == TaskStatus.IN_PROGRESS)
        pending = sum(1 for t in self.task_board.values()
                     if t.status == TaskStatus.PENDING)

        progress_pct = (completed / total * 100) if total > 0 else 0

        report = f"""
📊 PROJECT PROGRESS REPORT
{'='*40}
Sprint: #{self.sprint_number}

Total Tasks: {total}
✅ Completed: {completed}
🔄 In Progress: {in_progress}
⏳ Pending: {pending}
❌ Failed: {total - completed - in_progress - pending}

Progress: {progress_pct:.1f}%

TASK DETAILS:
{'─'*40}
"""
        status_emoji = {
            TaskStatus.COMPLETED: "✅",
            TaskStatus.IN_PROGRESS: "🔄",
            TaskStatus.PENDING: "⏳",
            TaskStatus.FAILED: "❌",
            TaskStatus.BLOCKED: "🚫",
            TaskStatus.REVIEW: "👀"
        }

        for task_id, task in self.task_board.items():
            emoji = status_emoji.get(task.status, "❓")
            assigned = task.assigned_to.value if task.assigned_to else "unassigned"
            report += f"  {emoji} [{task.id}] {task.title} -> {assigned}\n"

        return report
