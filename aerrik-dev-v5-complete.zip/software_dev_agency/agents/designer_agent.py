"""
UI/UX Designer Agent - Girl Child 3
Creates design systems, wireframes, component specs
"""
from agents.base_agent import BaseAgent, Task, TaskStatus
from config import AgentRole, AGENT_CONFIGS


class DesignerAgent(BaseAgent):
    """
    👧 GIRL CHILD 3 - UI/UX Designer

    Creates design specifications, wireframes, and design systems.
    Expert in UI/UX, TailwindCSS theming, component design
    """

    def __init__(self, api_key: str = "", verbose: bool = True):
        super().__init__(
            config=AGENT_CONFIGS[AgentRole.DESIGNER],
            role=AgentRole.DESIGNER,
            api_key=api_key,
            verbose=verbose
        )

    def execute_task(self, task: Task) -> str:
        """Execute a design task"""
        self.current_task = task
        task.status = TaskStatus.IN_PROGRESS

        if self.verbose:
            print(f"\n👧 {self.name} working on: {task.title}")

        task_lower = task.description.lower()

        if any(w in task_lower for w in ["wireframe", "mockup", "layout"]):
            result = self._create_wireframe(task)
        elif any(w in task_lower for w in ["design system", "theme", "token"]):
            result = self._create_design_system(task)
        elif any(w in task_lower for w in ["color", "palette", "typography"]):
            result = self._create_color_typography(task)
        elif any(w in task_lower for w in ["component", "spec", "specification"]):
            result = self._create_component_spec(task)
        else:
            result = self._generic_design_task(task)

        task.status = TaskStatus.COMPLETED
        task.result = result
        self.current_task = None
        return result

    def _create_wireframe(self, task: Task) -> str:
        """Create text-based wireframes"""
        prompt = f"""
Create detailed wireframes (text-based) for:

{task.description}

Use ASCII/text representation for each screen:

┌─────────────────────────────────────┐
│          HEADER / NAVBAR            │
│  [Logo]    [Nav1] [Nav2]  [Login]   │
├─────────────────────────────────────┤
│                                     │
│          HERO SECTION               │
│    [Large Heading Text]             │
│    [Subtitle Text]                  │
│    [CTA Button]                     │
│                                     │
├─────────────────────────────────────┤
│  [Card1]   [Card2]   [Card3]       │
└─────────────────────────────────────┘

Include:
1. Desktop wireframe
2. Mobile wireframe
3. User flow description
4. Interactive elements noted
"""
        return self.think(prompt)

    def _create_design_system(self, task: Task) -> str:
        """Create design system/tokens"""
        prompt = f"""
Create a complete design system:

{task.description}

Provide:
1. TailwindCSS theme configuration (tailwind.config.ts)
2. CSS custom properties (globals.css)
3. Color tokens (primary, secondary, accent, neutral, semantic)
4. Typography scale
5. Spacing scale
6. Border radius tokens
7. Shadow tokens
8. Animation tokens
9. Breakpoint definitions
10. Component variants (button sizes, card styles, etc.)

Format as actual TailwindCSS configuration file.
"""
        return self.think(prompt)

    def _create_color_typography(self, task: Task) -> str:
        """Create color palette and typography"""
        prompt = f"""
Create color palette and typography system:

{task.description}

Colors (provide hex codes):
- Primary: (main brand color + shades 50-950)
- Secondary: (supporting color + shades)
- Accent: (call-to-action color)
- Neutral: (grays for text, bg)
- Success: green shades
- Warning: yellow/orange shades
- Error: red shades
- Info: blue shades

Typography:
- Font families (heading, body, code)
- Font sizes (xs through 6xl)
- Line heights
- Font weights
- Letter spacing

Provide as TailwindCSS theme extension.
"""
        return self.think(prompt)

    def _create_component_spec(self, task: Task) -> str:
        """Create component specifications"""
        prompt = f"""
Create component specifications:

{task.description}

For each component provide:
1. Component name
2. Variants (sizes, colors, states)
3. Props/API
4. States (default, hover, active, disabled, loading)
5. Responsive behavior
6. Accessibility notes
7. TailwindCSS classes for each variant

Format as a component spec document.
"""
        return self.think(prompt)

    def _generic_design_task(self, task: Task) -> str:
        """Handle generic design tasks"""
        return self.think(f"""
Complete this design task:
{task.description}
Provide design specifications and TailwindCSS implementations.
""")
