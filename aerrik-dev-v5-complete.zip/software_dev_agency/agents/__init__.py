"""
Agents package - Full expanded family with Grandparents
"""
from agents.base_agent import BaseAgent, Task, TaskStatus, AgentMemory
from agents.project_manager import ProjectManagerAgent
from agents.frontend_agent import FrontendAgent
from agents.backend_agent import BackendAgent
from agents.database_agent import DatabaseAgent
from agents.devops_agent import DevOpsAgent
from agents.tester_agent import TesterAgent
from agents.designer_agent import DesignerAgent
from agents.mobile_agent import MobileAgent
from agents.security_agent import SecurityAgent
from agents.grandfather_agent import GrandfatherAgent
from agents.grandmother_agent import GrandmotherAgent
from config import AgentRole, AGENT_CONFIGS, ProjectConfig


class ArchitectAgent(BaseAgent):
    """
    👨‍💼 DAD / FATHER - The Architect

    The head of the family. Makes all major technical decisions.
    Creates system architecture, delegates to Mommy, who delegates to children.
    """

    def __init__(self, api_key: str = "", verbose: bool = True):
        super().__init__(
            config=AGENT_CONFIGS[AgentRole.ARCHITECT],
            role=AgentRole.ARCHITECT,
            api_key=api_key,
            verbose=verbose
        )
        self.architecture: str = ""
        self.tech_decisions: dict = {}

    def execute_task(self, task: Task) -> str:
        """Architect executes by designing and delegating"""
        self.current_task = task

        if self.verbose:
            print(f"\n👨‍💼 {self.name} architecting: {task.title}")

        prompt = f"""
As the Chief Software Architect, analyze and design:

TASK: {task.title}
DESCRIPTION: {task.description}

Provide:
1. HIGH-LEVEL ARCHITECTURE
   - System components
   - How they interact
   - Data flow

2. TECH STACK DECISION
   - Frontend: (framework, state management, styling)
   - Backend: (language, framework, auth)
   - Database: (type, ORM)
   - DevOps: (containerization, CI/CD)

3. FOLDER STRUCTURE
   - Complete project structure

4. API DESIGN
   - Main endpoints
   - Request/Response format

5. DATABASE SCHEMA OVERVIEW
   - Main entities
   - Relationships

6. SECURITY CONSIDERATIONS

7. SCALABILITY PLAN
"""
        result = self.think(prompt)
        self.architecture = result
        self.remember("architecture", result)

        self.current_task = None
        return result

    def design_architecture(self, project_description: str) -> str:
        """Create full system architecture"""
        task = Task(
            title="System Architecture Design",
            description=project_description
        )
        return self.execute_task(task)


class AgencyFamily:
    """
    🏠 THE EXPANDED FAMILY (v3.0)

    Family Structure:
    👴 Grandfather (Supreme Reviewer) ── HEAD ELDER
    👵 Grandmother (Wise Advisor)     ── HEAD ELDER
      │
      👨‍💼 Dad (Architect)
        └── 👩‍💼 Mommy (Project Manager)
              ├── 👧 Girls Team (Frontend)
              │    ├── 👧 Girl 1 (Frontend Dev)
              │    ├── 👧 Girl 2 (Tester)
              │    ├── 👧 Girl 3 (Designer)
              │    └── 👧📱 Girl 4 (Mobile Dev)
              │
              └── 👦 Boys Team (Backend)
                   ├── 👦 Boy 1 (Backend Dev)
                   ├── 👦 Boy 2 (Database Expert)
                   ├── 👦 Boy 3 (DevOps)
                   └── 👦🔐 Boy 4 (Security & Perf)
    """

    def __init__(self, api_key: str = "", verbose: bool = True):
        self.api_key = api_key
        self.verbose = verbose

        if verbose:
            print("\n" + "=" * 60)
            print("🏠 BUILDING THE EXPANDED AGENCY FAMILY")
            print("=" * 60)

        # ─── Grandparents ────────────────────────────────
        self.grandfather = GrandfatherAgent(api_key=api_key, verbose=verbose)
        self.grandmother = GrandmotherAgent(api_key=api_key, verbose=verbose)

        # ─── Parents ─────────────────────────────────────
        self.dad = ArchitectAgent(api_key=api_key, verbose=verbose)
        self.mommy = ProjectManagerAgent(api_key=api_key, verbose=verbose)

        # ─── Girls Team (Frontend) ───────────────────────
        self.frontend_girl = FrontendAgent(api_key=api_key, verbose=verbose)
        self.tester_girl = TesterAgent(api_key=api_key, verbose=verbose)
        self.designer_girl = DesignerAgent(api_key=api_key, verbose=verbose)
        self.mobile_girl = MobileAgent(api_key=api_key, verbose=verbose)

        # ─── Boys Team (Backend) ─────────────────────────
        self.backend_boy = BackendAgent(api_key=api_key, verbose=verbose)
        self.database_boy = DatabaseAgent(api_key=api_key, verbose=verbose)
        self.devops_boy = DevOpsAgent(api_key=api_key, verbose=verbose)
        self.security_boy = SecurityAgent(api_key=api_key, verbose=verbose)

        # Build family tree
        self._build_family_tree()

        if verbose:
            print("\n" + "=" * 60)
            print("✅ EXPANDED FAMILY BUILT SUCCESSFULLY!")
            print("=" * 60)
            self.print_family_tree()

    def _build_family_tree(self):
        """Build the expanded family hierarchy"""
        # Grandparents oversee everyone
        self.grandfather.add_child(self.dad)
        self.grandfather.add_child(self.grandmother)
        self.grandmother.add_child(self.dad)

        # Dad → Mommy
        self.dad.add_child(self.mommy)

        # Mommy coordinates both teams
        # Girls Team
        self.mommy.add_child(self.frontend_girl)
        self.mommy.add_child(self.tester_girl)
        self.mommy.add_child(self.designer_girl)
        self.mommy.add_child(self.mobile_girl)

        # Boys Team
        self.mommy.add_child(self.backend_boy)
        self.mommy.add_child(self.database_boy)
        self.mommy.add_child(self.devops_boy)
        self.mommy.add_child(self.security_boy)

        # Cross-team delegation
        self.frontend_girl.add_child(self.designer_girl)
        self.frontend_girl.add_child(self.mobile_girl)
        self.backend_boy.add_child(self.database_boy)
        self.backend_boy.add_child(self.security_boy)

    def print_family_tree(self):
        """Print the expanded family tree"""
        tree = """
🏠 EXPANDED AGENCY FAMILY TREE
══════════════════════════════════════════════════

👴 Grandfather ─── SUPREME REVIEWER (weak points)
👵 Grandmother ─── WISE ADVISOR (best practices)
  │
  👨‍💼 Dad (Architect) ─── SYSTEM DESIGN
    │
    └── 👩‍💼 Mommy (Project Manager) ─── COORDINATOR
        │
        ├── 👧 GIRLS TEAM (Frontend)
        │    ├── 👧 Girl 1 (Frontend Dev)     ─ React, Next.js
        │    ├── 👧 Girl 2 (QA Tester)        ─ pytest, Jest
        │    ├── 👧 Girl 3 (UI/UX Designer)   ─ Wireframes
        │    └── 👧📱 Girl 4 (Mobile Dev)      ─ React Native, PWA
        │
        └── 👦 BOYS TEAM (Backend)
             ├── 👦 Boy 1 (Backend Dev)       ─ FastAPI, Node.js
             ├── 👦 Boy 2 (Database Expert)   ─ PostgreSQL, Redis
             ├── 👦 Boy 3 (DevOps)            ─ Docker, CI/CD
             └── 👦🔐 Boy 4 (Security & Perf)  ─ Pen testing, optimization

🐕 Aerrik ─── TERMINAL COMPANION (barks on errors!)

══════════════════════════════════════════════════
"""
        print(tree)

    def get_all_agents(self):
        """Get all agents as a dictionary"""
        return {
            "grandfather": self.grandfather,
            "grandmother": self.grandmother,
            "architect": self.dad,
            "project_manager": self.mommy,
            "frontend": self.frontend_girl,
            "tester": self.tester_girl,
            "designer": self.designer_girl,
            "mobile": self.mobile_girl,
            "backend": self.backend_boy,
            "database": self.database_boy,
            "devops": self.devops_boy,
            "security": self.security_boy,
        }

    def get_girls_team(self):
        """Get Girls Team (Frontend focused)"""
        return {
            "frontend": self.frontend_girl,
            "tester": self.tester_girl,
            "designer": self.designer_girl,
            "mobile": self.mobile_girl,
        }

    def get_boys_team(self):
        """Get Boys Team (Backend focused)"""
        return {
            "backend": self.backend_boy,
            "database": self.database_boy,
            "devops": self.devops_boy,
            "security": self.security_boy,
        }

    def get_family_status(self) -> str:
        """Get status of all family members"""
        status = "\n📊 FAMILY STATUS\n" + "=" * 50 + "\n"
        for name, agent in self.get_all_agents().items():
            s = agent.get_status()
            busy = "🔴 BUSY" if s["is_busy"] else "🟢 FREE"
            status += f"  {agent.name}: {busy} | Tasks: {s['tasks_completed']}\n"
        return status


__all__ = [
    "BaseAgent",
    "ArchitectAgent",
    "ProjectManagerAgent",
    "FrontendAgent",
    "BackendAgent",
    "DatabaseAgent",
    "DevOpsAgent",
    "TesterAgent",
    "DesignerAgent",
    "AgencyFamily",
    "Task",
    "TaskStatus",
]
