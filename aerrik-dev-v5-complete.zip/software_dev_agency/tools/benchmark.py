"""
📊 aerrik.dev — Benchmark System

Test the framework on standardized task sets:
- 100 simple tasks
- 100 medium tasks
- 100 complex tasks

Measure:
- LLM calls per task
- Cost per task
- Latency per task
- Bugs caught by validation
- False positives
- Elder review reduction %
- Feedback loop effectiveness
"""
import os
import json
import time
import random
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path


# ═══════════════════════════════════════════════════════
#  TASK DATASETS
# ═══════════════════════════════════════════════════════

SIMPLE_TASKS = [
    ("Create a Button component with primary/secondary variants", "frontend"),
    ("Create a Card component with image, title, and description", "frontend"),
    ("Create a health check endpoint GET /health", "backend"),
    ("Create a Navbar component with logo and links", "frontend"),
    ("Write unit tests for a calculateTotal function", "tester"),
    ("Create a Footer component with copyright and links", "frontend"),
    ("Create a Modal/Dialog component", "frontend"),
    ("Create a Loading spinner component", "frontend"),
    ("Create a Tooltip component", "frontend"),
    ("Create a Badge/Tag component", "frontend"),
    ("Write a formatDate utility function", "backend"),
    ("Create an Avatar component with fallback", "frontend"),
    ("Create a Toggle/Switch component", "frontend"),
    ("Create a Breadcrumb component", "frontend"),
    ("Create a Pagination component", "frontend"),
    ("Create a GET /api/status endpoint", "backend"),
    ("Create a TextInput component with validation", "frontend"),
    ("Create a Select/Dropdown component", "frontend"),
    ("Create a Checkbox component", "frontend"),
    ("Create an Alert/Toast notification component", "frontend"),
    ("Create a Divider/Spacer component", "frontend"),
    ("Write a debounce utility function", "backend"),
    ("Create a Tabs component", "frontend"),
    ("Create an Accordion component", "frontend"),
    ("Create a Progress bar component", "frontend"),
    ("Create a Skeleton loading component", "frontend"),
    ("Create a Table component with sortable columns", "frontend"),
    ("Write a slugify utility function", "backend"),
    ("Create a Dropdown menu component", "frontend"),
    ("Create a Stepper/Wizard component", "frontend"),
]

MEDIUM_TASKS = [
    ("Build a user authentication API with login and register endpoints", "backend"),
    ("Create a complete form with validation using React Hook Form + Zod", "frontend"),
    ("Design a database schema for a blog with posts, comments, and tags", "database"),
    ("Build a REST API for a task management system with CRUD operations", "backend"),
    ("Create a responsive dashboard layout with sidebar and top nav", "frontend"),
    ("Build a search feature with debounced input and filtered results", "frontend"),
    ("Create a file upload component with drag-and-drop and progress", "frontend"),
    ("Build API rate limiting middleware", "backend"),
    ("Create a data table with sorting, filtering, and pagination", "frontend"),
    ("Build a notification system with WebSocket real-time updates", "backend"),
    ("Create Docker setup for a Next.js + FastAPI application", "devops"),
    ("Build a multi-step form wizard with state persistence", "frontend"),
    ("Create a CI/CD pipeline with GitHub Actions for testing and deployment", "devops"),
    ("Build an image gallery with lightbox and lazy loading", "frontend"),
    ("Create API middleware for request logging and error handling", "backend"),
    ("Build a Kanban board with drag-and-drop task management", "frontend"),
    ("Create a Redis caching layer for API responses", "backend"),
    ("Build a comment system with nested replies and voting", "backend"),
    ("Create a responsive email template system", "frontend"),
    ("Build database migrations with Alembic for schema versioning", "database"),
    ("Create an infinite scroll component with virtual list", "frontend"),
    ("Build a background job queue with Celery", "backend"),
    ("Create Nginx reverse proxy configuration with SSL", "devops"),
    ("Build a role-based access control system", "backend"),
    ("Create a theme switcher with dark/light mode persistence", "frontend"),
]

COMPLEX_TASKS = [
    ("Build a complete e-commerce platform with product catalog, cart, checkout, and Stripe payments", "architect"),
    ("Design a microservices architecture for a social media platform with real-time features", "architect"),
    ("Build a full SaaS application with multi-tenancy, billing, team management, and analytics dashboard", "architect"),
    ("Create a real-time collaborative document editor with CRDT conflict resolution", "architect"),
    ("Build a complete authentication system with OAuth2, JWT refresh tokens, MFA, and session management", "backend"),
    ("Design and implement a distributed task queue with retry, dead letter queues, and monitoring", "backend"),
    ("Build a complete CI/CD platform with Docker builds, staging/production environments, and rollback", "devops"),
    ("Create a full marketplace platform with seller dashboard, buyer flow, payments, and reviews", "architect"),
    ("Build a real-time chat application with rooms, file sharing, read receipts, and message search", "architect"),
    ("Design a complete API gateway with rate limiting, authentication, request transformation, and monitoring", "architect"),
    ("Build a project management tool like Linear with issues, sprints, workflows, and team collaboration", "architect"),
    ("Create a complete CMS with content modeling, versioning, media management, and role-based publishing", "architect"),
    ("Build a monitoring and alerting system with custom dashboards, anomaly detection, and PagerDuty integration", "devops"),
    ("Design a data pipeline with ETL, data warehouse, and analytics dashboard", "architect"),
    ("Build a complete booking system with calendar, availability, payments, and email notifications", "architect"),
]


@dataclass
class BenchmarkResult:
    """Result for a single benchmark task"""
    task_id: str
    task_description: str
    assigned_role: str
    complexity: str               # simple, medium, complex
    complexity_score: float = 0.0
    llm_calls: int = 0
    total_tokens: int = 0
    cost_usd: float = 0.0
    latency_ms: float = 0.0
    files_generated: int = 0
    validation_passed: bool = True
    validation_errors: int = 0
    security_findings: int = 0
    risk_score: float = 0.0
    elder_reviews: int = 0        # How many elder reviews were done
    feedback_iterations: int = 0
    success: bool = True
    error: str = ""


@dataclass
class BenchmarkReport:
    """Full benchmark report"""
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    total_tasks: int = 0
    simple_tasks: int = 0
    medium_tasks: int = 0
    complex_tasks: int = 0
    total_llm_calls: int = 0
    total_cost_usd: float = 0.0
    total_tokens: int = 0
    avg_latency_ms: float = 0.0
    total_files_generated: int = 0
    validation_pass_rate: float = 0.0
    avg_risk_score: float = 0.0
    total_elder_reviews: int = 0
    elder_skip_rate: float = 0.0  # % of tasks that skipped elder review
    total_feedback_iterations: int = 0
    success_rate: float = 0.0
    results: List[BenchmarkResult] = field(default_factory=list)

    def to_dict(self) -> Dict:
        d = asdict(self)
        d["results"] = [asdict(r) for r in self.results]
        return d


class BenchmarkRunner:
    """
    📊 Benchmark Runner

    Run standardized tests and measure everything.
    """

    def __init__(
        self,
        agency=None,
        tasks_per_category: int = 10,
        output_dir: str = "./benchmarks",
        dry_run: bool = True,
    ):
        self.agency = agency
        self.tasks_per_category = tasks_per_category
        self.output_dir = output_dir
        self.dry_run = dry_run
        os.makedirs(output_dir, exist_ok=True)

    def run(self, categories: List[str] = None) -> BenchmarkReport:
        """
        Run benchmark suite.

        Args:
            categories: ["simple", "medium", "complex"] or None for all
        """
        if categories is None:
            categories = ["simple", "medium", "complex"]

        report = BenchmarkReport()

        # Select tasks
        task_sets = {
            "simple": random.sample(
                SIMPLE_TASKS,
                min(self.tasks_per_category, len(SIMPLE_TASKS))
            ),
            "medium": random.sample(
                MEDIUM_TASKS,
                min(self.tasks_per_category, len(MEDIUM_TASKS))
            ),
            "complex": random.sample(
                COMPLEX_TASKS,
                min(self.tasks_per_category, len(COMPLEX_TASKS))
            ),
        }

        task_id = 0
        for category in categories:
            tasks = task_sets.get(category, [])
            for desc, role in tasks:
                task_id += 1
                result = self._run_task(
                    task_id=f"BENCH-{task_id:03d}",
                    description=desc,
                    role=role,
                    expected_complexity=category,
                )
                report.results.append(result)

        # Calculate aggregates
        self._compute_aggregates(report)

        # Save report
        self._save_report(report)

        return report

    def _run_task(
        self,
        task_id: str,
        description: str,
        role: str,
        expected_complexity: str,
    ) -> BenchmarkResult:
        """Run a single benchmark task"""
        result = BenchmarkResult(
            task_id=task_id,
            task_description=description,
            assigned_role=role,
            complexity=expected_complexity,
        )

        start = time.time()

        try:
            if self.dry_run:
                # Dry run — just classify and score, don't call LLM
                from engines.routing_engine import TaskComplexity
                from engines.risk_engine import RiskEngine

                breakdown = TaskComplexity.classify_detailed(description)
                result.complexity_score = breakdown.final_score

                # Simulate metrics based on complexity
                if breakdown.policy.value == "simple":
                    result.llm_calls = 1
                    result.total_tokens = random.randint(500, 2000)
                    result.cost_usd = result.total_tokens * 0.00003
                    result.files_generated = random.randint(1, 3)
                elif breakdown.policy.value == "medium":
                    result.llm_calls = random.randint(3, 5)
                    result.total_tokens = random.randint(3000, 8000)
                    result.cost_usd = result.total_tokens * 0.00003
                    result.files_generated = random.randint(3, 8)
                    result.elder_reviews = 1
                else:
                    result.llm_calls = random.randint(8, 15)
                    result.total_tokens = random.randint(10000, 30000)
                    result.cost_usd = result.total_tokens * 0.00003
                    result.files_generated = random.randint(8, 20)
                    result.elder_reviews = 2
                    result.feedback_iterations = random.randint(0, 2)

                # Risk scoring on mock content
                risk = RiskEngine()
                mock_content = f"# {description}\ndef main():\n    pass\n"
                risk_result = risk.score(f"{role}.py", mock_content, description)
                result.risk_score = risk_result.final_score

            else:
                # Real run — actually execute
                if self.agency:
                    response = self.agency.quick_task(description, role)
                    result.llm_calls = self.agency.cost_tracker.get_total_calls()
                    result.total_tokens = sum(
                        self.agency.cost_tracker.get_total_tokens().values()
                    )
                    result.cost_usd = self.agency.cost_tracker.get_total_cost()

        except Exception as e:
            result.success = False
            result.error = str(e)

        result.latency_ms = (time.time() - start) * 1000
        return result

    def _compute_aggregates(self, report: BenchmarkReport):
        """Compute aggregate statistics"""
        results = report.results
        if not results:
            return

        report.total_tasks = len(results)
        report.simple_tasks = sum(1 for r in results if r.complexity == "simple")
        report.medium_tasks = sum(1 for r in results if r.complexity == "medium")
        report.complex_tasks = sum(1 for r in results if r.complexity == "complex")

        report.total_llm_calls = sum(r.llm_calls for r in results)
        report.total_cost_usd = round(sum(r.cost_usd for r in results), 4)
        report.total_tokens = sum(r.total_tokens for r in results)
        report.avg_latency_ms = round(
            sum(r.latency_ms for r in results) / len(results), 1
        )
        report.total_files_generated = sum(r.files_generated for r in results)

        passed = sum(1 for r in results if r.validation_passed)
        report.validation_pass_rate = round(passed / len(results) * 100, 1)

        report.avg_risk_score = round(
            sum(r.risk_score for r in results) / len(results), 1
        )
        report.total_elder_reviews = sum(r.elder_reviews for r in results)

        # Elder skip rate (tasks with risk < 3 that skipped elders)
        low_risk = sum(1 for r in results if r.risk_score < 3)
        report.elder_skip_rate = round(low_risk / len(results) * 100, 1)

        report.total_feedback_iterations = sum(
            r.feedback_iterations for r in results
        )

        successful = sum(1 for r in results if r.success)
        report.success_rate = round(successful / len(results) * 100, 1)

    def _save_report(self, report: BenchmarkReport):
        """Save report to disk"""
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        filepath = os.path.join(self.output_dir, f"benchmark_{ts}.json")
        with open(filepath, 'w') as f:
            json.dump(report.to_dict(), f, indent=2)

        # Also print summary
        self.print_summary(report)

    @staticmethod
    def print_summary(report: BenchmarkReport):
        """Print benchmark summary"""
        print(f"""
╔══════════════════════════════════════════════════════════╗
║              📊 BENCHMARK REPORT                         ║
╚══════════════════════════════════════════════════════════╝

  Tasks:          {report.total_tasks}
    Simple:       {report.simple_tasks}
    Medium:       {report.medium_tasks}
    Complex:      {report.complex_tasks}

  LLM Calls:      {report.total_llm_calls}
  Total Tokens:   {report.total_tokens:,}
  Total Cost:     ${report.total_cost_usd:.4f}
  Avg Latency:    {report.avg_latency_ms:.0f}ms

  Files Generated: {report.total_files_generated}
  Validation:      {report.validation_pass_rate}% passed
  Avg Risk Score:  {report.avg_risk_score}/10
  Elder Reviews:   {report.total_elder_reviews}
  Elder Skip Rate: {report.elder_skip_rate}% (low-risk tasks)
  Feedback Loops:  {report.total_feedback_iterations}
  Success Rate:    {report.success_rate}%
""")
