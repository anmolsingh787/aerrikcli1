"""
🔍 Code Validator — Multi-language code validation before writing to disk

Validates generated code for:
- Python: syntax, imports, type hints
- TypeScript/TSX: basic syntax, JSX balance
- JavaScript/JSX: basic syntax
- JSON: valid JSON
- YAML: valid YAML
- SQL: basic syntax
- Dockerfile: instruction validation
- Shell scripts: basic syntax

Prevents broken/vulnerable code from being written to disk.
"""
import ast
import json
import re
import subprocess
import tempfile
import os
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field


@dataclass
class ValidationResult:
    """Result of code validation"""
    valid: bool
    language: str
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    line_count: int = 0
    has_security_issues: bool = False
    security_warnings: List[str] = field(default_factory=list)

    def __str__(self):
        if self.valid and not self.warnings:
            return f"✅ {self.language}: {self.line_count} lines, no issues"
        elif self.valid:
            return f"⚠️ {self.language}: {self.line_count} lines, {len(self.warnings)} warnings"
        else:
            return f"❌ {self.language}: {len(self.errors)} errors"


class CodeValidator:
    """
    🔍 Multi-language code validator

    Used as a pre-write gate to catch:
    - Syntax errors
    - Security issues (hardcoded secrets, unsafe patterns)
    - Common anti-patterns
    - Missing imports
    """

    # ─── Dangerous patterns (security) ────────────────────
    SECURITY_PATTERNS = {
        "hardcoded_secret": [
            r'(?i)(password|secret|api_key|apikey|token)\s*=\s*["\'][^"\']{8,}["\']',
            r'(?i)sk-[a-zA-Z0-9]{20,}',  # OpenAI keys
            r'(?i)AKIA[0-9A-Z]{16}',      # AWS keys
            r'(?i)ghp_[a-zA-Z0-9]{36}',   # GitHub tokens
        ],
        "unsafe_eval": [
            r'\beval\s*\(',
            r'\bexec\s*\(',
            r'__import__\s*\(',
            r'compile\s*\(',
        ],
        "sql_injection": [
            r'execute\s*\(\s*f["\']',           # f-string in SQL
            r'execute\s*\(\s*["\'].*%s',         # % formatting in SQL
            r'execute\s*\(\s*["\'].*\+',         # string concat in SQL
        ],
        "command_injection": [
            r'os\.system\s*\(',
            r'subprocess\.call\s*\(.*shell\s*=\s*True',
            r'subprocess\.Popen\s*\(.*shell\s*=\s*True',
        ],
        "insecure_deserialization": [
            r'pickle\.loads?\s*\(',
            r'yaml\.load\s*\([^,]*\)(?!\s*,\s*Loader)',  # yaml.load without safe Loader
            r'marshal\.loads?\s*\(',
        ],
        "unsafe_file_access": [
            r'open\s*\(.*\+.*\)',  # Dynamic file path construction
        ],
    }

    # ─── Language detection ───────────────────────────────

    def detect_language(self, filepath: str, content: str = "") -> str:
        """Detect programming language from file extension or content"""
        ext = os.path.splitext(filepath)[1].lower()
        lang_map = {
            ".py": "python",
            ".tsx": "typescript-react",
            ".ts": "typescript",
            ".jsx": "javascript-react",
            ".js": "javascript",
            ".json": "json",
            ".yaml": "yaml",
            ".yml": "yaml",
            ".sql": "sql",
            ".sh": "shell",
            ".bash": "shell",
            ".dockerfile": "dockerfile",
            ".html": "html",
            ".css": "css",
            ".md": "markdown",
            ".toml": "toml",
            ".ini": "ini",
            ".cfg": "ini",
            ".env": "env",
            ".xml": "xml",
        }

        lang = lang_map.get(ext, "unknown")

        # Special cases
        if lang == "unknown":
            basename = os.path.basename(filepath).lower()
            if basename == "dockerfile" or basename.startswith("dockerfile."):
                lang = "dockerfile"
            elif basename == "makefile":
                lang = "makefile"
            elif basename.endswith(".env") or ".env." in basename:
                lang = "env"

        return lang

    # ─── Main validation entry point ──────────────────────

    def validate(self, filepath: str, content: str) -> ValidationResult:
        """Validate code based on file type"""
        language = self.detect_language(filepath, content)
        line_count = len(content.splitlines())

        validators = {
            "python": self._validate_python,
            "typescript": self._validate_typescript,
            "typescript-react": self._validate_typescript,
            "javascript": self._validate_javascript,
            "javascript-react": self._validate_javascript,
            "json": self._validate_json,
            "yaml": self._validate_yaml,
            "sql": self._validate_sql,
            "shell": self._validate_shell,
            "dockerfile": self._validate_dockerfile,
            "html": self._validate_html,
        }

        validator = validators.get(language)
        if validator:
            result = validator(content)
        else:
            result = ValidationResult(valid=True, language=language)

        result.line_count = line_count

        # Always run security checks on code files
        if language in ("python", "javascript", "typescript",
                        "javascript-react", "typescript-react", "shell"):
            sec_result = self._check_security(content, language)
            result.security_warnings = sec_result["warnings"]
            result.has_security_issues = sec_result["has_issues"]
            if sec_result["has_issues"]:
                result.warnings.extend(
                    f"🔒 Security: {w}" for w in sec_result["warnings"]
                )

        return result

    # ─── Language-specific validators ─────────────────────

    def _validate_python(self, code: str) -> ValidationResult:
        """Validate Python code using AST parsing"""
        result = ValidationResult(valid=True, language="python")

        # 1. Syntax check
        try:
            tree = ast.parse(code)
        except SyntaxError as e:
            result.valid = False
            result.errors.append(f"Syntax error at line {e.lineno}: {e.msg}")
            return result

        # 2. Check for common issues
        warnings = []

        # Check for bare except
        for node in ast.walk(tree):
            if isinstance(node, ast.ExceptHandler) and node.type is None:
                warnings.append(
                    f"Line {node.lineno}: Bare 'except:' catches all exceptions "
                    f"including KeyboardInterrupt — use 'except Exception:'"
                )

        # Check for mutable default arguments
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                for default in node.args.defaults:
                    if isinstance(default, (ast.List, ast.Dict, ast.Set)):
                        warnings.append(
                            f"Line {node.lineno}: Mutable default argument in "
                            f"'{node.name}' — use None and assign inside function"
                        )

        # Check for star imports
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom):
                for alias in node.names:
                    if alias.name == "*":
                        warnings.append(
                            f"Line {node.lineno}: Star import 'from {node.module} import *' "
                            f"— import specific names"
                        )

        result.warnings = warnings
        return result

    def _validate_typescript(self, code: str) -> ValidationResult:
        """Basic TypeScript/TSX validation"""
        result = ValidationResult(valid=True, language="typescript")

        # 1. Check balanced braces/parens/brackets
        stack = []
        pairs = {"}": "{", ")": "(", "]": "["}
        in_string = False
        string_char = None
        escaped = False

        for i, char in enumerate(code):
            if escaped:
                escaped = False
                continue
            if char == "\\":
                escaped = True
                continue
            if char in ('"', "'", "`") and not in_string:
                in_string = True
                string_char = char
                continue
            if char == string_char and in_string:
                in_string = False
                string_char = None
                continue
            if in_string:
                continue

            if char in "{([":
                stack.append((char, i))
            elif char in "})]":
                if not stack:
                    line = code[:i].count("\n") + 1
                    result.valid = False
                    result.errors.append(f"Unmatched '{char}' at line {line}")
                    return result
                top, _ = stack.pop()
                if top != pairs[char]:
                    line = code[:i].count("\n") + 1
                    result.valid = False
                    result.errors.append(
                        f"Mismatched brackets at line {line}: "
                        f"expected '{pairs[char]}', found '{char}'"
                    )
                    return result

        if stack:
            char, pos = stack[-1]
            line = code[:pos].count("\n") + 1
            result.valid = False
            result.errors.append(f"Unclosed '{char}' at line {line}")

        # 2. JSX balance check for .tsx files
        if "tsx" in result.language or "<" in code:
            jsx_issues = self._check_jsx_balance(code)
            result.warnings.extend(jsx_issues)

        # 3. Common anti-patterns
        if "any" in code and ": any" in code:
            result.warnings.append("Uses 'any' type — prefer specific types or generics")
        if "console.log" in code:
            result.warnings.append("Contains console.log — remove before production")
        if "// @ts-ignore" in code or "// @ts-nocheck" in code:
            result.warnings.append("Contains @ts-ignore/@ts-nocheck — fix the type errors instead")

        return result

    def _validate_javascript(self, code: str) -> ValidationResult:
        """Basic JavaScript/JSX validation"""
        result = self._validate_typescript(code)
        result.language = "javascript"
        return result

    def _check_jsx_balance(self, code: str) -> List[str]:
        """Check JSX tag balance (basic heuristic)"""
        warnings = []
        # Find self-closing tags (skip) and opening/closing tags
        self_closing = re.findall(r'<\w+[^>]*/>', code)
        opening = re.findall(r'<([A-Z]\w*)[^>/]*>', code)
        closing = re.findall(r'</([A-Z]\w*)>', code)

        open_counts: Dict[str, int] = {}
        close_counts: Dict[str, int] = {}

        for tag in opening:
            open_counts[tag] = open_counts.get(tag, 0) + 1
        for tag in closing:
            close_counts[tag] = close_counts.get(tag, 0) + 1

        for tag in set(list(open_counts.keys()) + list(close_counts.keys())):
            o = open_counts.get(tag, 0)
            c = close_counts.get(tag, 0)
            if o != c:
                warnings.append(
                    f"JSX tag <{tag}> mismatch: {o} opening vs {c} closing"
                )

        return warnings

    def _validate_json(self, code: str) -> ValidationResult:
        """Validate JSON"""
        result = ValidationResult(valid=True, language="json")
        try:
            json.loads(code)
        except json.JSONDecodeError as e:
            result.valid = False
            result.errors.append(f"JSON parse error at line {e.lineno}, col {e.colno}: {e.msg}")
        return result

    def _validate_yaml(self, code: str) -> ValidationResult:
        """Validate YAML (basic — check indentation consistency)"""
        result = ValidationResult(valid=True, language="yaml")

        # Check for tabs (YAML doesn't allow tabs for indentation)
        for i, line in enumerate(code.splitlines(), 1):
            if "\t" in line.split("#")[0]:  # Ignore tabs in comments
                result.warnings.append(f"Line {i}: Tab character in indentation (YAML requires spaces)")

        # Try to parse with yaml if available
        try:
            import yaml
            yaml.safe_load(code)
        except ImportError:
            pass  # yaml not installed, skip deep validation
        except Exception as e:
            result.valid = False
            result.errors.append(f"YAML parse error: {str(e)}")

        return result

    def _validate_sql(self, code: str) -> ValidationResult:
        """Basic SQL validation"""
        result = ValidationResult(valid=True, language="sql")

        # Check balanced parentheses
        depth = 0
        for char in code:
            if char == "(":
                depth += 1
            elif char == ")":
                depth -= 1
            if depth < 0:
                result.valid = False
                result.errors.append("Unmatched closing parenthesis ')'")
                return result
        if depth != 0:
            result.valid = False
            result.errors.append(f"Unclosed parenthesis — {depth} missing ')'")

        # Check for common SQL injection patterns
        if re.search(r'["\'].*\+.*["\']', code):
            result.warnings.append("Possible string concatenation in SQL — use parameterized queries")

        return result

    def _validate_shell(self, code: str) -> ValidationResult:
        """Basic shell script validation"""
        result = ValidationResult(valid=True, language="shell")

        # Check for shebang
        if not code.startswith("#!"):
            result.warnings.append("Missing shebang line (e.g., #!/bin/bash)")

        # Check for common issues
        if "rm -rf /" in code:
            result.valid = False
            result.errors.append("DANGEROUS: 'rm -rf /' detected!")

        # Check balanced quotes
        single = code.count("'") % 2
        double = code.count('"') % 2
        if single != 0:
            result.warnings.append("Unmatched single quotes")
        if double != 0:
            result.warnings.append("Unmatched double quotes")

        # Try bash -n syntax check if available
        try:
            with tempfile.NamedTemporaryFile(mode='w', suffix='.sh', delete=False) as f:
                f.write(code)
                f.flush()
                proc = subprocess.run(
                    ["bash", "-n", f.name],
                    capture_output=True, text=True, timeout=5
                )
                os.unlink(f.name)
                if proc.returncode != 0:
                    result.valid = False
                    result.errors.append(f"Bash syntax error: {proc.stderr.strip()}")
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass  # bash not available or timeout

        return result

    def _validate_dockerfile(self, code: str) -> ValidationResult:
        """Validate Dockerfile"""
        result = ValidationResult(valid=True, language="dockerfile")

        lines = code.splitlines()
        valid_instructions = {
            "FROM", "RUN", "CMD", "LABEL", "MAINTAINER", "EXPOSE",
            "ENV", "ADD", "COPY", "ENTRYPOINT", "VOLUME", "USER",
            "WORKDIR", "ARG", "ONBUILD", "STOPSIGNAL", "HEALTHCHECK", "SHELL"
        }

        has_from = False
        for i, line in enumerate(lines, 1):
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue

            # Check instruction
            parts = stripped.split(None, 1)
            if parts:
                instruction = parts[0].upper()
                if instruction == "FROM":
                    has_from = True
                elif instruction not in valid_instructions and not stripped.startswith("\\"):
                    # Could be a continuation line
                    if not any(
                        lines[j].rstrip().endswith("\\")
                        for j in range(max(0, i-2), i-1)
                    ):
                        result.warnings.append(
                            f"Line {i}: Unknown instruction '{parts[0]}'"
                        )

        if not has_from:
            result.valid = False
            result.errors.append("Dockerfile must start with FROM instruction")

        # Security checks
        if "RUN apt-get" in code and "rm -rf /var/lib/apt/lists" not in code:
            result.warnings.append("apt-get without cleanup — add '&& rm -rf /var/lib/apt/lists/*'")
        if "USER root" in code or (not any("USER" in l for l in lines)):
            result.warnings.append("Container runs as root — add USER instruction")

        return result

    def _validate_html(self, code: str) -> ValidationResult:
        """Basic HTML validation"""
        result = ValidationResult(valid=True, language="html")

        # Check for DOCTYPE
        if "<!DOCTYPE" not in code.upper() and "<html" in code.lower():
            result.warnings.append("Missing <!DOCTYPE html> declaration")

        return result

    # ─── Security checks ─────────────────────────────────

    def _check_security(self, code: str, language: str) -> Dict:
        """Run security pattern checks"""
        warnings = []
        has_issues = False

        for category, patterns in self.SECURITY_PATTERNS.items():
            for pattern in patterns:
                matches = re.findall(pattern, code)
                if matches:
                    has_issues = True
                    # Find line numbers
                    for i, line in enumerate(code.splitlines(), 1):
                        if re.search(pattern, line):
                            warnings.append(
                                f"Line {i}: {category.replace('_', ' ').title()} "
                                f"pattern detected"
                            )
                            break

        return {"warnings": warnings, "has_issues": has_issues}

    # ─── Batch validation ─────────────────────────────────

    def validate_files(self, files: Dict[str, str]) -> Dict[str, ValidationResult]:
        """Validate multiple files at once"""
        results = {}
        for filepath, content in files.items():
            results[filepath] = self.validate(filepath, content)
        return results

    def get_validation_report(self, files: Dict[str, str]) -> str:
        """Get formatted validation report"""
        results = self.validate_files(files)

        total = len(results)
        passed = sum(1 for r in results.values() if r.valid)
        failed = total - passed
        security_issues = sum(1 for r in results.values() if r.has_security_issues)

        report = f"""
🔍 CODE VALIDATION REPORT
{'═' * 50}

  Files:          {total}
  ✅ Passed:      {passed}
  ❌ Failed:      {failed}
  🔒 Security:    {security_issues} issues found

"""
        for filepath, result in results.items():
            icon = "✅" if result.valid else "❌"
            report += f"  {icon} {filepath} ({result.language}, {result.line_count} lines)\n"
            for error in result.errors:
                report += f"     ❌ {error}\n"
            for warning in result.warnings:
                report += f"     ⚠️ {warning}\n"

        return report

    # ═════════════════════════════════════════════════════
    #  LEVEL 3: External Tool Integration
    # ═════════════════════════════════════════════════════

    def validate_with_external_tools(
        self, filepath: str, content: str
    ) -> Dict[str, any]:
        """
        Level 3 validation — Run external security/lint tools if available.

        Tools checked (best-effort, tool must be installed):
        - Python:  ruff (linter), bandit (security), pip-audit (deps)
        - JS/TS:   eslint, tsc --noEmit
        - Secrets: gitleaks, detect-secrets
        - Container: trivy, hadolint

        Returns dict with tool results. Missing tools are silently skipped.
        """
        results = {
            "tools_run": [],
            "tools_skipped": [],
            "findings": [],
            "level": 3,
        }

        language = self.detect_language(filepath)

        # Write to temp file for tool execution
        import tempfile
        ext = os.path.splitext(filepath)[1]
        try:
            with tempfile.NamedTemporaryFile(
                mode='w', suffix=ext, delete=False, encoding='utf-8'
            ) as f:
                f.write(content)
                temp_path = f.name
        except Exception:
            return results

        try:
            if language == "python":
                self._run_ruff(temp_path, results)
                self._run_bandit(temp_path, results)
            elif language in ("javascript", "typescript",
                              "javascript-react", "typescript-react"):
                self._run_eslint(temp_path, results)
            elif language == "dockerfile":
                self._run_hadolint(temp_path, results)

            # Universal: secret scanning
            self._run_gitleaks(temp_path, results)

        finally:
            try:
                os.unlink(temp_path)
            except Exception:
                pass

        return results

    def _run_tool(
        self, cmd: List[str], tool_name: str, results: Dict
    ) -> Optional[str]:
        """Run an external tool, return stdout or None if not available"""
        try:
            proc = subprocess.run(
                cmd, capture_output=True, text=True, timeout=30
            )
            results["tools_run"].append(tool_name)
            return proc.stdout + proc.stderr
        except FileNotFoundError:
            results["tools_skipped"].append(
                f"{tool_name} (not installed)"
            )
            return None
        except subprocess.TimeoutExpired:
            results["tools_skipped"].append(
                f"{tool_name} (timeout)"
            )
            return None

    def _run_ruff(self, filepath: str, results: Dict):
        """Run ruff linter on Python code"""
        output = self._run_tool(
            ["ruff", "check", "--output-format=json", filepath],
            "ruff", results
        )
        if output:
            try:
                findings = json.loads(output)
                for f in findings[:10]:  # Limit to 10 findings
                    results["findings"].append({
                        "tool": "ruff",
                        "severity": "warning",
                        "rule": f.get("code", "?"),
                        "message": f.get("message", ""),
                        "line": f.get("location", {}).get("row", 0),
                    })
            except json.JSONDecodeError:
                pass

    def _run_bandit(self, filepath: str, results: Dict):
        """Run bandit security scanner on Python code"""
        output = self._run_tool(
            ["bandit", "-f", "json", "-q", filepath],
            "bandit", results
        )
        if output:
            try:
                data = json.loads(output)
                for issue in data.get("results", [])[:10]:
                    results["findings"].append({
                        "tool": "bandit",
                        "severity": issue.get("issue_severity", "MEDIUM"),
                        "rule": issue.get("test_id", "?"),
                        "message": issue.get("issue_text", ""),
                        "line": issue.get("line_number", 0),
                    })
            except json.JSONDecodeError:
                pass

    def _run_eslint(self, filepath: str, results: Dict):
        """Run ESLint on JS/TS code"""
        output = self._run_tool(
            ["npx", "eslint", "--format=json", "--no-eslintrc", filepath],
            "eslint", results
        )
        if output:
            try:
                data = json.loads(output)
                for file_result in data:
                    for msg in file_result.get("messages", [])[:10]:
                        results["findings"].append({
                            "tool": "eslint",
                            "severity": "warning" if msg.get("severity") == 1 else "error",
                            "rule": msg.get("ruleId", "?"),
                            "message": msg.get("message", ""),
                            "line": msg.get("line", 0),
                        })
            except json.JSONDecodeError:
                pass

    def _run_hadolint(self, filepath: str, results: Dict):
        """Run hadolint on Dockerfile"""
        output = self._run_tool(
            ["hadolint", "--format=json", filepath],
            "hadolint", results
        )
        if output:
            try:
                findings = json.loads(output)
                for f in findings[:10]:
                    results["findings"].append({
                        "tool": "hadolint",
                        "severity": f.get("level", "warning"),
                        "rule": f.get("code", "?"),
                        "message": f.get("message", ""),
                        "line": f.get("line", 0),
                    })
            except json.JSONDecodeError:
                pass

    def _run_gitleaks(self, filepath: str, results: Dict):
        """Run gitleaks for secret detection"""
        output = self._run_tool(
            ["gitleaks", "detect", "--source", filepath,
             "--report-format", "json", "--report-path", "/dev/stdout",
             "--no-git"],
            "gitleaks", results
        )
        if output:
            try:
                findings = json.loads(output)
                for f in findings[:10]:
                    results["findings"].append({
                        "tool": "gitleaks",
                        "severity": "critical",
                        "rule": f.get("RuleID", "secret"),
                        "message": f"Possible secret: {f.get('Description', '')}",
                        "line": f.get("StartLine", 0),
                    })
            except (json.JSONDecodeError, TypeError):
                pass

    def get_available_tools(self) -> Dict[str, bool]:
        """Check which external tools are installed"""
        tools = {}
        for tool_name, cmd in [
            ("ruff", ["ruff", "--version"]),
            ("bandit", ["bandit", "--version"]),
            ("eslint", ["npx", "eslint", "--version"]),
            ("hadolint", ["hadolint", "--version"]),
            ("gitleaks", ["gitleaks", "version"]),
            ("pip-audit", ["pip-audit", "--version"]),
            ("trivy", ["trivy", "--version"]),
        ]:
            try:
                subprocess.run(cmd, capture_output=True, timeout=5)
                tools[tool_name] = True
            except (FileNotFoundError, subprocess.TimeoutExpired):
                tools[tool_name] = False
        return tools
