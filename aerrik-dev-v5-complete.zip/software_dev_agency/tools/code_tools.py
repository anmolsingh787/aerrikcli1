"""
Code manipulation and analysis tools for agents
"""
import re
import ast
from typing import List, Dict, Optional


class CodeTools:
    """Tools for code analysis and manipulation"""

    def extract_functions(self, code: str) -> List[Dict[str, str]]:
        """Extract function definitions from Python code"""
        functions = []
        try:
            tree = ast.parse(code)
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    functions.append({
                        "name": node.name,
                        "line": node.lineno,
                        "args": [arg.arg for arg in node.args.args],
                        "decorators": [
                            ast.unparse(d) for d in node.decorator_list
                        ],
                    })
        except SyntaxError:
            pass
        return functions

    def extract_classes(self, code: str) -> List[Dict[str, str]]:
        """Extract class definitions from Python code"""
        classes = []
        try:
            tree = ast.parse(code)
            for node in ast.walk(tree):
                if isinstance(node, ast.ClassDef):
                    methods = [
                        n.name for n in node.body
                        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
                    ]
                    classes.append({
                        "name": node.name,
                        "line": node.lineno,
                        "methods": methods,
                        "bases": [ast.unparse(b) for b in node.bases],
                    })
        except SyntaxError:
            pass
        return classes

    def extract_imports(self, code: str) -> List[str]:
        """Extract import statements"""
        imports = []
        for line in code.splitlines():
            stripped = line.strip()
            if stripped.startswith("import ") or stripped.startswith("from "):
                imports.append(stripped)
        return imports

    def validate_python(self, code: str) -> Dict:
        """Basic Python syntax validation"""
        try:
            compile(code, "<string>", "exec")
            return {"valid": True, "error": None}
        except SyntaxError as e:
            return {"valid": False, "error": str(e), "line": e.lineno}

    def count_lines(self, code: str) -> Dict[str, int]:
        """Count different types of lines"""
        lines = code.splitlines()
        total = len(lines)
        blank = sum(1 for l in lines if not l.strip())
        comments = sum(1 for l in lines if l.strip().startswith("#"))
        code_lines = total - blank - comments
        return {
            "total": total,
            "code": code_lines,
            "comments": comments,
            "blank": blank,
        }
