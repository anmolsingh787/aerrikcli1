"""
File manipulation tools for agents
"""
import os
import re
from typing import List, Dict
from pathlib import Path


class FileTools:
    """Tools for file creation and manipulation"""

    def __init__(self, base_dir: str = "./output"):
        self.base_dir = base_dir
        os.makedirs(base_dir, exist_ok=True)

    def create_file(self, filepath: str, content: str) -> str:
        """Create a file with content"""
        full_path = os.path.join(self.base_dir, filepath)
        os.makedirs(os.path.dirname(full_path), exist_ok=True)

        with open(full_path, 'w', encoding='utf-8') as f:
            f.write(content)

        return f"✅ Created: {full_path}"

    def read_file(self, filepath: str) -> str:
        """Read a file"""
        full_path = os.path.join(self.base_dir, filepath)
        if os.path.exists(full_path):
            with open(full_path, 'r', encoding='utf-8') as f:
                return f.read()
        return f"❌ File not found: {full_path}"

    def delete_file(self, filepath: str) -> str:
        """Delete a file"""
        full_path = os.path.join(self.base_dir, filepath)
        if os.path.exists(full_path):
            os.remove(full_path)
            return f"🗑️ Deleted: {full_path}"
        return f"❌ File not found: {full_path}"

    def create_directory(self, dirpath: str) -> str:
        """Create a directory"""
        full_path = os.path.join(self.base_dir, dirpath)
        os.makedirs(full_path, exist_ok=True)
        return f"✅ Directory created: {full_path}"

    def list_files(self, dirpath: str = "") -> List[str]:
        """List all files in a directory"""
        full_path = os.path.join(self.base_dir, dirpath)
        files = []
        if os.path.exists(full_path):
            for root, dirs, filenames in os.walk(full_path):
                for filename in filenames:
                    rel_path = os.path.relpath(
                        os.path.join(root, filename), self.base_dir
                    )
                    files.append(rel_path)
        return files

    def create_project_structure(self, structure: Dict) -> List[str]:
        """
        Create a project structure from a dictionary.

        Example:
        {
            "src": {
                "components": {
                    "Button.tsx": "content...",
                    "Card.tsx": "content..."
                },
                "pages": {
                    "index.tsx": "content..."
                }
            },
            "package.json": "content..."
        }
        """
        created_files = []
        self._create_recursive(structure, "", created_files)
        return created_files

    def _create_recursive(self, structure: Dict, current_path: str,
                          created_files: List[str]):
        """Recursively create project structure"""
        for name, content in structure.items():
            path = os.path.join(current_path, name)
            if isinstance(content, dict):
                self.create_directory(path)
                self._create_recursive(content, path, created_files)
            else:
                self.create_file(path, str(content))
                created_files.append(path)

    def extract_files_from_response(self, llm_response: str) -> Dict[str, str]:
        """
        Extract file paths and contents from LLM response.

        Looks for patterns like:
        // filepath: src/components/Button.tsx
        # filepath: app/main.py
        ```typescript
        // src/components/Button.tsx
        ```
        """
        files = {}

        # Pattern 1: // filepath: or # filepath:
        pattern1 = r'(?://|#)\s*filepath:\s*(.+?)\n(.*?)(?=(?://|#)\s*filepath:|```|\Z)'
        matches = re.findall(pattern1, llm_response, re.DOTALL)
        for filepath, content in matches:
            files[filepath.strip()] = content.strip()

        # Pattern 2: ```language\n// path\n...```
        pattern2 = r'```\w*\n(?://|#)\s*(.+?)\n(.*?)```'
        matches = re.findall(pattern2, llm_response, re.DOTALL)
        for filepath, content in matches:
            clean_path = filepath.strip().rstrip(':')
            if clean_path not in files:
                files[clean_path] = content.strip()

        return files

    def save_extracted_files(self, llm_response: str) -> List[str]:
        """Extract files from LLM response and save them"""
        files = self.extract_files_from_response(llm_response)
        created = []
        for filepath, content in files.items():
            if content.strip():
                result = self.create_file(filepath, content)
                created.append(result)
                print(f"   📄 {result}")
        return created

    def write_readme(self, project_name: str, description: str) -> str:
        """Create a README.md file"""
        readme_content = f"""# {project_name}

{description}

## 🚀 Getting Started

### Prerequisites
- Node.js 18+ / Python 3.11+
- Docker (optional)

### Installation

```bash
# Clone the repository
git clone <repository-url>
cd {project_name.lower().replace(' ', '-')}

# Install dependencies
npm install  # or pip install -r requirements.txt
```

### Running the project

```bash
# Development
npm run dev  # or uvicorn main:app --reload

# Production
npm run build && npm start
```

## 📁 Project Structure
Generated by Software Development Agency 🏢

## 📝 License
MIT
"""
        return self.create_file("README.md", readme_content)
