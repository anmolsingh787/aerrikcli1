"""
Git-related tools for agents
"""
import os
import subprocess
from typing import Optional, List


class GitTools:
    """Tools for git operations"""

    def __init__(self, repo_path: str = "./output"):
        self.repo_path = repo_path

    def _run_git(self, args: List[str]) -> str:
        """Run a git command"""
        try:
            result = subprocess.run(
                ["git"] + args,
                cwd=self.repo_path,
                capture_output=True,
                text=True,
                timeout=30
            )
            if result.returncode == 0:
                return result.stdout
            return f"Git error: {result.stderr}"
        except Exception as e:
            return f"Git execution error: {str(e)}"

    def init_repo(self) -> str:
        """Initialize a git repository"""
        os.makedirs(self.repo_path, exist_ok=True)
        return self._run_git(["init"])

    def add_all(self) -> str:
        """Add all files"""
        return self._run_git(["add", "."])

    def commit(self, message: str) -> str:
        """Commit with message"""
        return self._run_git(["commit", "-m", message])

    def create_gitignore(self, project_type: str = "fullstack") -> str:
        """Create a .gitignore file"""
        gitignore_templates = {
            "fullstack": """# Dependencies
node_modules/
__pycache__/
*.pyc
.venv/
venv/

# Environment
.env
.env.local
.env.production

# Build
dist/
build/
.next/
out/

# IDE
.vscode/
.idea/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db

# Logs
*.log
logs/

# Testing
coverage/
.coverage
.pytest_cache/

# Docker
*.pid
""",
            "python": """__pycache__/
*.pyc
*.pyo
.venv/
venv/
.env
.pytest_cache/
coverage/
dist/
*.egg-info/
""",
            "node": """node_modules/
dist/
.next/
.env
.env.local
npm-debug.log*
yarn-debug.log*
yarn-error.log*
coverage/
""",
        }

        content = gitignore_templates.get(project_type, gitignore_templates["fullstack"])
        gitignore_path = os.path.join(self.repo_path, ".gitignore")
        with open(gitignore_path, "w") as f:
            f.write(content)
        return f"✅ Created .gitignore at {gitignore_path}"

    def get_status(self) -> str:
        """Get git status"""
        return self._run_git(["status", "--short"])

    def get_log(self, n: int = 10) -> str:
        """Get git log"""
        return self._run_git(["log", f"-{n}", "--oneline"])
