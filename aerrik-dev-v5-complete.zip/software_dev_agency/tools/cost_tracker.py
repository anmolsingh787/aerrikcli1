"""
💰 Cost Tracker — Token counting, cost estimation, and budget enforcement

Tracks LLM API usage across all agents with per-model pricing.
Prevents runaway costs with budget limits and real-time tracking.
"""
import time
import json
import os
from typing import Dict, Optional, List
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path


# ─── Pricing per 1M tokens (USD) ───────────────────────────
# Updated July 2026 — verify at provider dashboards
MODEL_PRICING = {
    # OpenAI
    "gpt-4":          {"input": 30.00, "output": 60.00},
    "gpt-4-turbo":    {"input": 10.00, "output": 30.00},
    "gpt-4o":         {"input": 2.50,  "output": 10.00},
    "gpt-4o-mini":    {"input": 0.15,  "output": 0.60},
    "gpt-3.5-turbo":  {"input": 0.50,  "output": 1.50},
    "o1-preview":     {"input": 15.00, "output": 60.00},
    "o1-mini":        {"input": 3.00,  "output": 12.00},

    # Anthropic
    "claude-opus-4":       {"input": 15.00, "output": 75.00},
    "claude-sonnet-4":     {"input": 3.00,  "output": 15.00},
    "claude-haiku-3.5":    {"input": 0.80,  "output": 4.00},
    "claude-3.5-sonnet":   {"input": 3.00,  "output": 15.00},
    "claude-3-haiku":      {"input": 0.25,  "output": 1.25},

    # Google
    "gemini-2.5-pro":      {"input": 1.25,  "output": 10.00},
    "gemini-2.5-flash":    {"input": 0.15,  "output": 0.60},
    "gemini-2.0-flash":    {"input": 0.10,  "output": 0.40},

    # Groq
    "llama-3.3-70b":       {"input": 0.59,  "output": 0.79},
    "llama-3.1-8b":        {"input": 0.05,  "output": 0.08},
    "mixtral-8x7b":        {"input": 0.24,  "output": 0.24},

    # DeepSeek
    "deepseek-chat":       {"input": 0.27,  "output": 1.10},
    "deepseek-reasoner":   {"input": 0.55,  "output": 2.19},

    # Mock/default
    "mock":                {"input": 0.00,  "output": 0.00},
}

DEFAULT_PRICING = {"input": 5.00, "output": 15.00}  # Conservative fallback


@dataclass
class UsageRecord:
    """Single API call record"""
    timestamp: str
    agent_name: str
    model: str
    input_tokens: int
    output_tokens: int
    cost_usd: float
    latency_ms: float
    task_title: str = ""
    success: bool = True
    error: str = ""


@dataclass
class AgentUsage:
    """Aggregated usage per agent"""
    agent_name: str
    total_calls: int = 0
    total_input_tokens: int = 0
    total_output_tokens: int = 0
    total_cost_usd: float = 0.0
    total_latency_ms: float = 0.0
    errors: int = 0
    models_used: Dict[str, int] = field(default_factory=dict)


class CostTracker:
    """
    💰 Cost Tracker

    Features:
    - Real-time token counting per agent
    - Cost estimation using model pricing
    - Budget enforcement (stop when limit reached)
    - Session history with persistence
    - Per-agent breakdown
    - Cost warnings at thresholds
    """

    def __init__(
        self,
        budget_usd: float = 5.0,
        warning_threshold: float = 0.7,
        storage_path: str = "./memory_data",
    ):
        self.budget_usd = budget_usd
        self.warning_threshold = warning_threshold  # 70% = warn
        self.storage_path = storage_path
        os.makedirs(storage_path, exist_ok=True)

        self.records: List[UsageRecord] = []
        self.agent_usage: Dict[str, AgentUsage] = {}
        self.session_start = datetime.now()
        self._budget_warned = False
        self._budget_exceeded = False

    # ─── Core tracking ────────────────────────────────────

    def estimate_tokens(self, text: str) -> int:
        """
        Rough token estimation (~4 chars per token for English, ~2 for code).
        For precise counts, use tiktoken.
        """
        if not text:
            return 0
        # Average: ~3.5 chars per token (mix of code + prose)
        return max(1, len(text) // 4)

    def calculate_cost(self, model: str, input_tokens: int, output_tokens: int) -> float:
        """Calculate cost in USD for a single API call"""
        pricing = MODEL_PRICING.get(model, DEFAULT_PRICING)
        input_cost = (input_tokens / 1_000_000) * pricing["input"]
        output_cost = (output_tokens / 1_000_000) * pricing["output"]
        return round(input_cost + output_cost, 6)

    def record_call(
        self,
        agent_name: str,
        model: str,
        input_text: str,
        output_text: str,
        latency_ms: float = 0,
        task_title: str = "",
        success: bool = True,
        error: str = "",
        input_tokens: int = 0,
        output_tokens: int = 0,
    ) -> UsageRecord:
        """Record a single LLM API call"""
        # Use provided tokens or estimate
        if input_tokens == 0:
            input_tokens = self.estimate_tokens(input_text)
        if output_tokens == 0:
            output_tokens = self.estimate_tokens(output_text)

        cost = self.calculate_cost(model, input_tokens, output_tokens)

        record = UsageRecord(
            timestamp=datetime.now().isoformat(),
            agent_name=agent_name,
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cost_usd=cost,
            latency_ms=latency_ms,
            task_title=task_title,
            success=success,
            error=error,
        )

        self.records.append(record)
        self._update_agent_usage(record)
        self._check_budget()

        return record

    def _update_agent_usage(self, record: UsageRecord):
        """Update per-agent aggregated stats"""
        name = record.agent_name
        if name not in self.agent_usage:
            self.agent_usage[name] = AgentUsage(agent_name=name)

        au = self.agent_usage[name]
        au.total_calls += 1
        au.total_input_tokens += record.input_tokens
        au.total_output_tokens += record.output_tokens
        au.total_cost_usd += record.cost_usd
        au.total_latency_ms += record.latency_ms
        if not record.success:
            au.errors += 1

        model = record.model
        au.models_used[model] = au.models_used.get(model, 0) + 1

    def _check_budget(self):
        """Check budget thresholds and set flags"""
        total = self.get_total_cost()

        if total >= self.budget_usd:
            self._budget_exceeded = True
        elif total >= self.budget_usd * self.warning_threshold:
            self._budget_warned = True

    # ─── Getters ──────────────────────────────────────────

    def get_total_cost(self) -> float:
        """Get total session cost in USD"""
        return round(sum(r.cost_usd for r in self.records), 6)

    def get_total_tokens(self) -> Dict[str, int]:
        """Get total token counts"""
        return {
            "input": sum(r.input_tokens for r in self.records),
            "output": sum(r.output_tokens for r in self.records),
            "total": sum(r.input_tokens + r.output_tokens for r in self.records),
        }

    def get_total_calls(self) -> int:
        """Get total API calls made"""
        return len(self.records)

    def get_average_latency(self) -> float:
        """Get average call latency in ms"""
        if not self.records:
            return 0
        return sum(r.latency_ms for r in self.records) / len(self.records)

    def is_budget_exceeded(self) -> bool:
        """Check if budget has been exceeded"""
        return self._budget_exceeded

    def is_budget_warning(self) -> bool:
        """Check if budget warning threshold reached"""
        return self._budget_warned

    def get_budget_remaining(self) -> float:
        """Get remaining budget in USD"""
        return max(0, self.budget_usd - self.get_total_cost())

    def get_cost_breakdown_by_agent(self) -> Dict[str, Dict]:
        """Get cost breakdown per agent"""
        result = {}
        for name, usage in self.agent_usage.items():
            result[name] = {
                "calls": usage.total_calls,
                "input_tokens": usage.total_input_tokens,
                "output_tokens": usage.total_output_tokens,
                "cost_usd": round(usage.total_cost_usd, 4),
                "errors": usage.errors,
                "models": usage.models_used,
            }
        return result

    def get_cost_breakdown_by_model(self) -> Dict[str, Dict]:
        """Get cost breakdown per model"""
        models: Dict[str, Dict] = {}
        for r in self.records:
            if r.model not in models:
                models[r.model] = {"calls": 0, "tokens": 0, "cost_usd": 0.0}
            models[r.model]["calls"] += 1
            models[r.model]["tokens"] += r.input_tokens + r.output_tokens
            models[r.model]["cost_usd"] += r.cost_usd

        for m in models:
            models[m]["cost_usd"] = round(models[m]["cost_usd"], 4)
        return models

    # ─── Reporting ────────────────────────────────────────

    def get_summary(self) -> str:
        """Get formatted cost summary"""
        total_cost = self.get_total_cost()
        tokens = self.get_total_tokens()
        calls = self.get_total_calls()
        duration = datetime.now() - self.session_start
        budget_pct = (total_cost / self.budget_usd * 100) if self.budget_usd > 0 else 0

        # Budget status
        if self._budget_exceeded:
            status = "🔴 EXCEEDED"
        elif self._budget_warned:
            status = "🟡 WARNING"
        else:
            status = "🟢 OK"

        summary = f"""
💰 SESSION COST REPORT
{'═' * 50}

  Status:        {status}
  Budget:        ${self.budget_usd:.2f}
  Spent:         ${total_cost:.4f} ({budget_pct:.1f}%)
  Remaining:     ${self.get_budget_remaining():.4f}

  API Calls:     {calls}
  Input Tokens:  {tokens['input']:,}
  Output Tokens: {tokens['output']:,}
  Total Tokens:  {tokens['total']:,}
  Avg Latency:   {self.get_average_latency():.0f}ms
  Duration:      {str(duration).split('.')[0]}

"""
        # Agent breakdown
        if self.agent_usage:
            summary += "  AGENT BREAKDOWN:\n"
            summary += f"  {'─' * 46}\n"
            for name, usage in sorted(
                self.agent_usage.items(),
                key=lambda x: x[1].total_cost_usd,
                reverse=True
            ):
                summary += (
                    f"  {name:30s} │ ${usage.total_cost_usd:.4f} │ "
                    f"{usage.total_calls} calls │ {usage.errors} errors\n"
                )

        # Model breakdown
        model_breakdown = self.get_cost_breakdown_by_model()
        if model_breakdown:
            summary += f"\n  MODEL BREAKDOWN:\n"
            summary += f"  {'─' * 46}\n"
            for model, data in sorted(
                model_breakdown.items(),
                key=lambda x: x[1]["cost_usd"],
                reverse=True
            ):
                summary += (
                    f"  {model:30s} │ ${data['cost_usd']:.4f} │ "
                    f"{data['tokens']:,} tokens\n"
                )

        return summary

    def get_compact_summary(self) -> str:
        """One-line cost summary for terminal prompt/status"""
        total = self.get_total_cost()
        tokens = self.get_total_tokens()
        calls = self.get_total_calls()

        if self._budget_exceeded:
            icon = "🔴"
        elif self._budget_warned:
            icon = "🟡"
        else:
            icon = "🟢"

        return f"{icon} ${total:.4f} / ${self.budget_usd:.2f} │ {calls} calls │ {tokens['total']:,} tokens"

    # ─── Persistence ──────────────────────────────────────

    def save(self, filename: str = None) -> str:
        """Save session data to disk"""
        if filename is None:
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"cost_session_{ts}.json"

        filepath = os.path.join(self.storage_path, filename)
        data = {
            "session_start": self.session_start.isoformat(),
            "budget_usd": self.budget_usd,
            "total_cost": self.get_total_cost(),
            "total_tokens": self.get_total_tokens(),
            "total_calls": self.get_total_calls(),
            "records": [
                {
                    "timestamp": r.timestamp,
                    "agent_name": r.agent_name,
                    "model": r.model,
                    "input_tokens": r.input_tokens,
                    "output_tokens": r.output_tokens,
                    "cost_usd": r.cost_usd,
                    "latency_ms": r.latency_ms,
                    "task_title": r.task_title,
                    "success": r.success,
                    "error": r.error,
                }
                for r in self.records
            ],
        }

        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)

        return filepath

    def estimate_project_cost(self, description: str, model: str = "gpt-4") -> Dict:
        """
        Estimate cost for a full project build BEFORE starting.
        Based on empirical averages from real builds.
        """
        # Average tokens per step (empirical)
        estimates = {
            "architecture":    {"input": 2000, "output": 3000, "calls": 1},
            "project_plan":    {"input": 4000, "output": 2500, "calls": 1},
            "task_breakdown":  {"input": 5000, "output": 2000, "calls": 1},
            "per_task_avg":    {"input": 1500, "output": 2500, "calls": 1},
        }

        # Estimate number of tasks based on description length/complexity
        word_count = len(description.split())
        if word_count < 20:
            est_tasks = 4
        elif word_count < 50:
            est_tasks = 8
        elif word_count < 100:
            est_tasks = 12
        else:
            est_tasks = 18

        total_input = (
            estimates["architecture"]["input"]
            + estimates["project_plan"]["input"]
            + estimates["task_breakdown"]["input"]
            + (estimates["per_task_avg"]["input"] * est_tasks)
        )
        total_output = (
            estimates["architecture"]["output"]
            + estimates["project_plan"]["output"]
            + estimates["task_breakdown"]["output"]
            + (estimates["per_task_avg"]["output"] * est_tasks)
        )
        total_calls = 3 + est_tasks  # 3 setup calls + per-task
        total_cost = self.calculate_cost(model, total_input, total_output)

        return {
            "estimated_tasks": est_tasks,
            "estimated_calls": total_calls,
            "estimated_input_tokens": total_input,
            "estimated_output_tokens": total_output,
            "estimated_total_tokens": total_input + total_output,
            "estimated_cost_usd": round(total_cost, 4),
            "model": model,
            "budget_remaining": self.get_budget_remaining(),
            "within_budget": total_cost <= self.get_budget_remaining(),
        }
