"""
🐕 Aerrik Dog — 2D animated terminal companion

A cute ASCII dog that reacts to agent activity:
- Idle: sits and looks around
- Thinking: thought bubble with dots
- Working: running animation
- Happy: wagging tail
- Error: sad face
- Sleeping: zzz
"""
import time
import threading
import sys
from typing import Optional

# ─── Dog Frames ─────────────────────────────────────────

DOG_IDLE = [
    r"""
    ╭──────╮
    │ ◕ ᴗ ◕│  aerrik
    │  ▼   │  .dev
    ╰──┬┬──╯
       ││
    ╭──┘└──╮
    │      │
    ╰┬────┬╯
     ╵    ╵
    """,
    r"""
    ╭──────╮
    │ ◕ ᴗ ◕│  aerrik
    │  ▽   │  .dev
    ╰──┬┬──╯
       ││
    ╭──┘└──╮
    │      │
    ╰┬────┬╯
     ╵    ╵
    """,
]

DOG_THINK = [
    r"""
      ·  ·
     · ·· ·
    ╭──────╮
    │ ◑ ◑  │  hmm...
    │  ―   │
    ╰──┬┬──╯
       ││
    ╭──┘└──╮
    │      │
    ╰┬────┬╯
     ╵    ╵
    """,
    r"""
      ··
     · ·· ··
    ╭──────╮
    │ ◑ ◑  │  thinking
    │  ―   │
    ╰──┬┬──╯
       ││
    ╭──┘└──╮
    │      │
    ╰┬────┬╯
     ╵    ╵
    """,
    r"""
       ··
     ···  ·
    ╭──────╮
    │ ◑ ◑  │  ...
    │  ∪   │
    ╰──┬┬──╯
       ││
    ╭──┘└──╮
    │      │
    ╰┬────┬╯
     ╵    ╵
    """,
]

DOG_RUN = [
    r"""
    ╭──────╮
    │ ◕ ◕  │
    │  ▽   │  woosh!
    ╰──┬┬──╯
      ╱││╲
    ╭╱  └╲╮
    ╱      ╲
    ┘      └
    """,
    r"""
    ╭──────╮
    │ ◕ ◕  │
    │  ▽   │
    ╰──┬┬──╯
     ╱││╲
    ╭╱ └╲╮
    │    │
    └    ┘
    """,
]

DOG_HAPPY = [
    r"""
    ╭──────╮
    │ ★ ᴗ ★│  yay!
    │  ▽   │  woof!
    ╰──┬┬──╯
       ││  ~
    ╭──┘└──╮
    │      │
    ╰┬────┬╯
     ╵    ╵~
    """,
    r"""
    ╭──────╮
    │ ★ ᴗ ★│
    │  ▽   │  ~woof!
    ╰──┬┬──╯
       ││~
    ╭──┘└──╮
    │      │
    ╰┬────┬╯
    ~╵    ╵
    """,
]

DOG_SAD = [
    r"""
    ╭──────╮
    │ ◔ ◔  │  oh no
    │  ∧   │
    ╰──┬┬──╯
       ││
    ╭──┘└──╮
    │      │
    ╰┬────┬╯
     ╵    ╵
    """,
]

DOG_SLEEP = [
    r"""
              z
    ╭──────╮ z
    │ ┑ ┒  │z  zz..
    │  ‿   │
    ╰──┬┬──╯
       ││
    ╭──┘└──╮
    │      │
    ╰┬────┬╯
     ╵    ╵
    """,
    r"""
             z
    ╭──────╮z
    │ ┑ ┒  │  zZ..
    │  ‿   │
    ╰──┬┬──╯
       ││
    ╭──┘└──╮
    │      │
    ╰┬────┬╯
     ╵    ╵
    """,
]

DOG_BARK = [
    r"""
    ╭──────╮
    │ ◕ ◕  │
    │  О   │  WOOF!
    ╰──┬┬──╯  ★
       ││
    ╭──┘└──╮
    │      │
    ╰┬────┬╯
     ╵    ╵
    """,
]

# ─── State-based frame sets ────────────────────────────
DOG_STATES = {
    "idle":    DOG_IDLE,
    "think":   DOG_THINK,
    "run":     DOG_RUN,
    "happy":   DOG_HAPPY,
    "sad":     DOG_SAD,
    "sleep":   DOG_SLEEP,
    "bark":    DOG_BARK,
}

# ─── Agent → Dog mood mapping ──────────────────────────
AGENT_MOODS = {
    "architect":  "think",
    "pm":         "think",
    "frontend":   "run",
    "backend":    "run",
    "database":   "think",
    "devops":     "run",
    "tester":     "think",
    "designer":   "happy",
}


class AerrikDog:
    """
    🐕 Animated terminal dog companion

    Usage:
        dog = AerrikDog()
        dog.set_state("think")    # When agent is thinking
        dog.set_state("run")      # When agent is working
        dog.set_state("happy")    # When task completes
        dog.set_state("sad")      # When error occurs
        dog.set_state("idle")     # Default state
    """

    def __init__(self, animated: bool = True, speed: float = 0.4):
        self.state = "idle"
        self.frame_index = 0
        self.animated = animated
        self.speed = speed
        self._message = ""
        self._agent_name = ""
        self._running = False
        self._thread: Optional[threading.Thread] = None

    def set_state(self, state: str, message: str = "", agent_name: str = ""):
        """Set dog state"""
        if state not in DOG_STATES:
            state = "idle"
        self.state = state
        self._message = message
        self._agent_name = agent_name
        self.frame_index = 0

    def set_agent_mood(self, agent_key: str, is_working: bool = True):
        """Set mood based on agent activity"""
        if is_working:
            self.set_state(
                AGENT_MOODS.get(agent_key, "think"),
                agent_name=agent_key,
            )
        else:
            self.set_state("idle")

    def get_frame(self) -> str:
        """Get current animation frame"""
        frames = DOG_STATES.get(self.state, DOG_IDLE)
        frame = frames[self.frame_index % len(frames)]
        self.frame_index += 1
        return frame

    def get_static(self) -> str:
        """Get static (non-animated) dog for current state"""
        frames = DOG_STATES.get(self.state, DOG_IDLE)
        return frames[0]

    def render(self) -> str:
        """Render dog with optional status line"""
        frame = self.get_frame()

        if self._message:
            frame += f"\n    💬 {self._message}\n"

        return frame

    def get_compact(self) -> str:
        """One-line compact dog for inline display"""
        compact = {
            "idle":  "🐕 aerrik",
            "think": "🐕💭 hmm...",
            "run":   "🐕💨 woosh!",
            "happy": "🐕✨ woof!",
            "sad":   "🐕💧 oh no",
            "sleep": "🐕💤 zz..",
            "bark":  "🐕🔊 WOOF!",
        }
        return compact.get(self.state, "🐕 aerrik")

    # ─── Rich Panel Rendering ─────────────────────────

    def to_panel_content(self) -> str:
        """Get dog formatted for Rich panel"""
        return self.get_frame()

    def get_status_line(self) -> str:
        """Get a status line showing dog + active agent"""
        compact = self.get_compact()
        if self._agent_name:
            return f"  {compact} │ watching [cyan]{self._agent_name}[/]"
        return f"  {compact}"

    # ─── Animation for rich Live ──────────────────────

    def animate_sequence(self, states: list, durations: list = None):
        """Play a sequence of animations (blocking)"""
        if durations is None:
            durations = [0.5] * len(states)

        for state, dur in zip(states, durations):
            self.set_state(state)
            time.sleep(dur)

        self.set_state("idle")

    # ─── Celebration! ─────────────────────────────────

    def celebrate(self):
        """Play happy animation"""
        self.set_state("happy", message="Build complete! 🎉")

    def error(self, error_message: str = ""):
        """Show sad face + bark on error"""
        self.set_state("bark", message=f"WOOF! Error detected! 🚨 {error_message}")
        # After bark, switch to sad
        self._error_message = error_message

    def post_error(self):
        """Switch to sad state after barking"""
        self.set_state("sad", message=self._error_message or "Something went wrong...")

    def welcome(self) -> str:
        """Welcome message with dog"""
        return f"""
    ╭───────────────────────────────────────────╮
    │  ╭──────╮                                 │
    │  │ ◕ ᴗ ◕│  Welcome to aerrik.dev!        │
    │  │  ▽   │                                 │
    │  ╰──┬┬──╯  I'm Aerrik, your AI dev dog!  │
    │     ││                                    │
    │  ╭──┘└──╮  I'll help you build software  │
    │  │      │  with my agent family.          │
    │  ╰┬────┬╯                                 │
    │   ╵    ╵   woof! 🐾                       │
    ╰───────────────────────────────────────────╯
"""

    def goodbye(self) -> str:
        """Goodbye message"""
        return """
    ╭──────╮
    │ ◕ ᴗ ◕│  bye bye!
    │  ▽   │  see you soon!
    ╰──┬┬──╯  woof! 🐾
       ││
    ╭──┘└──╮
    │      │
    ╰┬────┬╯
     ╵    ╵
"""
