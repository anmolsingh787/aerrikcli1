"""
🖥️ Terminal Interface - Claude Code Style REPL for Software Dev Agency
Full interactive terminal experience with:
- @agent mentions to switch agents
- /slash commands
- Rich formatting, spinners, panels
- Conversation history
- Code highlighting
- Multi-agent chat
"""
import os
import sys
import re
import time
from typing import Optional, Dict, List
from datetime import datetime

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.syntax import Syntax
from rich.markdown import Markdown
from rich.text import Text
from rich.live import Live
from rich.spinner import Spinner
from rich.columns import Columns
from rich.rule import Rule
from rich.prompt import Prompt, Confirm
from rich.layout import Layout
from rich.align import Align
from rich.progress import Progress, SpinnerColumn, TextColumn

# Path setup
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from main import SoftwareDevAgency
from agents.base_agent import Task
from skills.skills_loader import SkillsLoader

console = Console()


# ============ WELCOME SCREEN ============

WELCOME_ART = r"""
[bold cyan]  ╔═══════════════════════════════════════════════════════════╗[/]
[bold cyan]  ║[/]                                                           [bold cyan]║[/]
[bold cyan]  ║[/]   [bold magenta]🏢  SOFTWARE DEVELOPMENT AGENCY[/]                      [bold cyan]║[/]
[bold cyan]  ║[/]   [dim]Multi-Agent AI Terminal • v2.0[/]                        [bold cyan]║[/]
[bold cyan]  ║[/]                                                           [bold cyan]║[/]
[bold cyan]  ║[/]   [cyan]👨‍💼[/] Dad (Architect)   [green]👦[/] Backend Boy   [blue]👦[/] DevOps Boy    [bold cyan]║[/]
[bold cyan]  ║[/]   [yellow]👩‍💼[/] Mommy (PM)       [green]👦[/] Database Boy  [red]👧[/] Tester Girl   [bold cyan]║[/]
[bold cyan]  ║[/]   [cyan]👧[/] Frontend Girl     [magenta]👧[/] Designer Girl                   [bold cyan]║[/]
[bold cyan]  ║[/]                                                           [bold cyan]║[/]
[bold cyan]  ╚═══════════════════════════════════════════════════════════╝[/]
"""


HELP_TEXT = """
[bold cyan]SLASH COMMANDS[/bold cyan]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  [bold]/help[/bold]              Show this help
  [bold]/status[/bold]            Show all agents status
  [bold]/tree[/bold]              Show family tree
  [bold]/skills[/bold]            Show loaded skills
  [bold]/switch[/bold] [color cyan]<agent>[/color cyan]   Switch active agent
  [bold]/build[/bold] [color cyan]<desc>[/color cyan]      Build a complete project
  [bold]/agents[/bold]            List available agents
  [bold]/history[/bold]           Show conversation history
  [bold]/clear[/bold]             Clear screen
  [bold]/exit[/bold]              Exit agency

[bold cyan]@MENTIONS (Quick Switch)[/bold cyan]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  [bold]@dad[/bold] or [bold]@architect[/bold]   Ask the Architect
  [bold]@mommy[/bold] or [bold]@pm[/bold]        Ask the Project Manager
  [bold]@frontend[/bold]            Ask Frontend Developer
  [bold]@backend[/bold]             Ask Backend Developer
  [bold]@database[/bold]            Ask Database Expert
  [bold]@devops[/bold]              Ask DevOps Engineer
  [bold]@tester[/bold]              Ask QA Tester
  [bold]@designer[/bold]            Ask UI/UX Designer

[bold cyan]EXAMPLES[/bold cyan]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  [dim]>[/dim] @frontend Create a responsive navbar with dark mode
  [dim]>[/dim] @backend Build JWT authentication API
  [dim]>[/dim] /build Todo app with React + FastAPI + PostgreSQL
  [dim]>[/dim] Design microservices for e-commerce platform
"""


# ============ AGENT CONFIGS ============

AGENT_ALIASES = {
    "@dad": "architect", "@architect": "architect",
    "@mommy": "pm", "@pm": "pm",
    "@frontend": "frontend", "@fe": "frontend",
    "@backend": "backend", "@be": "backend",
    "@database": "database", "@db": "database",
    "@devops": "devops", "@ops": "devops",
    "@tester": "tester", "@qa": "tester",
    "@designer": "designer", "@ux": "designer",
}

AGENT_EMOJIS = {
    "architect": "👨‍💼",
    "pm": "👩‍💼",
    "frontend": "👧",
    "backend": "👦",
    "database": "👦",
    "devops": "👦",
    "tester": "👧",
    "designer": "👧",
}

AGENT_COLORS = {
    "architect": "magenta",
    "pm": "yellow",
    "frontend": "cyan",
    "backend": "green",
    "database": "blue",
    "devops": "blue",
    "tester": "red",
    "designer": "magenta",
}


# ============ TERMINAL CLASS ============

class AgencyTerminal:
    """
    🖥️ Claude Code-style Terminal Interface for the Agency
    """

    def __init__(self, api_key: str = ""):
        self.api_key = api_key
        self.agency: Optional[SoftwareDevAgency] = None
        self.active_agent_key = "architect"
        self.history: List[Dict] = []
        self.session_start = datetime.now()
        self.message_count = 0

    def _get_agent_map(self) -> Dict:
        """Get mapping of agent keys to agent objects"""
        f = self.agency.family
        return {
            "architect": f.dad,
            "pm": f.mommy,
            "frontend": f.frontend_girl,
            "backend": f.backend_boy,
            "database": f.database_boy,
            "devops": f.devops_boy,
            "tester": f.tester_girl,
            "designer": f.designer_girl,
        }

    def _get_active_agent(self):
        """Get the currently active agent"""
        return self._get_agent_map().get(self.active_agent_key)

    # ============ INITIALIZATION ============

    def start(self):
        """Start the terminal session"""
        console.clear()

        # Show welcome
        console.print(WELCOME_ART)

        # Initialize agency with spinner
        with console.status("[bold green]🏠 Building the agency family...[/bold green]", spinner="dots"):
            self.agency = SoftwareDevAgency(api_key=self.api_key, verbose=False)
            time.sleep(0.5)

        console.print("[bold green]✅ Agency ready![/bold green]\n")

        # Show skills
        loader = SkillsLoader()
        skills_count = len(loader.list_skills())
        console.print(f"[dim]📚 {skills_count} skills loaded • 8 agents online • Type [bold]/help[/bold] for commands[/dim]\n")

        # Show quick tips
        console.print(Panel(
            "[bold]Quick Start:[/bold] Type [cyan]@frontend[/cyan] or [cyan]@backend[/cyan] to switch agents, "
            "or just type to talk to [magenta]@dad[/magenta] (Architect)\n"
            "[dim]Press Ctrl+C or type /exit to quit[/dim]",
            title="[bold cyan]💡 Tip[/bold cyan]",
            border_style="dim",
            expand=False
        ))
        console.print()

        # Enter REPL
        self._repl()

    # ============ REPL LOOP ============

    def _repl(self):
        """Main Read-Eval-Print Loop"""
        while True:
            try:
                # Build prompt with active agent info
                agent = self._get_active_agent()
                emoji = AGENT_EMOJIS.get(self.active_agent_key, "🤖")
                color = AGENT_COLORS.get(self.active_agent_key, "white")
                agent_name = agent.name if agent else "Unknown"

                prompt_text = f"[bold {color}]{emoji} {agent_name}[/bold {color}] [dim]>[/dim] "

                user_input = console.input(prompt_text).strip()

                if not user_input:
                    continue

                # Process input
                self._process_input(user_input)

            except KeyboardInterrupt:
                console.print("\n\n[bold yellow]👋 Goodbye! See you next time.[/bold yellow]")
                break
            except EOFError:
                console.print("\n[bold yellow]👋 EOF received. Exiting.[/bold yellow]")
                break
            except Exception as e:
                console.print(f"[red]❌ Error: {str(e)}[/red]")

    def _process_input(self, user_input: str):
        """Process user input - handle commands, @mentions, and chat"""

        # Slash commands
        if user_input.startswith("/"):
            self._handle_command(user_input)
            return

        # Check for @mention
        target_agent = self._parse_mention(user_input)
        if target_agent:
            # Remove the @mention from the message
            for alias, key in AGENT_ALIASES.items():
                if key == target_agent:
                    user_input = user_input.replace(alias, "", 1).strip()
                    break
            self.active_agent_key = target_agent

        # Empty message after stripping mention
        if not user_input:
            console.print("[yellow]⚠️ Please type a message after the @mention[/yellow]")
            return

        # Record in history
        self.history.append({
            "role": "user",
            "content": user_input,
            "agent": self.active_agent_key,
            "timestamp": datetime.now().isoformat()
        })
        self.message_count += 1

        # Send to agent
        self._send_to_agent(user_input)

    def _parse_mention(self, text: str) -> Optional[str]:
        """Parse @agent mention from text"""
        text_lower = text.lower().split()[0] if text.split() else ""
        return AGENT_ALIASES.get(text_lower)

    # ============ COMMANDS ============

    def _handle_command(self, cmd_input: str):
        """Handle slash commands"""
        parts = cmd_input.split(maxsplit=1)
        cmd = parts[0].lower()
        arg = parts[1] if len(parts) > 1 else ""

        commands = {
            "/help": self._cmd_help,
            "/status": self._cmd_status,
            "/tree": self._cmd_tree,
            "/skills": self._cmd_skills,
            "/agents": self._cmd_agents,
            "/switch": self._cmd_switch,
            "/build": self._cmd_build,
            "/history": self._cmd_history,
            "/clear": self._cmd_clear,
            "/exit": self._cmd_exit,
            "/quit": self._cmd_exit,
        }

        handler = commands.get(cmd)
        if handler:
            handler(arg)
        else:
            console.print(f"[red]❌ Unknown command: {cmd}[/red]")
            console.print("[dim]Type /help for available commands[/dim]")

    def _cmd_help(self, arg: str = ""):
        """Show help"""
        console.print(Panel(HELP_TEXT, title="[bold cyan]📖 Help[/bold cyan]", border_style="cyan"))

    def _cmd_status(self, arg: str = ""):
        """Show agent status"""
        table = Table(
            title="🏢 Agency Status",
            show_header=True,
            header_style="bold magenta",
            border_style="dim"
        )
        table.add_column("Agent", style="cyan")
        table.add_column("Role", style="green")
        table.add_column("Status", justify="center")
        table.add_column("Active", justify="center")
        table.add_column("Skills", style="yellow")

        agent_map = self._get_agent_map()
        for key, agent in agent_map.items():
            is_active = "▶️ " if key == self.active_agent_key else ""
            emoji = AGENT_EMOJIS.get(key, "")
            color = AGENT_COLORS.get(key, "white")

            # Count skills
            skills = []
            if "🎯 PONYTAIL" in agent.system_prompt:
                skills.append("🎯")
            if "🎨 FRONTEND" in agent.system_prompt:
                skills.append("🎨")
            if "⚙️ BACKEND" in agent.system_prompt:
                skills.append("⚙️")

            table.add_row(
                f"{is_active}{emoji} {agent.name}",
                agent.role.value,
                "[green]🟢 Ready[/green]",
                "[bold cyan]✓[/bold cyan]" if key == self.active_agent_key else "",
                " ".join(skills)
            )

        console.print()
        console.print(table)
        console.print()

    def _cmd_tree(self, arg: str = ""):
        """Show family tree"""
        tree = """
[bold cyan]🏠 FAMILY TREE[/bold cyan]
[bold]══════════════════════════════════════════[/bold]

[bold magenta]👨‍💼 Dad (Architect)[/bold magenta] ─── HEAD OF FAMILY
  │
  └──[bold yellow]👩‍💼 Mommy (Project Manager)[/bold yellow] ─── COORDINATOR
      │
      ├── [cyan]👧 Frontend Girl[/cyan] → [magenta]👧 Designer Girl[/magenta]
      ├── [green]👦 Backend Boy[/green]  → [blue]👦 Database Boy[/blue]
      ├── [blue]👦 DevOps Boy[/blue]
      └── [red]👧 Tester Girl[/red]
"""
        console.print(tree)

    def _cmd_skills(self, arg: str = ""):
        """Show skills"""
        loader = SkillsLoader()

        table = Table(title="🎓 Loaded Skills", show_header=True, header_style="bold magenta")
        table.add_column("Skill", style="cyan")
        table.add_column("Description", style="green")
        table.add_column("Lines", justify="right")
        table.add_column("Source", style="yellow")

        sources = {
            'ponytail': 'DietrichGebert/ponytail (84k⭐)',
            'frontend_skills': 'sickn33/agentic-awesome-skills',
            'backend_skills': 'sickn33/awesome-skills + steipete/agent-rules',
        }

        for name, content in loader.skills.items():
            first_line = content.split('\n')[0].replace('#', '').strip()
            table.add_row(
                name,
                first_line[:40],
                str(len(content.splitlines())),
                sources.get(name, "local")
            )

        console.print()
        console.print(table)

        # Skills per agent
        assign = Table(title="📋 Skills per Agent", show_header=True, header_style="bold cyan")
        assign.add_column("Agent")
        assign.add_column("Skills")

        for key, agent in self._get_agent_map().items():
            emoji = AGENT_EMOJIS.get(key, "")
            skills = []
            if "🎯 PONYTAIL" in agent.system_prompt: skills.append("[yellow]🎯 Ponytail[/yellow]")
            if "🎨 FRONTEND" in agent.system_prompt: skills.append("[cyan]🎨 Frontend[/cyan]")
            if "⚙️ BACKEND" in agent.system_prompt: skills.append("[green]⚙️ Backend[/green]")

            assign.add_row(f"{emoji} {agent.name}", " + ".join(skills))

        console.print()
        console.print(assign)
        console.print()

    def _cmd_agents(self, arg: str = ""):
        """List agents with @mentions"""
        table = Table(title="🤖 Available Agents", show_header=True, header_style="bold cyan")
        table.add_column("Agent", style="bold")
        table.add_column("@Mention", style="cyan")
        table.add_column("Specialty", style="green")
        table.add_column("Active", justify="center")

        agents_info = {
            "architect": ("Dad", "@dad @architect", "System design, architecture"),
            "pm": ("Mommy", "@mommy @pm", "Task management, coordination"),
            "frontend": ("Frontend Girl", "@frontend @fe", "React, Next.js, TypeScript"),
            "backend": ("Backend Boy", "@backend @be", "Python, FastAPI, APIs"),
            "database": ("Database Boy", "@database @db", "PostgreSQL, Redis, schemas"),
            "devops": ("DevOps Boy", "@devops @ops", "Docker, CI/CD, deployment"),
            "tester": ("Tester Girl", "@tester @qa", "pytest, Jest, E2E testing"),
            "designer": ("Designer Girl", "@designer @ux", "UI/UX, wireframes, design"),
        }

        for key, (name, mention, specialty) in agents_info.items():
            emoji = AGENT_EMOJIS.get(key, "")
            active = "[bold green]◀ ACTIVE[/bold green]" if key == self.active_agent_key else ""
            table.add_row(f"{emoji} {name}", mention, specialty, active)

        console.print()
        console.print(table)
        console.print()

    def _cmd_switch(self, arg: str = ""):
        """Switch active agent"""
        if not arg:
            console.print("[yellow]Usage: /switch <agent>[/yellow]")
            console.print("[dim]Example: /switch frontend[/dim]")
            return

        arg_lower = arg.lower().strip().lstrip("@")
        valid_keys = list(self._get_agent_map().keys())

        if arg_lower in valid_keys:
            self.active_agent_key = arg_lower
            agent = self._get_active_agent()
            emoji = AGENT_EMOJIS.get(self.active_agent_key, "")
            color = AGENT_COLORS.get(self.active_agent_key, "white")
            console.print(f"[bold {color}]✅ Switched to {emoji} {agent.name}[/bold {color}]")
        else:
            console.print(f"[red]❌ Unknown agent: {arg}[/red]")
            console.print(f"[dim]Available: {', '.join(valid_keys)}[/dim]")

    def _cmd_build(self, arg: str = ""):
        """Build a complete project"""
        if not arg:
            console.print("[yellow]Usage: /build <project description>[/yellow]")
            console.print('[dim]Example: /build Todo app with React + FastAPI[/dim]')
            return

        console.print()
        console.print(Panel(
            f"[bold]{arg}[/bold]",
            title="[bold magenta]🚀 Building Project[/bold magenta]",
            border_style="magenta"
        ))
        console.print()

        # Build with progress
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:

            # Step 1
            t1 = progress.add_task("👨‍💼 Dad designing architecture...", total=None)
            architecture = self.agency.family.dad.design_architecture(arg)
            progress.update(t1, description="[green]✅ Architecture designed[/green]")

            # Step 2
            t2 = progress.add_task("👩‍💼 Mommy creating project plan...", total=None)
            plan = self.agency.family.mommy.create_project_plan(architecture)
            progress.update(t2, description="[green]✅ Project plan created[/green]")

            # Step 3
            t3 = progress.add_task("👩‍💼 Breaking into tasks...", total=None)
            tasks = self.agency.family.mommy.break_into_tasks(
                f"Architecture:\n{architecture}\n\nPlan:\n{plan}"
            )
            progress.update(t3, description=f"[green]✅ {len(tasks)} tasks created[/green]")

            # Step 4
            t4 = progress.add_task("👧👦 Executing tasks...", total=None)
            results = self.agency.family.mommy.assign_and_execute(tasks)
            progress.update(t4, description=f"[green]✅ {len(results)} tasks completed[/green]")

            # Step 5
            t5 = progress.add_task("💾 Saving files...", total=None)
            all_files = []
            for task_id, result in results.items():
                saved = self.agency.file_tools.save_extracted_files(result)
                all_files.extend(saved)
            progress.update(t5, description=f"[green]✅ {len(all_files)} files saved[/green]")

        # Summary
        console.print()
        console.print(Panel(
            f"[bold green]✅ Build Complete![/bold green]\n\n"
            f"📊 Tasks: [cyan]{len(tasks)}[/cyan]\n"
            f"📄 Files: [cyan]{len(all_files)}[/cyan]\n"
            f"📁 Output: [cyan]./output/[/cyan]",
            title="[bold green]🎉 Success[/bold green]",
            border_style="green",
            expand=False
        ))
        console.print()

    def _cmd_history(self, arg: str = ""):
        """Show conversation history"""
        if not self.history:
            console.print("[yellow]No conversation history yet.[/yellow]")
            return

        table = Table(title=f"💬 Conversation History ({len(self.history)} messages)", show_header=True)
        table.add_column("#", style="dim", width=4)
        table.add_column("Agent", style="cyan", width=15)
        table.add_column("Message", style="white")
        table.add_column("Time", style="dim", width=10)

        for i, msg in enumerate(self.history[-20:], 1):
            emoji = AGENT_EMOJIS.get(msg["agent"], "")
            color = AGENT_COLORS.get(msg["agent"], "white")
            content = msg["content"][:60] + ("..." if len(msg["content"]) > 60 else "")
            t = msg["timestamp"][11:16]  # HH:MM

            role_style = "green" if msg["role"] == "user" else color
            role_icon = "➤" if msg["role"] == "user" else emoji

            table.add_row(
                str(i),
                f"[{role_style}]{role_icon} {msg['agent']}[/{role_style}]",
                content,
                t
            )

        console.print()
        console.print(table)
        console.print()

    def _cmd_clear(self, arg: str = ""):
        """Clear screen"""
        console.clear()
        console.print(WELCOME_ART)
        console.print(f"[dim]📚 {len(self.history)} messages in history • Type [bold]/help[/bold] for commands[/dim]\n")

    def _cmd_exit(self, arg: str = ""):
        """Exit"""
        duration = datetime.now() - self.session_start
        console.print()
        console.print(Panel(
            f"[bold]Session Summary[/bold]\n\n"
            f"⏱️  Duration: {str(duration).split('.')[0]}\n"
            f"💬 Messages: {self.message_count}\n"
            f"🤖 Agents used: {len(set(m['agent'] for m in self.history)) if self.history else 0}\n",
            title="[bold yellow]👋 Session Complete[/bold yellow]",
            border_style="yellow",
            expand=False
        ))
        console.print("[bold yellow]👋 Goodbye! See you next time.[/bold yellow]\n")
        sys.exit(0)

    # ============ AGENT COMMUNICATION ============

    def _send_to_agent(self, message: str):
        """Send message to active agent and display response"""
        agent = self._get_active_agent()
        if not agent:
            console.print("[red]❌ No active agent[/red]")
            return

        emoji = AGENT_EMOJIS.get(self.active_agent_key, "🤖")
        color = AGENT_COLORS.get(self.active_agent_key, "white")

        # Show thinking spinner
        with console.status(f"[bold {color}]{emoji} {agent.name} is thinking...[/bold {color}]", spinner="dots"):
            task = Task(title=message[:50], description=message)
            response = agent.execute_task(task)

        # Record response
        self.history.append({
            "role": "assistant",
            "content": response,
            "agent": self.active_agent_key,
            "timestamp": datetime.now().isoformat()
        })

        # Display response
        self._display_response(response, agent)

    def _display_response(self, response: str, agent):
        """Display agent response with proper formatting"""
        emoji = AGENT_EMOJIS.get(self.active_agent_key, "🤖")
        color = AGENT_COLORS.get(self.active_agent_key, "white")

        console.print()

        # Check if response contains code blocks
        has_code = "```" in response or "filepath:" in response

        if has_code:
            # Try to extract and syntax-highlight code blocks
            self._display_code_response(response, agent, emoji, color)
        else:
            # Display as markdown
            try:
                console.print(Panel(
                    Markdown(response),
                    title=f"[bold {color}]{emoji} {agent.name}[/bold {color}]",
                    border_style=color,
                    padding=(1, 2)
                ))
            except Exception:
                console.print(Panel(
                    response,
                    title=f"[bold {color}]{emoji} {agent.name}[/bold {color}]",
                    border_style=color,
                    padding=(1, 2)
                ))

        console.print()

    def _display_code_response(self, response: str, agent, emoji: str, color: str):
        """Display response with code blocks highlighted"""
        # Split response into text and code parts
        parts = re.split(r'(```\w*\n.*?```)', response, flags=re.DOTALL)

        console.print(f"[bold {color}]╭─ {emoji} {agent.name} ─────────────────────────────╮[/bold {color}]")

        for part in parts:
            if part.startswith("```"):
                # Extract language and code
                match = re.match(r'```(\w*)\n(.*?)```', part, re.DOTALL)
                if match:
                    lang = match.group(1) or "text"
                    code = match.group(2).strip()
                    console.print()
                    console.print(Syntax(
                        code,
                        lang,
                        theme="monokai",
                        line_numbers=True,
                        padding=(0, 2),
                        border_style="dim"
                    ))
                    console.print()
                else:
                    console.print(f"  {part}")
            else:
                # Regular text
                if part.strip():
                    for line in part.strip().split('\n'):
                        console.print(f"  [white]{line}[/white]")

        console.print(f"[bold {color}]╰──────────────────────────────────────────────╯[/bold {color}]")


# ============ MAIN ENTRY ============

def main():
    """Launch the terminal"""
    import argparse

    parser = argparse.ArgumentParser(description="🏢 Software Dev Agency Terminal")
    parser.add_argument("--key", "-k", help="OpenAI API key")
    parser.add_argument("--demo", action="store_true", help="Demo mode (mock)")
    args = parser.parse_args()

    api_key = ""
    if args.demo:
        api_key = ""
    elif args.key:
        api_key = args.key
    else:
        api_key = os.getenv("OPENAI_API_KEY", "")

    terminal = AgencyTerminal(api_key=api_key)
    terminal.start()


if __name__ == "__main__":
    main()
