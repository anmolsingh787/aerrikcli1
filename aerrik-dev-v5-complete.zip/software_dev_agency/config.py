"""
Configuration file for Software Development Agency
"""
import os
from dataclasses import dataclass, field
from typing import Dict, List
from enum import Enum


class AgentRole(Enum):
    """Agent roles in the agency"""
    ARCHITECT = "architect"                  # Dad
    PROJECT_MANAGER = "project_manager"      # Mommy
    FRONTEND_DEV = "frontend_developer"      # Girl Child 1
    BACKEND_DEV = "backend_developer"        # Boy Child 1
    DATABASE_EXPERT = "database_expert"      # Boy Child 2
    DEVOPS = "devops_engineer"               # Boy Child 3
    TESTER = "tester"                        # Girl Child 2
    DESIGNER = "ui_ux_designer"              # Girl Child 3
    MOBILE_DEV = "mobile_developer"          # Girl Child 4
    SECURITY_ENG = "security_engineer"       # Boy Child 4
    GRANDFATHER = "grandfather"              # Supreme Reviewer
    GRANDMOTHER = "grandmother"              # Wise Advisor


class ProjectType(Enum):
    """Types of projects"""
    WEB_APP = "web_application"
    MOBILE_APP = "mobile_application"
    API = "api_service"
    FULLSTACK = "fullstack"
    MICROSERVICE = "microservice"


class TechStack(Enum):
    """Technology stacks"""
    REACT_NODE = "react_node"
    ANGULAR_DJANGO = "angular_django"
    VUE_FLASK = "vue_flask"
    NEXTJS_FASTAPI = "nextjs_fastapi"
    REACT_SPRING = "react_spring"


@dataclass
class AgentConfig:
    """Configuration for individual agent"""
    name: str
    role: AgentRole
    model: str = "gpt-4"
    temperature: float = 0.7
    max_tokens: int = 4000
    skills: List[str] = field(default_factory=list)
    can_delegate_to: List[AgentRole] = field(default_factory=list)
    priority: int = 1  # 1 = highest


@dataclass
class ProjectConfig:
    """Project configuration"""
    name: str
    description: str
    project_type: ProjectType = ProjectType.FULLSTACK
    tech_stack: TechStack = TechStack.NEXTJS_FASTAPI
    output_dir: str = "./output"
    max_iterations: int = 10
    enable_testing: bool = True
    enable_ci_cd: bool = True


@dataclass
class AppConfig:
    """Main application configuration"""
    openai_api_key: str = os.getenv("OPENAI_API_KEY", "")
    anthropic_api_key: str = os.getenv("ANTHROPIC_API_KEY", "")
    groq_api_key: str = os.getenv("GROQ_API_KEY", "")
    default_model: str = "gpt-4"
    debug: bool = True
    log_level: str = "INFO"
    max_retries: int = 3
    timeout: int = 120


# ============ DEFAULT AGENT CONFIGURATIONS ============

AGENT_CONFIGS: Dict[AgentRole, AgentConfig] = {
    AgentRole.ARCHITECT: AgentConfig(
        name="Architect Dad 👨‍💼",
        role=AgentRole.ARCHITECT,
        model="gpt-4",
        temperature=0.5,
        skills=["system_design", "architecture", "tech_decisions", "code_review"],
        can_delegate_to=[
            AgentRole.PROJECT_MANAGER,
            AgentRole.FRONTEND_DEV,
            AgentRole.BACKEND_DEV,
            AgentRole.DATABASE_EXPERT,
            AgentRole.DEVOPS,
            AgentRole.TESTER,
            AgentRole.DESIGNER
        ],
        priority=1
    ),

    AgentRole.PROJECT_MANAGER: AgentConfig(
        name="Project Manager Mommy 👩‍💼",
        role=AgentRole.PROJECT_MANAGER,
        model="gpt-4",
        temperature=0.6,
        skills=["task_management", "coordination", "planning", "reporting"],
        can_delegate_to=[
            AgentRole.FRONTEND_DEV,
            AgentRole.BACKEND_DEV,
            AgentRole.DATABASE_EXPERT,
            AgentRole.DEVOPS,
            AgentRole.TESTER,
            AgentRole.DESIGNER
        ],
        priority=2
    ),

    AgentRole.FRONTEND_DEV: AgentConfig(
        name="Frontend Girl 👧",
        role=AgentRole.FRONTEND_DEV,
        model="gpt-4",
        temperature=0.7,
        skills=["react", "nextjs", "css", "tailwind", "typescript", "html"],
        can_delegate_to=[AgentRole.DESIGNER],
        priority=3
    ),

    AgentRole.BACKEND_DEV: AgentConfig(
        name="Backend Boy 👦",
        role=AgentRole.BACKEND_DEV,
        model="gpt-4",
        temperature=0.6,
        skills=["python", "fastapi", "nodejs", "api_design", "authentication"],
        can_delegate_to=[AgentRole.DATABASE_EXPERT],
        priority=3
    ),

    AgentRole.DATABASE_EXPERT: AgentConfig(
        name="Database Boy 👦",
        role=AgentRole.DATABASE_EXPERT,
        model="gpt-4",
        temperature=0.5,
        skills=["postgresql", "mongodb", "redis", "schema_design", "optimization"],
        can_delegate_to=[],
        priority=4
    ),

    AgentRole.DEVOPS: AgentConfig(
        name="DevOps Boy 👦",
        role=AgentRole.DEVOPS,
        model="gpt-4",
        temperature=0.5,
        skills=["docker", "kubernetes", "ci_cd", "aws", "nginx", "monitoring"],
        can_delegate_to=[],
        priority=4
    ),

    AgentRole.TESTER: AgentConfig(
        name="Tester Girl 👧",
        role=AgentRole.TESTER,
        model="gpt-4",
        temperature=0.6,
        skills=["unit_testing", "integration_testing", "e2e_testing", "pytest", "jest"],
        can_delegate_to=[],
        priority=4
    ),

    AgentRole.DESIGNER: AgentConfig(
        name="Designer Girl 👧",
        role=AgentRole.DESIGNER,
        model="gpt-4",
        temperature=0.8,
        skills=["ui_design", "ux_design", "wireframing", "component_design", "figma"],
        can_delegate_to=[],
        priority=4
    ),
}
