"""
🚀 Professional CLI for Software Development Agency
Uses: rich (beautiful output) + click (command structure)
"""
import os
import sys
import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.syntax import Syntax
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
from rich.live import Live
from rich.text import Text
from rich.columns import Columns
from rich import print as rprint
from rich.markdown import Markdown
import time

# Add parent to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from main import SoftwareDevAgency
from config import AgentRole

console = Console()


# ============ ASCII ART ============

AGENCY_BANNER = """
[bold cyan]╔═══════════════════════════════════════════════════════════╗[/]
[bold cyan]║[/]  [bold magenta]🏢 SOFTWARE DEVELOPMENT AGENCY[/]                         [bold cyan]║[/]
[bold cyan]║[/]  [dim]Multi-Agent AI Development Framework[/]                   [bold cyan]║[/]
[bold cyan]║[/]                                                           [bold cyan]║[/]
[bold cyan]║[/]  👨‍💼 [bold]Dad[/] (Architect)                                      [bold cyan]║[/]
[bold cyan]║[/]   └── 👩‍💼 [bold]Mommy[/] (Project Manager)                        [bold cyan]║[/]
[bold cyan]║[/]        ├── 👧 Frontend  ├── 👦 Backend  ├── 👦 DevOps    [bold cyan]║[/]
[bold cyan]║[/]        ├── 👦 Database  ├── 👧 Tester   └── 👧 Designer  [bold cyan]║[/]
[bold cyan]╚═══════════════════════════════════════════════════════════╝[/]
"""


def show_banner():
    """Show the agency banner"""
    console.print(AGENCY_BANNER)
    console.print()


def get_agency(api_key: str = None, verbose: bool = False) -> SoftwareDevAgency:
    """Get or create agency instance"""
    if api_key is None:
        api_key = os.getenv("OPENAI_API_KEY", "")
    return SoftwareDevAgency(api_key=api_key, verbose=verbose)


# ============ MAIN CLI GROUP ============

@click.group(invoke_without_command=True)
@click.option('--key', '-k', help='OpenAI API key')
@click.option('--demo', is_flag=True, help='Run in demo mode (mock responses)')
@click.pass_context
def cli(ctx, key, demo):
    """
    🏢 Software Development Agency CLI

    Build complete software projects with AI agent family!
    """
    ctx.ensure_object(dict)

    if demo:
        ctx.obj['api_key'] = ''
    elif key:
        ctx.obj['api_key'] = key
    else:
        ctx.obj['api_key'] = os.getenv("OPENAI_API_KEY", "")

    if ctx.invoked_subcommand is None:
        show_banner()
        console.print("[bold yellow]💡 Tip:[/bold yellow] Use [cyan]--help[/cyan] to see available commands\n")
        console.print("[bold]Available Commands:[/bold]")
        console.print("  [cyan]build[/cyan]      - Build a complete project")
        console.print("  [cyan]ask[/cyan]        - Ask a specific agent")
        console.print("  [cyan]task[/cyan]       - Assign task to an agent")
        console.print("  [cyan]status[/cyan]     - Show family status")
        console.print("  [cyan]tree[/cyan]       - Show family tree")
        console.print("  [cyan]chat[/cyan]       - Chat with Dad (Architect)")
        console.print()


# ============ BUILD COMMAND ============

@cli.command()
@click.argument('description')
@click.option('--tech', '-t', default='', help='Tech stack preference')
@click.pass_context
def build(ctx, description, tech):
    """
    🚀 Build a complete software project

    Example: agency build "Task management app with auth and kanban"
    """
    show_banner()

    if tech:
        description += f"\n\nTech Stack: {tech}"

    # Show project info
    console.print(Panel(
        f"[bold]{description}[/bold]",
        title="[bold magenta]📋 Project Description[/bold magenta]",
        border_style="magenta"
    ))
    console.print()

    # Initialize agency
    with console.status("[bold green]🏠 Building agency family...[/bold green]", spinner="dots"):
        agency = get_agency(ctx.obj['api_key'], verbose=False)

    console.print("[green]✅ Agency family ready![/green]\n")

    # Progress tracking
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        console=console,
    ) as progress:

        # Step 1: Architecture
        task1 = progress.add_task("👨‍💼 Dad designing architecture...", total=100)
        architecture = agency.family.dad.design_architecture(description)
        progress.update(task1, completed=100)

        console.print(Panel(
            architecture[:1000] + ("..." if len(architecture) > 1000 else ""),
            title="[bold blue]📐 Architecture[/bold blue]",
            border_style="blue",
            expand=False
        ))
        console.print()

        # Step 2: Project Plan
        task2 = progress.add_task("👩‍💼 Mommy creating project plan...", total=100)
        project_plan = agency.family.mommy.create_project_plan(architecture)
        progress.update(task2, completed=100)

        # Step 3: Break into tasks
        task3 = progress.add_task("👩‍💼 Breaking into tasks...", total=100)
        tasks = agency.family.mommy.break_into_tasks(
            f"Architecture:\n{architecture}\n\nProject Plan:\n{project_plan}"
        )
        progress.update(task3, completed=100)

        # Show tasks table
        task_table = Table(title="📋 Generated Tasks", show_header=True, header_style="bold cyan")
        task_table.add_column("ID", style="dim", width=12)
        task_table.add_column("Title", style="bold")
        task_table.add_column("Assigned To", style="magenta")

        for t in tasks:
            assigned = t.assigned_to.value if t.assigned_to else "unassigned"
            task_table.add_row(t.id, t.title, assigned)

        console.print(task_table)
        console.print()

        # Step 4: Execute tasks
        task4 = progress.add_task(f"👧👦 Executing {len(tasks)} tasks...", total=len(tasks))

        results = {}
        for i, task in enumerate(tasks):
            if task.assigned_to and task.assigned_to in agency.family.mommy.children:
                child = agency.family.mommy.children[task.assigned_to]
                progress.update(task4, description=f"👧👦 {child.name}: {task.title[:40]}...")
                result = agency.family.mommy.delegate_task(task, task.assigned_to)
                results[task.id] = result
            progress.update(task4, advance=1)

    # Step 5: Save files
    console.print("\n[bold cyan]💾 Saving generated files...[/bold cyan]")
    file_tools = agency.file_tools
    all_files = []

    for task_id, result in results.items():
        saved = file_tools.save_extracted_files(result)
        all_files.extend(saved)

    # Final report
    console.print()
    console.print(Panel(
        f"[bold green]✅ Project Build Complete![/bold green]\n\n"
        f"📊 Tasks Completed: [cyan]{len(tasks)}[/cyan]\n"
        f"📄 Files Generated: [cyan]{len(all_files)}[/cyan]\n"
        f"📁 Output Directory: [cyan]./output/[/cyan]",
        title="[bold green]🎉 Success[/bold green]",
        border_style="green"
    ))


# ============ ASK COMMAND ============

@cli.command()
@click.argument('role', type=click.Choice(['architect', 'pm', 'frontend', 'backend', 'database', 'devops', 'tester', 'designer']))
@click.argument('question')
@click.pass_context
def ask(ctx, role, question):
    """
    💬 Ask a specific agent a question

    Example: agency ask frontend "How to create a responsive navbar?"
    """
    agency = get_agency(ctx.obj['api_key'], verbose=False)

    role_emoji = {
        'architect': '👨‍💼', 'pm': '👩‍💼', 'frontend': '👧',
        'backend': '👦', 'database': '👦', 'devops': '👦',
        'tester': '👧', 'designer': '👧'
    }

    role_map = {
        'architect': agency.family.dad,
        'pm': agency.family.mommy,
        'frontend': agency.family.frontend_girl,
        'backend': agency.family.backend_boy,
        'database': agency.family.database_boy,
        'devops': agency.family.devops_boy,
        'tester': agency.family.tester_girl,
        'designer': agency.family.designer_girl,
    }

    agent = role_map[role]
    emoji = role_emoji[role]

    console.print(f"\n{emoji} [bold]{agent.name}[/bold] is thinking...\n")

    with console.status(f"[bold cyan]{agent.name} is thinking...[/bold cyan]", spinner="dots"):
        response = agent.process_request(question)

    # Try to detect if response contains code
    if "```" in response or "filepath:" in response:
        console.print(Panel(
            response,
            title=f"[bold cyan]{emoji} {agent.name}[/bold cyan]",
            border_style="cyan",
            expand=False
        ))
    else:
        console.print(Panel(
            Markdown(response),
            title=f"[bold cyan]{emoji} {agent.name}[/bold cyan]",
            border_style="cyan",
            expand=False
        ))


# ============ TASK COMMAND ============

@cli.command()
@click.argument('role', type=click.Choice(['architect', 'pm', 'frontend', 'backend', 'database', 'devops', 'tester', 'designer']))
@click.argument('description')
@click.pass_context
def task(ctx, role, description):
    """
    📝 Assign a task to an agent

    Example: agency task backend "Create user authentication API"
    """
    agency = get_agency(ctx.obj['api_key'], verbose=False)

    role_map = {
        'architect': agency.family.dad,
        'pm': agency.family.mommy,
        'frontend': agency.family.frontend_girl,
        'backend': agency.family.backend_boy,
        'database': agency.family.database_boy,
        'devops': agency.family.devops_boy,
        'tester': agency.family.tester_girl,
        'designer': agency.family.designer_girl,
    }

    agent = role_map[role]

    console.print(f"\n[bold cyan]📝 Task assigned to {agent.name}[/bold cyan]")
    console.print(f"[dim]{description}[/dim]\n")

    from agents.base_agent import Task as AgentTask
    task_obj = AgentTask(title=description[:50], description=description)

    with console.status(f"[bold cyan]{agent.name} working on task...[/bold cyan]", spinner="dots"):
        result = agent.execute_task(task_obj)

    # Save any files
    saved = agency.file_tools.save_extracted_files(result)

    # Show result
    console.print(Panel(
        result[:2000] + ("..." if len(result) > 2000 else ""),
        title=f"[bold green]✅ Result from {agent.name}[/bold green]",
        border_style="green",
        expand=False
    ))

    if saved:
        console.print(f"\n[bold cyan]📄 Files saved:[/bold cyan]")
        for f in saved:
            console.print(f"  • {f}")


# ============ STATUS COMMAND ============

@cli.command()
@click.pass_context
def status(ctx):
    """📊 Show status of all agents"""
    agency = get_agency(ctx.obj['api_key'], verbose=False)

    table = Table(title="🏢 Agency Family Status", show_header=True, header_style="bold magenta")
    table.add_column("Agent", style="cyan", no_wrap=True)
    table.add_column("Role", style="green")
    table.add_column("Status", justify="center")
    table.add_column("Tasks Done", justify="right")
    table.add_column("Children", justify="right")

    agents = agency.family.get_all_agents()
    for name, agent in agents.items():
        s = agent.get_status()
        status_emoji = "🔴 BUSY" if s["is_busy"] else "🟢 FREE"
        table.add_row(
            agent.name,
            agent.role.value,
            status_emoji,
            str(s["tasks_completed"]),
            str(len(agent.children))
        )

    console.print()
    console.print(table)
    console.print()


# ============ TREE COMMAND ============

@cli.command()
def tree():
    """🌳 Show the family tree"""
    tree_text = """
[bold cyan]🏠 AGENCY FAMILY TREE[/bold cyan]
[bold]══════════════════════════════════════════[/bold]

[bold magenta]👨‍💼 Dad (Architect)[/bold magenta] ─── HEAD OF FAMILY
  │
  └──[bold yellow]👩‍💼 Mommy (Project Manager)[/bold yellow] ─── COORDINATOR
      │
      ├── [cyan]👧 Girl Child 1 (Frontend Developer)[/cyan]
      │    └── [cyan]👧 Girl Child 3 (UI/UX Designer)[/cyan]
      │
      ├── [green]👦 Boy Child 1 (Backend Developer)[/green]
      │    └── [green]👦 Boy Child 2 (Database Expert)[/green]
      │
      ├── [blue]👦 Boy Child 3 (DevOps Engineer)[/blue]
      │
      └── [red]👧 Girl Child 2 (QA Tester)[/red]

[bold]══════════════════════════════════════════[/bold]
"""
    console.print(tree_text)


# ============ SKILLS COMMAND ============

@cli.command()
@click.option('--detail', '-d', is_flag=True, help='Show detailed skill content')
@click.option('--skill', '-s', help='Show details for a specific skill')
def skills(detail, skill):
    """🎓 Show loaded skills from GitHub"""
    from skills.skills_loader import SkillsLoader

    loader = SkillsLoader()

    if skill:
        content = loader.get_skill(skill)
        if content:
            console.print(Panel(
                Markdown(content),
                title=f"[bold cyan]🎓 Skill: {skill}[/bold cyan]",
                border_style="cyan"
            ))
        else:
            console.print(f"[red]❌ Skill not found: {skill}[/red]")
            console.print(f"Available: {', '.join(loader.list_skills())}")
        return

    # Skills table
    table = Table(title="🎓 Loaded Skills (from GitHub)", show_header=True, header_style="bold magenta")
    table.add_column("Skill", style="cyan", no_wrap=True)
    table.add_column("Description", style="green")
    table.add_column("Lines", justify="right")
    table.add_column("Source", style="yellow")

    sources = {
        'ponytail': 'github.com/DietrichGebert/ponytail',
        'frontend_skills': 'sickn33/agentic-awesome-skills',
        'backend_skills': 'sickn33/agentic-awesome-skills + steipete/agent-rules',
    }

    for name, content in loader.skills.items():
        first_line = content.split('\n')[0].replace('#', '').strip()
        line_count = len(content.splitlines())
        source = sources.get(name, 'local')
        table.add_row(name, first_line, str(line_count), source)

    console.print()
    console.print(table)

    # Skills assignment table
    console.print()
    assign_table = Table(title="📋 Skills per Agent", show_header=True, header_style="bold cyan")
    assign_table.add_column("Agent", style="cyan")
    assign_table.add_column("Skills Applied", style="green")

    agent_skills = {
        "👨‍💼 Dad (Architect)": "✅ Ponytail + ✅ Frontend + ✅ Backend",
        "👩‍💼 Mommy (PM)": "✅ Ponytail",
        "👧 Frontend Girl": "✅ Ponytail + ✅ Frontend Skills",
        "👦 Backend Boy": "✅ Ponytail + ✅ Backend Skills",
        "👦 Database Boy": "✅ Ponytail + ✅ Backend Skills",
        "👦 DevOps Boy": "✅ Ponytail + ✅ Backend Skills",
        "👧 Tester Girl": "✅ Ponytail + ✅ Frontend + ✅ Backend",
        "👧 Designer Girl": "✅ Ponytail + ✅ Frontend Skills",
    }

    for agent, skills_list in agent_skills.items():
        assign_table.add_row(agent, skills_list)

    console.print(assign_table)

    if detail:
        console.print()
        for name, content in loader.skills.items():
            console.print(Panel(
                content[:1000] + ("..." if len(content) > 1000 else ""),
                title=f"[bold cyan]🎓 {name}[/bold cyan]",
                border_style="cyan",
                expand=False
            ))
            console.print()


# ============ CHAT COMMAND ============

@cli.command()
@click.argument('message')
@click.pass_context
def chat(ctx, message):
    """💬 Chat with Dad (Architect)"""
    agency = get_agency(ctx.obj['api_key'], verbose=False)

    console.print(f"\n[bold cyan]💬 You:[/bold cyan] {message}\n")

    with console.status("[bold cyan]👨‍💼 Dad is thinking...[/bold cyan]", spinner="dots"):
        response = agency.chat(message)

    console.print(Panel(
        Markdown(response),
        title="[bold magenta]👨‍💼 Architect Dad[/bold magenta]",
        border_style="magenta"
    ))


# ============ INTERACTIVE COMMAND ============

@cli.command()
@click.pass_context
def interactive(ctx):
    """🎮 Start interactive mode"""
    show_banner()
    console.print("[bold yellow]🎮 Interactive Mode[/bold yellow]")
    console.print("[dim]Type 'help' for commands, 'quit' to exit[/dim]\n")

    agency = get_agency(ctx.obj['api_key'], verbose=False)

    while True:
        try:
            user_input = console.input("[bold cyan]🏢 Agency >[/bold cyan] ").strip()

            if not user_input:
                continue

            if user_input.lower() in ['quit', 'exit', 'q']:
                console.print("\n[bold yellow]👋 Goodbye![/bold yellow]")
                break

            elif user_input.lower() == 'help':
                console.print("\n[bold]Commands:[/bold]")
                console.print("  [cyan]build <desc>[/cyan]    - Build project")
                console.print("  [cyan]ask <role> <q>[/cyan]  - Ask agent")
                console.print("  [cyan]task <role> <d>[/cyan] - Assign task")
                console.print("  [cyan]status[/cyan]          - Show status")
                console.print("  [cyan]tree[/cyan]            - Family tree")
                console.print("  [cyan]quit[/cyan]            - Exit\n")

            elif user_input.lower() == 'status':
                ctx.invoke(status)

            elif user_input.lower() == 'tree':
                ctx.invoke(tree)

            elif user_input.lower().startswith('build '):
                desc = user_input[6:]
                ctx.invoke(build, description=desc, tech='')

            elif user_input.lower().startswith('ask '):
                parts = user_input[4:].split(' ', 1)
                if len(parts) == 2:
                    role, question = parts
                    if role in ['architect', 'pm', 'frontend', 'backend', 'database', 'devops', 'tester', 'designer']:
                        ctx.invoke(ask, role=role, question=question)
                    else:
                        console.print(f"[red]❌ Unknown role: {role}[/red]")
                else:
                    console.print("[yellow]Usage: ask <role> <question>[/yellow]")

            elif user_input.lower().startswith('task '):
                parts = user_input[5:].split(' ', 1)
                if len(parts) == 2:
                    role, desc = parts
                    if role in ['architect', 'pm', 'frontend', 'backend', 'database', 'devops', 'tester', 'designer']:
                        ctx.invoke(task, role=role, description=desc)
                    else:
                        console.print(f"[red]❌ Unknown role: {role}[/red]")
                else:
                    console.print("[yellow]Usage: task <role> <description>[/yellow]")

            else:
                # Default: chat with dad
                with console.status("[bold cyan]👨‍💼 Dad is thinking...[/bold cyan]", spinner="dots"):
                    response = agency.chat(user_input)
                console.print(Panel(
                    Markdown(response),
                    title="[bold magenta]👨‍💼 Architect Dad[/bold magenta]",
                    border_style="magenta"
                ))

        except KeyboardInterrupt:
            console.print("\n[bold yellow]👋 Goodbye![/bold yellow]")
            break
        except Exception as e:
            console.print(f"[red]❌ Error: {str(e)}[/red]")


# ============ MAIN ============

if __name__ == "__main__":
    cli(obj={})
