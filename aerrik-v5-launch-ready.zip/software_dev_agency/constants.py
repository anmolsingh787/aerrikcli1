"""
⚙️ aerrik.dev — Core Constants & Policies

Single source of truth for all framework numbers and policies.
Never hardcode these anywhere else.
"""
from enum import Enum
from typing import Dict, List


# ═══════════════════════════════════════════════════════
#  FAMILY CONSTANTS (single source of truth)
# ═══════════════════════════════════════════════════════

TOTAL_AGENTS = 12
TOTAL_COMPANIONS = 1
TOTAL_ENTITIES = TOTAL_AGENTS + TOTAL_COMPANIONS  # 13

ELDERS_COUNT = 2       # Grandfather, Grandmother
PARENTS_COUNT = 2      # Dad, Mommy
GIRLS_COUNT = 4        # Frontend, Tester, Designer, Mobile
BOYS_COUNT = 4         # Backend, Database, DevOps, Security

assert ELDERS_COUNT + PARENTS_COUNT + GIRLS_COUNT + BOYS_COUNT == TOTAL_AGENTS

SKILLS_COUNT = 7
LLM_PROVIDERS_COUNT = 8
TOOL_MODULES_COUNT = 6

VERSION = "5.0.0"
CODENAME = "Engineering Runtime"


# ═══════════════════════════════════════════════════════
#  AGENT ACTIVATION POLICY
# ═══════════════════════════════════════════════════════

class ActivationPolicy(Enum):
    """
    🧠 Not every task deserves the whole family.

    SIMPLE   → User → Target Agent → Validator (2-3 calls)
    MEDIUM   → Dad → Mommy → Agents → Tester (5-8 calls)
    COMPLEX  → Full Family Pipeline (10-20 calls)
    """
    SIMPLE = "simple"       # Direct to agent, minimal overhead
    MEDIUM = "medium"       # Architecture + planning + execution + test
    COMPLEX = "complex"     # Full pipeline with elders review


class TaskComplexity:
    """
    Classify task complexity to determine activation policy.
    """

    # Keywords that indicate simple tasks
    SIMPLE_KEYWORDS = [
        "create a", "make a", "write a",
        "component", "function", "hook", "test",
        "fix", "update", "change", "add", "remove",
        "button", "card", "form", "modal", "navbar",
    ]

    # Keywords that indicate medium complexity
    MEDIUM_KEYWORDS = [
        "api", "endpoint", "authentication", "auth",
        "jwt", "oauth", "database", "schema",
        "docker", "pipeline", "middleware",
        "websocket", "real-time",
        "build a", "implement",
    ]

    # Keywords that indicate complex tasks
    COMPLEX_KEYWORDS = [
        "full", "complete", "entire", "production",
        "microservice", "platform", "system", "architecture",
        "distributed", "scalable", "enterprise",
        "e-commerce", "saas", "multi-tenant",
        "with auth", "with billing", "with payment",
    ]

    @staticmethod
    def classify(description: str) -> ActivationPolicy:
        """
        Classify task complexity from description.

        SIMPLE:  Short, single-component tasks
        MEDIUM:  Multi-step but focused tasks
        COMPLEX: Full system design / production builds
        """
        desc_lower = description.lower()
        word_count = len(description.split())

        # Count signals
        complex_signals = sum(
            1 for kw in TaskComplexity.COMPLEX_KEYWORDS
            if kw in desc_lower
        )
        medium_signals = sum(
            1 for kw in TaskComplexity.MEDIUM_KEYWORDS
            if kw in desc_lower
        )
        simple_signals = sum(
            1 for kw in TaskComplexity.SIMPLE_KEYWORDS
            if kw in desc_lower
        )

        # Classification logic (complex > medium > simple)
        if complex_signals >= 2 or word_count > 40:
            return ActivationPolicy.COMPLEX
        elif complex_signals >= 1 and medium_signals >= 1:
            return ActivationPolicy.COMPLEX
        elif medium_signals >= 2 or word_count > 20:
            return ActivationPolicy.MEDIUM
        elif medium_signals >= 1:
            return ActivationPolicy.MEDIUM
        elif word_count < 15 and simple_signals >= 1:
            return ActivationPolicy.SIMPLE
        else:
            return ActivationPolicy.MEDIUM  # Default to medium (safe)


# ═══════════════════════════════════════════════════════
#  RISK SCORING (determines Elder activation)
# ═══════════════════════════════════════════════════════

class RiskLevel(Enum):
    """Risk level for generated code"""
    LOW = 0          # Static content, UI components
    MEDIUM = 1       # Business logic, data processing
    HIGH = 2         # Auth, payments, external APIs
    CRITICAL = 3     # Crypto, PII, financial transactions


class RiskScorer:
    """
    Score risk based on file type, content, and context.
    Determines which reviewers are activated.

    LOW (0-2)     → No Elder review (save tokens)
    MEDIUM (3-5)  → Grandmother review only
    HIGH (6-8)    → Grandfather + Grandmother
    CRITICAL (9+) → Grandfather + Grandmother + Human approval
    """

    # File patterns and their base risk
    FILE_RISK = {
        # Low risk
        ".md": 0, ".txt": 0, ".css": 0,
        ".html": 1, ".json": 1, ".yaml": 1,
        ".svg": 0, ".png": 0,

        # Medium risk
        ".tsx": 2, ".jsx": 2, ".vue": 2, ".svelte": 2,
        ".ts": 2, ".js": 2,

        # High risk
        ".py": 3, ".go": 3, ".rs": 3, ".java": 3,
        ".sql": 4, ".sh": 4,

        # Critical risk
        "dockerfile": 5,
        ".env": 6,
    }

    # Content patterns that increase risk
    HIGH_RISK_PATTERNS = [
        "password", "secret", "token", "api_key", "private_key",
        "payment", "stripe", "billing", "charge",
        "auth", "login", "register", "jwt",
        "encrypt", "decrypt", "hash",
        "exec(", "eval(", "subprocess",
        "DROP TABLE", "DELETE FROM",
        "rm -rf", "sudo",
        "os.system", "shell=True",
    ]

    CRITICAL_RISK_PATTERNS = [
        "crypto", "bitcoin", "wallet",
        "ssn", "social_security", "credit_card",
        "hipaa", "gdpr", "pci",
        "production", "deploy",
    ]

    @staticmethod
    def score_file(filepath: str, content: str) -> int:
        """Score risk for a single file (0-10)"""
        import os

        # Base risk from file type
        ext = os.path.splitext(filepath)[1].lower()
        basename = os.path.basename(filepath).lower()

        risk = RiskScorer.FILE_RISK.get(ext, 2)
        risk = max(risk, RiskScorer.FILE_RISK.get(basename, 0))

        # Content-based risk increase
        content_lower = content.lower()
        high_hits = sum(1 for p in RiskScorer.HIGH_RISK_PATTERNS if p in content_lower)
        critical_hits = sum(1 for p in RiskScorer.CRITICAL_RISK_PATTERNS if p in content_lower)

        risk += min(high_hits, 3)      # Max +3 from high-risk patterns
        risk += critical_hits * 2       # Each critical pattern adds 2

        return min(risk, 10)

    @staticmethod
    def score_batch(files: Dict[str, str]) -> Dict[str, int]:
        """Score risk for multiple files"""
        return {
            filepath: RiskScorer.score_file(filepath, content)
            for filepath, content in files.items()
        }

    @staticmethod
    def get_level(score: int) -> RiskLevel:
        """Convert numeric score to RiskLevel"""
        if score <= 2:
            return RiskLevel.LOW
        elif score <= 5:
            return RiskLevel.MEDIUM
        elif score <= 8:
            return RiskLevel.HIGH
        else:
            return RiskLevel.CRITICAL

    @staticmethod
    def should_review_elders(score: int) -> Dict[str, bool]:
        """
        Determine which reviewers to activate based on risk.

        LOW (0-2)     → No Elder review (save tokens)
        MEDIUM (3-5)  → Grandmother only
        HIGH (6-8)    → Grandfather + Grandmother
        CRITICAL (9+) → Grandfather + Grandmother + Human approval
        """
        level = RiskScorer.get_level(score)
        return {
            "grandfather": level.value >= RiskLevel.HIGH.value,
            "grandmother": level.value >= RiskLevel.MEDIUM.value,
            "human_approval": level == RiskLevel.CRITICAL,
            "tester": level.value >= RiskLevel.MEDIUM.value,
        }


# ═══════════════════════════════════════════════════════
#  VALIDATION LEVELS
# ═══════════════════════════════════════════════════════

class ValidationLevel(Enum):
    """
    3-level code validation:
    Level 1 → Syntax (AST, brackets, parse)
    Level 2 → Static Heuristics (regex patterns, anti-patterns)
    Level 3 → External Tools (ruff, bandit, eslint, pip-audit)
    """
    SYNTAX = 1
    HEURISTIC = 2
    EXTERNAL = 3


# ═══════════════════════════════════════════════════════
#  ENGINE NAMES (internal architecture terminology)
# ═══════════════════════════════════════════════════════

ENGINES = {
    "review_engine":     "Risk-Aware Review Engine",
    "planning_engine":   "Task Decomposition Engine",
    "execution_engine":  "Multi-Agent Execution Engine",
    "validation_engine": "Deterministic Validation Engine",
    "cost_engine":       "Budget-Aware Cost Engine",
    "memory_engine":     "Context Memory Engine",
    "approval_engine":   "Human-in-the-Loop Approval Engine",
    "routing_engine":    "Complexity-Aware Routing Engine",
}
