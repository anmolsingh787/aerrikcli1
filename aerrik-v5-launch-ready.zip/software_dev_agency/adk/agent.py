"""
🤖 aerrik ADK — Agent Primitive

An Agent is an autonomous worker with:
- A name and role
- Skills (knowledge domains)
- Tools (actions it can take)
- A system prompt
- Permission level
- Cost tracking

Agents run inside the Aerrik Runtime Loop.
"""
import uuid
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime


class AgentRole(Enum):
    ARCHITECT = "architect"
    PLANNER = "planner"
    FRONTEND = "frontend"
    BACKEND = "backend"
    DATABASE = "database"
    DEVOPS = "devops"
    TESTER = "tester"
    DESIGNER = "designer"
    MOBILE = "mobile"
    SECURITY = "security"
    REVIEWER = "reviewer"
    ADVISOR = "advisor"
    CUSTOM = "custom"


@dataclass
class AgentConfig:
    """Configuration for an agent"""
    name: str = ""
    role: AgentRole = AgentRole.CUSTOM
    model: str = "gpt-4o"
    temperature: float = 0.7
    max_tokens: int = 4096
    system_prompt: str = ""
    skills: List[str] = field(default_factory=list)
    can_delegate_to: List[str] = field(default_factory=list)
    permission_level: str = "moderate"  # safe, moderate, strict
    max_budget_usd: float = 1.0


class Agent:
    """
    🤖 Agent — Core ADK primitive.

    Usage:
        agent = Agent(
            name="frontend_dev",
            role=AgentRole.FRONTEND,
            skills=["frontend", "shadcn"],
            system_prompt="You are a senior React developer."
        )

        agent.add_tool(read_tool)
        agent.add_tool(write_tool)

        result = agent.run("Build a login page")
    """

    def __init__(
        self,
        name: str,
        role: AgentRole = AgentRole.CUSTOM,
        system_prompt: str = "",
        skills: List[str] = None,
        model: str = "gpt-4o",
        temperature: float = 0.7,
        max_tokens: int = 4096,
        permission_level: str = "moderate",
        max_budget_usd: float = 1.0,
        verbose: bool = True,
    ):
        self.id = f"agent_{uuid.uuid4().hex[:8]}"
        self.name = name
        self.role = role
        self.system_prompt = system_prompt
        self.skills = skills or []
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.permission_level = permission_level
        self.max_budget_usd = max_budget_usd
        self.verbose = verbose

        # Tools registry
        self._tools: Dict[str, Any] = {}

        # Handoffs (other agents this can delegate to)
        self._handoffs: Dict[str, 'Agent'] = {}

        # Loaded skill content
        self._skill_content: Dict[str, str] = {}

        # Runtime state
        self.is_busy = False
        self.current_task: Optional[str] = None
        self.tasks_completed: int = 0
        self.total_cost: float = 0.0

        # Config
        self.config = AgentConfig(
            name=name,
            role=role,
            model=model,
            temperature=temperature,
            max_tokens=max_tokens,
            system_prompt=system_prompt,
            skills=self.skills,
            permission_level=permission_level,
            max_budget_usd=max_budget_usd,
        )

    # ─── Tool Management ───────────────────────────────

    def add_tool(self, tool) -> 'Agent':
        """Add a tool to this agent"""
        if hasattr(tool, 'name'):
            self._tools[tool.name] = tool
        elif isinstance(tool, dict) and 'name' in tool:
            self._tools[tool['name']] = tool
        return self

    def remove_tool(self, name: str) -> 'Agent':
        """Remove a tool"""
        self._tools.pop(name, None)
        return self

    def get_tools(self) -> List[str]:
        """Get list of tool names"""
        return list(self._tools.keys())

    def has_tool(self, name: str) -> bool:
        return name in self._tools

    # ─── Handoff Management ────────────────────────────

    def add_handoff(self, agent: 'Agent') -> 'Agent':
        """Add a handoff target (agent to delegate to)"""
        self._handoffs[agent.name] = agent
        self.config.can_delegate_to.append(agent.name)
        return self

    def get_handoffs(self) -> Dict[str, 'Agent']:
        return self._handoffs

    # ─── Skill Management ──────────────────────────────

    def load_skill(self, name: str, content: str) -> 'Agent':
        """Load skill content"""
        self._skill_content[name] = content
        if name not in self.skills:
            self.skills.append(name)
        return self

    def get_skill_context(self) -> str:
        """Get all loaded skill content as context"""
        if not self._skill_content:
            return ""
        parts = []
        for name, content in self._skill_content.items():
            parts.append(f"## Skill: {name}\n{content[:2000]}")
        return "\n\n".join(parts)

    # ─── Execution ─────────────────────────────────────

    def run(self, task: str, context: str = "") -> str:
        """
        Execute a task using the agent runtime loop.

        This is the main entry point. The Aerrik Runtime handles
        the think → tool → result → think loop internally.
        """
        self.is_busy = True
        self.current_task = task

        if self.verbose:
            import sys
            sys.stderr.write(f"  🤖 [{self.name}] Starting: {task[:60]}...\n")

        try:
            # Build full prompt
            full_prompt = self._build_prompt(task, context)

            # The actual execution happens via the Runtime
            # This is a standalone fallback (mock mode)
            result = self._execute_standalone(full_prompt)

            self.tasks_completed += 1
            return result

        except Exception as e:
            if self.verbose:
                import sys
                sys.stderr.write(f"  ❌ [{self.name}] Error: {str(e)[:100]}\n")
            return f"Error: {str(e)}"

        finally:
            self.is_busy = False
            self.current_task = None

    def _build_prompt(self, task: str, context: str = "") -> str:
        """Build the full prompt with system + skills + context + task"""
        parts = []

        if self.system_prompt:
            parts.append(self.system_prompt)

        skill_ctx = self.get_skill_context()
        if skill_ctx:
            parts.append(skill_ctx)

        if context:
            parts.append(f"Context:\n{context}")

        parts.append(f"Task: {task}")

        return "\n\n".join(parts)

    def _execute_standalone(self, prompt: str) -> str:
        """Standalone execution without full runtime (mock/dev mode)"""
        return (
            f"[Agent: {self.name} | Model: {self.model}]\n"
            f"Processed task: {self.current_task[:100] if self.current_task else 'unknown'}\n"
            f"[Connect an LLM provider for real responses]"
        )

    # ─── Status ────────────────────────────────────────

    def get_status(self) -> Dict:
        """Get agent status"""
        return {
            "id": self.id,
            "name": self.name,
            "role": self.role.value,
            "model": self.model,
            "is_busy": self.is_busy,
            "current_task": self.current_task,
            "tasks_completed": self.tasks_completed,
            "total_cost": round(self.total_cost, 4),
            "tools": self.get_tools(),
            "handoffs": list(self._handoffs.keys()),
            "skills": self.skills,
            "permission_level": self.permission_level,
        }

    def __repr__(self):
        return f"<Agent: {self.name} ({self.role.value}) tools={len(self._tools)}>"

    def __str__(self):
        return self.name
